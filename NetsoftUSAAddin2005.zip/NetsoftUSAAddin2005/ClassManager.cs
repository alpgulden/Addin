using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;
using System.Text;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class ClassManager : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TabPage tabEntityes;
		private System.Windows.Forms.TabPage tabCollections;
		private System.Windows.Forms.TabControl tab;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button cmdCreateEntity;
		private System.Windows.Forms.Button cmdCreateCollectionClass;
		private System.Windows.Forms.Button cmdRefresh;
		private System.Windows.Forms.ListBox lsEntityes;
		private System.Windows.Forms.ListBox lsCollectionsForClass;
		private System.Windows.Forms.Button cmdBuildEntity;
		private System.Windows.Forms.Button cmdBuildCollectionForClass;
		private System.Windows.Forms.Button cmdShowFormBuilder;
		private System.Windows.Forms.CheckBox chkKeepOpen;
		private System.Windows.Forms.TabPage tabDataConnection;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button cmdConfigureConnection;
		private System.Windows.Forms.Label lbHelp;
		private System.Windows.Forms.TabPage tabLanguageClasses;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox lsLanguageClasses;
		private System.Windows.Forms.Button cmdCreateLanguageClass;
		private System.Windows.Forms.Button butBuildLangClass;
		private System.Windows.Forms.TabPage tabFindManage;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TabControl tabClassFeatures;
		private System.Windows.Forms.TabPage tabSPs;
		private System.Windows.Forms.ListBox lstSPs;
		private System.Windows.Forms.TextBox txtByBaseClass;
		private System.Windows.Forms.TextBox txtByAttribute;
		private System.Windows.Forms.ListBox lstClassesFound;
		private System.Windows.Forms.CheckBox chkRecreateSP;
		private System.Windows.Forms.Button butFindByBaseClass;
		private System.Windows.Forms.Button butFindByAttributes;
		private System.Windows.Forms.Button butCreateSelectedSPs;

		private StringBuilder strGenerationLog = null;
		private object[] classesFound = null;
		private string procsGenerated = null;
		private System.Windows.Forms.CheckBox chkPreviewOnly;
		private System.Windows.Forms.TabControl tabSearchFor;
		private System.Windows.Forms.TabPage tabByBaseClass;
		private System.Windows.Forms.TabPage tabByAttributes;
		private System.Windows.Forms.TabPage tabBySPTpl;
		private System.Windows.Forms.TextBox txtBySPTpl;
		private System.Windows.Forms.Button butFindBySPAndTpl;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtBySPName;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ClassManager()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ClassManager));
			this.lbHelp = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tab = new System.Windows.Forms.TabControl();
			this.tabEntityes = new System.Windows.Forms.TabPage();
			this.cmdBuildEntity = new System.Windows.Forms.Button();
			this.cmdCreateEntity = new System.Windows.Forms.Button();
			this.lsEntityes = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lsCollectionsForClass = new System.Windows.Forms.ListBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cmdCreateCollectionClass = new System.Windows.Forms.Button();
			this.cmdBuildCollectionForClass = new System.Windows.Forms.Button();
			this.cmdShowFormBuilder = new System.Windows.Forms.Button();
			this.tabFindManage = new System.Windows.Forms.TabPage();
			this.tabSearchFor = new System.Windows.Forms.TabControl();
			this.tabByBaseClass = new System.Windows.Forms.TabPage();
			this.txtByBaseClass = new System.Windows.Forms.TextBox();
			this.butFindByBaseClass = new System.Windows.Forms.Button();
			this.tabBySPTpl = new System.Windows.Forms.TabPage();
			this.txtBySPTpl = new System.Windows.Forms.TextBox();
			this.butFindBySPAndTpl = new System.Windows.Forms.Button();
			this.txtBySPName = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.tabByAttributes = new System.Windows.Forms.TabPage();
			this.butFindByAttributes = new System.Windows.Forms.Button();
			this.txtByAttribute = new System.Windows.Forms.TextBox();
			this.tabClassFeatures = new System.Windows.Forms.TabControl();
			this.tabSPs = new System.Windows.Forms.TabPage();
			this.butCreateSelectedSPs = new System.Windows.Forms.Button();
			this.lstSPs = new System.Windows.Forms.ListBox();
			this.chkPreviewOnly = new System.Windows.Forms.CheckBox();
			this.chkRecreateSP = new System.Windows.Forms.CheckBox();
			this.lstClassesFound = new System.Windows.Forms.ListBox();
			this.label5 = new System.Windows.Forms.Label();
			this.tabCollections = new System.Windows.Forms.TabPage();
			this.tabLanguageClasses = new System.Windows.Forms.TabPage();
			this.butBuildLangClass = new System.Windows.Forms.Button();
			this.cmdCreateLanguageClass = new System.Windows.Forms.Button();
			this.lsLanguageClasses = new System.Windows.Forms.ListBox();
			this.label2 = new System.Windows.Forms.Label();
			this.tabDataConnection = new System.Windows.Forms.TabPage();
			this.label4 = new System.Windows.Forms.Label();
			this.cmdConfigureConnection = new System.Windows.Forms.Button();
			this.cmdRefresh = new System.Windows.Forms.Button();
			this.chkKeepOpen = new System.Windows.Forms.CheckBox();
			this.tab.SuspendLayout();
			this.tabEntityes.SuspendLayout();
			this.tabFindManage.SuspendLayout();
			this.tabSearchFor.SuspendLayout();
			this.tabByBaseClass.SuspendLayout();
			this.tabBySPTpl.SuspendLayout();
			this.tabByAttributes.SuspendLayout();
			this.tabClassFeatures.SuspendLayout();
			this.tabSPs.SuspendLayout();
			this.tabLanguageClasses.SuspendLayout();
			this.tabDataConnection.SuspendLayout();
			this.SuspendLayout();
			// 
			// lbHelp
			// 
			this.lbHelp.Location = new System.Drawing.Point(160, 8);
			this.lbHelp.Name = "lbHelp";
			this.lbHelp.Size = new System.Drawing.Size(296, 72);
			this.lbHelp.TabIndex = 3;
			this.lbHelp.Text = "lbHelp";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(376, 328);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 1;
			this.butCancel.Text = "Close";
			this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// tab
			// 
			this.tab.Controls.Add(this.tabEntityes);
			this.tab.Controls.Add(this.tabFindManage);
			this.tab.Controls.Add(this.tabCollections);
			this.tab.Controls.Add(this.tabLanguageClasses);
			this.tab.Controls.Add(this.tabDataConnection);
			this.tab.Location = new System.Drawing.Point(16, 88);
			this.tab.Name = "tab";
			this.tab.SelectedIndex = 0;
			this.tab.Size = new System.Drawing.Size(432, 232);
			this.tab.TabIndex = 7;
			this.tab.SelectedIndexChanged += new System.EventHandler(this.tab_SelectedIndexChanged);
			// 
			// tabEntityes
			// 
			this.tabEntityes.Controls.Add(this.cmdBuildEntity);
			this.tabEntityes.Controls.Add(this.cmdCreateEntity);
			this.tabEntityes.Controls.Add(this.lsEntityes);
			this.tabEntityes.Controls.Add(this.label1);
			this.tabEntityes.Controls.Add(this.lsCollectionsForClass);
			this.tabEntityes.Controls.Add(this.label3);
			this.tabEntityes.Controls.Add(this.cmdCreateCollectionClass);
			this.tabEntityes.Controls.Add(this.cmdBuildCollectionForClass);
			this.tabEntityes.Controls.Add(this.cmdShowFormBuilder);
			this.tabEntityes.Location = new System.Drawing.Point(4, 22);
			this.tabEntityes.Name = "tabEntityes";
			this.tabEntityes.Size = new System.Drawing.Size(424, 206);
			this.tabEntityes.TabIndex = 0;
			this.tabEntityes.Text = "Entity Classes";
			this.tabEntityes.ToolTipText = "This page lists all the Entity Classes in this project.  When you click on a data c" +
				"lass, a list of all collection classes associated with this class is displayed o" +
				"n the right.";
			this.tabEntityes.Click += new System.EventHandler(this.tabEntityes_Click);
			// 
			// cmdBuildEntity
			// 
			this.cmdBuildEntity.Location = new System.Drawing.Point(80, 176);
			this.cmdBuildEntity.Name = "cmdBuildEntity";
			this.cmdBuildEntity.Size = new System.Drawing.Size(64, 23);
			this.cmdBuildEntity.TabIndex = 4;
			this.cmdBuildEntity.Text = "Build";
			this.cmdBuildEntity.Click += new System.EventHandler(this.cmdBuildEntity_Click);
			// 
			// cmdCreateEntity
			// 
			this.cmdCreateEntity.Location = new System.Drawing.Point(16, 176);
			this.cmdCreateEntity.Name = "cmdCreateEntity";
			this.cmdCreateEntity.Size = new System.Drawing.Size(64, 23);
			this.cmdCreateEntity.TabIndex = 3;
			this.cmdCreateEntity.Text = "Create";
			this.cmdCreateEntity.Click += new System.EventHandler(this.cmdCreateEntity_Click);
			// 
			// lsEntityes
			// 
			this.lsEntityes.Location = new System.Drawing.Point(16, 24);
			this.lsEntityes.Name = "lsEntityes";
			this.lsEntityes.Size = new System.Drawing.Size(192, 147);
			this.lsEntityes.TabIndex = 1;
			this.lsEntityes.DoubleClick += new System.EventHandler(this.lsEntityes_DoubleClick);
			this.lsEntityes.SelectedIndexChanged += new System.EventHandler(this.lsEntityes_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(176, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Entity Classes in This Project:";
			// 
			// lsCollectionsForClass
			// 
			this.lsCollectionsForClass.Location = new System.Drawing.Point(224, 24);
			this.lsCollectionsForClass.Name = "lsCollectionsForClass";
			this.lsCollectionsForClass.Size = new System.Drawing.Size(192, 147);
			this.lsCollectionsForClass.TabIndex = 1;
			this.lsCollectionsForClass.DoubleClick += new System.EventHandler(this.lsCollectionsForClass_DoubleClick);
			this.lsCollectionsForClass.SelectedIndexChanged += new System.EventHandler(this.lsCollectionsForClass_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(224, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(184, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "Collections of This Class:";
			// 
			// cmdCreateCollectionClass
			// 
			this.cmdCreateCollectionClass.Location = new System.Drawing.Point(224, 176);
			this.cmdCreateCollectionClass.Name = "cmdCreateCollectionClass";
			this.cmdCreateCollectionClass.Size = new System.Drawing.Size(64, 23);
			this.cmdCreateCollectionClass.TabIndex = 3;
			this.cmdCreateCollectionClass.Text = "Create";
			this.cmdCreateCollectionClass.Click += new System.EventHandler(this.cmdCreateCollectionClass_Click);
			// 
			// cmdBuildCollectionForClass
			// 
			this.cmdBuildCollectionForClass.Location = new System.Drawing.Point(288, 176);
			this.cmdBuildCollectionForClass.Name = "cmdBuildCollectionForClass";
			this.cmdBuildCollectionForClass.Size = new System.Drawing.Size(64, 23);
			this.cmdBuildCollectionForClass.TabIndex = 4;
			this.cmdBuildCollectionForClass.Text = "Build";
			this.cmdBuildCollectionForClass.Click += new System.EventHandler(this.cmdBuildCollectionForClass_Click);
			// 
			// cmdShowFormBuilder
			// 
			this.cmdShowFormBuilder.Location = new System.Drawing.Point(144, 176);
			this.cmdShowFormBuilder.Name = "cmdShowFormBuilder";
			this.cmdShowFormBuilder.Size = new System.Drawing.Size(64, 23);
			this.cmdShowFormBuilder.TabIndex = 4;
			this.cmdShowFormBuilder.Text = "BuildForm";
			this.cmdShowFormBuilder.Click += new System.EventHandler(this.cmdShowFormBuilder_Click);
			// 
			// tabFindManage
			// 
			this.tabFindManage.Controls.Add(this.tabSearchFor);
			this.tabFindManage.Controls.Add(this.tabClassFeatures);
			this.tabFindManage.Controls.Add(this.lstClassesFound);
			this.tabFindManage.Controls.Add(this.label5);
			this.tabFindManage.Location = new System.Drawing.Point(4, 22);
			this.tabFindManage.Name = "tabFindManage";
			this.tabFindManage.Size = new System.Drawing.Size(424, 206);
			this.tabFindManage.TabIndex = 4;
			this.tabFindManage.Text = "Find/Manage Classes";
			this.tabFindManage.ToolTipText = "This page allows you to search for classes in the project and perform batch opera" +
				"tions on the selected classes.";
			// 
			// tabSearchFor
			// 
			this.tabSearchFor.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
			this.tabSearchFor.Controls.Add(this.tabByBaseClass);
			this.tabSearchFor.Controls.Add(this.tabBySPTpl);
			this.tabSearchFor.Controls.Add(this.tabByAttributes);
			this.tabSearchFor.Location = new System.Drawing.Point(8, 0);
			this.tabSearchFor.Name = "tabSearchFor";
			this.tabSearchFor.SelectedIndex = 0;
			this.tabSearchFor.Size = new System.Drawing.Size(200, 64);
			this.tabSearchFor.TabIndex = 11;
			// 
			// tabByBaseClass
			// 
			this.tabByBaseClass.Controls.Add(this.txtByBaseClass);
			this.tabByBaseClass.Controls.Add(this.butFindByBaseClass);
			this.tabByBaseClass.Location = new System.Drawing.Point(4, 25);
			this.tabByBaseClass.Name = "tabByBaseClass";
			this.tabByBaseClass.Size = new System.Drawing.Size(192, 35);
			this.tabByBaseClass.TabIndex = 0;
			this.tabByBaseClass.Text = "By Base Class";
			// 
			// txtByBaseClass
			// 
			this.txtByBaseClass.Location = new System.Drawing.Point(8, 8);
			this.txtByBaseClass.Name = "txtByBaseClass";
			this.txtByBaseClass.Size = new System.Drawing.Size(128, 20);
			this.txtByBaseClass.TabIndex = 0;
			this.txtByBaseClass.Text = "";
			// 
			// butFindByBaseClass
			// 
			this.butFindByBaseClass.Location = new System.Drawing.Point(144, 8);
			this.butFindByBaseClass.Name = "butFindByBaseClass";
			this.butFindByBaseClass.Size = new System.Drawing.Size(40, 22);
			this.butFindByBaseClass.TabIndex = 1;
			this.butFindByBaseClass.Text = "Find";
			this.butFindByBaseClass.Click += new System.EventHandler(this.butFindByBaseClass_Click);
			// 
			// tabBySPTpl
			// 
			this.tabBySPTpl.Controls.Add(this.txtBySPTpl);
			this.tabBySPTpl.Controls.Add(this.butFindBySPAndTpl);
			this.tabBySPTpl.Controls.Add(this.txtBySPName);
			this.tabBySPTpl.Controls.Add(this.label6);
			this.tabBySPTpl.Controls.Add(this.label7);
			this.tabBySPTpl.Location = new System.Drawing.Point(4, 25);
			this.tabBySPTpl.Name = "tabBySPTpl";
			this.tabBySPTpl.Size = new System.Drawing.Size(192, 35);
			this.tabBySPTpl.TabIndex = 2;
			this.tabBySPTpl.Text = "By SP/Tpl";
			// 
			// txtBySPTpl
			// 
			this.txtBySPTpl.Location = new System.Drawing.Point(20, 6);
			this.txtBySPTpl.Name = "txtBySPTpl";
			this.txtBySPTpl.Size = new System.Drawing.Size(50, 20);
			this.txtBySPTpl.TabIndex = 2;
			this.txtBySPTpl.Text = "";
			// 
			// butFindBySPAndTpl
			// 
			this.butFindBySPAndTpl.Location = new System.Drawing.Point(144, 6);
			this.butFindBySPAndTpl.Name = "butFindBySPAndTpl";
			this.butFindBySPAndTpl.Size = new System.Drawing.Size(40, 22);
			this.butFindBySPAndTpl.TabIndex = 3;
			this.butFindBySPAndTpl.Text = "Find";
			this.butFindBySPAndTpl.Click += new System.EventHandler(this.butFindBySPAndTpl_Click);
			// 
			// txtBySPName
			// 
			this.txtBySPName.Location = new System.Drawing.Point(90, 6);
			this.txtBySPName.Name = "txtBySPName";
			this.txtBySPName.Size = new System.Drawing.Size(50, 20);
			this.txtBySPName.TabIndex = 2;
			this.txtBySPName.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(0, 8);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(32, 23);
			this.label6.TabIndex = 4;
			this.label6.Text = "Tpl:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(69, 8);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(32, 23);
			this.label7.TabIndex = 4;
			this.label7.Text = "SP:";
			// 
			// tabByAttributes
			// 
			this.tabByAttributes.Controls.Add(this.butFindByAttributes);
			this.tabByAttributes.Controls.Add(this.txtByAttribute);
			this.tabByAttributes.Location = new System.Drawing.Point(4, 25);
			this.tabByAttributes.Name = "tabByAttributes";
			this.tabByAttributes.Size = new System.Drawing.Size(192, 35);
			this.tabByAttributes.TabIndex = 1;
			this.tabByAttributes.Text = "By Attributes";
			// 
			// butFindByAttributes
			// 
			this.butFindByAttributes.Location = new System.Drawing.Point(144, 8);
			this.butFindByAttributes.Name = "butFindByAttributes";
			this.butFindByAttributes.Size = new System.Drawing.Size(40, 20);
			this.butFindByAttributes.TabIndex = 3;
			this.butFindByAttributes.Text = "Find";
			this.butFindByAttributes.Click += new System.EventHandler(this.butFindByAttributes_Click);
			// 
			// txtByAttribute
			// 
			this.txtByAttribute.Location = new System.Drawing.Point(8, 8);
			this.txtByAttribute.Name = "txtByAttribute";
			this.txtByAttribute.Size = new System.Drawing.Size(128, 20);
			this.txtByAttribute.TabIndex = 2;
			this.txtByAttribute.Text = "";
			// 
			// tabClassFeatures
			// 
			this.tabClassFeatures.Controls.Add(this.tabSPs);
			this.tabClassFeatures.Location = new System.Drawing.Point(208, 8);
			this.tabClassFeatures.Name = "tabClassFeatures";
			this.tabClassFeatures.SelectedIndex = 0;
			this.tabClassFeatures.Size = new System.Drawing.Size(216, 192);
			this.tabClassFeatures.TabIndex = 10;
			// 
			// tabSPs
			// 
			this.tabSPs.Controls.Add(this.butCreateSelectedSPs);
			this.tabSPs.Controls.Add(this.lstSPs);
			this.tabSPs.Controls.Add(this.chkPreviewOnly);
			this.tabSPs.Controls.Add(this.chkRecreateSP);
			this.tabSPs.Location = new System.Drawing.Point(4, 22);
			this.tabSPs.Name = "tabSPs";
			this.tabSPs.Size = new System.Drawing.Size(208, 166);
			this.tabSPs.TabIndex = 0;
			this.tabSPs.Text = "SPs";
			// 
			// butCreateSelectedSPs
			// 
			this.butCreateSelectedSPs.Location = new System.Drawing.Point(0, 144);
			this.butCreateSelectedSPs.Name = "butCreateSelectedSPs";
			this.butCreateSelectedSPs.Size = new System.Drawing.Size(72, 23);
			this.butCreateSelectedSPs.TabIndex = 1;
			this.butCreateSelectedSPs.Text = "Create SPs";
			this.butCreateSelectedSPs.Click += new System.EventHandler(this.butCreateSelectedSPs_Click);
			// 
			// lstSPs
			// 
			this.lstSPs.Location = new System.Drawing.Point(0, 0);
			this.lstSPs.Name = "lstSPs";
			this.lstSPs.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.lstSPs.Size = new System.Drawing.Size(208, 147);
			this.lstSPs.TabIndex = 0;
			// 
			// chkPreviewOnly
			// 
			this.chkPreviewOnly.Location = new System.Drawing.Point(144, 144);
			this.chkPreviewOnly.Name = "chkPreviewOnly";
			this.chkPreviewOnly.Size = new System.Drawing.Size(72, 24);
			this.chkPreviewOnly.TabIndex = 2;
			this.chkPreviewOnly.Text = "Preview";
			// 
			// chkRecreateSP
			// 
			this.chkRecreateSP.Location = new System.Drawing.Point(72, 144);
			this.chkRecreateSP.Name = "chkRecreateSP";
			this.chkRecreateSP.Size = new System.Drawing.Size(80, 24);
			this.chkRecreateSP.TabIndex = 2;
			this.chkRecreateSP.Text = "Recreate";
			// 
			// lstClassesFound
			// 
			this.lstClassesFound.IntegralHeight = false;
			this.lstClassesFound.Location = new System.Drawing.Point(8, 64);
			this.lstClassesFound.Name = "lstClassesFound";
			this.lstClassesFound.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.lstClassesFound.Size = new System.Drawing.Size(200, 136);
			this.lstClassesFound.TabIndex = 4;
			this.lstClassesFound.SelectedIndexChanged += new System.EventHandler(this.lstClassesFound_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 42);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(176, 23);
			this.label5.TabIndex = 4;
			this.label5.Text = "Classes found:";
			// 
			// tabCollections
			// 
			this.tabCollections.Location = new System.Drawing.Point(4, 22);
			this.tabCollections.Name = "tabCollections";
			this.tabCollections.Size = new System.Drawing.Size(424, 206);
			this.tabCollections.TabIndex = 1;
			this.tabCollections.Text = "Colections";
			this.tabCollections.ToolTipText = "This page will display all collections in this project.";
			// 
			// tabLanguageClasses
			// 
			this.tabLanguageClasses.Controls.Add(this.butBuildLangClass);
			this.tabLanguageClasses.Controls.Add(this.cmdCreateLanguageClass);
			this.tabLanguageClasses.Controls.Add(this.lsLanguageClasses);
			this.tabLanguageClasses.Controls.Add(this.label2);
			this.tabLanguageClasses.Location = new System.Drawing.Point(4, 22);
			this.tabLanguageClasses.Name = "tabLanguageClasses";
			this.tabLanguageClasses.Size = new System.Drawing.Size(424, 206);
			this.tabLanguageClasses.TabIndex = 3;
			this.tabLanguageClasses.Text = "Language Classes";
			this.tabLanguageClasses.ToolTipText = "The language classes derived from NetsoftUSA.Model.Language.  These classes d" +
				"efine messages on their members and provide translation functionality.";
			// 
			// butBuildLangClass
			// 
			this.butBuildLangClass.Location = new System.Drawing.Point(264, 168);
			this.butBuildLangClass.Name = "butBuildLangClass";
			this.butBuildLangClass.TabIndex = 4;
			this.butBuildLangClass.Text = "Build";
			this.butBuildLangClass.Click += new System.EventHandler(this.butBuildLangClass_Click);
			// 
			// cmdCreateLanguageClass
			// 
			this.cmdCreateLanguageClass.Location = new System.Drawing.Point(336, 168);
			this.cmdCreateLanguageClass.Name = "cmdCreateLanguageClass";
			this.cmdCreateLanguageClass.TabIndex = 3;
			this.cmdCreateLanguageClass.Text = "Create";
			this.cmdCreateLanguageClass.Click += new System.EventHandler(this.cmdCreateLanguageClass_Click);
			// 
			// lsLanguageClasses
			// 
			this.lsLanguageClasses.Location = new System.Drawing.Point(16, 24);
			this.lsLanguageClasses.Name = "lsLanguageClasses";
			this.lsLanguageClasses.Size = new System.Drawing.Size(192, 160);
			this.lsLanguageClasses.TabIndex = 2;
			this.lsLanguageClasses.DoubleClick += new System.EventHandler(this.lsLanguageClasses_DoubleClick);
			this.lsLanguageClasses.SelectedIndexChanged += new System.EventHandler(this.lsLanguageClasses_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(184, 23);
			this.label2.TabIndex = 0;
			this.label2.Text = "Language Classes:";
			// 
			// tabDataConnection
			// 
			this.tabDataConnection.Controls.Add(this.label4);
			this.tabDataConnection.Controls.Add(this.cmdConfigureConnection);
			this.tabDataConnection.Location = new System.Drawing.Point(4, 22);
			this.tabDataConnection.Name = "tabDataConnection";
			this.tabDataConnection.Size = new System.Drawing.Size(424, 206);
			this.tabDataConnection.TabIndex = 2;
			this.tabDataConnection.Text = "Data Connection";
			this.tabDataConnection.ToolTipText = "Data connection for the project";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(64, 32);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(312, 56);
			this.label4.TabIndex = 1;
			this.label4.Text = "The data connection is specific to this project and it is kept in the NetsoftUSAA" +
				"ddinConnect.udl file in the folder of a Entity Class.  Normally this folder is the" +
				" project folder.  Here you can configure the connection.";
			// 
			// cmdConfigureConnection
			// 
			this.cmdConfigureConnection.Location = new System.Drawing.Point(168, 112);
			this.cmdConfigureConnection.Name = "cmdConfigureConnection";
			this.cmdConfigureConnection.TabIndex = 0;
			this.cmdConfigureConnection.Text = "Connection";
			this.cmdConfigureConnection.Click += new System.EventHandler(this.cmdConfigureConnection_Click);
			// 
			// cmdRefresh
			// 
			this.cmdRefresh.Location = new System.Drawing.Point(296, 328);
			this.cmdRefresh.Name = "cmdRefresh";
			this.cmdRefresh.TabIndex = 0;
			this.cmdRefresh.Text = "Refresh";
			this.cmdRefresh.Click += new System.EventHandler(this.cmdRefresh_Click);
			// 
			// chkKeepOpen
			// 
			this.chkKeepOpen.Checked = true;
			this.chkKeepOpen.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkKeepOpen.Location = new System.Drawing.Point(32, 328);
			this.chkKeepOpen.Name = "chkKeepOpen";
			this.chkKeepOpen.TabIndex = 9;
			this.chkKeepOpen.Text = "Keep Open";
			this.chkKeepOpen.CheckedChanged += new System.EventHandler(this.chkKeepOpen_CheckedChanged);
			// 
			// ClassManager
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(466, 360);
			this.Controls.Add(this.chkKeepOpen);
			this.Controls.Add(this.cmdRefresh);
			this.Controls.Add(this.tab);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.lbHelp);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Name = "ClassManager";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Class Manager";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.tab.ResumeLayout(false);
			this.tabEntityes.ResumeLayout(false);
			this.tabFindManage.ResumeLayout(false);
			this.tabSearchFor.ResumeLayout(false);
			this.tabByBaseClass.ResumeLayout(false);
			this.tabBySPTpl.ResumeLayout(false);
			this.tabByAttributes.ResumeLayout(false);
			this.tabClassFeatures.ResumeLayout(false);
			this.tabSPs.ResumeLayout(false);
			this.tabLanguageClasses.ResumeLayout(false);
			this.tabDataConnection.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public static void Manage()
		{
			ClassManager clsMng = new ClassManager();
			clsMng.Show();
		}

		private void SetHelp()
		{
			lbHelp.Text = tab.SelectedTab.ToolTipText;
		}

		private void EnableButtons()
		{
			cmdBuildEntity.Enabled = lsEntityes.SelectedItem != null;
			cmdShowFormBuilder.Enabled = lsEntityes.SelectedItem != null;
			cmdCreateCollectionClass.Enabled = lsEntityes.SelectedItem != null;
			cmdBuildCollectionForClass.Enabled = lsCollectionsForClass.SelectedItem != null;
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			SetHelp();
			chkKeepOpen.Checked = Util.GetSetting("__ClassManager", "KeepOpen", chkKeepOpen.Checked);
			FillLists();
		}

		private void cmdRefresh_Click(object sender, System.EventArgs e)
		{
			FillLists();
		}

		private void FillLists()
		{
			FillEntityes();
			FillCollectionsForEntity();
			FillLanguageClasses();
			EnableButtons();
		}

		private string SelectedEntity
		{
			get
			{
				if (lsEntityes.SelectedItem != null)
					return (string)lsEntityes.SelectedItem;
				return null;
			}
		}

		private string SelectedLanguageClass
		{
			get
			{
				if (lsLanguageClasses.SelectedItem != null)
					return (string)lsLanguageClasses.SelectedItem;
				return null;
			}
		}

		private string SelectedCollectionForClass
		{
			get
			{
				if (lsCollectionsForClass.SelectedItem != null)
					return (string)lsCollectionsForClass.SelectedItem;
				return null;
			}
		}

		private void FillEntityes()
		{
			object[] classes = Util.FindEntityesInProject();
			Util.FillClassNames(lsEntityes, classes, true);
		}

		private void FillCollectionsForEntity()
		{
			string selClass = this.SelectedEntity;
			lsCollectionsForClass.Items.Clear();
			if (selClass != null)
			{
				object[] classes = Util.FindCollectionClassesInProject(null, selClass);
				Util.FillClassNames(lsCollectionsForClass, classes, true);
			}
		}

		private void FillLanguageClasses()
		{
			object[] classes = Util.FindClassesWithBaseInProject("Language");
			Util.FillClassNames(lsLanguageClasses, classes, true);
		}

		private void lsEntityes_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Util.ShowClass(this.SelectedEntity);
			FillCollectionsForEntity();
			EnableButtons();
		}

		private void lsCollectionsForClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Util.ShowClass(this.SelectedCollectionForClass);
			EnableButtons();
		}

		private void cmdCreateEntity_Click(object sender, System.EventArgs e)
		{
			if (!chkKeepOpen.Checked)
				this.Close();
			else
				this.Hide();
			EntityCreator.CreateEntity();
			if (chkKeepOpen.Checked)
				this.Show();
			FillLists();
		}

		private void cmdBuildEntity_Click(object sender, System.EventArgs e)
		{
			CodeClass cls = Util.FindClassInProject(this.SelectedEntity);
			if (cls != null)
			{
				if (!chkKeepOpen.Checked)
					this.Close();
				EntityBuilder.BuildClass(cls);
			}
		}

		private void cmdBuildCollectionForClass_Click(object sender, System.EventArgs e)
		{
			CodeClass cls = Util.FindClassInProject(this.SelectedCollectionForClass);
			if (cls != null)
			{
				if (!chkKeepOpen.Checked)
					this.Close();
				CollectionClassBuilder.BuildCollectionClass(cls);
			}
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cmdCreateCollectionClass_Click(object sender, System.EventArgs e)
		{
			CodeClass cls = Util.FindClassInProject(this.SelectedEntity);
			if (cls != null)
			{
				if (!chkKeepOpen.Checked)
					this.Close();
				else
					this.Hide();
				CollectionClassCreator.CreateCollectionClass(cls);
				if (chkKeepOpen.Checked)
					this.Show();
				FillCollectionsForEntity();
				EnableButtons();
			}
		}

		private void tabEntityes_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lsEntityes_DoubleClick(object sender, System.EventArgs e)
		{
			cmdBuildEntity_Click(sender, e);
		}

		private void lsCollectionsForClass_DoubleClick(object sender, System.EventArgs e)
		{
			cmdBuildCollectionForClass_Click(sender, e);
		}

		private void cmdShowFormBuilder_Click(object sender, System.EventArgs e)
		{
			CodeClass cls = Util.FindClassInProject(this.SelectedEntity);
			if (cls != null)
			{
				if (!chkKeepOpen.Checked)
					this.Close();
				WebFormBuilder.BuildWebForm(cls);
			}
		}

		private void chkKeepOpen_CheckedChanged(object sender, System.EventArgs e)
		{
			Util.SetSetting("__ClassManager", "KeepOpen", chkKeepOpen.Checked);
		}

		private void cmdConfigureConnection_Click(object sender, System.EventArgs e)
		{
			string file = Util.ProjectConnectionString;
			this.Close();
			System.Diagnostics.Process.Start(file);
		}

		private void tab_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetHelp();
		}

		private void cmdCreateLanguageClass_Click(object sender, System.EventArgs e)
		{
			if (!chkKeepOpen.Checked)
				this.Close();
			else
				this.Hide();
			LanguageClassCreator.CreateLanguageClass();
			if (chkKeepOpen.Checked)
				this.Show();
			FillLanguageClasses();
		}

		private void lsLanguageClasses_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Util.ShowClass(this.SelectedLanguageClass);
		}

		private void butBuildLangClass_Click(object sender, System.EventArgs e)
		{
			CodeClass cls = Util.FindClassInProject(this.SelectedLanguageClass);
			if (cls != null)
			{
				if (!chkKeepOpen.Checked)
					this.Close();
				LanguageClassBuilder.BuildLanguageClass(cls);
			}
		}

		private void lsLanguageClasses_DoubleClick(object sender, System.EventArgs e)
		{
			butBuildLangClass_Click(sender, e);
		}

		/// <summary>
		/// Find all the SP attributes for the classes in the lstClassesFound list
		/// </summary>
		private void FindSPAttribsForClasses()
		{
			lstSPs.Items.Clear();
			Hashtable foundSPs = new Hashtable();

			if (classesFound == null)
				return;

			for (int i = 0; i < classesFound.Length; i++)
			{
				CodeClass cls = (CodeClass)classesFound[i];
				string className = cls.Name;

				if (cls == null)
				{
					if (Connect.Instance.ShowDialog(this, "Class " + className + " not found!", "SP batch generation", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
						return;
				}
				else
				{
					// add the found sps
					ArrayList arr = Util.GetSPAutoGenAttributes(cls);
					for (int j = 0; j < arr.Count; j++)
					{
						CodeAttribute att = arr[j] as CodeAttribute;
						if (att != null)
						{
							string tplKey = Util.GetParamFromAttrib(att, null, 1);
							if (!foundSPs.ContainsKey(tplKey))		// check if already added to hashtable
							{
								foundSPs[tplKey] = tplKey;		// just add to hashtable
							}
						}
					}
					Util.NAR(cls);
				}

			}

			// fill the found sps to the list
			foreach (DictionaryEntry de in foundSPs)
			{
				lstSPs.Items.Add(de.Key);
			}

			foreach (object o in classesFound)
				Util.NAR(o);
			classesFound = null;
		}

		private void butFindByBaseClass_Click(object sender, System.EventArgs e)
		{
			lstClassesFound.Items.Clear();
			lstSPs.Items.Clear();
			string baseClass = txtByBaseClass.Text.Trim();
			if (baseClass == "")
				return;
			object[] classes = Util.FindClassesWithBaseInProject(txtByBaseClass.Text);
			this.classesFound = classes;
			if (classes == null)
				return;

			Util.FillClassNames(lstClassesFound, classes, true);

			FindSPAttribsForClasses();
		}

		private void butFindByAttributes_Click(object sender, System.EventArgs e)
		{
			lstClassesFound.Items.Clear();
			lstSPs.Items.Clear();
			string attributes = txtByAttribute.Text.Trim();
			if (attributes == "")
				return;
			string[] attribs = attributes.Split(',');
			object[] classes = Util.FindClassesWithAttribsInProject(attribs);
			this.classesFound = classes;
			if (classes == null)
				return;
			Util.FillClassNames(lstClassesFound, classes, true);

			FindSPAttribsForClasses();
		}

		private void butFindBySPAndTpl_Click(object sender, System.EventArgs e)
		{
			lstClassesFound.Items.Clear();
			lstSPs.Items.Clear();
			string spTpl = txtBySPTpl.Text.Trim();
			string spName = txtBySPName.Text.Trim();
			object[] classes = Util.FindClassesWithSPTemplateAndSPName(spTpl, spName);
			this.classesFound = classes;
			if (classes == null)
				return;
			Util.FillClassNames(lstClassesFound, classes, true);

			FindSPAttribsForClasses();
		}

		private void lstClassesFound_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Util.ShowClass( (string)lstClassesFound.SelectedItem );
		}

		private bool GenerateAllSPForAttrib(CodeClass cls, CodeAttribute att)
		{
			string sp = null, tpl = null, args = null, manuallyManaged = null;
			SPGenerationInjections injections = null;
			Util.GetSPAutoDeclAttribValues(att, ref sp, ref tpl, ref args, ref injections, ref manuallyManaged);

			if (manuallyManaged == "true")
			{
				//string err = String.Format("Manually managed sp  '{1}' is skipped!", sp);
				//errorMsgs += "\r\n\r\n" + err;
				//AddWarningMsgToShowSP("/* " + err + " */\r\n");
				return true;	// just skip
			}

			string projPath = cls.ProjectItem.ContainingProject.FullName;
			projPath = Path.GetDirectoryName(projPath);
			string spTemplatesPath = projPath + @"\SPTemplates";

			StoredProcTemplate spTpl = StoredProcTemplate.GetSPTemplate(spTemplatesPath, tpl);
			if (spTpl == null)
			{
				// template not found
				if (Connect.Instance.ShowDialog(this, 
					String.Format("Procedure template {0} used by {1} not found!", tpl, sp), "SP batch generation", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
					return false;
				else
					return true;
			}
			else
			{
				// template found
				Hashtable templateMap = StoredProcTemplate.GetSPTemplateMap(spTemplatesPath);
				ArrayList arrReferredArgs = new ArrayList();
				TemplatedProcGenerator generator = new TemplatedProcGenerator(cls, templateMap, spTpl, sp, args, injections, arrReferredArgs);
				string sproc = generator.GenerateSP();
				if (generator.ParseError || generator.GenerationError)
				{
					if (Connect.Instance.ShowDialog(this, "Templated stored procedure generation error sp " + sproc + " of class " + cls.Name + "\r\n" + generator.ErrorString, "SP batch generation", MessageBoxButtons.OKCancel ) == DialogResult.Cancel)
						return false;
				}
				else
				{
					if (strGenerationLog != null)
					{
						strGenerationLog.Append("\r\n\r\n");
						strGenerationLog.Append(sproc);
					}
					if (!chkPreviewOnly.Checked)
					{
						if (Util.SetStoredProcOnDB(this, sp, sproc, chkRecreateSP.Checked, false))
							procsGenerated += "\r\n" + sp;
					}
					else
						procsGenerated += "\r\n" + sp;
				}
			}

			return true;
		}

		private bool GenerateAllSPsForClass(string className)
		{
			CodeClass cls = Util.FindClassInProject(className);
			if (cls == null)
			{
				if (Connect.Instance.ShowDialog(this, "Class " + className + " not found!", "SP batch generation", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
					return false;
			}
			else
			{
				// Walk on the SPs and try to create the sp if this class has a declaration
				for (int i = 0; i < lstSPs.SelectedItems.Count; i++)
				{
					string spTpl = (string)lstSPs.SelectedItems[i];
					ArrayList spAutoGenAttribs = Util.GetSPAutoDeclAttribForTemplate(cls, spTpl);
					if (spAutoGenAttribs != null)
					{
						foreach (CodeAttribute att in spAutoGenAttribs)
							if (!GenerateAllSPForAttrib(cls, att))
								return false;
					}
				}
				Util.NAR(cls);
			}
			return true;
		}

		// Create all selected SPs for all classes
		private void butCreateSelectedSPs_Click(object sender, System.EventArgs e)
		{
			if (lstClassesFound.SelectedItems.Count == 0)
			{
				Connect.Instance.ShowDialog(this, "No classes selected", "SP batch generation", MessageBoxButtons.OKCancel);
				return;
			}

			if (lstSPs.SelectedItems.Count == 0)
			{
				Connect.Instance.ShowDialog(this, "No SPs selected", "SP batch generation", MessageBoxButtons.OKCancel);
				return;
			}

			string msgOp = null, msgNote = null;

			if (chkPreviewOnly.Checked) 
				msgOp = "Generate a preview of all selected SPs for all selected classes?";
			else
				msgOp = "Create all selected SPs for all selected classes?";

			if (chkRecreateSP.Checked)
				msgNote = " (Existing SPs will also be processed)";
			else
				msgNote = " (Existing SPs will be ignored)";

			if ( Connect.Instance.ShowDialog(this, msgOp + msgNote, "SP batch generation", MessageBoxButtons.OKCancel) != DialogResult.OK )
				return;

			if (!chkPreviewOnly.Checked && chkRecreateSP.Checked)
				if ( Connect.Instance.ShowDialog(this, "WARNING: This will 'overwrite' existing SPs.  Please confirm to continue..", "SP batch generation", MessageBoxButtons.OKCancel ) != DialogResult.OK )
					return;

			strGenerationLog = new StringBuilder();
			procsGenerated = null;

			for (int i = 0; i < lstClassesFound.SelectedItems.Count; i++)
			{
				string className = (string)lstClassesFound.SelectedItems[i];

				// Create all sps
				if (!GenerateAllSPsForClass(className))
					break;
			}

			if (procsGenerated != null)
			{
				Connect.Instance.ShowDialog(this, procsGenerated);

				string str = strGenerationLog.ToString();
				if (str != null)
				{
					string s = "/* Stored Procedures Generated: \r\n\r\n" + procsGenerated + " \r\n*/\r\n\r\n"
						+ str.ToString();
					string fileName = Util.ProjectPath + "\\CreateSPs.sql";
					StreamWriter sw = File.CreateText(fileName);
					sw.Write(s);
					sw.Close();
					System.Diagnostics.Process.Start("NotePad.exe", fileName);
				}
			}
			else
				Connect.Instance.ShowDialog(this, "No stored procedures have been created.\r\n", "Templated stored procedure generation");

		}

		


	}
}
