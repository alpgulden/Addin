using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for CollectionLookupMethodCreator.
	/// </summary>
	public class CollectionValueLookupMethodOptions : System.Windows.Forms.Form
	{
		//private CodeClass elementCls;
		private CodeClass elemCls;
		private ValueLookupOptions options;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.ComboBox cbMemberToReturn;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtMethodName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CollectionValueLookupMethodOptions ()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CollectionValueLookupMethodOptions));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cbMemberToReturn = new System.Windows.Forms.ComboBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtMethodName = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(240, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select a member to lookup and a member to return.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 144);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 144);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 72);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(160, 24);
			this.label4.TabIndex = 0;
			this.label4.Text = "Member to return after lookup:";
			// 
			// cbMemberToReturn
			// 
			this.cbMemberToReturn.Location = new System.Drawing.Point(160, 72);
			this.cbMemberToReturn.Name = "cbMemberToReturn";
			this.cbMemberToReturn.Size = new System.Drawing.Size(232, 21);
			this.cbMemberToReturn.TabIndex = 2;
			this.cbMemberToReturn.TextChanged += new System.EventHandler(this.cbMemberToReturn_TextChanged);
			this.cbMemberToReturn.SelectedIndexChanged += new System.EventHandler(this.cbMemberToReturn_SelectedIndexChanged);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(8, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(16, 16);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 21;
			this.pictureBox2.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 96);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 23;
			this.label1.Text = "Method Name:";
			// 
			// txtMethodName
			// 
			this.txtMethodName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMethodName.Location = new System.Drawing.Point(160, 96);
			this.txtMethodName.Name = "txtMethodName";
			this.txtMethodName.Size = new System.Drawing.Size(232, 20);
			this.txtMethodName.TabIndex = 22;
			this.txtMethodName.Text = "";
			// 
			// CollectionValueLookupMethodOptions
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(402, 175);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtMethodName);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbMemberToReturn);
			this.Controls.Add(this.label4);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CollectionValueLookupMethodOptions";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Collection Value Lookup Method Options";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.ChildMemberCreator_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void EnableButtons()
		{
			butCreate.Enabled = 
				txtMethodName.Text != "" &&
				cbMemberToReturn.Text != "";
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				options.MethodName = txtMethodName.Text;
				options.MemberToReturn = cbMemberToReturn.Text;

				DialogResult = DialogResult.OK;
				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void FillMembersInCombo()
		{
			cbMemberToReturn.Items.Clear();
			FillMembersInCombo(elemCls);
		}

		private void FillMembersInCombo(CodeClass elemCls)
		{
			for (int i = 1; i <= elemCls.Members.Count; i++)
			{
				CodeProperty prop = elemCls.Members.Item(i) as CodeProperty;
				if (prop != null)
					cbMemberToReturn.Items.Add(prop.Name);
			}

			if (elemCls.Bases != null)
			{
				for (int i = 1; i <= elemCls.Bases.Count; i++)
					FillMembersInCombo(elemCls.Bases.Item(i) as CodeClass);
			}
		}

		private void ChildMemberCreator_Load(object sender, System.EventArgs e)
		{
			FillMembersInCombo();
			cbMemberToReturn.Text = options.MemberToReturn;
			MakeMethodName();
			EnableButtons();
		}

		private void MakeMethodName()
		{
			txtMethodName.Text = "Lookup_" + cbMemberToReturn.Text + "By" + options.RootName;
		}

		public static bool Display(CodeClass elemCls, ValueLookupOptions options)
		{
			CollectionValueLookupMethodOptions cvl = new CollectionValueLookupMethodOptions();
			cvl.elemCls = elemCls;
			cvl.options = options;
			if (cvl.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void cbMemberToReturn_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			MakeMethodName();
			EnableButtons();
		}

		private void cbMemberToReturn_TextChanged(object sender, System.EventArgs e)
		{
			MakeMethodName();
			EnableButtons(); 
		}

	}

	public class ValueLookupOptions
	{
		public string MethodName = null;
		public string RootName = null;
		public string MemberToReturn = null;
	}
}
