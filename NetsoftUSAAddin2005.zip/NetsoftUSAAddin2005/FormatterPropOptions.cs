using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for FormatterPropOptions.
	/// </summary>
	public class FormatterPropOptions : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbFormatterKind;
		private System.Windows.Forms.CheckBox chkSet;
		private System.Windows.Forms.CheckBox chkGet;
		private System.Windows.Forms.CheckBox chkMapperProperty;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FormatterPropOptions()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormatterPropOptions));
			this.label1 = new System.Windows.Forms.Label();
			this.cbFormatterKind = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.chkSet = new System.Windows.Forms.CheckBox();
			this.chkGet = new System.Windows.Forms.CheckBox();
			this.chkMapperProperty = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Formatter Kind:";
			// 
			// cbFormatterKind
			// 
			this.cbFormatterKind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFormatterKind.Location = new System.Drawing.Point(136, 80);
			this.cbFormatterKind.Name = "cbFormatterKind";
			this.cbFormatterKind.Size = new System.Drawing.Size(248, 21);
			this.cbFormatterKind.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(224, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Select build options to be used for formatter properties.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 184);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.butCreate.Location = new System.Drawing.Point(224, 184);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// chkSet
			// 
			this.chkSet.Checked = true;
			this.chkSet.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkSet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkSet.Location = new System.Drawing.Point(240, 104);
			this.chkSet.Name = "chkSet";
			this.chkSet.TabIndex = 7;
			this.chkSet.Text = "Set";
			// 
			// chkGet
			// 
			this.chkGet.Checked = true;
			this.chkGet.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkGet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkGet.Location = new System.Drawing.Point(136, 104);
			this.chkGet.Name = "chkGet";
			this.chkGet.TabIndex = 8;
			this.chkGet.Text = "Get";
			// 
			// chkMapperProperty
			// 
			this.chkMapperProperty.Location = new System.Drawing.Point(136, 152);
			this.chkMapperProperty.Name = "chkMapperProperty";
			this.chkMapperProperty.Size = new System.Drawing.Size(192, 24);
			this.chkMapperProperty.TabIndex = 9;
			this.chkMapperProperty.Text = "Mapper Property";
			this.chkMapperProperty.CheckedChanged += new System.EventHandler(this.chkMapperProperty_CheckedChanged);
			// 
			// FormatterPropOptions
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(394, 215);
			this.Controls.Add(this.chkMapperProperty);
			this.Controls.Add(this.chkGet);
			this.Controls.Add(this.chkSet);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbFormatterKind);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FormatterPropOptions";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Formatter Property Options";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool Display(FormatterPropBuildOptions options) //CodeClass elemClass)
		{
			FormatterPropOptions ccb = new FormatterPropOptions();
			if (ccb.ShowDialog(Connect.Instance) == DialogResult.OK)
			{
				if (ccb.cbFormatterKind.SelectedIndex < 0)
					return false;
				options.Kind = (FormatterPropertyKind)ccb.cbFormatterKind.SelectedItem;
				options.GetAccessor = ccb.chkGet.Checked;
				options.SetAccessor = ccb.chkSet.Checked;
				options.MapperProperty = ccb.chkMapperProperty.Checked;
				return true;
			}

			return false;
		}

		private void FillFormatterKinds()
		{
			cbFormatterKind.Items.Clear();
			cbFormatterKind.Items.Add(FormatterPropertyKind.Default);
			cbFormatterKind.Items.Add(FormatterPropertyKind.NoImplementation);
			cbFormatterKind.Items.Add(FormatterPropertyKind.UseAsIs);
			cbFormatterKind.Items.Add(FormatterPropertyKind.UseConvert);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Currency);
			cbFormatterKind.Items.Add(FormatterPropertyKind.ShortDate);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USSSN);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USSSNInt);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USZipCode);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USZipCodeInt);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USPhoneNumber);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USPhoneNumberInt);
			cbFormatterKind.Items.Add(FormatterPropertyKind.USState);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Gender);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Int);
			cbFormatterKind.Items.Add(FormatterPropertyKind.IntThousands);
			cbFormatterKind.Items.Add(FormatterPropertyKind.IntLookup);
			cbFormatterKind.Items.Add(FormatterPropertyKind.StringLookup);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Float);
			cbFormatterKind.Items.Add(FormatterPropertyKind.FloatThousands);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Double);
			cbFormatterKind.Items.Add(FormatterPropertyKind.DoubleThousands);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Decimal);
			cbFormatterKind.Items.Add(FormatterPropertyKind.DecimalThousands);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Email);
			cbFormatterKind.Items.Add(FormatterPropertyKind.URL);
			cbFormatterKind.Items.Add(FormatterPropertyKind.Password);
			cbFormatterKind.SelectedIndex = 0;
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			FillFormatterKinds();
		}

		private void chkMapperProperty_CheckedChanged(object sender, System.EventArgs e)
		{
			cbFormatterKind.Enabled = !chkMapperProperty.Checked;
		}

	}

	public class FormatterPropBuildOptions
	{
		public FormatterPropertyKind Kind = FormatterPropertyKind.Default;
		public bool SetAccessor = true;
		public bool GetAccessor = true;
		public bool MapperProperty = false;
	}
}
