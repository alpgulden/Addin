using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class ChildMemberCreator : System.Windows.Forms.Form
	{
		//private CodeClass elementCls;
		private CodeClass cls;
		private EntityBuilder dcb;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbCollection;
		private System.Windows.Forms.TextBox txtMemberName;
		private System.Windows.Forms.CheckBox chkAddParent;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cbForeignKey;
		private System.Windows.Forms.CheckBox chkCreateOnDemandLoadSave;
		private System.Windows.Forms.TextBox txtSPLoadChild;
		private System.Windows.Forms.Label lbSPLoadChild;
		private System.Windows.Forms.PictureBox pictureBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ChildMemberCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ChildMemberCreator));
			this.label1 = new System.Windows.Forms.Label();
			this.cbCollection = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtMemberName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.chkAddParent = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cbForeignKey = new System.Windows.Forms.ComboBox();
			this.chkCreateOnDemandLoadSave = new System.Windows.Forms.CheckBox();
			this.txtSPLoadChild = new System.Windows.Forms.TextBox();
			this.lbSPLoadChild = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Collection Type:";
			// 
			// cbCollection
			// 
			this.cbCollection.Location = new System.Drawing.Point(136, 80);
			this.cbCollection.Name = "cbCollection";
			this.cbCollection.Size = new System.Drawing.Size(248, 21);
			this.cbCollection.TabIndex = 2;
			this.cbCollection.TextChanged += new System.EventHandler(this.cbCollection_TextChanged);
			this.cbCollection.SelectedIndexChanged += new System.EventHandler(this.cbCollection_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(240, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select a collection class to create a child member";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 224);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 224);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtMemberName
			// 
			this.txtMemberName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMemberName.Location = new System.Drawing.Point(136, 128);
			this.txtMemberName.Name = "txtMemberName";
			this.txtMemberName.Size = new System.Drawing.Size(248, 20);
			this.txtMemberName.TabIndex = 11;
			this.txtMemberName.Text = "";
			this.txtMemberName.TextChanged += new System.EventHandler(this.txtMemberName_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(136, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Child Member Name:";
			// 
			// chkAddParent
			// 
			this.chkAddParent.Checked = true;
			this.chkAddParent.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkAddParent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkAddParent.Location = new System.Drawing.Point(104, 184);
			this.chkAddParent.Name = "chkAddParent";
			this.chkAddParent.Size = new System.Drawing.Size(240, 16);
			this.chkAddParent.TabIndex = 12;
			this.chkAddParent.Text = "Add Parent property to the child collection";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 104);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 0;
			this.label4.Text = "Foreign key member:";
			// 
			// cbForeignKey
			// 
			this.cbForeignKey.Location = new System.Drawing.Point(136, 104);
			this.cbForeignKey.Name = "cbForeignKey";
			this.cbForeignKey.Size = new System.Drawing.Size(248, 21);
			this.cbForeignKey.TabIndex = 2;
			this.cbForeignKey.DropDown += new System.EventHandler(this.cbForeignKey_DropDown);
			this.cbForeignKey.SelectedIndexChanged += new System.EventHandler(this.cbForeignKey_SelectedIndexChanged);
			// 
			// chkCreateOnDemandLoadSave
			// 
			this.chkCreateOnDemandLoadSave.Checked = true;
			this.chkCreateOnDemandLoadSave.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkCreateOnDemandLoadSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateOnDemandLoadSave.Location = new System.Drawing.Point(104, 200);
			this.chkCreateOnDemandLoadSave.Name = "chkCreateOnDemandLoadSave";
			this.chkCreateOnDemandLoadSave.Size = new System.Drawing.Size(232, 16);
			this.chkCreateOnDemandLoadSave.TabIndex = 13;
			this.chkCreateOnDemandLoadSave.Text = "Create on-demand Load/Save methods";
			// 
			// txtSPLoadChild
			// 
			this.txtSPLoadChild.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtSPLoadChild.Location = new System.Drawing.Point(136, 152);
			this.txtSPLoadChild.Name = "txtSPLoadChild";
			this.txtSPLoadChild.Size = new System.Drawing.Size(248, 20);
			this.txtSPLoadChild.TabIndex = 15;
			this.txtSPLoadChild.Text = "";
			this.txtSPLoadChild.TextChanged += new System.EventHandler(this.txtSPLoadChild_TextChanged);
			// 
			// lbSPLoadChild
			// 
			this.lbSPLoadChild.Location = new System.Drawing.Point(16, 152);
			this.lbSPLoadChild.Name = "lbSPLoadChild";
			this.lbSPLoadChild.Size = new System.Drawing.Size(136, 23);
			this.lbSPLoadChild.TabIndex = 14;
			this.lbSPLoadChild.Text = "SP for Load Child:";
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(8, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(16, 16);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 16;
			this.pictureBox2.TabStop = false;
			// 
			// ChildMemberCreator
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(402, 255);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.txtSPLoadChild);
			this.Controls.Add(this.lbSPLoadChild);
			this.Controls.Add(this.chkCreateOnDemandLoadSave);
			this.Controls.Add(this.txtMemberName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbCollection);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkAddParent);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.cbForeignKey);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ChildMemberCreator";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Child Member Creator";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.ChildMemberCreator_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void EnableButtons()
		{
			butCreate.Enabled = 
				(cbCollection.Text != "") &&
				(cbForeignKey.Text != "") &&
				(txtMemberName.Text != "") &&
				(!txtSPLoadChild.Visible || (txtSPLoadChild.Visible && txtSPLoadChild.Text != ""));
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
            bool withDataAccess = Util.IsEntityWithDataAccess(this.cls);
			try
			{
				CodeClass colCls = Util.FindClassInProject(cls.ProjectItem.ContainingProject, cbCollection.Text);
				if (colCls == null)
				{
					if (Connect.Instance.ShowDialog(this, "Can't find collection class!  Continue?", "Create Child Collection Member", MessageBoxButtons.YesNo) 
						!= DialogResult.Yes)
						return;
				}

				CodeClass elemCls = null;
				if (colCls != null)
				{
					elemCls = Util.GetElementClassOfCollection(colCls);
					if (elemCls == null)
					{
						Connect.Instance.ShowDialog(this, "Can't find element class for the specified collection!");
						return;
					}
				}

				string childTableName = Util.GetTableMappingForClass(elemCls, true);

				//string parentVar = "parent" + cls.Name;
				string parentProp = "Parent" + cls.Name;

				if (chkAddParent.Checked)
				{
                    if ((colCls != null) && (Util.FindFirstMember(colCls, parentProp) == null))
					{
						// Add a variable to this class (parent) to the child collection

						//CodeVariable var = null;
						
						// add public Parent property
						CodeProperty prop = Util.FindFirstMember(colCls, parentProp) as CodeProperty;
						if (prop == null)
						{
							prop = colCls.AddProperty(parentProp, parentProp,
								cls.Name,
								-1, 
								EnvDTE.vsCMAccess.vsCMAccessPublic, 
								null);

							prop.Comment = String.Format("Parent {0} that contains this collection", cls.Name); 

							EditPoint ep = prop.Getter.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							//if (this.extendsBaseEntity)
							ep.Insert(String.Format("\t\t\t\treturn this.ParentEntity as {0};", cls.Name));

							ep = prop.Getter.StartPoint.CreateEditPoint();
							Util.MergeFollowingLine(ep, 3);

							ep = prop.Setter.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							//if (this.extendsBaseEntity)
							ep.Insert(String.Format("\t\t\t\tthis.ParentEntity = value; /* parent is set when contained by a {0} */\r\n", cls.Name));

							ep = prop.Setter.StartPoint.CreateEditPoint();
							Util.MergeFollowingLine(ep, 3);
						}

					}
				}

				// insert after last mapped member
				object insertPos = Util.FindLastMappedColumn(cls);
				if (insertPos == null)
					insertPos = 0;

				// create a private member name
				string propName = txtMemberName.Text;
				string varName = Util.NormalizeIdentifierName(propName, true, "");
				if (varName == txtMemberName.Text)
					varName = "_" + varName;

				if (varName != null)
				{
					CodeVariable var = null;
					
					var = Util.FindFirstMember(cls, varName) as CodeVariable;
					if (var == null)
					{
						cls.AddVariable(varName,
							cbCollection.Text,
							insertPos, 
							EnvDTE.vsCMAccess.vsCMAccessPrivate, 
							null);
					}

					CodeProperty prop = null;
					
					prop = Util.FindFirstMember(cls, propName) as CodeProperty;

					if (prop == null)
					{
						prop = cls.AddProperty(propName, propName,
							cbCollection.Text,
							-1, 
							EnvDTE.vsCMAccess.vsCMAccessPublic, 
							null);

						string pkMember = Util.GetPKMemberForClass(cls);
						string pkCol = Util.GetColMappingForMember(cls, pkMember);
						string fkMember = cbForeignKey.Text;
						string fkCol = null;
						if (elemCls != null)
							fkCol = Util.GetColMappingForMember(elemCls, fkMember);

						prop.Comment = String.Format("Child {0} mapped to related rows of table {1} where [{2}] = [{3}]", propName, Util.GetTableMappingForClass(elemCls), pkCol, fkCol);

						//if (true) //this.extendsBaseEntity) // !!! This should depend on whether sps or sql generation is used
                            Util.DeclareChildCollectionAttrib(prop, elemCls, fkMember);
                        //else
							//Util.DeclareSPLoadChildAttrib(prop, txtSPLoadChild.Text, fkMember);
						//else
						//	Util.DeclareSimpleRelationAttrib(prop, pkCol, fkCol);

						EditPoint ep = null;
					
						ep = prop.Getter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);
						
                        ep.Insert(String.Format("\t\t\t\treturn this.{0};", varName));
						ep = prop.Getter.StartPoint.CreateEditPoint();
						Util.MergeFollowingLine(ep, 3);

						ep = prop.Setter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						ep.Insert(String.Format("\t\t\t\tthis.{0} = value;\r\n", varName));
						if (chkAddParent.Checked)
						{
							ep.Insert(String.Format("\t\t\t\tif (value != null)\r\n"));
							ep.Insert(String.Format("\t\t\t\t\tvalue.{0} = this; // set this as a parent of the child collection\r\n", parentProp));
						}

						ep = prop.StartPoint.CreateEditPoint();
						ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
					}	// end of child collection prop

					if (chkCreateOnDemandLoadSave.Checked)
					{
						if (dcb != null)
							dcb.EnsureSqlDataProp();

						string functionName = null;
					
						// create on-demand load/save
						CodeFunction func = null;
					
						// load function
						functionName = "Load" + propName;
						
						func = Util.FindFirstMethod(cls, functionName) as CodeFunction;
						if (func == null)
						{
							func = cls.AddFunction(functionName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
								EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
								-1, 
								EnvDTE.vsCMAccess.vsCMAccessPublic, 
								null);
							func.Comment = "Loads the " + propName + " collection";

							func.AddParameter("forceReload", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
                            if (withDataAccess)
                                ep.Insert(String.Format("\t\t\tthis.{0} = ({2}){2}.LoadChildCollection(\"{1}\", this, typeof({2}), {0}, forceReload, null);", varName, propName, cbCollection.Text));
                            else
							    ep.Insert(String.Format("\t\t\tthis.{0} = ({2}){2}.LoadChildCollectionUsingService(\"{1}\", this, typeof({2}), {0}, forceReload, null);", varName, propName, cbCollection.Text));
						}

						// save function
						functionName = "Save" + propName;
						func = Util.FindFirstMethod(cls, functionName) as CodeFunction;
						if (func == null)
						{
							func = cls.AddFunction(functionName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
								EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
								-1, 
								EnvDTE.vsCMAccess.vsCMAccessPublic, 
								null);
							func.Comment = "Saves the " + propName + " collection";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
                            if (withDataAccess)
    							ep.Insert(String.Format("\t\t\t{1}.SaveChildCollection(this.{0}, true);", varName, cbCollection.Text));
                            else
                                ep.Insert(String.Format("\t\t\t{1}.SaveChildCollectionUsingService(this.{0}, true);", varName, cbCollection.Text));
						}

                        // synchronize function  // don't generate synchronize.. it's never used anyway.
						/*if (true)
						{
							functionName = "Synchronize" + propName;
							func = Util.FindFirstMethod(cls, functionName) as CodeFunction;
							if (func == null)
							{
								func = cls.AddFunction(functionName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
									EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
									-1, 
									EnvDTE.vsCMAccess.vsCMAccessPublic, 
									null);
								func.Comment = "Synchronizes the " + propName + " collection";
								EditPoint ep = func.StartPoint.CreateEditPoint();
								ep.LineDown(2);
								ep.StartOfLine();
								Util.DeleteEditLine(ep);
								ep.Insert(String.Format("\t\t\t{1}.SynchronizeChildCollection(this.{0}, true);", varName, cbCollection.Text));
							}
						}*/

					}
				}

				DialogResult = DialogResult.OK;
				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void SetMemberName()
		{
			string colName = Util.NormalizeClassName(cbCollection.Text);
			txtMemberName.Text = Util.MakeCollectionInstanceName(cls.ProjectItem.ContainingProject, colName);
		}

		private void cbForeignKey_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void txtMemberName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbCollection_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetMemberName();

			CodeClass colCls = Util.FindClassInProject(cls.ProjectItem.ContainingProject, cbCollection.Text);
			if (colCls == null)
			{
				Connect.Instance.ShowDialog(this, "Can't find collection class!");
				EnableButtons();
				return;
			}
			CodeClass elemCls = null;
			if (colCls != null)
			{
				elemCls = Util.GetElementClassOfCollection(colCls);
				if (elemCls == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find element class for the specified collection!");
					EnableButtons();
					return;
				}
			}
			string childTableName = Util.GetTableMappingForClass(elemCls, true);
			string spName = Util.MakeSPLoadChildName(cls.Name, childTableName);
			if (Util.ExistsStoredProcFromDB(spName))
			{
				// the sp already exists in db, maybe it was used by single Load method.
				// Try making it plural.
				spName = Util.MakeSPLoadChildName(cls.Name, Util.MakePlural(childTableName));
				if (Util.ExistsStoredProcFromDB(spName))
					spName = Util.MakeSPLoadChildName("Child", cls.Name, childTableName);
			}
			txtSPLoadChild.Text = spName;

			EnableButtons();
		}

		private void FillCollections()
		{
			cbCollection.Items.Clear();
			object[] colClasses = Util.FindCollectionClassesInProject(cls.ProjectItem.ContainingProject, null);
			for (int i = 0; i < colClasses.Length; i++)
			{
				CodeClass col = colClasses[i] as CodeClass;
				if (col != null)
					//if (Util.IsCollectionClass(col))
						cbCollection.Items.Add(col.Name);
			}
		}

		private void FillMembersInFKCombo()
		{
			cbForeignKey.Items.Clear();
			CodeClass colCls = Util.FindClassInProject(cls.ProjectItem.ContainingProject, cbCollection.Text);
			if (colCls == null)
				return;
			CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
			if (elemCls == null)
				return;
			for (int i = 1; i <= elemCls.Members.Count; i++)
			{
				CodeElement elem = elemCls.Members.Item(i);
				string colMap = Util.GetColMappingForMember(elemCls, elem.Name);
				if (colMap != null)
					cbForeignKey.Items.Add(elem.Name);
			}
		}

		private void ChildMemberCreator_Load(object sender, System.EventArgs e)
		{
            //txtSPLoadChild.Visible = true; // this.extendsBaseEntity;
            //lbSPLoadChild.Visible = true; // this.extendsBaseEntity;
			FillCollections();
			EnableButtons();
		}

		public static void CreateChildMember(EntityBuilder dcb, CodeClass parentClass)
		{
			ChildMemberCreator cmc = new ChildMemberCreator();
			cmc.cls = parentClass;
			cmc.dcb = dcb;
			//if (dcb != null)
			//cmc.extendsBaseEntity = Util.IsDerivedFromBaseEntity(parentClass);
			if (cmc.ShowDialog(Connect.Instance) == DialogResult.OK)
			{		
			}
		}

		private void cbCollection_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbForeignKey_DropDown(object sender, System.EventArgs e)
		{
			FillMembersInFKCombo();
		}

		private void txtSPLoadChild_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

	}
}
