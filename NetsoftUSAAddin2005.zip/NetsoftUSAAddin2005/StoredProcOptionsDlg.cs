using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class StoredProcOptionsDlg : System.Windows.Forms.Form
	{
		private CodeClass cls;
		private StoredProcedureOptions options;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TextBox txtMethodName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.RadioButton rbFillIntoObjects;
		private System.Windows.Forms.RadioButton rbFillIntoCollection;
		private System.Windows.Forms.RadioButton rbFillIntoThisObject;
		private System.Windows.Forms.RadioButton rbReturnAsScalarValue;
		private System.Windows.Forms.RadioButton rbReturnAsDataReader;
		private System.Windows.Forms.RadioButton rbNoResult;
		private System.Windows.Forms.CheckBox chkPassMultipleObjects;
		private System.Windows.Forms.CheckBox chkPassThisObject;
		private System.Windows.Forms.CheckBox chkUseSPParams;
		private System.Windows.Forms.ComboBox cbCollectionClass;
		private System.Windows.Forms.CheckBox chkCreateCachedProp;
		private System.Windows.Forms.CheckBox chkPassExtraParamsWithObjects;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public StoredProcOptionsDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(StoredProcOptionsDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtMethodName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rbFillIntoObjects = new System.Windows.Forms.RadioButton();
			this.rbFillIntoCollection = new System.Windows.Forms.RadioButton();
			this.rbFillIntoThisObject = new System.Windows.Forms.RadioButton();
			this.rbReturnAsScalarValue = new System.Windows.Forms.RadioButton();
			this.rbReturnAsDataReader = new System.Windows.Forms.RadioButton();
			this.rbNoResult = new System.Windows.Forms.RadioButton();
			this.cbCollectionClass = new System.Windows.Forms.ComboBox();
			this.chkCreateCachedProp = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.chkUseSPParams = new System.Windows.Forms.CheckBox();
			this.chkPassMultipleObjects = new System.Windows.Forms.CheckBox();
			this.chkPassThisObject = new System.Windows.Forms.CheckBox();
			this.chkPassExtraParamsWithObjects = new System.Windows.Forms.CheckBox();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select stored procedure calling method\'s options";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(144, 336);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 336);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtMethodName
			// 
			this.txtMethodName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMethodName.Location = new System.Drawing.Point(112, 72);
			this.txtMethodName.Name = "txtMethodName";
			this.txtMethodName.Size = new System.Drawing.Size(312, 20);
			this.txtMethodName.TabIndex = 7;
			this.txtMethodName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 72);
			this.label1.Name = "label1";
			this.label1.TabIndex = 8;
			this.label1.Text = "Method Name:";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rbFillIntoObjects);
			this.groupBox1.Controls.Add(this.rbFillIntoCollection);
			this.groupBox1.Controls.Add(this.rbFillIntoThisObject);
			this.groupBox1.Controls.Add(this.rbReturnAsScalarValue);
			this.groupBox1.Controls.Add(this.rbReturnAsDataReader);
			this.groupBox1.Controls.Add(this.rbNoResult);
			this.groupBox1.Controls.Add(this.cbCollectionClass);
			this.groupBox1.Controls.Add(this.chkCreateCachedProp);
			this.groupBox1.Location = new System.Drawing.Point(8, 96);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(256, 232);
			this.groupBox1.TabIndex = 9;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = " Output Usage ";
			// 
			// rbFillIntoObjects
			// 
			this.rbFillIntoObjects.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbFillIntoObjects.Location = new System.Drawing.Point(16, 112);
			this.rbFillIntoObjects.Name = "rbFillIntoObjects";
			this.rbFillIntoObjects.TabIndex = 5;
			this.rbFillIntoObjects.Text = "Fill into objects";
			this.rbFillIntoObjects.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// rbFillIntoCollection
			// 
			this.rbFillIntoCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbFillIntoCollection.Location = new System.Drawing.Point(16, 136);
			this.rbFillIntoCollection.Name = "rbFillIntoCollection";
			this.rbFillIntoCollection.Size = new System.Drawing.Size(112, 24);
			this.rbFillIntoCollection.TabIndex = 4;
			this.rbFillIntoCollection.Text = "Fill into collection";
			this.rbFillIntoCollection.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// rbFillIntoThisObject
			// 
			this.rbFillIntoThisObject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbFillIntoThisObject.Location = new System.Drawing.Point(16, 88);
			this.rbFillIntoThisObject.Name = "rbFillIntoThisObject";
			this.rbFillIntoThisObject.Size = new System.Drawing.Size(144, 24);
			this.rbFillIntoThisObject.TabIndex = 3;
			this.rbFillIntoThisObject.Text = "Fill into this object";
			this.rbFillIntoThisObject.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// rbReturnAsScalarValue
			// 
			this.rbReturnAsScalarValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbReturnAsScalarValue.Location = new System.Drawing.Point(16, 64);
			this.rbReturnAsScalarValue.Name = "rbReturnAsScalarValue";
			this.rbReturnAsScalarValue.Size = new System.Drawing.Size(144, 24);
			this.rbReturnAsScalarValue.TabIndex = 2;
			this.rbReturnAsScalarValue.Text = "Return as Scalar Value";
			this.rbReturnAsScalarValue.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// rbReturnAsDataReader
			// 
			this.rbReturnAsDataReader.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbReturnAsDataReader.Location = new System.Drawing.Point(16, 40);
			this.rbReturnAsDataReader.Name = "rbReturnAsDataReader";
			this.rbReturnAsDataReader.Size = new System.Drawing.Size(144, 24);
			this.rbReturnAsDataReader.TabIndex = 1;
			this.rbReturnAsDataReader.Text = "Return as DataReader";
			this.rbReturnAsDataReader.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// rbNoResult
			// 
			this.rbNoResult.Checked = true;
			this.rbNoResult.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.rbNoResult.Location = new System.Drawing.Point(16, 16);
			this.rbNoResult.Name = "rbNoResult";
			this.rbNoResult.TabIndex = 0;
			this.rbNoResult.TabStop = true;
			this.rbNoResult.Text = "No result";
			this.rbNoResult.CheckedChanged += new System.EventHandler(this.rbFillIntoObjects_CheckedChanged);
			// 
			// cbCollectionClass
			// 
			this.cbCollectionClass.Enabled = false;
			this.cbCollectionClass.Location = new System.Drawing.Point(32, 160);
			this.cbCollectionClass.Name = "cbCollectionClass";
			this.cbCollectionClass.Size = new System.Drawing.Size(216, 21);
			this.cbCollectionClass.TabIndex = 11;
			this.cbCollectionClass.SelectedIndexChanged += new System.EventHandler(this.cbCollectionClass_SelectedIndexChanged);
			// 
			// chkCreateCachedProp
			// 
			this.chkCreateCachedProp.Enabled = false;
			this.chkCreateCachedProp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateCachedProp.Location = new System.Drawing.Point(32, 184);
			this.chkCreateCachedProp.Name = "chkCreateCachedProp";
			this.chkCreateCachedProp.Size = new System.Drawing.Size(144, 16);
			this.chkCreateCachedProp.TabIndex = 12;
			this.chkCreateCachedProp.Text = "Create cached property";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.chkPassExtraParamsWithObjects);
			this.groupBox2.Controls.Add(this.chkUseSPParams);
			this.groupBox2.Controls.Add(this.chkPassMultipleObjects);
			this.groupBox2.Controls.Add(this.chkPassThisObject);
			this.groupBox2.Location = new System.Drawing.Point(272, 96);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(152, 128);
			this.groupBox2.TabIndex = 10;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = " Input Parameter Usage ";
			// 
			// chkUseSPParams
			// 
			this.chkUseSPParams.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkUseSPParams.Location = new System.Drawing.Point(8, 64);
			this.chkUseSPParams.Name = "chkUseSPParams";
			this.chkUseSPParams.Size = new System.Drawing.Size(136, 24);
			this.chkUseSPParams.TabIndex = 4;
			this.chkUseSPParams.Text = "Use SP Parameters";
			// 
			// chkPassMultipleObjects
			// 
			this.chkPassMultipleObjects.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkPassMultipleObjects.Location = new System.Drawing.Point(8, 40);
			this.chkPassMultipleObjects.Name = "chkPassMultipleObjects";
			this.chkPassMultipleObjects.Size = new System.Drawing.Size(136, 24);
			this.chkPassMultipleObjects.TabIndex = 2;
			this.chkPassMultipleObjects.Text = "Pass multiple objects";
			// 
			// chkPassThisObject
			// 
			this.chkPassThisObject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkPassThisObject.Location = new System.Drawing.Point(8, 16);
			this.chkPassThisObject.Name = "chkPassThisObject";
			this.chkPassThisObject.Size = new System.Drawing.Size(136, 24);
			this.chkPassThisObject.TabIndex = 0;
			this.chkPassThisObject.Text = "Pass this object";
			// 
			// chkPassExtraParamsWithObjects
			// 
			this.chkPassExtraParamsWithObjects.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkPassExtraParamsWithObjects.Location = new System.Drawing.Point(8, 88);
			this.chkPassExtraParamsWithObjects.Name = "chkPassExtraParamsWithObjects";
			this.chkPassExtraParamsWithObjects.Size = new System.Drawing.Size(136, 32);
			this.chkPassExtraParamsWithObjects.TabIndex = 5;
			this.chkPassExtraParamsWithObjects.Text = "Pass Extra Params With Objects";
			// 
			// StoredProcOptionsDlg
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(434, 367);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtMethodName);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "StoredProcOptionsDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Stored Procedure Invoker Options";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.StoredProcOptionsDlg_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool SelectStoredProcOptions(StoredProcedureOptions options)
		{
			StoredProcOptionsDlg spo = new StoredProcOptionsDlg();
			spo.options = options;
			spo.cls = options.Class;
			if (spo.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				DialogResult = DialogResult.OK;

				//Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseEntity.Checked);

				options.MethodName = txtMethodName.Text;
				if (rbNoResult.Checked)
					options.resultUsage = EnumResultUsage.NoResult;
				if (rbReturnAsScalarValue.Checked)
					options.resultUsage = EnumResultUsage.ReturnAsScalarValue;
				if (rbReturnAsDataReader.Checked)
					options.resultUsage = EnumResultUsage.ReturnAsDataReader;
				if (rbFillIntoThisObject.Checked)
					options.resultUsage = EnumResultUsage.FillIntoThisObject;
				if (rbFillIntoObjects.Checked)
					options.resultUsage = EnumResultUsage.FillIntoObjects;
				if (rbFillIntoCollection.Checked)
					options.resultUsage = EnumResultUsage.FillIntoCollection;

				options.createCachedProp = chkCreateCachedProp.Enabled && chkCreateCachedProp.Checked;
				//options.createChildLoader = chkCreateChildLoader.Enabled && chkCreateChildLoader.Checked;
				options.PassMultipleObjects = chkPassMultipleObjects.Checked;
				options.PassExtraParamsWithObjects = chkPassExtraParamsWithObjects.Checked;
				options.PassThisObject = chkPassThisObject.Checked;
				options.UseSPParams = chkUseSPParams.Checked;
				options.CollectionClassName = (string)cbCollectionClass.SelectedItem;
				if (options.CollectionClassName == "")
					options.CollectionClassName = null;

				/*if (options.CreateOnClasses != null)
				{
					options.CreateOnClassesSel = new bool[options.CreateOnClasses.Length];
					for (int i = 0; i < options.CreateOnClasses.Length; i++)
					{
						options.CreateOnClassesSel[i] = chkCreateOnClasses.GetItemChecked(i);
					}
				}*/

				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void StoredProcOptionsDlg_Load(object sender, System.EventArgs e)
		{
			txtMethodName.Text = options.MethodName;
			switch (options.resultUsage)
			{
				case EnumResultUsage.NoResult:
					rbNoResult.Checked = true;
					break;
				case EnumResultUsage.ReturnAsScalarValue:
					rbReturnAsScalarValue.Checked = true;
					break;
				case EnumResultUsage.ReturnAsDataReader:
					rbReturnAsDataReader.Checked = true;
					break;
				case EnumResultUsage.FillIntoThisObject:
					rbFillIntoThisObject.Checked = true;
					break;
				case EnumResultUsage.FillIntoObjects:
					rbFillIntoObjects.Checked = true;
					break;
				case EnumResultUsage.FillIntoCollection:
					rbFillIntoCollection.Checked = true;
					break;
			}

			chkCreateCachedProp.Checked = options.createCachedProp;
			//chkCreateChildLoader.Checked = options.createChildLoader;
			chkPassMultipleObjects.Checked = options.PassMultipleObjects;
			chkPassExtraParamsWithObjects.Checked = options.PassExtraParamsWithObjects;
			chkPassThisObject.Checked = options.PassThisObject;
			chkUseSPParams.Checked = options.UseSPParams;

			ToolTip tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(cbCollectionClass, "If you select a collection type, the method will be created on the selected collection.");

			tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(chkCreateCachedProp, "If you check this, a static property returning a cached collection will also be created.");

			//tooltip = new ToolTip();
			//tooltip.ShowAlways = true;
			//tooltip.SetToolTip(chkCreateChildLoader, "If you check this, the method will be created as a child loader method.");

		}

		private void rbFillIntoObjects_CheckedChanged(object sender, System.EventArgs e)
		{
			cbCollectionClass.Enabled = rbFillIntoCollection.Checked;
			chkCreateCachedProp.Enabled = rbFillIntoCollection.Checked;
			//chkCreateChildLoader.Enabled = cbCollectionClass.Text == "" && rbFillIntoCollection.Checked;
			if (cbCollectionClass.Enabled && cbCollectionClass.Items.Count == 0)
			{
				object[] colClasses = Util.FindCollectionClassesInProject(cls.ProjectItem.ContainingProject, cls.Name);
				for (int i = 0; i < colClasses.Length; i++)
				{
					CodeClass colClass = colClasses[i] as CodeClass;
					if (colClass != null)
						cbCollectionClass.Items.Add(colClass.Name);
				}
			}
		}

		private void cbCollectionClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

	}

	public enum EnumResultUsage
	{
		NoResult = 1,
		ReturnAsDataReader = 2,
		ReturnAsScalarValue = 3,
		FillIntoThisObject = 4,
		FillIntoObjects = 5,
		FillIntoCollection = 6
	}

	public class StoredProcedureOptions
	{
		public CodeClass Class;

		public string MethodName = null;
		public EnumResultUsage resultUsage = EnumResultUsage.NoResult;
		public bool PassThisObject = false;
		public bool PassMultipleObjects = false;
		public bool PassExtraParamsWithObjects = false;
		public bool UseSPParams = false;
		public string CollectionClassName = null;
		public bool createCachedProp = false;
		public bool createChildLoader = false;

		public StoredProcedureOptions(CodeClass cls)
		{
			this.Class = cls;
		}

		public object GetReturnType()
		{
			switch(resultUsage)
			{
				case EnumResultUsage.NoResult:
					return EnvDTE.vsCMTypeRef.vsCMTypeRefVoid;
				case EnumResultUsage.ReturnAsScalarValue:
					return EnvDTE.vsCMTypeRef.vsCMTypeRefObject;
				case EnumResultUsage.ReturnAsDataReader:
					return "IDataReader";
				case EnumResultUsage.FillIntoThisObject:
					return EnvDTE.vsCMTypeRef.vsCMTypeRefBool;
				case EnumResultUsage.FillIntoObjects:
					return EnvDTE.vsCMTypeRef.vsCMTypeRefBool;
				case EnumResultUsage.FillIntoCollection:
					return EnvDTE.vsCMTypeRef.vsCMTypeRefInt;
			}
			return EnvDTE.vsCMTypeRef.vsCMTypeRefVoid;
		}

		public string GetFuncInvokerPart()
		{
			switch(resultUsage)
			{
				case EnumResultUsage.NoResult:
					return "SqlData.SPExecNonQuery";
				case EnumResultUsage.ReturnAsScalarValue:
					return "return SqlData.SPExecScalar";
				case EnumResultUsage.ReturnAsDataReader:
					return "return SqlData.SPExecRead";
				case EnumResultUsage.FillIntoThisObject:
					return "return SqlData.SPExecReadObj";
				case EnumResultUsage.FillIntoObjects:
					return "return SqlData.SPExecReadObj";
				case EnumResultUsage.FillIntoCollection:
					return "return SqlData.SPExecReadCol";
			}
			return null;
		}

		public string GetParams(string queryMems, string paramsArr, string valuesArr)
		{
			if (!this.PassThisObject && !this.PassMultipleObjects)
			{
				if (queryMems == null || queryMems.Length == 0)
					queryMems = null;
				else
					queryMems = ", new object[] { " + queryMems + " }";
				switch(resultUsage)
				{
					case EnumResultUsage.NoResult:
					case EnumResultUsage.ReturnAsScalarValue:
					case EnumResultUsage.ReturnAsDataReader:
						return queryMems;
					case EnumResultUsage.FillIntoThisObject:
						return "this, false" + queryMems;
					case EnumResultUsage.FillIntoObjects:
						return "new object[] { this /*, other objects to be filled */ }, false" + queryMems;
					case EnumResultUsage.FillIntoCollection:
						return "maxRecords, @collection@, false" + queryMems;	// @collection@ replaced by the caller
				}
				return null;
			}
			else
			{
				// pass this and/or other objects as input params
				string passedObjects = null;
				if (this.PassMultipleObjects)
				{
					if (this.PassThisObject)
						passedObjects = "new object[] { this /*, other objects to be passed */ }";
					else
						passedObjects = "new object[] { /* all objects to be passed */ }";
				}
				else
					passedObjects = "this";

				passedObjects += ", false";	// ignore assignment error = false

				string namedParams = String.Format("\r\n\t\t\t\tnew string[] {0},\r\n", paramsArr) + 
						String.Format("\t\t\t\tnew object[] {0}", valuesArr);

				switch(resultUsage)
				{
					case EnumResultUsage.NoResult:
					case EnumResultUsage.ReturnAsScalarValue:
					case EnumResultUsage.ReturnAsDataReader:
						if (queryMems.Length == 0 || !this.PassExtraParamsWithObjects)
							return passedObjects;
						else
							return passedObjects + ", " + namedParams;
					case EnumResultUsage.FillIntoThisObject:
						if (queryMems.Length == 0 || !this.PassExtraParamsWithObjects)
							return "this, " + passedObjects;
						else
							return "this, " + passedObjects + ", " + namedParams;
					case EnumResultUsage.FillIntoObjects:
					{
						string  targetObjs = "new object[] { this /*, other objects */ }";;
						if (queryMems.Length == 0 || !this.PassExtraParamsWithObjects)
							return targetObjs + ", " + passedObjects;
						else
							return targetObjs + ", " + passedObjects + ", " + namedParams;
					}
					case EnumResultUsage.FillIntoCollection:
					{
						string colPar = "maxRecords, @collection@";
						if (queryMems.Length == 0 || !this.PassExtraParamsWithObjects)
							return colPar + ", " + passedObjects;
						else
							return colPar + ", " + passedObjects + ", " + namedParams;
					}
				}
				return null;
			}

		}

	}

}
