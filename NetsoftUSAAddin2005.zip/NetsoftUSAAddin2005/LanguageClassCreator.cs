using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for LanguageClassCreator.
	/// </summary>
	public class LanguageClassCreator : System.Windows.Forms.Form
	{
		private CodeClass cls;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbTables;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cbMessageIDcolumn;
		private System.Windows.Forms.ComboBox cbLanguageIDcolumn;
		private System.Windows.Forms.ComboBox cbMessageColumn;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LanguageClassCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LanguageClassCreator));
			this.label1 = new System.Windows.Forms.Label();
			this.cbTables = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cbMessageIDcolumn = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cbLanguageIDcolumn = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cbMessageColumn = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Table:";
			// 
			// cbTables
			// 
			this.cbTables.Location = new System.Drawing.Point(136, 80);
			this.cbTables.Name = "cbTables";
			this.cbTables.Size = new System.Drawing.Size(264, 21);
			this.cbTables.TabIndex = 2;
			this.cbTables.SelectedIndexChanged += new System.EventHandler(this.cbTables_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(240, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select a table and then message id, lang id and message columns.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 216);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 216);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtClassName
			// 
			this.txtClassName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtClassName.Location = new System.Drawing.Point(136, 184);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(264, 20);
			this.txtClassName.TabIndex = 11;
			this.txtClassName.Text = "";
			this.txtClassName.TextChanged += new System.EventHandler(this.txtClassName_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 184);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(80, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Class Name:";
			// 
			// cbMessageIDcolumn
			// 
			this.cbMessageIDcolumn.Location = new System.Drawing.Point(136, 104);
			this.cbMessageIDcolumn.Name = "cbMessageIDcolumn";
			this.cbMessageIDcolumn.Size = new System.Drawing.Size(264, 21);
			this.cbMessageIDcolumn.TabIndex = 2;
			this.cbMessageIDcolumn.SelectedIndexChanged += new System.EventHandler(this.cbMessageIDcolumn_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 104);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 0;
			this.label4.Text = "Message ID Column:";
			// 
			// cbLanguageIDcolumn
			// 
			this.cbLanguageIDcolumn.Location = new System.Drawing.Point(136, 128);
			this.cbLanguageIDcolumn.Name = "cbLanguageIDcolumn";
			this.cbLanguageIDcolumn.Size = new System.Drawing.Size(264, 21);
			this.cbLanguageIDcolumn.TabIndex = 2;
			this.cbLanguageIDcolumn.SelectedIndexChanged += new System.EventHandler(this.cbMessageIDcolumn_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 128);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(120, 23);
			this.label5.TabIndex = 0;
			this.label5.Text = "Language ID Column:";
			// 
			// cbMessageColumn
			// 
			this.cbMessageColumn.Location = new System.Drawing.Point(136, 152);
			this.cbMessageColumn.Name = "cbMessageColumn";
			this.cbMessageColumn.Size = new System.Drawing.Size(264, 21);
			this.cbMessageColumn.TabIndex = 2;
			this.cbMessageColumn.SelectedIndexChanged += new System.EventHandler(this.cbMessageIDcolumn_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 152);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(120, 23);
			this.label6.TabIndex = 0;
			this.label6.Text = "Message Column:";
			// 
			// LanguageClassCreator
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(410, 248);
			this.Controls.Add(this.txtClassName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbTables);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cbMessageIDcolumn);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.cbLanguageIDcolumn);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.cbMessageColumn);
			this.Controls.Add(this.label6);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "LanguageClassCreator";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Language Class Creator";
			this.TopMost = true;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.LanguageClassCreator_Closing);
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static void CreateLanguageClass()
		{
			LanguageClassCreator lcc = new LanguageClassCreator();
			if (lcc.ShowDialog(Connect.Instance) == DialogResult.OK)
			{		
				if (lcc.cls != null)
				{
					LanguageClassBuilder.BuildLanguageClass(lcc.cls);
				}
			}
		}

		private void EnableButtons()
		{
			butCreate.Enabled = cbTables.Text != "" &&
				cbMessageIDcolumn.Text != "" &&
				cbLanguageIDcolumn.Text != "" &&
				cbMessageColumn.Text != "" &&
				txtClassName.Text != "";
		}

		private void LoadSettings()
		{
			string key = @"__LangTables\" + cbTables.Text;
			cbMessageIDcolumn.Text = (string)Util.GetSetting(key, "MessageIDcolumn", cbMessageIDcolumn.Text);
			cbLanguageIDcolumn.Text = (string)Util.GetSetting(key, "LanguageIDcolumn", cbLanguageIDcolumn.Text);
			cbMessageColumn.Text = (string)Util.GetSetting(key, "MessageColumn", cbMessageColumn.Text);
		}

		private void SaveSettings()
		{
			string key = @"__LangTables\" + cbTables.Text;
			Util.SetSetting(key, "MessageIDcolumn", cbMessageIDcolumn.Text);
			Util.SetSetting(key, "LanguageIDcolumn", cbLanguageIDcolumn.Text);
			Util.SetSetting(key, "MessageColumn", cbMessageColumn.Text);
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				//NewCSharpFile.cs
                cls = Connect.Instance.AddClassToCurrentProject(txtClassName.Text, "Language");
                ProjectItem prjItem = cls.ProjectItem;
				//DataTable tbl = Util.GetTablePrototype(cbTables.Text);
                CodeNamespace ns = cls.Namespace; // Util.FindCodeNamespace(prjItem.FileCodeModel.CodeElements); // as CodeNamespace;

				Util.AddReference(prjItem.ContainingProject, "NetsoftUSA.Model");

				// add:   using NetsoftUSA.Model;
				EditPoint ep = ns.StartPoint.CreateEditPoint();
				ep.LineUp(1);
				ep.EndOfLine();
				ep.Insert("\r\nusing NetsoftUSA.Model;\r\n\r\n");

				if (cls != null)
				{
					string tableName = cbTables.Text;

					cls.Comment = "Language class that contains app specific messages";

					ep = cls.StartPoint.CreateEditPoint();
					ep.LineUp(1);
					ep.EndOfLine();
					ep.Insert(String.Format("\r\n\t[LanguageTable(\"{0}\", \"{1}\", \"{2}\", \"{3}\")]", tableName, cbMessageIDcolumn.Text, cbLanguageIDcolumn.Text, cbMessageColumn.Text));

					CodeFunction funcConst = Util.FindFirstMember(cls, cls.Name) as CodeFunction;
					Util.DeleteElement(cls, funcConst as CodeElement);
					funcConst = cls.AddFunction(cls.Name, EnvDTE.vsCMFunction.vsCMFunctionConstructor,
						EnvDTE.vsCMTypeRef.vsCMTypeRefOther,
						0,
						EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);
					if (funcConst != null)
					{
						funcConst.AddParameter("langID", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);
						ep = funcConst.StartPoint.CreateEditPoint();
						ep.EndOfLine();
						ep.Insert(String.Format(": base(langID)"));
						ep.LineDown(2);
						ep.StartOfLine();
						ep.Insert(String.Format("\t\t\tLoadFromTable();\r\n"));
					}
				}

				prjItem.Save(null);
				prjItem.Open(Constants.vsViewKindCode);
				DialogResult = DialogResult.OK;
				Close();
				SaveSettings();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			Util.FillTableNamesInCombo(cbTables, false);
			LoadSettings();
			EnableButtons();
		}

		private void cbTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();

			DataTable tbl = null;
			
			try
			{
				tbl = Util.GetTablePrototype(cbTables.Text);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, String.Format("Can't access to table {0}.\r\n{1}", 
					cbTables.Text, ex.Message));																					 
				return;
			}

			Util.FillTableColumnsInCombo(tbl, cbMessageIDcolumn);
			Util.FillTableColumnsInCombo(tbl, cbLanguageIDcolumn);
			Util.FillTableColumnsInCombo(tbl, cbMessageColumn);

			LoadSettings();
		}

		private void cbMessageIDcolumn_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void txtClassName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void LanguageClassCreator_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
		}

	}
}
