using System;
using System.Collections;
using System.Windows.Forms;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	public enum IconIndices
	{
		Blank = 0,
		TextBox,
		ComboBox,
		CheckBox,
		RadioButton,
		CheckBoxList,
		RadioButtonList,
		List,
		Button,
		Label,

		LinkButton,
		ImageButton,
		HyperLink,
		Image,
		Literal
	}

	public enum ControlGenerationMethods
	{
		UseNetsoftOBControls = 0,
		UseNetsoftWrappersForInfragistics = 1,
		UseASPControls = 2,
		UseHTMLContols = 3
	}

	public class ControlGenerationOptions
	{
		public ControlGenerationMethods method;
		public bool GenerateValidators = true;
		public bool AlwaysGenerateValidators = false; 

		public bool IsNetsoftUSAControl
		{
			get 
			{ 
				return method == ControlGenerationMethods.UseNetsoftOBControls ||
					method == ControlGenerationMethods.UseNetsoftWrappersForInfragistics;
			}
		}
	}

	public class FilteringOptions
	{
		public bool formattersOnly;
		public bool fieldValuesProps;
		public bool validatorProps;
		public string searchMember;

		public bool IsMatch(CodeClass cls, string memberName)
		{
			CodeElement elem = Util.FindFirstMember(cls, memberName);
			if (formattersOnly)
				if (!Util.IsFormatter(elem))
					return false;

			if (searchMember != null && searchMember != "")
				if (memberName.ToUpper().IndexOf(searchMember.ToUpper()) < 0)
					return false;

			if (!fieldValuesProps)
				if (Util.IsFieldValuesProp(elem))
					return false;

			if (!validatorProps)
				if (Util.IsValidator(elem))
					return false;

			return true;
		}
	}

	/// <summary>
	/// Contains the information about a bindable member.
	/// </summary>
	public abstract class BindableMember
	{
		protected string name;

		public BindableMember(string name) 
		{ 
			this.name = name;
		}

		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		public abstract string CreateScript(CodeClass cls, ControlGenerationOptions options);
		public virtual string CreateScriptForLabel(CodeClass cls, ControlGenerationOptions options)
		{
			return CreateScriptForLabel(cls, options, "{0}:");
		}

		public string CreateScriptForLabel(CodeClass cls, ControlGenerationOptions options, string formatString)
		{
			string flbName = "flb" + name;
			string desc = String.Format(formatString, Util.GetFieldDescriptionForClassMember(cls, name, true));
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				{
					if (formatString == "{0}:")
						formatString = "";
					else
						formatString = " FormatString=\"" + formatString + "\"";
					return "<ns:OBFieldLabel id=\""
                        + flbName + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server EnableViewState=false" + formatString + "></ns:OBFieldLabel>";
				}
				case ControlGenerationMethods.UseASPControls:
                    return "<asp:Label id=\"" + flbName + "\" runat=server EnableViewState=false>" + desc + "</asp:Label>";
				case ControlGenerationMethods.UseHTMLContols:
                    return "<div name=\"" + flbName + "\" id=\"" + flbName + "\">" + desc + "</div>";
			}
			return null;
		}

		public string CreateScriptForClientValidators(CodeClass cls, ControlGenerationOptions options)
		{
			return CreateScriptForClientValidators(cls, options, false);
		}

		public string CreateScriptForClientValidators(CodeClass cls, ControlGenerationOptions options, bool forceCreate)
		{
			//if (!forceCreate && !options.GenerateValidators && !options.AlwaysGenerateValidators)
			if (!(forceCreate || options.GenerateValidators || options.AlwaysGenerateValidators))
				return null;

			ArrayList vlds = Util.GetClientValidationsForMember(cls, name, true);

			if (options.IsNetsoftUSAControl)
			{
				if (forceCreate || options.AlwaysGenerateValidators || vlds.Count > 0)
				{
					string vldName = "vld" + name;
					if (options.method == ControlGenerationMethods.UseNetsoftWrappersForInfragistics)
						return "<nsi:WebValidator id=\"" 
							+ vldName + "\" SourceMemberName=\"" 
							+ name + "\" SourceClassName=\"" 
							+ Util.GetFullClassName(cls) + "\" ControlToValidate=\""
							+ name
							+ "\" runat=server></nsi:WebValidator>";
					else
						return "<ns:OBValidator id=\"" 
						+ vldName + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" ControlToValidate=\""
						+ name
						+ "\" runat=server></ns:OBValidator>";
				}
				else
					return "";
			}
			
			string vld = "";
			if (vlds.Contains("Required"))
				vld += CreateScriptForRequiredFieldValidator(cls, options);

			if (vlds.Contains("String"))
				vld += CreateScriptForDataTypeValidator(cls, options, "String");

			if (vlds.Contains("Integer"))
				vld += CreateScriptForDataTypeValidator(cls, options, "Integer");

			if (vlds.Contains("Double"))
				vld += CreateScriptForDataTypeValidator(cls, options, "Double");

			if (vlds.Contains("Date"))
				vld += CreateScriptForDataTypeValidator(cls, options, "Date");

			if (vlds.Contains("Currency"))
				vld += CreateScriptForDataTypeValidator(cls, options, "Currency");

			if (vlds.Contains("Email"))
				vld += CreateScriptForDataTypeValidator(cls, options, "Email");

			if (vlds.Contains("URL"))
				vld += CreateScriptForDataTypeValidator(cls, options, "URL");

			if (vlds.Contains("USPhoneNumber"))
				vld += CreateScriptForDataTypeValidator(cls, options, "USPhoneNumber");

			if (vlds.Contains("USSSN"))
				vld += CreateScriptForDataTypeValidator(cls, options, "USSSN");

			if (vlds.Contains("USZipCode"))
				vld += CreateScriptForDataTypeValidator(cls, options, "USZipCode");

			return vld;
		}			

		public string CreateScriptForRequiredFieldValidator(CodeClass cls, ControlGenerationOptions options)
		{
			string vldName = "req" + name;
			string errMsg = String.Format("Field '{0}' is required.", Util.GetFieldDescriptionForClassMember(cls, name, true));
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseASPControls:
				case ControlGenerationMethods.UseHTMLContols:
					return 
						String.Format("<asp:RequiredFieldValidator id=\"{0}\" runat=server EnableViewState=false ControlToValidate=\"{1}\" ErrorMessage=\"{2}\"></asp:RequiredFieldValidator>", vldName, name, errMsg);
			}
			return null;
		}

		public string CreateScriptForDataTypeValidator(CodeClass cls, ControlGenerationOptions options, string dataType)
		{
			if (dataType == null || dataType == "")
				return "";  // no check
			if (dataType == "String")
				return "";	// no check
			string vldName = "dtv" + dataType + name;
			string errMsg = String.Format("Field '{0}' must be {1}.", Util.GetFieldDescriptionForClassMember(cls, name, true), dataType);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseASPControls:
				case ControlGenerationMethods.UseHTMLContols:
						if (dataType == "Email" || dataType == "URL" || dataType == "USPhoneNumber" ||
							dataType == "USSSN" || dataType == "USZipCode")
							return CreateRegularExpressionValidator(cls, options, dataType);
						else
							return String.Format("<asp:CompareValidator id=\"{0}\" runat=server EnableViewState=false ControlToValidate=\"{1}\" ErrorMessage=\"{2}\" Operator=\"DataTypeCheck\" Type=\"{3}\"></asp:CompareValidator>", vldName, name, errMsg, dataType);
			}
			return null;
		}

		public string CreateRegularExpressionValidator(CodeClass cls, ControlGenerationOptions options, string dataType)
		{
			if (dataType == null || dataType == "")
				return "";  // no check
			string regex = null;

			string vldName = "rxv" + dataType + name;

			string errMsg = String.Format("Field '{0}' must be {1}.", Util.GetFieldDescriptionForClassMember(cls, name, true), dataType);

			//regex = String.Format("<%# NetsoftUSA.Model.ValidationExpression.{0} %>", dataType);

			//return String.Format("<asp:RegularExpressionValidator id=\"{0}\" runat=server EnableViewState=false ControlToValidate=\"{1}\" ErrorMessage=\"{2}\" ValidationExpression=\"{3}\"></asp:RegularExpressionValidator>", vldName, name, errMsg, regex);

			
			switch(dataType)
			{
				case "Email":
					regex = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
					break;
				case "URL":
					regex = @"http://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?";
					break;
				case "USPhoneNumber":
					regex = @"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}";
					break;
				case "USSSN":
					regex = @"\d{3}-\d{2}-\d{4}";
					break;
				case "USZipCode":
					regex = @"\d{5}(-\d{4})?";
					break;
			}
			return String.Format("<asp:RegularExpressionValidator id=\"{0}\" runat=server EnableViewState=false ControlToValidate=\"{1}\" ErrorMessage=\"{2}\" ValidationExpression=\"{3}\"></asp:RegularExpressionValidator>", vldName, name, errMsg, regex);
		}

		public virtual string CreateScriptForButton(CodeClass cls, ControlGenerationOptions options)
		{
			string btName = "cmd" + name;
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return String.Format("<ns:OBButton id=\"{1}\" runat=server SourceMemberName=\"{0}\" SourceClassName=\"{2}\"></ns:OBButton>", name, btName, Util.GetFullClassName(cls));
				case ControlGenerationMethods.UseASPControls:
					return String.Format("<asp:Button id=\"{1}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>' CommandArgument='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:Button>", name, btName);
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<input type=button id=\"{1}\" runat=server value=\"{2}\"></input>", name, btName, desc);
			}
			return null;
		}

		public virtual string CreateScriptForLinkButton(CodeClass cls, ControlGenerationOptions options)
		{
			string btName = "cmd" + name;
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return String.Format("<ns:OBLinkButton id=\"{1}\" runat=server SourceMemberName=\"{0}\" SourceClassName=\"{2}\"></ns:OBLinkButton>", name, btName, Util.GetFullClassName(cls));
				case ControlGenerationMethods.UseASPControls:
					return String.Format("<asp:LinkButton id=\"{1}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>' CommandArgument='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:LinkButton>", name, btName);
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<a id=\"{1}\" runat=server href=\"\">{2}</a>", name, btName, desc);
			}
			return null;
		}

		public virtual string CreateScriptForImageButton(CodeClass cls, ControlGenerationOptions options)
		{
			string btName = "cmd" + name;
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return String.Format("<ns:OBImageButton id=\"{1}\" runat=server SourceMemberName=\"{0}\" SourceClassName=\"{2}\"></ns:OBImageButton>", name, btName, Util.GetFullClassName(cls));
				case ControlGenerationMethods.UseASPControls:
					return String.Format("<asp:ImageButton id=\"{1}\" runat=server ImageUrl='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>' CommandArgument='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:ImageButton>", name, btName);
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<img id=\"{1}\" runat=server src=\"\" alt=\"{2}\"></img>", name, btName, desc);
			}
			return null;
		}

		public virtual string CreateScriptForHyperLink(CodeClass cls, ControlGenerationOptions options)
		{
			string btName = "hl" + name;
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return String.Format("<ns:OBHyperlink id=\"{1}\" runat=server SourceMemberName=\"{0}\" SourceClassName=\"{2}\"></ns:OBHyperlink>", name, btName, Util.GetFullClassName(cls));
				case ControlGenerationMethods.UseASPControls:
					return String.Format("<asp:HyperLink id=\"{1}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>' NavigateUrl='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:HyperLink>", name, btName);
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<a id=\"{1}\" runat=server href=\"\">{2}</a>", name, btName, desc);
			}
			return null;
		}

		public virtual string CreateScriptForDataGridColumn(CodeClass cls, ControlGenerationOptions options)
		{
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				{
					// preare header, item, and edititem templates
					string headerTemplate = "\t<HeaderTemplate>\r\n" +
						"\t\t" + CreateScriptForLabel(cls, options, "{0}") + "\r\n" +
						"\t</HeaderTemplate>\r\n";
					string itemTemplate = "\t<ItemTemplate>\r\n" +
						"\t\t" + new LabelMember(name).CreateScript(cls, options) + "\r\n" +
						"\t</ItemTemplate>\r\n";
					string editItemTemplate = "\t<EditItemTemplate>\r\n" +
						"\t\t" + CreateScript(cls, options) + "\r\n" +
						"\t</EditItemTemplate>\r\n";
					return String.Format("<asp:TemplateColumn HeaderText=\"{0}\">\r\n{1}{2}{3}</asp:TemplateColumn>"
						, desc, headerTemplate, itemTemplate, editItemTemplate);
				}
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
				{
					// preare header, item, and edititem templates
					string boundLabelScript = String.Format(
							"<asp:Label id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:Label>"
							, name);

					string headerTemplate = "\t<HeaderTemplate>\r\n" +
						"\t\t" + CreateScriptForLabel(cls, options, "{0}") + "\r\n" +
						"\t</HeaderTemplate>\r\n";
					string itemTemplate = "\t<ItemTemplate>\r\n" +
						"\t\t" + boundLabelScript + "\r\n" +
						"\t</ItemTemplate>\r\n";
					string editItemTemplate = "\t<EditItemTemplate>\r\n" +
						//"\t\t" + @DATAGRIDCOLUMNTEMPLATE@\r\n" +	// will be substituted by deriving classes
						"\t\t" + CreateScriptForBoundControl(cls, options) +"\r\n" +
						"\t</EditItemTemplate>\r\n";
					return String.Format("<asp:TemplateColumn HeaderText=\"{0}\">\r\n{1}{2}{3}</asp:TemplateColumn>"
						, desc, headerTemplate, itemTemplate, editItemTemplate);
				}
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<asp:BoundColumn DataField=\"{0}\" HeaderText=\"{1}\"></asp:BoundColumn>", name, desc);	// direct asp bound column
			}
			return null;
		}

        public virtual string CreateScriptForGridViewColumn(CodeClass cls, ControlGenerationOptions options)
        {
            string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
            switch (options.method)
            {
                case ControlGenerationMethods.UseNetsoftOBControls:
                case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
                    {
                        // preare header, item, and edititem templates
                        string headerTemplate = "\t<HeaderTemplate>\r\n" +
                            "\t\t" + CreateScriptForLabel(cls, options, "{0}") + "\r\n" +
                            "\t</HeaderTemplate>\r\n";
                        string itemTemplate = "\t<ItemTemplate>\r\n" +
                            "\t\t" + new LabelMember(name).CreateScript(cls, options) + "\r\n" +
                            "\t</ItemTemplate>\r\n";
                        string editItemTemplate = "\t<EditItemTemplate>\r\n" +
                            "\t\t" + CreateScript(cls, options) + "\r\n" +
                            "\t</EditItemTemplate>\r\n";
                        return String.Format("<asp:TemplateField HeaderText=\"{0}\">\r\n{1}{2}{3}</asp:TemplateField>"
                            , desc, headerTemplate, itemTemplate, editItemTemplate);
                    }
                case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
                    {
                        // preare header, item, and edititem templates
                        string boundLabelScript = String.Format(
                                "<asp:Label id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:Label>"
                                , name);

                        string headerTemplate = "\t<HeaderTemplate>\r\n" +
                            "\t\t" + CreateScriptForLabel(cls, options, "{0}") + "\r\n" +
                            "\t</HeaderTemplate>\r\n";
                        string itemTemplate = "\t<ItemTemplate>\r\n" +
                            "\t\t" + boundLabelScript + "\r\n" +
                            "\t</ItemTemplate>\r\n";
                        string editItemTemplate = "\t<EditItemTemplate>\r\n" +
                            //"\t\t" + @GRIDVIEWCOLUMNTEMPLATE@\r\n" +	// will be substituted by deriving classes
                            "\t\t" + CreateScriptForBoundControl(cls, options) + "\r\n" +
                            "\t</EditItemTemplate>\r\n";
                        return String.Format("<asp:TemplateColumn HeaderText=\"{0}\">\r\n{1}{2}{3}</asp:TemplateColumn>"
                            , desc, headerTemplate, itemTemplate, editItemTemplate);
                    }
                case ControlGenerationMethods.UseHTMLContols:
                    return String.Format("<asp:BoundColumn DataField=\"{0}\" HeaderText=\"{1}\"></asp:BoundColumn>", name, desc);	// direct asp bound column
            }
            return null;
        }

		public abstract string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options);

		public virtual string CreateScriptForDataListColumn(CodeClass cls, ControlGenerationOptions options)
		{
			return
				"\t\t" + CreateScriptForLabel(cls, options) + "\r\n" +
				"\t\t" + CreateScriptForBoundControl(cls, options) + "\r\n";
			
			//string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
			/*switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				{
					// preare a 'label: control' item
					return
						"\t\t" + CreateScriptForLabel(cls, options) + "\r\n" +
						"\t\t@DATAGRIDCOLUMNTEMPLATE@\r\n";
				}
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
				{
					// preare a 'label: control' item
					string headerTemplate = "\t<HeaderTemplate>\r\n" +
						"\t\t" + CreateScriptForLabel(cls, options) + "\r\n" +
						"\t</HeaderTemplate>\r\n";
					string itemTemplate = "\t<ItemTemplate>\r\n" +
						"\t\t" + boundLabelScript + "\r\n" +
						"\t</ItemTemplate>\r\n";
					string editItemTemplate = "\t<EditItemTemplate>\r\n" +
						"\t\t@DATAGRIDCOLUMNTEMPLATE@\r\n" +	// will be substituted by deriving classes
						"\t</EditItemTemplate>\r\n";
					return String.Format("<asp:TemplateColumn HeaderText=\"{0}\">\r\n{1}{2}{3}</asp:TemplateColumn>"
						, desc, headerTemplate, itemTemplate, editItemTemplate);
				}
				case ControlGenerationMethods.UseHTMLContols:
					return String.Format("<asp:BoundColumn DataField=\"{0}\" HeaderText=\"{1}\"></asp:BoundColumn>", name, desc);	// direct asp bound column

				//case ControlGenerationMethods.UseNetsoftOBControls:
				//case ControlGenerationMethods.UseHTMLContols:
				//case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
				//	return String.Format(
				//		"\t\t@DATALISTCOLUMNTEMPLATE@\r\n");	// will be substituted by deriving classes
				//
			}
			return null;*/
		}

		public abstract int IconIndex { get; }


		public static BindableMember CreateForControlType(string name, string controlType)
		{
			controlType = Util.GetLastTerm(controlType);
			switch(controlType)
			{
				case "Label":
					return new LabelMember(name);
				case "TextBox":
					return new TextBoxMember(name);
				case "ComboBox":
					return new ComboBoxMember(name);
				case "CheckBox":
					return new CheckBoxMember(name);
				case "MultiCheckBox":
					return new MultiCheckBoxMember(name);
				case "RadioButtonBox":
					return new RadioButtonBoxMember(name);
			
				case "Button":
					return new ButtonMember(name);
				case "LinkButton":
					return new LinkButtonMember(name);
				case "ImageButton":
					return new ImageButtonMember(name);
				case "HyperLink":
					return new HyperLinkMember(name);
				case "Image":
					return new ImageMember(name);
				case "Literal":
					return new LiteralMember(name);
			}

			return null;
		}
	}

	/// <summary>
	/// Contains the information about a label member.
	/// </summary>
	public class LabelMember : BindableMember
	{
		public LabelMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			string desc = Util.GetFieldDescriptionForClassMember(cls, name, true);
            string lbName = "lb" + name;
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return "<ns:OBLabel id=\""
                        + lbName + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBLabel>";
				case ControlGenerationMethods.UseASPControls:
                    return String.Format("<asp:Label id=\"{0}\" Text=\"{1}\" runat=server></asp:Label>", lbName, desc);
				case ControlGenerationMethods.UseHTMLContols:
                    return String.Format("<div name=\"{0}\" id=\"{0}\" runat=server style=\"DISPLAY: inline; WIDTH: 70px; HEIGHT: 15px\" ms_positioning=\"FlowLayout\">{1}</div>", lbName, desc);
			}
			return null;
		}

		/*public override string CreateScriptForDataGridColumn(CodeClass cls, ControlGenerationOptions options)
		{
			string s = base.CreateScriptForDataGridColumn(cls, options);
			if (s != null)
			{
				switch(options.method)
				{
					case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					{
						string sctl = String.Format(
							"<asp:Label id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:Label>"
							, name);
						s = s.Replace("@DATAGRIDCOLUMNTEMPLATE@", sctl);
						break;
					}
				}
			}
			return s;
		}*/

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
            string lbName = "lb" + name;
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					return String.Format(
						"<asp:Label id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{1}\") %>'></asp:Label>"
						, lbName, name);
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.Label; }
		}
	}

	/// <summary>
	/// Contains the information about a textbox member.
	/// </summary>
	public class TextBoxMember : BindableMember
	{
		public TextBoxMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			string vld = CreateScriptForClientValidators(cls, options);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return CreateScriptForInfragisticsTextBox(cls, options) + vld;
				case ControlGenerationMethods.UseNetsoftOBControls:
					return "<ns:OBTextBox id=\"" 
						+ name + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBTextBox>" + vld;
				case ControlGenerationMethods.UseASPControls:
					return "<asp:TextBox id=\"" + name + "\" runat=server></asp:TextBox>" + vld;
				case ControlGenerationMethods.UseHTMLContols:
					return "<input type=text name=\"" + name + "\" id=\"" + name + "\" runat=server></input>" + vld;
			}
			return null;
		}

		private string CreateScriptForInfragisticsTextBox(CodeClass cls, ControlGenerationOptions options)
		{
			CodeElement elem = Util.FindFirstMember(cls, name);
			CodeProperty prop = elem as CodeProperty;
			CodeVariable var = elem as CodeVariable;
			CodeTypeRef typeRef = null;
			if (prop != null)
				typeRef = prop.Type;
			else if (var != null)
				typeRef = var.Type;
			else
				return null;
			Type type = Util.GetTypeForCodeTypeRef(typeRef);

			//string ctlType = Util.GetControlTypeForMember(elem, true);
			string macro = Util.GetLastTerm(Util.GetControlTypeMacroForMember(elem));
			string stereoType = Util.GetLastTerm(Util.GetStereoTypeForMember(elem));
			string inputMask = Util.GetInputMaskForMember(elem); 
			
			// determine infragistics control type
			string infraControl = null;
			
			if (inputMask != null)
				infraControl = "WebMaskEdit";
			else
				infraControl = DetectInfragisticsControlType(macro, stereoType, type);

			switch (infraControl)
			{
				//case "WebCombo":
				//	return CreateWebCombo(cls, options);
				case "WebCurrencyEdit":
					return CreateWebCurrencyEdit(cls, options);
				case "WebNumericEdit":
					return CreateWebNumericEdit(cls, options);
				case "WebDateTimeEdit":
					return CreateWebDateTimeEdit(cls, options);
				case "WebMaskEdit":
					return CreateWebMaskEdit(cls, options);	// no need to specify InputMask, it's detected at runtime
				case "WebTextEdit":
					return CreateWebTextEdit(cls, options);
				case "WebPasswordEdit":
					return CreateWebPasswordEdit(cls, options);
				default:
					return CreateWebTextEdit(cls, options);
			}

		}

		private string CreateWebCurrencyEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebCurrencyEdit id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebCurrencyEdit>";
		}

		private string CreateWebNumericEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebNumericEdit id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebNumericEdit>";
		}

		private string CreateWebDateTimeEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebDateTimeEdit id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebDateTimeEdit>";
		}

		private string CreateWebMaskEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebMaskEdit id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" DataMode=\"RawText\" runat=server></nsi:WebMaskEdit>";
				//+ Util.GetFullClassName(cls) + "\" DataMode=\"RawText\" BindToRawText=\"True\" runat=server></nsi:WebMaskEdit>";
		}

		private string CreateWebTextEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebTextEdit id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebTextEdit>";
		}

		/*private string CreateWebCombo(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebCombo id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebCombo>";
		}*/

		private string CreateWebPasswordEdit(CodeClass cls, ControlGenerationOptions options)
		{
			return "<ns:OBTextBox id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBTextBox>";
		}

		private string DetectInfragisticsControlType(string macro, string stereoType, Type type)
		{
			// WebCurrencyEdit control type
			if (macro == "Currency" || stereoType == "Currency")
				return "WebCurrencyEdit";

			// WebNumericEdit control type
			if (macro == "Int" || macro == "IntThousands" || macro == "Double" || macro == "DoubleThousands"
				|| macro == "Percent"
				|| stereoType == "Percent")
				return "WebNumericEdit";

			// WebDateTimeEdit control type
			if (macro == "ShortDate")
				return "WebDateTimeEdit";

			// WebMaskEdit control type
			if (macro == "USSSN" || macro == "USZipCode" || macro == "USPhoneNumber"
				|| macro == "USState" || macro == "Gender" || macro == "Day" || macro == "Month" || macro =="Year"
				|| macro == "YesNo" || macro == "TrueFalse"
				|| stereoType == "USSSN" || stereoType == "USZipCode" || stereoType == "USPhoneNumber"
				|| stereoType == "USState" || stereoType == "Gender" || stereoType == "Day" || stereoType == "Month" || stereoType == "Year"
				|| stereoType == "YesNo" || stereoType == "TrueFalse")
			{
				return "WebMaskEdit";
			}

			// WebTextEdit control type
			if (macro == "Email" || macro == "URL"
				|| stereoType == "Email" || stereoType == "URL")
				return "WebTextEdit";

			// Password control type
			if (macro == "Password"
				|| stereoType == "Password")
				return "WebPasswordEdit";

			/* This is textbox, never return combo from here
			 * // WebCombo control type
			if (macro == "IntLookup" || macro == "StringLookup")
				return "WebCombo";*/

			// detect what control type to use from the member type
			if (type == typeof(DateTime))
				return "WebDateTimeEdit";
			if (type == typeof(int) || type == typeof(long) || type == typeof(short) 
				|| type == typeof(float) || type == typeof(double) || type == typeof(byte) 
				|| type == typeof(decimal) || type == typeof(ulong) || type == typeof(ushort))
				return "WebNumericEdit";

			// return free text
			return "WebTextEdit";
		}

		/*public override string CreateScriptForDataGridColumn(CodeClass cls, ControlGenerationOptions options)
		{
			string s = base.CreateScriptForDataGridColumn(cls, options);
			if (s != null)
			{
				switch(options.method)
				{
					case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					{
						string sctl = String.Format(
							"<asp:TextBox id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:TextBox>"
							, name);
						s = s.Replace("@DATAGRIDCOLUMNTEMPLATE@", sctl);
						break;
					}
				}
			}
			return s;
		}*/

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					return String.Format(
						"<asp:TextBox id=\"{0}\" runat=server Text='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:TextBox>"
						, name);
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.TextBox; }
		}
	}

	/// <summary>
	/// Contains the information about a combobox member.
	/// </summary>
	public class ComboBoxMember : BindableMember
	{
		public ComboBoxMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			string vld = CreateScriptForClientValidators(cls, options);
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return CreateScriptForInfragisticsComboBox(cls, options) + vld;
				case ControlGenerationMethods.UseNetsoftOBControls:
					return "<ns:OBComboBox id=\"" 
						+ name + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBComboBox>" + vld;
				case ControlGenerationMethods.UseASPControls:
					return "<asp:DropDownList id=\"" + name + "\" runat=server></asp:DropDownList>" + vld;
				case ControlGenerationMethods.UseHTMLContols:
					return "<select name=\"" + name + "\" id=\"" + name + "\" runat=server></select>" + vld;
			}
			return null;
		}

		private string CreateScriptForInfragisticsComboBox(CodeClass cls, ControlGenerationOptions options)
		{
			return "<nsi:WebCombo id=\"" 
				+ name + "\" SourceMemberName=\"" 
				+ name + "\" SourceClassName=\"" 
				+ Util.GetFullClassName(cls) + "\" runat=server></nsi:WebCombo>";
		}

		/*public override string CreateScriptForDataGridColumn(CodeClass cls, ControlGenerationOptions options)
		{
			string s = base.CreateScriptForDataGridColumn(cls, options);
			if (s != null)
			{
				switch(options.method)
				{
					case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					{
						string valuesProp = Util.GetFieldValuesForClassMember(cls, name);
						string sctl = String.Format(
							"<asp:DropDownList id=\"{0}\" runat=server SelectedValue='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", name);
						if (valuesProp != null)
						{
							sctl += String.Format(" DataSource='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", valuesProp);
						}
						sctl += "></asp:DropDownList>";
						s = s.Replace("@DATAGRIDCOLUMNTEMPLATE@", sctl);
						break;
					}
				}
			}
			return s;
		}*/

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
				{
					string valuesProp = Util.GetFieldValuesForClassMember(cls, name);
					string sctl = String.Format(
						"<asp:DropDownList id=\"{0}\" runat=server SelectedValue='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", name);
					if (valuesProp != null)
					{
						sctl += String.Format(" DataSource='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", valuesProp);
					}
					sctl += "></asp:DropDownList>";
					return sctl;
				}
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.ComboBox; }
		}
	}

	/// <summary>
	/// Contains the information about a checkbox member.
	/// </summary>
	public class CheckBoxMember : BindableMember
	{
		public CheckBoxMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return "<ns:OBCheckBox id=\"" 
						+ name + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBCheckBox>";
				case ControlGenerationMethods.UseASPControls:
					return "<asp:CheckBox id=\"" + name + "\" runat=server></asp:CheckBox>";
				case ControlGenerationMethods.UseHTMLContols:
					return "<input type=checkbox name=\"" + name + "\" id=\"" + name + "\" runat=server></input>";
			}
			return null;
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					return String.Format(
						"<asp:CheckBox id=\"{0}\" runat=server Checked='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'></asp:CheckBox>"
						, name);
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.CheckBox; }
		}
	}

	/// <summary>
	/// Contains the information about a multicheckbox member.
	/// </summary>
	public class MultiCheckBoxMember : BindableMember
	{
		public MultiCheckBoxMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return "<ns:OBMultiCheckBox id=\"" 
						+ name + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBMultiCheckBox>";
				case ControlGenerationMethods.UseASPControls:
				case ControlGenerationMethods.UseHTMLContols:
					return "<asp:CheckBoxList id=\"" + name + "\" runat=server></asp:CheckBoxList>";
			}
			return null;
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					string valuesProp = Util.GetFieldValuesForClassMember(cls, name);
					string sctl = String.Format(
						"<asp:CheckBoxList id=\"{0}\" runat=server SelectedValue='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", name);
					if (valuesProp != null)
					{
						sctl += String.Format(" DataSource='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", valuesProp);
					}
					sctl += "></asp:CheckBoxList>";
					return sctl;
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.CheckBoxList; }
		}
	}

	/// <summary>
	/// Contains the information about a radiobuttonbox member.
	/// </summary>
	public class RadioButtonBoxMember : BindableMember
	{
		public RadioButtonBoxMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
					return "<ns:OBRadioButtonBox id=\"" 
						+ name + "\" SourceMemberName=\"" 
						+ name + "\" SourceClassName=\"" 
						+ Util.GetFullClassName(cls) + "\" runat=server></ns:OBRadioButtonBox>";
				case ControlGenerationMethods.UseASPControls:
				case ControlGenerationMethods.UseHTMLContols:
					return "<asp:RadioButtonList id=\"" + name + "\" runat=server></asp:RadioButtonList>";
			}
			return null;
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			switch(options.method)
			{
				case ControlGenerationMethods.UseNetsoftOBControls:
				case ControlGenerationMethods.UseNetsoftWrappersForInfragistics:
				case ControlGenerationMethods.UseHTMLContols:
					return CreateScript(cls, options);
				case ControlGenerationMethods.UseASPControls:	// allow control to generate templates columns
					string valuesProp = Util.GetFieldValuesForClassMember(cls, name);
					string sctl = String.Format(
						"<asp:RadioButtonList id=\"{0}\" runat=server SelectedValue='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", name);
					if (valuesProp != null)
					{
						sctl += String.Format(" DataSource='<%# DataBinder.Eval(Container, \"DataItem.{0}\") %>'", valuesProp);
					}
					sctl += "></asp:RadioButtonList>";
					return sctl;
			}
			return null;
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.RadioButtonList; }
		}
	}

	/// <summary>
	/// Contains the information about a button member.
	/// </summary>
	public class ButtonMember : BindableMember
	{
		public ButtonMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForButton(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.Button; }
		}
	}

	/// <summary>
	/// Contains the information about a image button member.
	/// </summary>
	public class ImageButtonMember : BindableMember
	{
		public ImageButtonMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForImageButton(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.ImageButton; }
		}
	}

	/// <summary>
	/// Contains the information about a link button member.
	/// </summary>
	public class LinkButtonMember : BindableMember
	{
		public LinkButtonMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForLinkButton(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.LinkButton; }
		}
	}

	/// <summary>
	/// Contains the information about a hyperlink member.
	/// </summary>
	public class HyperLinkMember : BindableMember
	{
		public HyperLinkMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForHyperLink(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.HyperLink; }
		}
	}

	/// <summary>
	/// Contains the information about a image member.
	/// </summary>
	public class ImageMember : BindableMember
	{
		public ImageMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForImageButton(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.Image; }
		}
	}

	/// <summary>
	/// Contains the information about a literal member.
	/// </summary>
	public class LiteralMember : BindableMember
	{
		public LiteralMember(string name) : base(name) { }

		public override string CreateScript(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScriptForImageButton(cls, options);
		}

		public override string CreateScriptForBoundControl(CodeClass cls, ControlGenerationOptions options)
		{
			return this.CreateScript(cls, options);
		}

		public override int IconIndex
		{
			get	{ return (int)IconIndices.Literal; }
		}
	}

	/// <summary>
	/// Base filter for filling the bindable members listview
	/// </summary>
	public class BindableFilter
	{
		/*protected string name;

		public string Name
		{
			get { return name; }
			set { name = value; }
		}*/

		public void AddBindable(ListView list, BindableMember bmember)
		{
			ListViewItem li = list.Items.Add(bmember.Name, bmember.IconIndex);
			li.Tag = bmember;
		}

		public virtual void AddBindable(ListView list, string name)
		{
			// do nothing
		}

		public virtual void FillBindables(CodeClass cls, ListView list, FilteringOptions options)
		{
			list.Items.Clear();
			// leave empty
		}

		public virtual string GetDescription()
		{
			return "";
		}
	}

	/// <summary>
	/// Filters the members for the specified control type
	/// </summary>
	public abstract class ControlTypeFilter : BindableFilter
	{
		protected string ctlType;

		public ControlTypeFilter(string ctlType)
		{
			this.ctlType = ctlType;
		}

		public string CtlType
		{
			get { return ctlType; }
			set { ctlType = value; }
		}

		public override void FillBindables(CodeClass cls, ListView list, FilteringOptions options)
		{
			list.Items.Clear();

			object[] members = Util.FindMembersForAttribs(cls, EnvDTE.vsCMAccess.vsCMAccessPublic, "ControlType");

			for (int i = 0; i < members.Length; i++)
			{
				CodeElement elem = members[i] as CodeElement;
				string ctlTypeDeclared = Util.GetControlTypeForMember(elem, true);
				ArrayList ctlTypes = Util.ParseFlags(ctlTypeDeclared, true);
				if (ctlTypes.Contains(ctlType))
					if (options.IsMatch(cls, elem.Name))
						AddBindable(list, elem.Name);
			}
		}

		public override string GetDescription()
		{
			return "All public members supporting " + Convert.ToString(ctlType);
		}
	}

	/// <summary>
	/// All types of controls member filter
	/// </summary>
	public class AllControlTypesFilter : BindableFilter
	{
		private string forceCtlType = null;

		public AllControlTypesFilter()
		{
		}

		public AllControlTypesFilter(string forceCtlType)
		{
			this.forceCtlType = forceCtlType;
		}

		public override void FillBindables(CodeClass cls, ListView list, FilteringOptions options)
		{
			list.Items.Clear();

			object[] members = Util.FindMembersForAttribs(cls, EnvDTE.vsCMAccess.vsCMAccessPublic);

			for (int i = 0; i < members.Length; i++)
			{
				CodeElement elem = members[i] as CodeElement;
				string ctlTypeDeclared = Util.GetControlTypeForMember(elem, true);
				ArrayList ctlTypes = Util.ParseFlags(ctlTypeDeclared, true);
				if (ctlTypes.Count > 0)
				{
					// use first control type declared
					string ctlType = null;
					if (forceCtlType != null)
						ctlType = forceCtlType;
					else
						ctlType = (string)ctlTypes[0];
					BindableMember bmember = BindableMember.CreateForControlType(elem.Name, ctlType);
					if (bmember != null)
						if (options.IsMatch(cls, elem.Name))
							AddBindable(list, bmember);
				}
			}
		}

		public override string GetDescription()
		{
			if (forceCtlType != null)
				return "All public members crated as " + forceCtlType;
			else
				return "All public members as declared control type";
		}

	}

	/// <summary>
	/// Filter members that don't define a control type
	/// </summary>
	public class UndefinedControlTypesFilter : BindableFilter
	{
		private string forceCtlType = null;
		private bool reverseLogic = false;	// defined only

		public UndefinedControlTypesFilter()
		{
		}

		public UndefinedControlTypesFilter(bool reverseLogic)
		{
			this.reverseLogic = reverseLogic;
		}

		public UndefinedControlTypesFilter(string forceCtlType, bool reverseLogic)
			: this(forceCtlType)
		{
			this.reverseLogic = reverseLogic;
		}

		public UndefinedControlTypesFilter(string forceCtlType)
		{
			this.forceCtlType = forceCtlType;
		}

		public override void FillBindables(CodeClass cls, ListView list, FilteringOptions options)
		{
			list.Items.Clear();

			object[] members = Util.FindMembersForAttribs(cls, EnvDTE.vsCMAccess.vsCMAccessPublic);

			for (int i = 0; i < members.Length; i++)
			{
				CodeElement elem = members[i] as CodeElement;
				string ctlTypeDeclared = Util.GetControlTypeForMember(elem, false);
				if (ctlTypeDeclared == null)
				{
					// use first control type declared
					string ctlType = null;
					if (forceCtlType != null)
						ctlType = forceCtlType;
					else
						ctlType = "TextBox";
					BindableMember bmember = BindableMember.CreateForControlType(elem.Name, ctlType);
					if (bmember != null)
						if (options.IsMatch(cls, elem.Name))
							if (!reverseLogic)
								AddBindable(list, bmember);
				}
				else
					if (reverseLogic)
					{
						ArrayList ctlTypes = Util.ParseFlags(ctlTypeDeclared, true);
						if (ctlTypes.Count > 0)
						{
							string ctlType = null;
							if (forceCtlType != null)
								ctlType = forceCtlType;
							else
								ctlType = (string)ctlTypes[0];
							BindableMember bmember = BindableMember.CreateForControlType(elem.Name, ctlType);
							AddBindable(list, bmember);
						}
					}
			}
		}

		public override string GetDescription()
		{
			string logic = null;

			if (reverseLogic)
				logic = "";			// that do declare
			else
				logic = "do not";	// that do not declare

			if (forceCtlType != null)
				return String.Format("All public members that {0} declare a control type created as " + forceCtlType, logic);
			else
				return String.Format("All public members that {0} declare a control type", logic);
		}

	}

	/// <summary>
	/// Label control type member filter
	/// </summary>
	public class LabelFilter : ControlTypeFilter
	{
		public LabelFilter() : base("Label")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new LabelMember(name));
		}
	}

	/// <summary>
	/// TextBox control type member filter
	/// </summary>
	public class TextBoxFilter : ControlTypeFilter
	{
		public TextBoxFilter() : base("TextBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new TextBoxMember(name));
		}
	}

	/// <summary>
	/// ComboBox control type member filter
	/// </summary>
	public class ComboBoxFilter : ControlTypeFilter
	{
		public ComboBoxFilter() : base("ComboBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new ComboBoxMember(name));
		}
	}

	/// <summary>
	/// CheckBox control type member filter
	/// </summary>
	public class CheckBoxFilter : ControlTypeFilter
	{
		public CheckBoxFilter() : base("CheckBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new CheckBoxMember(name));
		}
	}

	/// <summary>
	/// MultiCheckBox control type member filter
	/// </summary>
	public class MultiCheckBoxFilter : ControlTypeFilter
	{
		public MultiCheckBoxFilter() : base("MultiCheckBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new MultiCheckBoxMember(name));
		}
	}

	/// <summary>
	/// RadioButtonBox control type member filter
	/// </summary>
	public class RadioButtonBoxFilter : ControlTypeFilter
	{
		public RadioButtonBoxFilter() : base("RadioButtonBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new RadioButtonBoxMember(name));
		}
	}

	/// <summary>
	/// ComboBox control type member filter
	/// </summary>
	/*public class ComboBoxFilter : ControlTypeFilter
	{
		public ComboBoxFilter() : base("ComboBox")
		{
		}

		public override void AddBindable(ListView list, string name)
		{
			AddBindable(list, new ComboBoxMember(name));
		}
	}*/



}
