using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Data.OleDb;
using System.Text;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;
using EnvDTE80;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityBuilder.on
	/// </summary>
	public class EntityBuilder : System.Windows.Forms.Form
	{
		private ArrayList mismatchedInsertParams = new ArrayList();
		private ArrayList mismatchedUpdateParams = new ArrayList();
		private DataTable tbl;
		private CodeClass cls;
		string[] pkMembers;
		CodeTypeRef[] pkTypes; 
		string[] pkColNames;
		string tableName;
		private StoredProcedureOptions spOptions;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbTables;
		private System.Windows.Forms.Button butAdd;
		private System.Windows.Forms.ListBox lsMembers;
		private System.Windows.Forms.ListBox lsColumns;
		private System.Windows.Forms.Button butRemove;
		private System.Windows.Forms.Button butAddAll;
		private System.Windows.Forms.Button butRemoveAll;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lbClassName;
		private System.Windows.Forms.CheckBox chkExplicitAttribs;
		private System.Windows.Forms.ComboBox cbAccessLevel;
		private System.Windows.Forms.TabControl tab;
		private System.Windows.Forms.TabPage tabColumnMapping;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ListBox lsAllFields;
		private System.Windows.Forms.ListBox lsParams;
		private System.Windows.Forms.Button butRemoveParam;
		private System.Windows.Forms.Button butAddParam;
		private System.Windows.Forms.Button butUpdateMembers;
		private System.Windows.Forms.Button butCancel2;
		private System.Windows.Forms.CheckBox chkConstructor;
		private System.Windows.Forms.CheckBox chkLoad;
		private System.Windows.Forms.TabPage tabDBMethods;
		private System.Windows.Forms.CheckBox chkInsertMethod;
		private System.Windows.Forms.CheckBox chkUpdateMethod;
		private System.Windows.Forms.CheckBox chkSaveMethod;
		private System.Windows.Forms.CheckBox chkDeleteByPKMethod;
		private System.Windows.Forms.CheckBox chkDeleteMethod;
		private System.Windows.Forms.Button butCancel3;
		private System.Windows.Forms.Button butCreateDBMethods;
		private System.Windows.Forms.CheckBox chkAllDBMethods;
		private System.Windows.Forms.CheckBox chkCamelNotation;
		private System.Windows.Forms.TextBox txtPrefix;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.CheckBox chkCreateProps;
		private System.Windows.Forms.TabPage tabColMappingMode;
		private System.Windows.Forms.CheckBox chkMappedOnly;
		private System.Windows.Forms.CheckBox chkMapPublic;
		private System.Windows.Forms.CheckBox chkMapNonPublic;
		private System.Windows.Forms.Button butCancel4;
		private System.Windows.Forms.Button butUpdateColMapMode;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lbPKMember;
		private System.Windows.Forms.Button cmdShowInsertMethod;
		private System.Windows.Forms.Button cmdShowUpdateMethod;
		private System.Windows.Forms.Button cmdShowSaveMethod;
		private System.Windows.Forms.Button cmdShowDeleteByPKMethod;
		private System.Windows.Forms.Button cmdShowDeleteMethod;
		private System.Windows.Forms.Button butShowColsMapModeAttrib;
		private System.Windows.Forms.Button cmdShowLoadByPKMethod;
		private System.Windows.Forms.CheckBox chkLoadByPKMethod;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TabPage tabSQLHint;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Button butCreateSQLHintAttrib;
		private System.Windows.Forms.Button butCancel5;
		private System.Windows.Forms.ListBox lsSQLHintCols;
		private System.Windows.Forms.ListBox lsColumns2;
		private System.Windows.Forms.Button butAddHint;
		private System.Windows.Forms.Button butRemoveAllHint;
		private System.Windows.Forms.Button butRemoveHint;
		private System.Windows.Forms.Button butAddAllHint;
		private System.Windows.Forms.Button cmdShowSQLHintAttrib;
		private System.Windows.Forms.Label lbHelp;
		private System.Windows.Forms.Button cmdFillFromColMapping;
		private System.Windows.Forms.Button cmdReloadTable;
		private System.Windows.Forms.Button cmdShowTableMappingAtt;
		private System.Windows.Forms.Button cmdCreateTest;
		private System.Windows.Forms.CheckBox chkReadMethod;
		private System.Windows.Forms.Button cmdShowReadMethod;
		private System.Windows.Forms.Button cmdCreateTestForRead;
		private System.Windows.Forms.Button cmdShowReadColMethod;
		private System.Windows.Forms.CheckBox chkReadColMethod;
		private System.Windows.Forms.Button cmdCreateTestForReadCol;
		private System.Windows.Forms.Button butCreateParamsMethods;
		private System.Windows.Forms.CheckBox chkToStringMethod;
		private System.Windows.Forms.CheckBox chkExecuteReaderMethod;
		private System.Windows.Forms.TabPage tabCodeGenOpt;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox chkEnsureSqlData;
		private System.Windows.Forms.Button butCreateSqlDataProp;
		private System.Windows.Forms.CheckBox chkAllUtilityMethods;
		private System.Windows.Forms.CheckBox chkLoadFromDataRowView;
		private System.Windows.Forms.CheckBox chkSaveToDataRowView;
		private System.Windows.Forms.Button cmdShowLoadFromDataRowView;
		private System.Windows.Forms.Button cmdShowSaveToDataRowView;
		private System.Windows.Forms.CheckBox chkExecuteSQL;
		private System.Windows.Forms.TabPage tabCollections;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ListBox lsCollectionClasses;
		private System.Windows.Forms.Button cmdShowColBuilder;
		private System.Windows.Forms.Button cmdShowWebFormBuilder;
		private System.Windows.Forms.Button cmdShowToStringMethod;
		private System.Windows.Forms.TabPage tabStoredProcs;
		private System.Windows.Forms.CheckBox chkAllCRUDsps;
		private System.Windows.Forms.CheckBox chkSPforDelete;
		private System.Windows.Forms.CheckBox chkSPforUpdate;
		private System.Windows.Forms.CheckBox chkSPforInsert;
		private System.Windows.Forms.CheckBox chkSPforLoad;
		private System.Windows.Forms.Button cmdShowSPforDelete;
		private System.Windows.Forms.Button cmdShowSPforUpdate;
		private System.Windows.Forms.Button cmdShowSPforInsert;
		private System.Windows.Forms.Button cmdShowSPforLoad;
		private System.Windows.Forms.Button cmdCancel6;
		private System.Windows.Forms.Button cmdCreateCRUDsps;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.CheckBox chkRecreateCRUDsps;
		private System.Windows.Forms.Button cmdDropCRUDsp;
		private System.Windows.Forms.CheckBox chkExistsByPK;
		private System.Windows.Forms.CheckBox chkExists;
		private System.Windows.Forms.Button cmdShowExistsByPK;
		private System.Windows.Forms.Button cmdShowExists;
		private System.Windows.Forms.CheckBox chkSPforExists;
		private System.Windows.Forms.Button cmdShowSPforExists;
		private System.Windows.Forms.CheckBox chkExecuteStoredProcMethod;
		private System.Windows.Forms.ComboBox cbSprocName;
		private System.Windows.Forms.TabPage tabBuildParamsMethods;
		private System.Windows.Forms.CheckBox chkAllStoredProcs;
		private System.Windows.Forms.TabPage tabChildren;
		private System.Windows.Forms.ListBox lsChildren;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button butCreateCollectionClass;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button cmdCreateChild;
		private System.Windows.Forms.CheckBox chkEnsureServerScript;
		private System.Windows.Forms.Button butCreateServerScriptProp;
		private System.Windows.Forms.CheckBox chkCalculateScriptMethod;
		private System.Windows.Forms.ListBox lsInvalidMappings;
		private System.Windows.Forms.CheckBox chkShowInvalidMappings;
		private System.Windows.Forms.Button cmdShowSynchronizeMethod;
		private System.Windows.Forms.CheckBox chkSynchronizeMethod;
		private System.Windows.Forms.CheckBox chkNewMethod;
		private System.Windows.Forms.Button butRemoveParamAll;
		private System.Windows.Forms.Button butAddParamAll;
		private System.Windows.Forms.Button butAddParamsOnlyMapped;
		private System.Windows.Forms.TabPage tabOverrides;
		private System.Windows.Forms.ListBox lstOverridables;
		private System.Windows.Forms.ListBox lstOverriddenMethods;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Button butCancel6;
		private System.Windows.Forms.Button butRemoveOverridable;
		private System.Windows.Forms.Button butAddOverridable;
		private System.Windows.Forms.Button butCreateOverridingMethods;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.CheckBox chkOverrideCRUDpassMembers;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.LinkLabel lbProcNameLabel;
		private System.Windows.Forms.LinkLabel lbCRUDspname;
		private System.Windows.Forms.RichTextBox txtPreviewCRUDsps;
		private System.Windows.Forms.Button butCreateSPLoadChild;
		private System.Windows.Forms.LinkLabel lbSPLoadChild;
		private System.Windows.Forms.TextBox txtSPForLoadChild;
		private System.Windows.Forms.Button butEnsureAllChildLoaderSPs;
		private System.Windows.Forms.TabPage tabContainedObjects;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Button cmdCreateContainedEntityObject;
		private System.Windows.Forms.ListBox lsContainedEntityObjects;
		private System.Windows.Forms.Button cmdShowContainedClassBuilder;
		private System.Windows.Forms.Button cmdShowChildColBuilder;
		private System.Windows.Forms.ListBox lsParentObjects;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Button cmdShowClassBuilderForParent;
		private System.Windows.Forms.LinkLabel butMismatchedInsertParams;
		private System.Windows.Forms.LinkLabel butMismatchedUpdateParams;
		private System.Windows.Forms.Button butCreateCRUDTester;
		private System.Windows.Forms.CheckBox chkDeclareSPAtt;
		private System.Windows.Forms.LinkLabel butPossibleInvalidLoadSP;
		private System.Windows.Forms.CheckBox chkAutoGenSPs;
		private System.Windows.Forms.Button butManageAutoGenSPs;
		private System.Windows.Forms.LinkLabel butPossibleInvalidAutoGenSPs;
		private System.Windows.Forms.LinkLabel butSelectSPTemplate;
		private System.Windows.Forms.Button butShowContainmentModel;
		private System.Windows.Forms.Button butShowContainmentBuilder2;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.CheckBox chkIntsAreFKs;
		private System.Windows.Forms.CheckBox chkPreviewOnly;
		private System.Windows.Forms.Label label27;
        private CheckBox chkColumnNameConstants;

		private string[] allOverridables = 
			new string[] {
							"SPExecuteLoad",
							"SPExecuteInsert",
							"SPExecuteUpdate",
							"SPExecuteDelete",
							"InternalSave",
							"InternalLoad",
							"OnCompleteSave",
							"FillFromReader",
							"NewRecord",
							"InternalInsert",
							"InternalUpdate",
							"InternalDelete",
						};
		public CodeClass Class
		{
			get { return this.cls; }
		}

		public string PKMembersStr
		{
			get
			{
				return String.Join(",", pkMembers);
			}
			set
			{
				if (value == null)
					pkMembers = null;
				else
					pkMembers = value.Split(',');
			}
		}

		public string GetPKMembersArrDef(string prefix)
		{
			string s= "new object[] {";
			for (int i = 0; i < pkMembers.Length; i++)
			{
				if (i > 0)
					s += ",";
				s += prefix + pkMembers[i];
			}
			return s + "}";
		}

		public string GetPKMembersCommaSep(string prefix)
		{
			string s= null;
			for (int i = 0; i < pkMembers.Length; i++)
			{
				if (i > 0)
					s += ",";
				s += prefix + pkMembers[i];
			}
			return s;
		}

		private string DataProjPath
		{
			get
			{
				string projPath = cls.ProjectItem.ContainingProject.FullName;
				projPath = Path.GetDirectoryName(projPath);
				return projPath;
			}
		}

		private string SPTemplatesPath
		{
			get
			{
				return this.DataProjPath + @"\SPTemplates";
			}
		}

		public EntityBuilder()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EntityBuilder));
            this.label1 = new System.Windows.Forms.Label();
            this.cbTables = new System.Windows.Forms.ComboBox();
            this.lbHelp = new System.Windows.Forms.Label();
            this.butCancel = new System.Windows.Forms.Button();
            this.butUpdateMembers = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.butAdd = new System.Windows.Forms.Button();
            this.lsMembers = new System.Windows.Forms.ListBox();
            this.lsColumns = new System.Windows.Forms.ListBox();
            this.butRemove = new System.Windows.Forms.Button();
            this.butAddAll = new System.Windows.Forms.Button();
            this.butRemoveAll = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbClassName = new System.Windows.Forms.Label();
            this.chkExplicitAttribs = new System.Windows.Forms.CheckBox();
            this.cbAccessLevel = new System.Windows.Forms.ComboBox();
            this.tab = new System.Windows.Forms.TabControl();
            this.tabColumnMapping = new System.Windows.Forms.TabPage();
            this.chkColumnNameConstants = new System.Windows.Forms.CheckBox();
            this.chkIntsAreFKs = new System.Windows.Forms.CheckBox();
            this.lsInvalidMappings = new System.Windows.Forms.ListBox();
            this.chkShowInvalidMappings = new System.Windows.Forms.CheckBox();
            this.chkCreateProps = new System.Windows.Forms.CheckBox();
            this.txtPrefix = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chkCamelNotation = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabStoredProcs = new System.Windows.Forms.TabPage();
            this.butPossibleInvalidAutoGenSPs = new System.Windows.Forms.LinkLabel();
            this.butManageAutoGenSPs = new System.Windows.Forms.Button();
            this.chkAutoGenSPs = new System.Windows.Forms.CheckBox();
            this.butPossibleInvalidLoadSP = new System.Windows.Forms.LinkLabel();
            this.chkDeclareSPAtt = new System.Windows.Forms.CheckBox();
            this.butMismatchedUpdateParams = new System.Windows.Forms.LinkLabel();
            this.butMismatchedInsertParams = new System.Windows.Forms.LinkLabel();
            this.txtPreviewCRUDsps = new System.Windows.Forms.RichTextBox();
            this.cmdCancel6 = new System.Windows.Forms.Button();
            this.cmdDropCRUDsp = new System.Windows.Forms.Button();
            this.chkRecreateCRUDsps = new System.Windows.Forms.CheckBox();
            this.cmdCreateCRUDsps = new System.Windows.Forms.Button();
            this.cmdShowSPforInsert = new System.Windows.Forms.Button();
            this.chkAllCRUDsps = new System.Windows.Forms.CheckBox();
            this.chkSPforDelete = new System.Windows.Forms.CheckBox();
            this.chkSPforUpdate = new System.Windows.Forms.CheckBox();
            this.chkSPforInsert = new System.Windows.Forms.CheckBox();
            this.cmdShowSPforUpdate = new System.Windows.Forms.Button();
            this.cmdShowSPforDelete = new System.Windows.Forms.Button();
            this.cmdShowSPforLoad = new System.Windows.Forms.Button();
            this.chkSPforLoad = new System.Windows.Forms.CheckBox();
            this.chkSPforExists = new System.Windows.Forms.CheckBox();
            this.cmdShowSPforExists = new System.Windows.Forms.Button();
            this.chkAllStoredProcs = new System.Windows.Forms.CheckBox();
            this.lbCRUDspname = new System.Windows.Forms.LinkLabel();
            this.label15 = new System.Windows.Forms.Label();
            this.chkPreviewOnly = new System.Windows.Forms.CheckBox();
            this.tabDBMethods = new System.Windows.Forms.TabPage();
            this.butCreateCRUDTester = new System.Windows.Forms.Button();
            this.chkSynchronizeMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowSynchronizeMethod = new System.Windows.Forms.Button();
            this.cmdCreateTest = new System.Windows.Forms.Button();
            this.cmdCreateTestForRead = new System.Windows.Forms.Button();
            this.cmdCreateTestForReadCol = new System.Windows.Forms.Button();
            this.chkAllUtilityMethods = new System.Windows.Forms.CheckBox();
            this.cmdShowInsertMethod = new System.Windows.Forms.Button();
            this.chkAllDBMethods = new System.Windows.Forms.CheckBox();
            this.butCreateDBMethods = new System.Windows.Forms.Button();
            this.butCancel3 = new System.Windows.Forms.Button();
            this.chkDeleteMethod = new System.Windows.Forms.CheckBox();
            this.chkDeleteByPKMethod = new System.Windows.Forms.CheckBox();
            this.chkSaveMethod = new System.Windows.Forms.CheckBox();
            this.chkUpdateMethod = new System.Windows.Forms.CheckBox();
            this.chkInsertMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowUpdateMethod = new System.Windows.Forms.Button();
            this.cmdShowSaveMethod = new System.Windows.Forms.Button();
            this.cmdShowDeleteByPKMethod = new System.Windows.Forms.Button();
            this.cmdShowDeleteMethod = new System.Windows.Forms.Button();
            this.cmdShowLoadByPKMethod = new System.Windows.Forms.Button();
            this.chkLoadByPKMethod = new System.Windows.Forms.CheckBox();
            this.chkReadMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowReadMethod = new System.Windows.Forms.Button();
            this.cmdShowReadColMethod = new System.Windows.Forms.Button();
            this.chkReadColMethod = new System.Windows.Forms.CheckBox();
            this.chkLoadFromDataRowView = new System.Windows.Forms.CheckBox();
            this.chkSaveToDataRowView = new System.Windows.Forms.CheckBox();
            this.cmdShowLoadFromDataRowView = new System.Windows.Forms.Button();
            this.cmdShowSaveToDataRowView = new System.Windows.Forms.Button();
            this.chkExistsByPK = new System.Windows.Forms.CheckBox();
            this.chkExists = new System.Windows.Forms.CheckBox();
            this.cmdShowExistsByPK = new System.Windows.Forms.Button();
            this.cmdShowExists = new System.Windows.Forms.Button();
            this.tabChildren = new System.Windows.Forms.TabPage();
            this.butShowContainmentBuilder2 = new System.Windows.Forms.Button();
            this.cmdShowChildColBuilder = new System.Windows.Forms.Button();
            this.butEnsureAllChildLoaderSPs = new System.Windows.Forms.Button();
            this.txtSPForLoadChild = new System.Windows.Forms.TextBox();
            this.lbSPLoadChild = new System.Windows.Forms.LinkLabel();
            this.butCreateSPLoadChild = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.cmdCreateChild = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.lsChildren = new System.Windows.Forms.ListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabContainedObjects = new System.Windows.Forms.TabPage();
            this.butShowContainmentModel = new System.Windows.Forms.Button();
            this.cmdShowClassBuilderForParent = new System.Windows.Forms.Button();
            this.lsParentObjects = new System.Windows.Forms.ListBox();
            this.cmdShowContainedClassBuilder = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.cmdCreateContainedEntityObject = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.lsContainedEntityObjects = new System.Windows.Forms.ListBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tabBuildParamsMethods = new System.Windows.Forms.TabPage();
            this.cbSprocName = new System.Windows.Forms.ComboBox();
            this.lbProcNameLabel = new System.Windows.Forms.LinkLabel();
            this.butAddParamsOnlyMapped = new System.Windows.Forms.Button();
            this.butRemoveParamAll = new System.Windows.Forms.Button();
            this.butAddParamAll = new System.Windows.Forms.Button();
            this.cmdShowToStringMethod = new System.Windows.Forms.Button();
            this.chkNewMethod = new System.Windows.Forms.CheckBox();
            this.chkExecuteStoredProcMethod = new System.Windows.Forms.CheckBox();
            this.chkExecuteSQL = new System.Windows.Forms.CheckBox();
            this.chkExecuteReaderMethod = new System.Windows.Forms.CheckBox();
            this.chkConstructor = new System.Windows.Forms.CheckBox();
            this.butCreateParamsMethods = new System.Windows.Forms.Button();
            this.butCancel2 = new System.Windows.Forms.Button();
            this.lsAllFields = new System.Windows.Forms.ListBox();
            this.lsParams = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.butRemoveParam = new System.Windows.Forms.Button();
            this.butAddParam = new System.Windows.Forms.Button();
            this.chkLoad = new System.Windows.Forms.CheckBox();
            this.chkToStringMethod = new System.Windows.Forms.CheckBox();
            this.chkCalculateScriptMethod = new System.Windows.Forms.CheckBox();
            this.butSelectSPTemplate = new System.Windows.Forms.LinkLabel();
            this.tabCollections = new System.Windows.Forms.TabPage();
            this.cmdShowColBuilder = new System.Windows.Forms.Button();
            this.lsCollectionClasses = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.butCreateCollectionClass = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabOverrides = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.chkOverrideCRUDpassMembers = new System.Windows.Forms.CheckBox();
            this.butCreateOverridingMethods = new System.Windows.Forms.Button();
            this.butCancel6 = new System.Windows.Forms.Button();
            this.lstOverridables = new System.Windows.Forms.ListBox();
            this.lstOverriddenMethods = new System.Windows.Forms.ListBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.butRemoveOverridable = new System.Windows.Forms.Button();
            this.butAddOverridable = new System.Windows.Forms.Button();
            this.tabCodeGenOpt = new System.Windows.Forms.TabPage();
            this.butCreateSqlDataProp = new System.Windows.Forms.Button();
            this.chkEnsureSqlData = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkEnsureServerScript = new System.Windows.Forms.CheckBox();
            this.butCreateServerScriptProp = new System.Windows.Forms.Button();
            this.tabSQLHint = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.cmdFillFromColMapping = new System.Windows.Forms.Button();
            this.cmdShowSQLHintAttrib = new System.Windows.Forms.Button();
            this.butCreateSQLHintAttrib = new System.Windows.Forms.Button();
            this.butCancel5 = new System.Windows.Forms.Button();
            this.lsSQLHintCols = new System.Windows.Forms.ListBox();
            this.lsColumns2 = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.butAddHint = new System.Windows.Forms.Button();
            this.butRemoveAllHint = new System.Windows.Forms.Button();
            this.butRemoveHint = new System.Windows.Forms.Button();
            this.butAddAllHint = new System.Windows.Forms.Button();
            this.tabColMappingMode = new System.Windows.Forms.TabPage();
            this.label25 = new System.Windows.Forms.Label();
            this.butShowColsMapModeAttrib = new System.Windows.Forms.Button();
            this.butUpdateColMapMode = new System.Windows.Forms.Button();
            this.butCancel4 = new System.Windows.Forms.Button();
            this.chkMapNonPublic = new System.Windows.Forms.CheckBox();
            this.chkMapPublic = new System.Windows.Forms.CheckBox();
            this.chkMappedOnly = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lbPKMember = new System.Windows.Forms.Label();
            this.cmdReloadTable = new System.Windows.Forms.Button();
            this.cmdShowTableMappingAtt = new System.Windows.Forms.Button();
            this.cmdShowWebFormBuilder = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tab.SuspendLayout();
            this.tabColumnMapping.SuspendLayout();
            this.tabStoredProcs.SuspendLayout();
            this.tabDBMethods.SuspendLayout();
            this.tabChildren.SuspendLayout();
            this.tabContainedObjects.SuspendLayout();
            this.tabBuildParamsMethods.SuspendLayout();
            this.tabCollections.SuspendLayout();
            this.tabOverrides.SuspendLayout();
            this.tabCodeGenOpt.SuspendLayout();
            this.tabSQLHint.SuspendLayout();
            this.tabColMappingMode.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(10, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Table:";
            // 
            // cbTables
            // 
            this.cbTables.Location = new System.Drawing.Point(50, 72);
            this.cbTables.Name = "cbTables";
            this.cbTables.Size = new System.Drawing.Size(135, 21);
            this.cbTables.TabIndex = 2;
            this.cbTables.SelectedIndexChanged += new System.EventHandler(this.cbTables_SelectedIndexChanged);
            // 
            // lbHelp
            // 
            this.lbHelp.Location = new System.Drawing.Point(160, 8);
            this.lbHelp.Name = "lbHelp";
            this.lbHelp.Size = new System.Drawing.Size(400, 56);
            this.lbHelp.TabIndex = 3;
            this.lbHelp.Text = "lbHelp";
            // 
            // butCancel
            // 
            this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel.Location = new System.Drawing.Point(352, 216);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 4;
            this.butCancel.Text = "Close";
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // butUpdateMembers
            // 
            this.butUpdateMembers.Location = new System.Drawing.Point(432, 216);
            this.butUpdateMembers.Name = "butUpdateMembers";
            this.butUpdateMembers.Size = new System.Drawing.Size(75, 23);
            this.butUpdateMembers.TabIndex = 5;
            this.butUpdateMembers.Text = "Create";
            this.butUpdateMembers.Click += new System.EventHandler(this.butUpdateMembers_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // butAdd
            // 
            this.butAdd.Enabled = false;
            this.butAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAdd.Location = new System.Drawing.Point(240, 24);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(40, 24);
            this.butAdd.TabIndex = 14;
            this.butAdd.Text = ">";
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // lsMembers
            // 
            this.lsMembers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsMembers.Location = new System.Drawing.Point(296, 24);
            this.lsMembers.Name = "lsMembers";
            this.lsMembers.Size = new System.Drawing.Size(208, 132);
            this.lsMembers.TabIndex = 11;
            this.lsMembers.DoubleClick += new System.EventHandler(this.lsMembers_DoubleClick);
            this.lsMembers.SelectedIndexChanged += new System.EventHandler(this.lsMembers_SelectedIndexChanged);
            // 
            // lsColumns
            // 
            this.lsColumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsColumns.Location = new System.Drawing.Point(16, 24);
            this.lsColumns.Name = "lsColumns";
            this.lsColumns.Size = new System.Drawing.Size(208, 132);
            this.lsColumns.TabIndex = 10;
            this.lsColumns.DoubleClick += new System.EventHandler(this.lsColumns_DoubleClick);
            this.lsColumns.SelectedIndexChanged += new System.EventHandler(this.lsColumns_SelectedIndexChanged);
            // 
            // butRemove
            // 
            this.butRemove.Enabled = false;
            this.butRemove.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemove.Location = new System.Drawing.Point(240, 48);
            this.butRemove.Name = "butRemove";
            this.butRemove.Size = new System.Drawing.Size(40, 24);
            this.butRemove.TabIndex = 15;
            this.butRemove.Text = "<";
            this.butRemove.Click += new System.EventHandler(this.butRemove_Click);
            // 
            // butAddAll
            // 
            this.butAddAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddAll.Location = new System.Drawing.Point(240, 72);
            this.butAddAll.Name = "butAddAll";
            this.butAddAll.Size = new System.Drawing.Size(40, 24);
            this.butAddAll.TabIndex = 12;
            this.butAddAll.Text = ">>";
            this.butAddAll.Click += new System.EventHandler(this.butAddAll_Click);
            // 
            // butRemoveAll
            // 
            this.butRemoveAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveAll.Location = new System.Drawing.Point(240, 96);
            this.butRemoveAll.Name = "butRemoveAll";
            this.butRemoveAll.Size = new System.Drawing.Size(40, 24);
            this.butRemoveAll.TabIndex = 13;
            this.butRemoveAll.Text = "<<";
            this.butRemoveAll.Click += new System.EventHandler(this.butRemoveAll_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(240, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 16;
            this.label3.Text = "Class:";
            // 
            // lbClassName
            // 
            this.lbClassName.Location = new System.Drawing.Point(304, 64);
            this.lbClassName.Name = "lbClassName";
            this.lbClassName.Size = new System.Drawing.Size(240, 16);
            this.lbClassName.TabIndex = 17;
            this.lbClassName.Text = "lbClassName";
            // 
            // chkExplicitAttribs
            // 
            this.chkExplicitAttribs.Checked = true;
            this.chkExplicitAttribs.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkExplicitAttribs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExplicitAttribs.Location = new System.Drawing.Point(16, 160);
            this.chkExplicitAttribs.Name = "chkExplicitAttribs";
            this.chkExplicitAttribs.Size = new System.Drawing.Size(184, 24);
            this.chkExplicitAttribs.TabIndex = 18;
            this.chkExplicitAttribs.Text = "Use Explicit Mapping Attributes";
            // 
            // cbAccessLevel
            // 
            this.cbAccessLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAccessLevel.Items.AddRange(new object[] {
            "Public",
            "Internal",
            "Protected",
            "Private"});
            this.cbAccessLevel.Location = new System.Drawing.Point(248, 168);
            this.cbAccessLevel.Name = "cbAccessLevel";
            this.cbAccessLevel.Size = new System.Drawing.Size(96, 21);
            this.cbAccessLevel.TabIndex = 19;
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabColumnMapping);
            this.tab.Controls.Add(this.tabStoredProcs);
            this.tab.Controls.Add(this.tabDBMethods);
            this.tab.Controls.Add(this.tabChildren);
            this.tab.Controls.Add(this.tabContainedObjects);
            this.tab.Controls.Add(this.tabBuildParamsMethods);
            this.tab.Controls.Add(this.tabCollections);
            this.tab.Controls.Add(this.tabOverrides);
            this.tab.Controls.Add(this.tabCodeGenOpt);
            this.tab.Controls.Add(this.tabSQLHint);
            this.tab.Controls.Add(this.tabColMappingMode);
            this.tab.HotTrack = true;
            this.tab.Location = new System.Drawing.Point(8, 112);
            this.tab.Multiline = true;
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(528, 288);
            this.tab.TabIndex = 20;
            this.tab.SelectedIndexChanged += new System.EventHandler(this.tab_SelectedIndexChanged);
            // 
            // tabColumnMapping
            // 
            this.tabColumnMapping.Controls.Add(this.butCancel);
            this.tabColumnMapping.Controls.Add(this.chkColumnNameConstants);
            this.tabColumnMapping.Controls.Add(this.chkIntsAreFKs);
            this.tabColumnMapping.Controls.Add(this.lsInvalidMappings);
            this.tabColumnMapping.Controls.Add(this.chkShowInvalidMappings);
            this.tabColumnMapping.Controls.Add(this.chkCreateProps);
            this.tabColumnMapping.Controls.Add(this.txtPrefix);
            this.tabColumnMapping.Controls.Add(this.label9);
            this.tabColumnMapping.Controls.Add(this.chkCamelNotation);
            this.tabColumnMapping.Controls.Add(this.lsMembers);
            this.tabColumnMapping.Controls.Add(this.lsColumns);
            this.tabColumnMapping.Controls.Add(this.label5);
            this.tabColumnMapping.Controls.Add(this.label4);
            this.tabColumnMapping.Controls.Add(this.butAdd);
            this.tabColumnMapping.Controls.Add(this.butRemoveAll);
            this.tabColumnMapping.Controls.Add(this.butRemove);
            this.tabColumnMapping.Controls.Add(this.butAddAll);
            this.tabColumnMapping.Controls.Add(this.chkExplicitAttribs);
            this.tabColumnMapping.Controls.Add(this.cbAccessLevel);
            this.tabColumnMapping.Controls.Add(this.butUpdateMembers);
            this.tabColumnMapping.Controls.Add(this.label12);
            this.tabColumnMapping.Location = new System.Drawing.Point(4, 40);
            this.tabColumnMapping.Name = "tabColumnMapping";
            this.tabColumnMapping.Size = new System.Drawing.Size(520, 244);
            this.tabColumnMapping.TabIndex = 0;
            this.tabColumnMapping.Text = "Column Mapping";
            this.tabColumnMapping.ToolTipText = "Please select columns to map in this class.  This wizard never removes any items " +
                "from your class, but adds newly selected items if they do not exist int the clas" +
                "s.";
            // 
            // chkColumnNameConstants
            // 
            this.chkColumnNameConstants.Checked = true;
            this.chkColumnNameConstants.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnNameConstants.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkColumnNameConstants.Location = new System.Drawing.Point(203, 224);
            this.chkColumnNameConstants.Name = "chkColumnNameConstants";
            this.chkColumnNameConstants.Size = new System.Drawing.Size(150, 16);
            this.chkColumnNameConstants.TabIndex = 31;
            this.chkColumnNameConstants.Text = "Column Name Constants";
            // 
            // chkIntsAreFKs
            // 
            this.chkIntsAreFKs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkIntsAreFKs.Location = new System.Drawing.Point(16, 224);
            this.chkIntsAreFKs.Name = "chkIntsAreFKs";
            this.chkIntsAreFKs.Size = new System.Drawing.Size(136, 16);
            this.chkIntsAreFKs.TabIndex = 30;
            this.chkIntsAreFKs.Text = "Declare Ints as FKs";
            // 
            // lsInvalidMappings
            // 
            this.lsInvalidMappings.BackColor = System.Drawing.Color.Wheat;
            this.lsInvalidMappings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsInvalidMappings.ForeColor = System.Drawing.Color.Red;
            this.lsInvalidMappings.Location = new System.Drawing.Point(320, 40);
            this.lsInvalidMappings.Name = "lsInvalidMappings";
            this.lsInvalidMappings.Size = new System.Drawing.Size(192, 119);
            this.lsInvalidMappings.TabIndex = 28;
            this.lsInvalidMappings.Visible = false;
            this.lsInvalidMappings.SelectedIndexChanged += new System.EventHandler(this.lsInvalidMappings_SelectedIndexChanged);
            // 
            // chkShowInvalidMappings
            // 
            this.chkShowInvalidMappings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkShowInvalidMappings.ForeColor = System.Drawing.Color.Red;
            this.chkShowInvalidMappings.Location = new System.Drawing.Point(397, 162);
            this.chkShowInvalidMappings.Name = "chkShowInvalidMappings";
            this.chkShowInvalidMappings.Size = new System.Drawing.Size(112, 24);
            this.chkShowInvalidMappings.TabIndex = 29;
            this.chkShowInvalidMappings.Text = "Invalid Mappings";
            this.chkShowInvalidMappings.Visible = false;
            this.chkShowInvalidMappings.CheckedChanged += new System.EventHandler(this.chkShowInvalidMappings_CheckedChanged);
            // 
            // chkCreateProps
            // 
            this.chkCreateProps.Checked = true;
            this.chkCreateProps.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCreateProps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkCreateProps.Location = new System.Drawing.Point(16, 200);
            this.chkCreateProps.Name = "chkCreateProps";
            this.chkCreateProps.Size = new System.Drawing.Size(152, 24);
            this.chkCreateProps.TabIndex = 25;
            this.chkCreateProps.Text = "Create Public Properties";
            // 
            // txtPrefix
            // 
            this.txtPrefix.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrefix.Location = new System.Drawing.Point(248, 192);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.Size = new System.Drawing.Size(80, 20);
            this.txtPrefix.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(200, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 23);
            this.label9.TabIndex = 24;
            this.label9.Text = "Prefix:";
            // 
            // chkCamelNotation
            // 
            this.chkCamelNotation.Checked = true;
            this.chkCamelNotation.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCamelNotation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkCamelNotation.Location = new System.Drawing.Point(16, 179);
            this.chkCamelNotation.Name = "chkCamelNotation";
            this.chkCamelNotation.Size = new System.Drawing.Size(144, 24);
            this.chkCamelNotation.TabIndex = 22;
            this.chkCamelNotation.Text = "Use camelNotation";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(296, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 21;
            this.label5.Text = "Mapped Columns:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 20;
            this.label4.Text = "Table Columns:";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(200, 168);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.TabIndex = 26;
            this.label12.Text = "Access:";
            // 
            // tabStoredProcs
            // 
            this.tabStoredProcs.Controls.Add(this.butPossibleInvalidAutoGenSPs);
            this.tabStoredProcs.Controls.Add(this.butManageAutoGenSPs);
            this.tabStoredProcs.Controls.Add(this.chkAutoGenSPs);
            this.tabStoredProcs.Controls.Add(this.butPossibleInvalidLoadSP);
            this.tabStoredProcs.Controls.Add(this.chkDeclareSPAtt);
            this.tabStoredProcs.Controls.Add(this.butMismatchedUpdateParams);
            this.tabStoredProcs.Controls.Add(this.butMismatchedInsertParams);
            this.tabStoredProcs.Controls.Add(this.txtPreviewCRUDsps);
            this.tabStoredProcs.Controls.Add(this.cmdCancel6);
            this.tabStoredProcs.Controls.Add(this.cmdDropCRUDsp);
            this.tabStoredProcs.Controls.Add(this.chkRecreateCRUDsps);
            this.tabStoredProcs.Controls.Add(this.cmdCreateCRUDsps);
            this.tabStoredProcs.Controls.Add(this.cmdShowSPforInsert);
            this.tabStoredProcs.Controls.Add(this.chkAllCRUDsps);
            this.tabStoredProcs.Controls.Add(this.chkSPforDelete);
            this.tabStoredProcs.Controls.Add(this.chkSPforUpdate);
            this.tabStoredProcs.Controls.Add(this.chkSPforInsert);
            this.tabStoredProcs.Controls.Add(this.cmdShowSPforUpdate);
            this.tabStoredProcs.Controls.Add(this.cmdShowSPforDelete);
            this.tabStoredProcs.Controls.Add(this.cmdShowSPforLoad);
            this.tabStoredProcs.Controls.Add(this.chkSPforLoad);
            this.tabStoredProcs.Controls.Add(this.chkSPforExists);
            this.tabStoredProcs.Controls.Add(this.cmdShowSPforExists);
            this.tabStoredProcs.Controls.Add(this.chkAllStoredProcs);
            this.tabStoredProcs.Controls.Add(this.lbCRUDspname);
            this.tabStoredProcs.Controls.Add(this.label15);
            this.tabStoredProcs.Controls.Add(this.chkPreviewOnly);
            this.tabStoredProcs.Location = new System.Drawing.Point(4, 40);
            this.tabStoredProcs.Name = "tabStoredProcs";
            this.tabStoredProcs.Size = new System.Drawing.Size(520, 244);
            this.tabStoredProcs.TabIndex = 7;
            this.tabStoredProcs.Text = "Stored Procs";
            this.tabStoredProcs.ToolTipText = "Generate stored procedures in the database for CRUD operations.  Existing procedu" +
                "res will not be recreated unless specified.";
            // 
            // butPossibleInvalidAutoGenSPs
            // 
            this.butPossibleInvalidAutoGenSPs.Location = new System.Drawing.Point(176, 188);
            this.butPossibleInvalidAutoGenSPs.Name = "butPossibleInvalidAutoGenSPs";
            this.butPossibleInvalidAutoGenSPs.Size = new System.Drawing.Size(14, 16);
            this.butPossibleInvalidAutoGenSPs.TabIndex = 46;
            this.butPossibleInvalidAutoGenSPs.TabStop = true;
            this.butPossibleInvalidAutoGenSPs.Text = "?";
            this.butPossibleInvalidAutoGenSPs.Visible = false;
            this.butPossibleInvalidAutoGenSPs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butPossibleInvalidAutoGenSPs_LinkClicked);
            // 
            // butManageAutoGenSPs
            // 
            this.butManageAutoGenSPs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butManageAutoGenSPs.Location = new System.Drawing.Point(16, 188);
            this.butManageAutoGenSPs.Name = "butManageAutoGenSPs";
            this.butManageAutoGenSPs.Size = new System.Drawing.Size(56, 23);
            this.butManageAutoGenSPs.TabIndex = 45;
            this.butManageAutoGenSPs.Text = "Manage";
            this.butManageAutoGenSPs.Click += new System.EventHandler(this.butManageAutoGenSPs_Click);
            // 
            // chkAutoGenSPs
            // 
            this.chkAutoGenSPs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAutoGenSPs.Location = new System.Drawing.Point(80, 184);
            this.chkAutoGenSPs.Name = "chkAutoGenSPs";
            this.chkAutoGenSPs.Size = new System.Drawing.Size(112, 32);
            this.chkAutoGenSPs.TabIndex = 44;
            this.chkAutoGenSPs.Text = "Declared Auto-Generated SPs";
            this.chkAutoGenSPs.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // butPossibleInvalidLoadSP
            // 
            this.butPossibleInvalidLoadSP.Location = new System.Drawing.Point(174, 69);
            this.butPossibleInvalidLoadSP.Name = "butPossibleInvalidLoadSP";
            this.butPossibleInvalidLoadSP.Size = new System.Drawing.Size(14, 16);
            this.butPossibleInvalidLoadSP.TabIndex = 43;
            this.butPossibleInvalidLoadSP.TabStop = true;
            this.butPossibleInvalidLoadSP.Text = "?";
            this.butPossibleInvalidLoadSP.Visible = false;
            this.butPossibleInvalidLoadSP.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butPossibleInvalidLoadSP_LinkClicked);
            // 
            // chkDeclareSPAtt
            // 
            this.chkDeclareSPAtt.Checked = true;
            this.chkDeclareSPAtt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDeclareSPAtt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkDeclareSPAtt.Location = new System.Drawing.Point(24, 216);
            this.chkDeclareSPAtt.Name = "chkDeclareSPAtt";
            this.chkDeclareSPAtt.Size = new System.Drawing.Size(160, 24);
            this.chkDeclareSPAtt.TabIndex = 42;
            this.chkDeclareSPAtt.Text = "Declare SP Attributes";
            // 
            // butMismatchedUpdateParams
            // 
            this.butMismatchedUpdateParams.Location = new System.Drawing.Point(159, 115);
            this.butMismatchedUpdateParams.Name = "butMismatchedUpdateParams";
            this.butMismatchedUpdateParams.Size = new System.Drawing.Size(17, 16);
            this.butMismatchedUpdateParams.TabIndex = 41;
            this.butMismatchedUpdateParams.TabStop = true;
            this.butMismatchedUpdateParams.Text = "?";
            this.butMismatchedUpdateParams.Visible = false;
            this.butMismatchedUpdateParams.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butMismatchedUpdateParams_LinkClicked);
            // 
            // butMismatchedInsertParams
            // 
            this.butMismatchedInsertParams.Location = new System.Drawing.Point(146, 92);
            this.butMismatchedInsertParams.Name = "butMismatchedInsertParams";
            this.butMismatchedInsertParams.Size = new System.Drawing.Size(14, 16);
            this.butMismatchedInsertParams.TabIndex = 39;
            this.butMismatchedInsertParams.TabStop = true;
            this.butMismatchedInsertParams.Text = "?";
            this.butMismatchedInsertParams.Visible = false;
            this.butMismatchedInsertParams.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butMismatchedInsertParams_LinkClicked);
            // 
            // txtPreviewCRUDsps
            // 
            this.txtPreviewCRUDsps.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtPreviewCRUDsps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPreviewCRUDsps.Location = new System.Drawing.Point(192, 32);
            this.txtPreviewCRUDsps.Name = "txtPreviewCRUDsps";
            this.txtPreviewCRUDsps.ReadOnly = true;
            this.txtPreviewCRUDsps.Size = new System.Drawing.Size(312, 168);
            this.txtPreviewCRUDsps.TabIndex = 38;
            this.txtPreviewCRUDsps.Text = "";
            this.txtPreviewCRUDsps.WordWrap = false;
            // 
            // cmdCancel6
            // 
            this.cmdCancel6.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel6.Location = new System.Drawing.Point(352, 216);
            this.cmdCancel6.Name = "cmdCancel6";
            this.cmdCancel6.Size = new System.Drawing.Size(75, 23);
            this.cmdCancel6.TabIndex = 31;
            this.cmdCancel6.Text = "Close";
            this.cmdCancel6.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // cmdDropCRUDsp
            // 
            this.cmdDropCRUDsp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdDropCRUDsp.Location = new System.Drawing.Point(432, 8);
            this.cmdDropCRUDsp.Name = "cmdDropCRUDsp";
            this.cmdDropCRUDsp.Size = new System.Drawing.Size(72, 23);
            this.cmdDropCRUDsp.TabIndex = 35;
            this.cmdDropCRUDsp.Text = "Drop this";
            this.cmdDropCRUDsp.Click += new System.EventHandler(this.cmdDropCRUDsp_Click);
            // 
            // chkRecreateCRUDsps
            // 
            this.chkRecreateCRUDsps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkRecreateCRUDsps.Location = new System.Drawing.Point(192, 205);
            this.chkRecreateCRUDsps.Name = "chkRecreateCRUDsps";
            this.chkRecreateCRUDsps.Size = new System.Drawing.Size(176, 16);
            this.chkRecreateCRUDsps.TabIndex = 34;
            this.chkRecreateCRUDsps.Text = "Recreate existing procedures";
            // 
            // cmdCreateCRUDsps
            // 
            this.cmdCreateCRUDsps.Location = new System.Drawing.Point(432, 216);
            this.cmdCreateCRUDsps.Name = "cmdCreateCRUDsps";
            this.cmdCreateCRUDsps.Size = new System.Drawing.Size(75, 23);
            this.cmdCreateCRUDsps.TabIndex = 32;
            this.cmdCreateCRUDsps.Text = "Create";
            this.cmdCreateCRUDsps.Click += new System.EventHandler(this.cmdCreateCRUDsps_Click);
            // 
            // cmdShowSPforInsert
            // 
            this.cmdShowSPforInsert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSPforInsert.Location = new System.Drawing.Point(16, 88);
            this.cmdShowSPforInsert.Name = "cmdShowSPforInsert";
            this.cmdShowSPforInsert.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSPforInsert.TabIndex = 23;
            this.cmdShowSPforInsert.Text = "Show";
            this.cmdShowSPforInsert.Visible = false;
            this.cmdShowSPforInsert.Click += new System.EventHandler(this.cmdShowSPforInsert_Click);
            // 
            // chkAllCRUDsps
            // 
            this.chkAllCRUDsps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllCRUDsps.Location = new System.Drawing.Point(40, 40);
            this.chkAllCRUDsps.Name = "chkAllCRUDsps";
            this.chkAllCRUDsps.Size = new System.Drawing.Size(152, 24);
            this.chkAllCRUDsps.TabIndex = 29;
            this.chkAllCRUDsps.Text = "All CRUD Procedures";
            this.chkAllCRUDsps.Click += new System.EventHandler(this.chkAllCRUDsps_Click);
            // 
            // chkSPforDelete
            // 
            this.chkSPforDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSPforDelete.Location = new System.Drawing.Point(64, 136);
            this.chkSPforDelete.Name = "chkSPforDelete";
            this.chkSPforDelete.Size = new System.Drawing.Size(160, 24);
            this.chkSPforDelete.TabIndex = 19;
            this.chkSPforDelete.Text = "SP for Delete By PK";
            this.chkSPforDelete.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // chkSPforUpdate
            // 
            this.chkSPforUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSPforUpdate.Location = new System.Drawing.Point(64, 112);
            this.chkSPforUpdate.Name = "chkSPforUpdate";
            this.chkSPforUpdate.Size = new System.Drawing.Size(160, 24);
            this.chkSPforUpdate.TabIndex = 17;
            this.chkSPforUpdate.Text = "SP for Update";
            this.chkSPforUpdate.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // chkSPforInsert
            // 
            this.chkSPforInsert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSPforInsert.Location = new System.Drawing.Point(64, 88);
            this.chkSPforInsert.Name = "chkSPforInsert";
            this.chkSPforInsert.Size = new System.Drawing.Size(160, 24);
            this.chkSPforInsert.TabIndex = 14;
            this.chkSPforInsert.Text = "SP for Insert";
            this.chkSPforInsert.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // cmdShowSPforUpdate
            // 
            this.cmdShowSPforUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSPforUpdate.Location = new System.Drawing.Point(16, 112);
            this.cmdShowSPforUpdate.Name = "cmdShowSPforUpdate";
            this.cmdShowSPforUpdate.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSPforUpdate.TabIndex = 25;
            this.cmdShowSPforUpdate.Text = "Show";
            this.cmdShowSPforUpdate.Visible = false;
            this.cmdShowSPforUpdate.Click += new System.EventHandler(this.cmdShowSPforUpdate_Click);
            // 
            // cmdShowSPforDelete
            // 
            this.cmdShowSPforDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSPforDelete.Location = new System.Drawing.Point(16, 136);
            this.cmdShowSPforDelete.Name = "cmdShowSPforDelete";
            this.cmdShowSPforDelete.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSPforDelete.TabIndex = 27;
            this.cmdShowSPforDelete.Text = "Show";
            this.cmdShowSPforDelete.Visible = false;
            this.cmdShowSPforDelete.Click += new System.EventHandler(this.cmdShowSPforDelete_Click);
            // 
            // cmdShowSPforLoad
            // 
            this.cmdShowSPforLoad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSPforLoad.Location = new System.Drawing.Point(16, 64);
            this.cmdShowSPforLoad.Name = "cmdShowSPforLoad";
            this.cmdShowSPforLoad.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSPforLoad.TabIndex = 21;
            this.cmdShowSPforLoad.Text = "Show";
            this.cmdShowSPforLoad.Visible = false;
            this.cmdShowSPforLoad.Click += new System.EventHandler(this.cmdShowSPforLoad_Click);
            // 
            // chkSPforLoad
            // 
            this.chkSPforLoad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSPforLoad.Location = new System.Drawing.Point(64, 64);
            this.chkSPforLoad.Name = "chkSPforLoad";
            this.chkSPforLoad.Size = new System.Drawing.Size(160, 24);
            this.chkSPforLoad.TabIndex = 13;
            this.chkSPforLoad.Text = "SP for Load By PK";
            this.chkSPforLoad.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // chkSPforExists
            // 
            this.chkSPforExists.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSPforExists.Location = new System.Drawing.Point(64, 162);
            this.chkSPforExists.Name = "chkSPforExists";
            this.chkSPforExists.Size = new System.Drawing.Size(160, 24);
            this.chkSPforExists.TabIndex = 19;
            this.chkSPforExists.Text = "SP for Exists By PK";
            this.chkSPforExists.Click += new System.EventHandler(this.chkSPforDelete_Click);
            // 
            // cmdShowSPforExists
            // 
            this.cmdShowSPforExists.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSPforExists.Location = new System.Drawing.Point(16, 162);
            this.cmdShowSPforExists.Name = "cmdShowSPforExists";
            this.cmdShowSPforExists.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSPforExists.TabIndex = 27;
            this.cmdShowSPforExists.Text = "Show";
            this.cmdShowSPforExists.Visible = false;
            this.cmdShowSPforExists.Click += new System.EventHandler(this.cmdShowSPforExists_Click);
            // 
            // chkAllStoredProcs
            // 
            this.chkAllStoredProcs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllStoredProcs.Location = new System.Drawing.Point(16, 16);
            this.chkAllStoredProcs.Name = "chkAllStoredProcs";
            this.chkAllStoredProcs.Size = new System.Drawing.Size(176, 24);
            this.chkAllStoredProcs.TabIndex = 29;
            this.chkAllStoredProcs.Text = "All Stored Procedures";
            this.chkAllStoredProcs.CheckedChanged += new System.EventHandler(this.chkAllStoredProcs_CheckedChanged);
            // 
            // lbCRUDspname
            // 
            this.lbCRUDspname.Location = new System.Drawing.Point(280, 15);
            this.lbCRUDspname.Name = "lbCRUDspname";
            this.lbCRUDspname.Size = new System.Drawing.Size(224, 18);
            this.lbCRUDspname.TabIndex = 37;
            this.lbCRUDspname.TabStop = true;
            this.lbCRUDspname.Text = "Procedure:";
            this.lbCRUDspname.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbCRUDspname_LinkClicked);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(192, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 23);
            this.label15.TabIndex = 33;
            this.label15.Text = "Stored Procedure:";
            // 
            // chkPreviewOnly
            // 
            this.chkPreviewOnly.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkPreviewOnly.Location = new System.Drawing.Point(192, 224);
            this.chkPreviewOnly.Name = "chkPreviewOnly";
            this.chkPreviewOnly.Size = new System.Drawing.Size(184, 16);
            this.chkPreviewOnly.TabIndex = 47;
            this.chkPreviewOnly.Text = "Preview Only/No save to DB";
            // 
            // tabDBMethods
            // 
            this.tabDBMethods.Controls.Add(this.butCreateCRUDTester);
            this.tabDBMethods.Controls.Add(this.chkSynchronizeMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowSynchronizeMethod);
            this.tabDBMethods.Controls.Add(this.cmdCreateTest);
            this.tabDBMethods.Controls.Add(this.cmdCreateTestForRead);
            this.tabDBMethods.Controls.Add(this.cmdCreateTestForReadCol);
            this.tabDBMethods.Controls.Add(this.chkAllUtilityMethods);
            this.tabDBMethods.Controls.Add(this.cmdShowInsertMethod);
            this.tabDBMethods.Controls.Add(this.chkAllDBMethods);
            this.tabDBMethods.Controls.Add(this.butCreateDBMethods);
            this.tabDBMethods.Controls.Add(this.butCancel3);
            this.tabDBMethods.Controls.Add(this.chkDeleteMethod);
            this.tabDBMethods.Controls.Add(this.chkDeleteByPKMethod);
            this.tabDBMethods.Controls.Add(this.chkSaveMethod);
            this.tabDBMethods.Controls.Add(this.chkUpdateMethod);
            this.tabDBMethods.Controls.Add(this.chkInsertMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowUpdateMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowSaveMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowDeleteByPKMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowDeleteMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowLoadByPKMethod);
            this.tabDBMethods.Controls.Add(this.chkLoadByPKMethod);
            this.tabDBMethods.Controls.Add(this.chkReadMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowReadMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowReadColMethod);
            this.tabDBMethods.Controls.Add(this.chkReadColMethod);
            this.tabDBMethods.Controls.Add(this.chkLoadFromDataRowView);
            this.tabDBMethods.Controls.Add(this.chkSaveToDataRowView);
            this.tabDBMethods.Controls.Add(this.cmdShowLoadFromDataRowView);
            this.tabDBMethods.Controls.Add(this.cmdShowSaveToDataRowView);
            this.tabDBMethods.Controls.Add(this.chkExistsByPK);
            this.tabDBMethods.Controls.Add(this.chkExists);
            this.tabDBMethods.Controls.Add(this.cmdShowExistsByPK);
            this.tabDBMethods.Controls.Add(this.cmdShowExists);
            this.tabDBMethods.Location = new System.Drawing.Point(4, 40);
            this.tabDBMethods.Name = "tabDBMethods";
            this.tabDBMethods.Size = new System.Drawing.Size(520, 244);
            this.tabDBMethods.TabIndex = 2;
            this.tabDBMethods.Text = "DB Methods";
            this.tabDBMethods.ToolTipText = resources.GetString("tabDBMethods.ToolTipText");
            // 
            // butCreateCRUDTester
            // 
            this.butCreateCRUDTester.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butCreateCRUDTester.Location = new System.Drawing.Point(352, 184);
            this.butCreateCRUDTester.Name = "butCreateCRUDTester";
            this.butCreateCRUDTester.Size = new System.Drawing.Size(152, 23);
            this.butCreateCRUDTester.TabIndex = 19;
            this.butCreateCRUDTester.Text = "Create CRUD Tester";
            this.butCreateCRUDTester.Click += new System.EventHandler(this.butCreateCRUDTester_Click);
            // 
            // chkSynchronizeMethod
            // 
            this.chkSynchronizeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSynchronizeMethod.Location = new System.Drawing.Point(64, 216);
            this.chkSynchronizeMethod.Name = "chkSynchronizeMethod";
            this.chkSynchronizeMethod.Size = new System.Drawing.Size(160, 24);
            this.chkSynchronizeMethod.TabIndex = 18;
            this.chkSynchronizeMethod.Text = "Synchronize Method";
            this.chkSynchronizeMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // cmdShowSynchronizeMethod
            // 
            this.cmdShowSynchronizeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSynchronizeMethod.Location = new System.Drawing.Point(16, 216);
            this.cmdShowSynchronizeMethod.Name = "cmdShowSynchronizeMethod";
            this.cmdShowSynchronizeMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSynchronizeMethod.TabIndex = 17;
            this.cmdShowSynchronizeMethod.Text = "Show";
            this.cmdShowSynchronizeMethod.Visible = false;
            this.cmdShowSynchronizeMethod.Click += new System.EventHandler(this.cmdShowSynchronizeMethod_Click);
            // 
            // cmdCreateTest
            // 
            this.cmdCreateTest.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTest.Location = new System.Drawing.Point(208, 24);
            this.cmdCreateTest.Name = "cmdCreateTest";
            this.cmdCreateTest.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTest.TabIndex = 14;
            this.cmdCreateTest.Text = "Create Tester";
            this.cmdCreateTest.Click += new System.EventHandler(this.cmdCreateTest_Click);
            // 
            // cmdCreateTestForRead
            // 
            this.cmdCreateTestForRead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTestForRead.Location = new System.Drawing.Point(208, 48);
            this.cmdCreateTestForRead.Name = "cmdCreateTestForRead";
            this.cmdCreateTestForRead.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTestForRead.TabIndex = 14;
            this.cmdCreateTestForRead.Text = "Create Tester";
            this.cmdCreateTestForRead.Click += new System.EventHandler(this.cmdCreateTestForRead_Click);
            // 
            // cmdCreateTestForReadCol
            // 
            this.cmdCreateTestForReadCol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTestForReadCol.Location = new System.Drawing.Point(208, 72);
            this.cmdCreateTestForReadCol.Name = "cmdCreateTestForReadCol";
            this.cmdCreateTestForReadCol.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTestForReadCol.TabIndex = 14;
            this.cmdCreateTestForReadCol.Text = "Create Tester";
            this.cmdCreateTestForReadCol.Click += new System.EventHandler(this.cmdCreateTestForReadCol_Click);
            // 
            // chkAllUtilityMethods
            // 
            this.chkAllUtilityMethods.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllUtilityMethods.Location = new System.Drawing.Point(304, 16);
            this.chkAllUtilityMethods.Name = "chkAllUtilityMethods";
            this.chkAllUtilityMethods.Size = new System.Drawing.Size(168, 24);
            this.chkAllUtilityMethods.TabIndex = 15;
            this.chkAllUtilityMethods.Text = "All Utility Methods";
            this.chkAllUtilityMethods.CheckedChanged += new System.EventHandler(this.chkAllUtilityMethods_CheckedChanged);
            // 
            // cmdShowInsertMethod
            // 
            this.cmdShowInsertMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowInsertMethod.Location = new System.Drawing.Point(16, 96);
            this.cmdShowInsertMethod.Name = "cmdShowInsertMethod";
            this.cmdShowInsertMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowInsertMethod.TabIndex = 7;
            this.cmdShowInsertMethod.Text = "Show";
            this.cmdShowInsertMethod.Visible = false;
            this.cmdShowInsertMethod.Click += new System.EventHandler(this.cmdShowInsertMethod_Click);
            // 
            // chkAllDBMethods
            // 
            this.chkAllDBMethods.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllDBMethods.Location = new System.Drawing.Point(16, 6);
            this.chkAllDBMethods.Name = "chkAllDBMethods";
            this.chkAllDBMethods.Size = new System.Drawing.Size(96, 16);
            this.chkAllDBMethods.TabIndex = 12;
            this.chkAllDBMethods.Text = "All Methods";
            this.chkAllDBMethods.CheckedChanged += new System.EventHandler(this.chkAllDBMethods_CheckedChanged);
            // 
            // butCreateDBMethods
            // 
            this.butCreateDBMethods.Location = new System.Drawing.Point(432, 216);
            this.butCreateDBMethods.Name = "butCreateDBMethods";
            this.butCreateDBMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateDBMethods.TabIndex = 14;
            this.butCreateDBMethods.Text = "Create";
            this.butCreateDBMethods.Click += new System.EventHandler(this.butCreateDBMethods_Click);
            // 
            // butCancel3
            // 
            this.butCancel3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel3.Location = new System.Drawing.Point(352, 216);
            this.butCancel3.Name = "butCancel3";
            this.butCancel3.Size = new System.Drawing.Size(75, 23);
            this.butCancel3.TabIndex = 13;
            this.butCancel3.Text = "Close";
            this.butCancel3.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // chkDeleteMethod
            // 
            this.chkDeleteMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkDeleteMethod.Location = new System.Drawing.Point(64, 192);
            this.chkDeleteMethod.Name = "chkDeleteMethod";
            this.chkDeleteMethod.Size = new System.Drawing.Size(160, 24);
            this.chkDeleteMethod.TabIndex = 5;
            this.chkDeleteMethod.Text = "Delete Method";
            this.chkDeleteMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkDeleteByPKMethod
            // 
            this.chkDeleteByPKMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkDeleteByPKMethod.Location = new System.Drawing.Point(64, 168);
            this.chkDeleteByPKMethod.Name = "chkDeleteByPKMethod";
            this.chkDeleteByPKMethod.Size = new System.Drawing.Size(160, 24);
            this.chkDeleteByPKMethod.TabIndex = 4;
            this.chkDeleteByPKMethod.Text = "Delete By PK Method";
            this.chkDeleteByPKMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkSaveMethod
            // 
            this.chkSaveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSaveMethod.Location = new System.Drawing.Point(64, 144);
            this.chkSaveMethod.Name = "chkSaveMethod";
            this.chkSaveMethod.Size = new System.Drawing.Size(168, 24);
            this.chkSaveMethod.TabIndex = 3;
            this.chkSaveMethod.Text = "Save Method (Insert/Update)";
            this.chkSaveMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkUpdateMethod
            // 
            this.chkUpdateMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkUpdateMethod.Location = new System.Drawing.Point(64, 120);
            this.chkUpdateMethod.Name = "chkUpdateMethod";
            this.chkUpdateMethod.Size = new System.Drawing.Size(160, 24);
            this.chkUpdateMethod.TabIndex = 2;
            this.chkUpdateMethod.Text = "Update Method";
            this.chkUpdateMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkInsertMethod
            // 
            this.chkInsertMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkInsertMethod.Location = new System.Drawing.Point(64, 96);
            this.chkInsertMethod.Name = "chkInsertMethod";
            this.chkInsertMethod.Size = new System.Drawing.Size(160, 24);
            this.chkInsertMethod.TabIndex = 1;
            this.chkInsertMethod.Text = "Insert Method";
            this.chkInsertMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // cmdShowUpdateMethod
            // 
            this.cmdShowUpdateMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowUpdateMethod.Location = new System.Drawing.Point(16, 120);
            this.cmdShowUpdateMethod.Name = "cmdShowUpdateMethod";
            this.cmdShowUpdateMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowUpdateMethod.TabIndex = 8;
            this.cmdShowUpdateMethod.Text = "Show";
            this.cmdShowUpdateMethod.Visible = false;
            this.cmdShowUpdateMethod.Click += new System.EventHandler(this.cmdShowUpdateMethod_Click);
            // 
            // cmdShowSaveMethod
            // 
            this.cmdShowSaveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSaveMethod.Location = new System.Drawing.Point(16, 144);
            this.cmdShowSaveMethod.Name = "cmdShowSaveMethod";
            this.cmdShowSaveMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSaveMethod.TabIndex = 9;
            this.cmdShowSaveMethod.Text = "Show";
            this.cmdShowSaveMethod.Visible = false;
            this.cmdShowSaveMethod.Click += new System.EventHandler(this.cmdShowSaveMethod_Click);
            // 
            // cmdShowDeleteByPKMethod
            // 
            this.cmdShowDeleteByPKMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowDeleteByPKMethod.Location = new System.Drawing.Point(16, 168);
            this.cmdShowDeleteByPKMethod.Name = "cmdShowDeleteByPKMethod";
            this.cmdShowDeleteByPKMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowDeleteByPKMethod.TabIndex = 10;
            this.cmdShowDeleteByPKMethod.Text = "Show";
            this.cmdShowDeleteByPKMethod.Visible = false;
            this.cmdShowDeleteByPKMethod.Click += new System.EventHandler(this.cmdShowDeleteByPKMethod_Click);
            // 
            // cmdShowDeleteMethod
            // 
            this.cmdShowDeleteMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowDeleteMethod.Location = new System.Drawing.Point(16, 192);
            this.cmdShowDeleteMethod.Name = "cmdShowDeleteMethod";
            this.cmdShowDeleteMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowDeleteMethod.TabIndex = 11;
            this.cmdShowDeleteMethod.Text = "Show";
            this.cmdShowDeleteMethod.Visible = false;
            this.cmdShowDeleteMethod.Click += new System.EventHandler(this.cmdShowDeleteMethod_Click);
            // 
            // cmdShowLoadByPKMethod
            // 
            this.cmdShowLoadByPKMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowLoadByPKMethod.Location = new System.Drawing.Point(16, 24);
            this.cmdShowLoadByPKMethod.Name = "cmdShowLoadByPKMethod";
            this.cmdShowLoadByPKMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowLoadByPKMethod.TabIndex = 6;
            this.cmdShowLoadByPKMethod.Text = "Show";
            this.cmdShowLoadByPKMethod.Visible = false;
            this.cmdShowLoadByPKMethod.Click += new System.EventHandler(this.cmdShowLoadByPKMethod_Click);
            // 
            // chkLoadByPKMethod
            // 
            this.chkLoadByPKMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLoadByPKMethod.Location = new System.Drawing.Point(64, 24);
            this.chkLoadByPKMethod.Name = "chkLoadByPKMethod";
            this.chkLoadByPKMethod.Size = new System.Drawing.Size(160, 24);
            this.chkLoadByPKMethod.TabIndex = 0;
            this.chkLoadByPKMethod.Text = "Load By PK Method";
            this.chkLoadByPKMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkReadMethod
            // 
            this.chkReadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkReadMethod.Location = new System.Drawing.Point(64, 48);
            this.chkReadMethod.Name = "chkReadMethod";
            this.chkReadMethod.Size = new System.Drawing.Size(160, 24);
            this.chkReadMethod.TabIndex = 1;
            this.chkReadMethod.Text = "Read Method";
            this.chkReadMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // cmdShowReadMethod
            // 
            this.cmdShowReadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowReadMethod.Location = new System.Drawing.Point(16, 48);
            this.cmdShowReadMethod.Name = "cmdShowReadMethod";
            this.cmdShowReadMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowReadMethod.TabIndex = 7;
            this.cmdShowReadMethod.Text = "Show";
            this.cmdShowReadMethod.Visible = false;
            this.cmdShowReadMethod.Click += new System.EventHandler(this.cmdShowReadMethod_Click);
            // 
            // cmdShowReadColMethod
            // 
            this.cmdShowReadColMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowReadColMethod.Location = new System.Drawing.Point(16, 72);
            this.cmdShowReadColMethod.Name = "cmdShowReadColMethod";
            this.cmdShowReadColMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowReadColMethod.TabIndex = 7;
            this.cmdShowReadColMethod.Text = "Show";
            this.cmdShowReadColMethod.Visible = false;
            this.cmdShowReadColMethod.Click += new System.EventHandler(this.cmdShowReadColMethod_Click);
            // 
            // chkReadColMethod
            // 
            this.chkReadColMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkReadColMethod.Location = new System.Drawing.Point(64, 72);
            this.chkReadColMethod.Name = "chkReadColMethod";
            this.chkReadColMethod.Size = new System.Drawing.Size(160, 24);
            this.chkReadColMethod.TabIndex = 1;
            this.chkReadColMethod.Text = "Read Collection Method";
            this.chkReadColMethod.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkLoadFromDataRowView
            // 
            this.chkLoadFromDataRowView.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLoadFromDataRowView.Location = new System.Drawing.Point(352, 40);
            this.chkLoadFromDataRowView.Name = "chkLoadFromDataRowView";
            this.chkLoadFromDataRowView.Size = new System.Drawing.Size(160, 24);
            this.chkLoadFromDataRowView.TabIndex = 0;
            this.chkLoadFromDataRowView.Text = "Load from DataRowView";
            this.chkLoadFromDataRowView.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkSaveToDataRowView
            // 
            this.chkSaveToDataRowView.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSaveToDataRowView.Location = new System.Drawing.Point(352, 64);
            this.chkSaveToDataRowView.Name = "chkSaveToDataRowView";
            this.chkSaveToDataRowView.Size = new System.Drawing.Size(160, 24);
            this.chkSaveToDataRowView.TabIndex = 0;
            this.chkSaveToDataRowView.Text = "Save to DataRowView";
            this.chkSaveToDataRowView.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // cmdShowLoadFromDataRowView
            // 
            this.cmdShowLoadFromDataRowView.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowLoadFromDataRowView.Location = new System.Drawing.Point(304, 40);
            this.cmdShowLoadFromDataRowView.Name = "cmdShowLoadFromDataRowView";
            this.cmdShowLoadFromDataRowView.Size = new System.Drawing.Size(42, 23);
            this.cmdShowLoadFromDataRowView.TabIndex = 6;
            this.cmdShowLoadFromDataRowView.Text = "Show";
            this.cmdShowLoadFromDataRowView.Visible = false;
            this.cmdShowLoadFromDataRowView.Click += new System.EventHandler(this.cmdShowLoadFromDataRowView_Click);
            // 
            // cmdShowSaveToDataRowView
            // 
            this.cmdShowSaveToDataRowView.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSaveToDataRowView.Location = new System.Drawing.Point(304, 64);
            this.cmdShowSaveToDataRowView.Name = "cmdShowSaveToDataRowView";
            this.cmdShowSaveToDataRowView.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSaveToDataRowView.TabIndex = 6;
            this.cmdShowSaveToDataRowView.Text = "Show";
            this.cmdShowSaveToDataRowView.Visible = false;
            this.cmdShowSaveToDataRowView.Click += new System.EventHandler(this.cmdShowSaveToDataRowView_Click);
            // 
            // chkExistsByPK
            // 
            this.chkExistsByPK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExistsByPK.Location = new System.Drawing.Point(352, 88);
            this.chkExistsByPK.Name = "chkExistsByPK";
            this.chkExistsByPK.Size = new System.Drawing.Size(160, 24);
            this.chkExistsByPK.TabIndex = 0;
            this.chkExistsByPK.Text = "PK Exists";
            this.chkExistsByPK.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // chkExists
            // 
            this.chkExists.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExists.Location = new System.Drawing.Point(352, 112);
            this.chkExists.Name = "chkExists";
            this.chkExists.Size = new System.Drawing.Size(160, 24);
            this.chkExists.TabIndex = 0;
            this.chkExists.Text = "Exists";
            this.chkExists.Click += new System.EventHandler(this.chkDeleteMethod_Click);
            // 
            // cmdShowExistsByPK
            // 
            this.cmdShowExistsByPK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowExistsByPK.Location = new System.Drawing.Point(304, 88);
            this.cmdShowExistsByPK.Name = "cmdShowExistsByPK";
            this.cmdShowExistsByPK.Size = new System.Drawing.Size(42, 23);
            this.cmdShowExistsByPK.TabIndex = 6;
            this.cmdShowExistsByPK.Text = "Show";
            this.cmdShowExistsByPK.Visible = false;
            this.cmdShowExistsByPK.Click += new System.EventHandler(this.cmdShowExistsByPK_Click);
            // 
            // cmdShowExists
            // 
            this.cmdShowExists.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowExists.Location = new System.Drawing.Point(304, 112);
            this.cmdShowExists.Name = "cmdShowExists";
            this.cmdShowExists.Size = new System.Drawing.Size(42, 23);
            this.cmdShowExists.TabIndex = 6;
            this.cmdShowExists.Text = "Show";
            this.cmdShowExists.Visible = false;
            this.cmdShowExists.Click += new System.EventHandler(this.cmdShowExists_Click);
            // 
            // tabChildren
            // 
            this.tabChildren.Controls.Add(this.butShowContainmentBuilder2);
            this.tabChildren.Controls.Add(this.cmdShowChildColBuilder);
            this.tabChildren.Controls.Add(this.butEnsureAllChildLoaderSPs);
            this.tabChildren.Controls.Add(this.txtSPForLoadChild);
            this.tabChildren.Controls.Add(this.lbSPLoadChild);
            this.tabChildren.Controls.Add(this.butCreateSPLoadChild);
            this.tabChildren.Controls.Add(this.label18);
            this.tabChildren.Controls.Add(this.cmdCreateChild);
            this.tabChildren.Controls.Add(this.button4);
            this.tabChildren.Controls.Add(this.lsChildren);
            this.tabChildren.Controls.Add(this.label16);
            this.tabChildren.Location = new System.Drawing.Point(4, 40);
            this.tabChildren.Name = "tabChildren";
            this.tabChildren.Size = new System.Drawing.Size(520, 244);
            this.tabChildren.TabIndex = 8;
            this.tabChildren.Text = "Children";
            this.tabChildren.ToolTipText = "Children are the collection members of this class which are mapped to related det" +
                "ail tables.  The relation is declared by a SimpleRelation or SPLoadChild attribu" +
                "te on the member.";
            // 
            // butShowContainmentBuilder2
            // 
            this.butShowContainmentBuilder2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butShowContainmentBuilder2.Location = new System.Drawing.Point(264, 8);
            this.butShowContainmentBuilder2.Name = "butShowContainmentBuilder2";
            this.butShowContainmentBuilder2.Size = new System.Drawing.Size(248, 23);
            this.butShowContainmentBuilder2.TabIndex = 40;
            this.butShowContainmentBuilder2.Text = "Show Containment Model";
            this.butShowContainmentBuilder2.Click += new System.EventHandler(this.butShowContainmentBuilder2_Click);
            // 
            // cmdShowChildColBuilder
            // 
            this.cmdShowChildColBuilder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowChildColBuilder.Location = new System.Drawing.Point(264, 32);
            this.cmdShowChildColBuilder.Name = "cmdShowChildColBuilder";
            this.cmdShowChildColBuilder.Size = new System.Drawing.Size(248, 23);
            this.cmdShowChildColBuilder.TabIndex = 34;
            this.cmdShowChildColBuilder.Text = "Show Collection Builder for this";
            this.cmdShowChildColBuilder.Click += new System.EventHandler(this.cmdShowChildColBuilder_Click);
            // 
            // butEnsureAllChildLoaderSPs
            // 
            this.butEnsureAllChildLoaderSPs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butEnsureAllChildLoaderSPs.Location = new System.Drawing.Point(352, 88);
            this.butEnsureAllChildLoaderSPs.Name = "butEnsureAllChildLoaderSPs";
            this.butEnsureAllChildLoaderSPs.Size = new System.Drawing.Size(160, 32);
            this.butEnsureAllChildLoaderSPs.TabIndex = 33;
            this.butEnsureAllChildLoaderSPs.Text = "Ensure all child loader SPs are created.";
            this.butEnsureAllChildLoaderSPs.Visible = false;
            this.butEnsureAllChildLoaderSPs.Click += new System.EventHandler(this.butEnsureAllChildLoaderSPs_Click);
            // 
            // txtSPForLoadChild
            // 
            this.txtSPForLoadChild.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSPForLoadChild.Location = new System.Drawing.Point(352, 64);
            this.txtSPForLoadChild.Name = "txtSPForLoadChild";
            this.txtSPForLoadChild.ReadOnly = true;
            this.txtSPForLoadChild.Size = new System.Drawing.Size(160, 20);
            this.txtSPForLoadChild.TabIndex = 32;
            this.txtSPForLoadChild.Visible = false;
            // 
            // lbSPLoadChild
            // 
            this.lbSPLoadChild.Location = new System.Drawing.Point(263, 66);
            this.lbSPLoadChild.Name = "lbSPLoadChild";
            this.lbSPLoadChild.Size = new System.Drawing.Size(96, 18);
            this.lbSPLoadChild.TabIndex = 31;
            this.lbSPLoadChild.TabStop = true;
            this.lbSPLoadChild.Text = "SP for Load Child:";
            this.lbSPLoadChild.Visible = false;
            this.lbSPLoadChild.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbSPLoadChild_LinkClicked);
            // 
            // butCreateSPLoadChild
            // 
            this.butCreateSPLoadChild.Enabled = false;
            this.butCreateSPLoadChild.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butCreateSPLoadChild.Location = new System.Drawing.Point(352, 120);
            this.butCreateSPLoadChild.Name = "butCreateSPLoadChild";
            this.butCreateSPLoadChild.Size = new System.Drawing.Size(160, 23);
            this.butCreateSPLoadChild.TabIndex = 30;
            this.butCreateSPLoadChild.Text = "Create child loader SP";
            this.butCreateSPLoadChild.Click += new System.EventHandler(this.butCreateSPLoadChild_Click);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(352, 168);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(160, 40);
            this.label18.TabIndex = 29;
            this.label18.Text = "Click Create to launch child collection member creation wizard.";
            // 
            // cmdCreateChild
            // 
            this.cmdCreateChild.Location = new System.Drawing.Point(432, 216);
            this.cmdCreateChild.Name = "cmdCreateChild";
            this.cmdCreateChild.Size = new System.Drawing.Size(75, 23);
            this.cmdCreateChild.TabIndex = 28;
            this.cmdCreateChild.Text = "Create Child";
            this.cmdCreateChild.Click += new System.EventHandler(this.cmdCreateChild_Click);
            // 
            // button4
            // 
            this.button4.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button4.Location = new System.Drawing.Point(352, 216);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 27;
            this.button4.Text = "Close";
            this.button4.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lsChildren
            // 
            this.lsChildren.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsChildren.Location = new System.Drawing.Point(16, 32);
            this.lsChildren.Name = "lsChildren";
            this.lsChildren.Size = new System.Drawing.Size(240, 158);
            this.lsChildren.TabIndex = 26;
            this.lsChildren.SelectedIndexChanged += new System.EventHandler(this.lsChildren_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(16, 8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(248, 23);
            this.label16.TabIndex = 25;
            this.label16.Text = "Child collection members of this class:";
            // 
            // tabContainedObjects
            // 
            this.tabContainedObjects.Controls.Add(this.butShowContainmentModel);
            this.tabContainedObjects.Controls.Add(this.cmdShowClassBuilderForParent);
            this.tabContainedObjects.Controls.Add(this.lsParentObjects);
            this.tabContainedObjects.Controls.Add(this.cmdShowContainedClassBuilder);
            this.tabContainedObjects.Controls.Add(this.label22);
            this.tabContainedObjects.Controls.Add(this.cmdCreateContainedEntityObject);
            this.tabContainedObjects.Controls.Add(this.button5);
            this.tabContainedObjects.Controls.Add(this.lsContainedEntityObjects);
            this.tabContainedObjects.Controls.Add(this.label23);
            this.tabContainedObjects.Controls.Add(this.label24);
            this.tabContainedObjects.Location = new System.Drawing.Point(4, 40);
            this.tabContainedObjects.Name = "tabContainedObjects";
            this.tabContainedObjects.Size = new System.Drawing.Size(520, 244);
            this.tabContainedObjects.TabIndex = 10;
            this.tabContainedObjects.Text = "Containeds/Parents";
            this.tabContainedObjects.ToolTipText = "Contained Entity Objects are non-collection Entity Objects that usually have 1-to" +
                "-1 relationship to this Entity Object.";
            // 
            // butShowContainmentModel
            // 
            this.butShowContainmentModel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butShowContainmentModel.Location = new System.Drawing.Point(264, 8);
            this.butShowContainmentModel.Name = "butShowContainmentModel";
            this.butShowContainmentModel.Size = new System.Drawing.Size(248, 23);
            this.butShowContainmentModel.TabIndex = 39;
            this.butShowContainmentModel.Text = "Show Containment Model";
            this.butShowContainmentModel.Click += new System.EventHandler(this.butShowContainmentModel_Click);
            // 
            // cmdShowClassBuilderForParent
            // 
            this.cmdShowClassBuilderForParent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowClassBuilderForParent.Location = new System.Drawing.Point(264, 56);
            this.cmdShowClassBuilderForParent.Name = "cmdShowClassBuilderForParent";
            this.cmdShowClassBuilderForParent.Size = new System.Drawing.Size(248, 23);
            this.cmdShowClassBuilderForParent.TabIndex = 38;
            this.cmdShowClassBuilderForParent.Text = "Show Class Builder for parent object";
            this.cmdShowClassBuilderForParent.Click += new System.EventHandler(this.cmdShowClassBuilderForParent_Click);
            // 
            // lsParentObjects
            // 
            this.lsParentObjects.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsParentObjects.Location = new System.Drawing.Point(16, 176);
            this.lsParentObjects.Name = "lsParentObjects";
            this.lsParentObjects.Size = new System.Drawing.Size(240, 54);
            this.lsParentObjects.TabIndex = 36;
            this.lsParentObjects.SelectedIndexChanged += new System.EventHandler(this.lsParentObjects_SelectedIndexChanged);
            // 
            // cmdShowContainedClassBuilder
            // 
            this.cmdShowContainedClassBuilder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowContainedClassBuilder.Location = new System.Drawing.Point(264, 32);
            this.cmdShowContainedClassBuilder.Name = "cmdShowContainedClassBuilder";
            this.cmdShowContainedClassBuilder.Size = new System.Drawing.Size(248, 23);
            this.cmdShowContainedClassBuilder.TabIndex = 35;
            this.cmdShowContainedClassBuilder.Text = "Show Class Builder for contained object";
            this.cmdShowContainedClassBuilder.Click += new System.EventHandler(this.cmdShowContainedClassBuilder_Click);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(352, 168);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(152, 40);
            this.label22.TabIndex = 34;
            this.label22.Text = "Click Create to launch contained Entity Object creation wizard.";
            // 
            // cmdCreateContainedEntityObject
            // 
            this.cmdCreateContainedEntityObject.Location = new System.Drawing.Point(432, 216);
            this.cmdCreateContainedEntityObject.Name = "cmdCreateContainedEntityObject";
            this.cmdCreateContainedEntityObject.Size = new System.Drawing.Size(75, 23);
            this.cmdCreateContainedEntityObject.TabIndex = 33;
            this.cmdCreateContainedEntityObject.Text = "Create";
            this.cmdCreateContainedEntityObject.Click += new System.EventHandler(this.cmdCreateContainedEntityObject_Click);
            // 
            // button5
            // 
            this.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button5.Location = new System.Drawing.Point(352, 216);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 32;
            this.button5.Text = "Close";
            this.button5.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lsContainedEntityObjects
            // 
            this.lsContainedEntityObjects.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsContainedEntityObjects.Location = new System.Drawing.Point(16, 32);
            this.lsContainedEntityObjects.Name = "lsContainedEntityObjects";
            this.lsContainedEntityObjects.Size = new System.Drawing.Size(240, 119);
            this.lsContainedEntityObjects.TabIndex = 31;
            this.lsContainedEntityObjects.SelectedIndexChanged += new System.EventHandler(this.lsContainedEntityObjects_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(16, 8);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(248, 23);
            this.label23.TabIndex = 30;
            this.label23.Text = "Contained Entity Objects of this class:";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(16, 160);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(248, 23);
            this.label24.TabIndex = 37;
            this.label24.Text = "Parent objects of this class:";
            // 
            // tabBuildParamsMethods
            // 
            this.tabBuildParamsMethods.Controls.Add(this.cbSprocName);
            this.tabBuildParamsMethods.Controls.Add(this.lbProcNameLabel);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParamsOnlyMapped);
            this.tabBuildParamsMethods.Controls.Add(this.butRemoveParamAll);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParamAll);
            this.tabBuildParamsMethods.Controls.Add(this.cmdShowToStringMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkNewMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkExecuteStoredProcMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkExecuteSQL);
            this.tabBuildParamsMethods.Controls.Add(this.chkExecuteReaderMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkConstructor);
            this.tabBuildParamsMethods.Controls.Add(this.butCreateParamsMethods);
            this.tabBuildParamsMethods.Controls.Add(this.butCancel2);
            this.tabBuildParamsMethods.Controls.Add(this.lsAllFields);
            this.tabBuildParamsMethods.Controls.Add(this.lsParams);
            this.tabBuildParamsMethods.Controls.Add(this.label7);
            this.tabBuildParamsMethods.Controls.Add(this.label6);
            this.tabBuildParamsMethods.Controls.Add(this.butRemoveParam);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParam);
            this.tabBuildParamsMethods.Controls.Add(this.chkLoad);
            this.tabBuildParamsMethods.Controls.Add(this.chkToStringMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkCalculateScriptMethod);
            this.tabBuildParamsMethods.Controls.Add(this.butSelectSPTemplate);
            this.tabBuildParamsMethods.Location = new System.Drawing.Point(4, 40);
            this.tabBuildParamsMethods.Name = "tabBuildParamsMethods";
            this.tabBuildParamsMethods.Size = new System.Drawing.Size(520, 244);
            this.tabBuildParamsMethods.TabIndex = 1;
            this.tabBuildParamsMethods.Text = "Parameterized Methods";
            this.tabBuildParamsMethods.ToolTipText = "Builds various methods with the given parameters.";
            // 
            // cbSprocName
            // 
            this.cbSprocName.Location = new System.Drawing.Point(358, 169);
            this.cbSprocName.Name = "cbSprocName";
            this.cbSprocName.Size = new System.Drawing.Size(152, 21);
            this.cbSprocName.TabIndex = 25;
            this.cbSprocName.SelectedIndexChanged += new System.EventHandler(this.cbSprocName_SelectedIndexChanged);
            this.cbSprocName.TextChanged += new System.EventHandler(this.cbSprocName_TextChanged);
            // 
            // lbProcNameLabel
            // 
            this.lbProcNameLabel.Location = new System.Drawing.Point(300, 175);
            this.lbProcNameLabel.Name = "lbProcNameLabel";
            this.lbProcNameLabel.Size = new System.Drawing.Size(100, 18);
            this.lbProcNameLabel.TabIndex = 30;
            this.lbProcNameLabel.TabStop = true;
            this.lbProcNameLabel.Text = "Procedure:";
            this.lbProcNameLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbProcNameLabel_LinkClicked);
            // 
            // butAddParamsOnlyMapped
            // 
            this.butAddParamsOnlyMapped.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParamsOnlyMapped.Location = new System.Drawing.Point(224, 120);
            this.butAddParamsOnlyMapped.Name = "butAddParamsOnlyMapped";
            this.butAddParamsOnlyMapped.Size = new System.Drawing.Size(72, 24);
            this.butAddParamsOnlyMapped.TabIndex = 29;
            this.butAddParamsOnlyMapped.Text = "Mapped >>";
            this.butAddParamsOnlyMapped.Click += new System.EventHandler(this.butAddParamsOnlyMapped_Click);
            // 
            // butRemoveParamAll
            // 
            this.butRemoveParamAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveParamAll.Location = new System.Drawing.Point(240, 96);
            this.butRemoveParamAll.Name = "butRemoveParamAll";
            this.butRemoveParamAll.Size = new System.Drawing.Size(40, 24);
            this.butRemoveParamAll.TabIndex = 28;
            this.butRemoveParamAll.Text = "<<";
            this.butRemoveParamAll.Click += new System.EventHandler(this.butRemoveParamAll_Click);
            // 
            // butAddParamAll
            // 
            this.butAddParamAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParamAll.Location = new System.Drawing.Point(240, 72);
            this.butAddParamAll.Name = "butAddParamAll";
            this.butAddParamAll.Size = new System.Drawing.Size(40, 24);
            this.butAddParamAll.TabIndex = 27;
            this.butAddParamAll.Text = ">>";
            this.butAddParamAll.Click += new System.EventHandler(this.butAddParamAll_Click);
            // 
            // cmdShowToStringMethod
            // 
            this.cmdShowToStringMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowToStringMethod.Location = new System.Drawing.Point(257, 205);
            this.cmdShowToStringMethod.Name = "cmdShowToStringMethod";
            this.cmdShowToStringMethod.Size = new System.Drawing.Size(40, 19);
            this.cmdShowToStringMethod.TabIndex = 23;
            this.cmdShowToStringMethod.Text = "Show";
            this.cmdShowToStringMethod.Visible = false;
            this.cmdShowToStringMethod.Click += new System.EventHandler(this.cmdShowToStringMethod_Click);
            // 
            // chkNewMethod
            // 
            this.chkNewMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkNewMethod.Location = new System.Drawing.Point(16, 224);
            this.chkNewMethod.Name = "chkNewMethod";
            this.chkNewMethod.Size = new System.Drawing.Size(320, 16);
            this.chkNewMethod.TabIndex = 26;
            this.chkNewMethod.Text = "New method to initialize the object to be inserted into DB.";
            this.chkNewMethod.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkExecuteStoredProcMethod
            // 
            this.chkExecuteStoredProcMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExecuteStoredProcMethod.Location = new System.Drawing.Point(296, 152);
            this.chkExecuteStoredProcMethod.Name = "chkExecuteStoredProcMethod";
            this.chkExecuteStoredProcMethod.Size = new System.Drawing.Size(168, 16);
            this.chkExecuteStoredProcMethod.TabIndex = 22;
            this.chkExecuteStoredProcMethod.Text = "ExecuteStoredProc Method";
            this.chkExecuteStoredProcMethod.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkExecuteSQL
            // 
            this.chkExecuteSQL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExecuteSQL.Location = new System.Drawing.Point(144, 168);
            this.chkExecuteSQL.Name = "chkExecuteSQL";
            this.chkExecuteSQL.Size = new System.Drawing.Size(176, 16);
            this.chkExecuteSQL.TabIndex = 22;
            this.chkExecuteSQL.Text = "ExecuteSQL Method";
            this.chkExecuteSQL.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkExecuteReaderMethod
            // 
            this.chkExecuteReaderMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExecuteReaderMethod.Location = new System.Drawing.Point(144, 152);
            this.chkExecuteReaderMethod.Name = "chkExecuteReaderMethod";
            this.chkExecuteReaderMethod.Size = new System.Drawing.Size(144, 16);
            this.chkExecuteReaderMethod.TabIndex = 21;
            this.chkExecuteReaderMethod.Text = "ExecuteReader Method";
            this.chkExecuteReaderMethod.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkConstructor
            // 
            this.chkConstructor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkConstructor.Location = new System.Drawing.Point(16, 152);
            this.chkConstructor.Name = "chkConstructor";
            this.chkConstructor.Size = new System.Drawing.Size(176, 16);
            this.chkConstructor.TabIndex = 20;
            this.chkConstructor.Text = "Constructor Method";
            this.chkConstructor.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // butCreateParamsMethods
            // 
            this.butCreateParamsMethods.Location = new System.Drawing.Point(432, 216);
            this.butCreateParamsMethods.Name = "butCreateParamsMethods";
            this.butCreateParamsMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateParamsMethods.TabIndex = 19;
            this.butCreateParamsMethods.Text = "Create";
            this.butCreateParamsMethods.Click += new System.EventHandler(this.butCreateParamsMethods_Click);
            // 
            // butCancel2
            // 
            this.butCancel2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel2.Location = new System.Drawing.Point(352, 216);
            this.butCancel2.Name = "butCancel2";
            this.butCancel2.Size = new System.Drawing.Size(75, 23);
            this.butCancel2.TabIndex = 18;
            this.butCancel2.Text = "Close";
            this.butCancel2.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lsAllFields
            // 
            this.lsAllFields.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsAllFields.Location = new System.Drawing.Point(16, 24);
            this.lsAllFields.Name = "lsAllFields";
            this.lsAllFields.Size = new System.Drawing.Size(208, 119);
            this.lsAllFields.TabIndex = 10;
            this.lsAllFields.DoubleClick += new System.EventHandler(this.lsAllFields_DoubleClick);
            this.lsAllFields.SelectedIndexChanged += new System.EventHandler(this.lsAllFields_SelectedIndexChanged);
            // 
            // lsParams
            // 
            this.lsParams.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsParams.Location = new System.Drawing.Point(296, 24);
            this.lsParams.Name = "lsParams";
            this.lsParams.Size = new System.Drawing.Size(208, 119);
            this.lsParams.TabIndex = 11;
            this.lsParams.DoubleClick += new System.EventHandler(this.lsParams_DoubleClick);
            this.lsParams.SelectedIndexChanged += new System.EventHandler(this.lsParams_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(296, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 17;
            this.label7.Text = "Parameters:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 16;
            this.label6.Text = "Members:";
            // 
            // butRemoveParam
            // 
            this.butRemoveParam.Enabled = false;
            this.butRemoveParam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveParam.Location = new System.Drawing.Point(240, 48);
            this.butRemoveParam.Name = "butRemoveParam";
            this.butRemoveParam.Size = new System.Drawing.Size(40, 24);
            this.butRemoveParam.TabIndex = 15;
            this.butRemoveParam.Text = "<";
            this.butRemoveParam.Click += new System.EventHandler(this.butRemoveParam_Click);
            // 
            // butAddParam
            // 
            this.butAddParam.Enabled = false;
            this.butAddParam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParam.Location = new System.Drawing.Point(240, 24);
            this.butAddParam.Name = "butAddParam";
            this.butAddParam.Size = new System.Drawing.Size(40, 24);
            this.butAddParam.TabIndex = 14;
            this.butAddParam.Text = ">";
            this.butAddParam.Click += new System.EventHandler(this.butAddParam_Click);
            // 
            // chkLoad
            // 
            this.chkLoad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLoad.Location = new System.Drawing.Point(16, 168);
            this.chkLoad.Name = "chkLoad";
            this.chkLoad.Size = new System.Drawing.Size(176, 16);
            this.chkLoad.TabIndex = 21;
            this.chkLoad.Text = "Load Method";
            this.chkLoad.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkToStringMethod
            // 
            this.chkToStringMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkToStringMethod.Location = new System.Drawing.Point(16, 208);
            this.chkToStringMethod.Name = "chkToStringMethod";
            this.chkToStringMethod.Size = new System.Drawing.Size(264, 16);
            this.chkToStringMethod.TabIndex = 21;
            this.chkToStringMethod.Text = "ToString Method to dump specified members";
            this.chkToStringMethod.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // chkCalculateScriptMethod
            // 
            this.chkCalculateScriptMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkCalculateScriptMethod.Location = new System.Drawing.Point(16, 192);
            this.chkCalculateScriptMethod.Name = "chkCalculateScriptMethod";
            this.chkCalculateScriptMethod.Size = new System.Drawing.Size(264, 16);
            this.chkCalculateScriptMethod.TabIndex = 21;
            this.chkCalculateScriptMethod.Text = "Parameterized CalculateScript Method";
            this.chkCalculateScriptMethod.Click += new System.EventHandler(this.chkConstructor_Click);
            // 
            // butSelectSPTemplate
            // 
            this.butSelectSPTemplate.Location = new System.Drawing.Point(299, 193);
            this.butSelectSPTemplate.Name = "butSelectSPTemplate";
            this.butSelectSPTemplate.Size = new System.Drawing.Size(200, 18);
            this.butSelectSPTemplate.TabIndex = 31;
            this.butSelectSPTemplate.TabStop = true;
            this.butSelectSPTemplate.Text = "Click here to select a sp template first";
            this.butSelectSPTemplate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butSelectSPTemplate_LinkClicked);
            // 
            // tabCollections
            // 
            this.tabCollections.Controls.Add(this.cmdShowColBuilder);
            this.tabCollections.Controls.Add(this.lsCollectionClasses);
            this.tabCollections.Controls.Add(this.label10);
            this.tabCollections.Controls.Add(this.label8);
            this.tabCollections.Controls.Add(this.butCreateCollectionClass);
            this.tabCollections.Controls.Add(this.button2);
            this.tabCollections.Location = new System.Drawing.Point(4, 40);
            this.tabCollections.Name = "tabCollections";
            this.tabCollections.Size = new System.Drawing.Size(520, 244);
            this.tabCollections.TabIndex = 6;
            this.tabCollections.Text = "Collections";
            this.tabCollections.ToolTipText = "Creates strongly typed collections for this class.";
            // 
            // cmdShowColBuilder
            // 
            this.cmdShowColBuilder.Enabled = false;
            this.cmdShowColBuilder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowColBuilder.Location = new System.Drawing.Point(272, 40);
            this.cmdShowColBuilder.Name = "cmdShowColBuilder";
            this.cmdShowColBuilder.Size = new System.Drawing.Size(136, 23);
            this.cmdShowColBuilder.TabIndex = 25;
            this.cmdShowColBuilder.Text = "Show Collection Builder";
            this.cmdShowColBuilder.Click += new System.EventHandler(this.cmdShowColBuilder_Click);
            // 
            // lsCollectionClasses
            // 
            this.lsCollectionClasses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsCollectionClasses.Location = new System.Drawing.Point(24, 40);
            this.lsCollectionClasses.Name = "lsCollectionClasses";
            this.lsCollectionClasses.Size = new System.Drawing.Size(240, 158);
            this.lsCollectionClasses.TabIndex = 24;
            this.lsCollectionClasses.DoubleClick += new System.EventHandler(this.lsCollectionClasses_DoubleClick);
            this.lsCollectionClasses.SelectedIndexChanged += new System.EventHandler(this.lsCollectionClasses_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(24, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(248, 23);
            this.label10.TabIndex = 23;
            this.label10.Text = "Typed collection classes for this Entity Class:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(352, 168);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 40);
            this.label8.TabIndex = 22;
            this.label8.Text = "Click Create to launch collection class creation wizard.";
            // 
            // butCreateCollectionClass
            // 
            this.butCreateCollectionClass.Location = new System.Drawing.Point(432, 216);
            this.butCreateCollectionClass.Name = "butCreateCollectionClass";
            this.butCreateCollectionClass.Size = new System.Drawing.Size(75, 23);
            this.butCreateCollectionClass.TabIndex = 21;
            this.butCreateCollectionClass.Text = "Create";
            this.butCreateCollectionClass.Click += new System.EventHandler(this.butCreateCollectionClass_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(352, 216);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Close";
            this.button2.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // tabOverrides
            // 
            this.tabOverrides.Controls.Add(this.label21);
            this.tabOverrides.Controls.Add(this.chkOverrideCRUDpassMembers);
            this.tabOverrides.Controls.Add(this.butCreateOverridingMethods);
            this.tabOverrides.Controls.Add(this.butCancel6);
            this.tabOverrides.Controls.Add(this.lstOverridables);
            this.tabOverrides.Controls.Add(this.lstOverriddenMethods);
            this.tabOverrides.Controls.Add(this.label19);
            this.tabOverrides.Controls.Add(this.label20);
            this.tabOverrides.Controls.Add(this.butRemoveOverridable);
            this.tabOverrides.Controls.Add(this.butAddOverridable);
            this.tabOverrides.Location = new System.Drawing.Point(4, 40);
            this.tabOverrides.Name = "tabOverrides";
            this.tabOverrides.Size = new System.Drawing.Size(520, 244);
            this.tabOverrides.TabIndex = 9;
            this.tabOverrides.Text = "Overrides";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(16, 152);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(145, 16);
            this.label21.TabIndex = 41;
            this.label21.Text = "Override Options:";
            // 
            // chkOverrideCRUDpassMembers
            // 
            this.chkOverrideCRUDpassMembers.Checked = true;
            this.chkOverrideCRUDpassMembers.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkOverrideCRUDpassMembers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkOverrideCRUDpassMembers.Location = new System.Drawing.Point(24, 168);
            this.chkOverrideCRUDpassMembers.Name = "chkOverrideCRUDpassMembers";
            this.chkOverrideCRUDpassMembers.Size = new System.Drawing.Size(248, 16);
            this.chkOverrideCRUDpassMembers.TabIndex = 37;
            this.chkOverrideCRUDpassMembers.Text = "Pass members directly in CRUD operations";
            // 
            // butCreateOverridingMethods
            // 
            this.butCreateOverridingMethods.Enabled = false;
            this.butCreateOverridingMethods.Location = new System.Drawing.Point(432, 216);
            this.butCreateOverridingMethods.Name = "butCreateOverridingMethods";
            this.butCreateOverridingMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateOverridingMethods.TabIndex = 36;
            this.butCreateOverridingMethods.Text = "Create";
            this.butCreateOverridingMethods.Click += new System.EventHandler(this.butCreateOverridingMethods_Click);
            // 
            // butCancel6
            // 
            this.butCancel6.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel6.Location = new System.Drawing.Point(352, 216);
            this.butCancel6.Name = "butCancel6";
            this.butCancel6.Size = new System.Drawing.Size(75, 23);
            this.butCancel6.TabIndex = 35;
            this.butCancel6.Text = "Close";
            this.butCancel6.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lstOverridables
            // 
            this.lstOverridables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstOverridables.Location = new System.Drawing.Point(16, 24);
            this.lstOverridables.Name = "lstOverridables";
            this.lstOverridables.Size = new System.Drawing.Size(208, 119);
            this.lstOverridables.Sorted = true;
            this.lstOverridables.TabIndex = 29;
            this.lstOverridables.DoubleClick += new System.EventHandler(this.lstOverridables_DoubleClick);
            this.lstOverridables.SelectedIndexChanged += new System.EventHandler(this.lstOverridables_SelectedIndexChanged);
            // 
            // lstOverriddenMethods
            // 
            this.lstOverriddenMethods.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstOverriddenMethods.Location = new System.Drawing.Point(296, 24);
            this.lstOverriddenMethods.Name = "lstOverriddenMethods";
            this.lstOverriddenMethods.Size = new System.Drawing.Size(208, 119);
            this.lstOverriddenMethods.TabIndex = 30;
            this.lstOverriddenMethods.DoubleClick += new System.EventHandler(this.lstOverriddenMethods_DoubleClick);
            this.lstOverriddenMethods.SelectedIndexChanged += new System.EventHandler(this.lstOverriddenMethods_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(296, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(161, 23);
            this.label19.TabIndex = 34;
            this.label19.Text = "Overridden Methods:";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(16, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(145, 23);
            this.label20.TabIndex = 33;
            this.label20.Text = "Overridable Methods:";
            // 
            // butRemoveOverridable
            // 
            this.butRemoveOverridable.Enabled = false;
            this.butRemoveOverridable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveOverridable.Location = new System.Drawing.Point(240, 48);
            this.butRemoveOverridable.Name = "butRemoveOverridable";
            this.butRemoveOverridable.Size = new System.Drawing.Size(40, 24);
            this.butRemoveOverridable.TabIndex = 32;
            this.butRemoveOverridable.Text = "<";
            this.butRemoveOverridable.Click += new System.EventHandler(this.butRemoveOverridable_Click);
            // 
            // butAddOverridable
            // 
            this.butAddOverridable.Enabled = false;
            this.butAddOverridable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddOverridable.Location = new System.Drawing.Point(240, 24);
            this.butAddOverridable.Name = "butAddOverridable";
            this.butAddOverridable.Size = new System.Drawing.Size(40, 24);
            this.butAddOverridable.TabIndex = 31;
            this.butAddOverridable.Text = ">";
            this.butAddOverridable.Click += new System.EventHandler(this.butAddOverridable_Click);
            // 
            // tabCodeGenOpt
            // 
            this.tabCodeGenOpt.Controls.Add(this.butCreateSqlDataProp);
            this.tabCodeGenOpt.Controls.Add(this.chkEnsureSqlData);
            this.tabCodeGenOpt.Controls.Add(this.label2);
            this.tabCodeGenOpt.Controls.Add(this.chkEnsureServerScript);
            this.tabCodeGenOpt.Controls.Add(this.butCreateServerScriptProp);
            this.tabCodeGenOpt.Location = new System.Drawing.Point(4, 40);
            this.tabCodeGenOpt.Name = "tabCodeGenOpt";
            this.tabCodeGenOpt.Size = new System.Drawing.Size(520, 244);
            this.tabCodeGenOpt.TabIndex = 5;
            this.tabCodeGenOpt.Text = "Code Generation Options";
            this.tabCodeGenOpt.ToolTipText = "Specify code generation options for this class here.";
            // 
            // butCreateSqlDataProp
            // 
            this.butCreateSqlDataProp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butCreateSqlDataProp.Location = new System.Drawing.Point(216, 40);
            this.butCreateSqlDataProp.Name = "butCreateSqlDataProp";
            this.butCreateSqlDataProp.Size = new System.Drawing.Size(75, 24);
            this.butCreateSqlDataProp.TabIndex = 2;
            this.butCreateSqlDataProp.Text = "Create Now";
            this.butCreateSqlDataProp.Click += new System.EventHandler(this.butCreateSqlDataProp_Click);
            // 
            // chkEnsureSqlData
            // 
            this.chkEnsureSqlData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkEnsureSqlData.Location = new System.Drawing.Point(40, 48);
            this.chkEnsureSqlData.Name = "chkEnsureSqlData";
            this.chkEnsureSqlData.Size = new System.Drawing.Size(160, 16);
            this.chkEnsureSqlData.TabIndex = 1;
            this.chkEnsureSqlData.Text = "Ensure SqlData Property";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Uncheck this if this is a derived class:";
            // 
            // chkEnsureServerScript
            // 
            this.chkEnsureServerScript.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkEnsureServerScript.Location = new System.Drawing.Point(40, 72);
            this.chkEnsureServerScript.Name = "chkEnsureServerScript";
            this.chkEnsureServerScript.Size = new System.Drawing.Size(176, 16);
            this.chkEnsureServerScript.TabIndex = 1;
            this.chkEnsureServerScript.Text = "Ensure ServerScript Property";
            // 
            // butCreateServerScriptProp
            // 
            this.butCreateServerScriptProp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butCreateServerScriptProp.Location = new System.Drawing.Point(216, 64);
            this.butCreateServerScriptProp.Name = "butCreateServerScriptProp";
            this.butCreateServerScriptProp.Size = new System.Drawing.Size(75, 24);
            this.butCreateServerScriptProp.TabIndex = 2;
            this.butCreateServerScriptProp.Text = "Create Now";
            this.butCreateServerScriptProp.Click += new System.EventHandler(this.butCreateServerScriptProp_Click);
            // 
            // tabSQLHint
            // 
            this.tabSQLHint.Controls.Add(this.label26);
            this.tabSQLHint.Controls.Add(this.cmdFillFromColMapping);
            this.tabSQLHint.Controls.Add(this.cmdShowSQLHintAttrib);
            this.tabSQLHint.Controls.Add(this.butCreateSQLHintAttrib);
            this.tabSQLHint.Controls.Add(this.butCancel5);
            this.tabSQLHint.Controls.Add(this.lsSQLHintCols);
            this.tabSQLHint.Controls.Add(this.lsColumns2);
            this.tabSQLHint.Controls.Add(this.label13);
            this.tabSQLHint.Controls.Add(this.label14);
            this.tabSQLHint.Controls.Add(this.butAddHint);
            this.tabSQLHint.Controls.Add(this.butRemoveAllHint);
            this.tabSQLHint.Controls.Add(this.butRemoveHint);
            this.tabSQLHint.Controls.Add(this.butAddAllHint);
            this.tabSQLHint.Location = new System.Drawing.Point(4, 40);
            this.tabSQLHint.Name = "tabSQLHint";
            this.tabSQLHint.Size = new System.Drawing.Size(520, 244);
            this.tabSQLHint.TabIndex = 4;
            this.tabSQLHint.Text = "SQL Hint";
            this.tabSQLHint.ToolTipText = resources.GetString("tabSQLHint.ToolTipText");
            // 
            // label26
            // 
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(132, 168);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(116, 64);
            this.label26.TabIndex = 34;
            this.label26.Text = "This feature is obsolete.  Please do not use this.";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmdFillFromColMapping
            // 
            this.cmdFillFromColMapping.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdFillFromColMapping.Location = new System.Drawing.Point(296, 168);
            this.cmdFillFromColMapping.Name = "cmdFillFromColMapping";
            this.cmdFillFromColMapping.Size = new System.Drawing.Size(168, 23);
            this.cmdFillFromColMapping.TabIndex = 33;
            this.cmdFillFromColMapping.Text = "Fill From Column Mapping";
            this.cmdFillFromColMapping.Click += new System.EventHandler(this.cmdFillFromColMapping_Click);
            // 
            // cmdShowSQLHintAttrib
            // 
            this.cmdShowSQLHintAttrib.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSQLHintAttrib.Location = new System.Drawing.Point(16, 168);
            this.cmdShowSQLHintAttrib.Name = "cmdShowSQLHintAttrib";
            this.cmdShowSQLHintAttrib.Size = new System.Drawing.Size(40, 23);
            this.cmdShowSQLHintAttrib.TabIndex = 32;
            this.cmdShowSQLHintAttrib.Text = "Show";
            this.cmdShowSQLHintAttrib.Visible = false;
            this.cmdShowSQLHintAttrib.Click += new System.EventHandler(this.cmdShowSQLHintAttrib_Click);
            // 
            // butCreateSQLHintAttrib
            // 
            this.butCreateSQLHintAttrib.Location = new System.Drawing.Point(432, 216);
            this.butCreateSQLHintAttrib.Name = "butCreateSQLHintAttrib";
            this.butCreateSQLHintAttrib.Size = new System.Drawing.Size(75, 23);
            this.butCreateSQLHintAttrib.TabIndex = 31;
            this.butCreateSQLHintAttrib.Text = "Create";
            this.butCreateSQLHintAttrib.Click += new System.EventHandler(this.butCreateSQLHintAttrib_Click);
            // 
            // butCancel5
            // 
            this.butCancel5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel5.Location = new System.Drawing.Point(352, 216);
            this.butCancel5.Name = "butCancel5";
            this.butCancel5.Size = new System.Drawing.Size(75, 23);
            this.butCancel5.TabIndex = 30;
            this.butCancel5.Text = "Close";
            this.butCancel5.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lsSQLHintCols
            // 
            this.lsSQLHintCols.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsSQLHintCols.Location = new System.Drawing.Point(296, 24);
            this.lsSQLHintCols.Name = "lsSQLHintCols";
            this.lsSQLHintCols.Size = new System.Drawing.Size(208, 132);
            this.lsSQLHintCols.TabIndex = 23;
            this.lsSQLHintCols.DoubleClick += new System.EventHandler(this.lsSQLHintCols_DoubleClick);
            this.lsSQLHintCols.SelectedIndexChanged += new System.EventHandler(this.lsSQLHintCols_SelectedIndexChanged);
            // 
            // lsColumns2
            // 
            this.lsColumns2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsColumns2.Location = new System.Drawing.Point(16, 24);
            this.lsColumns2.Name = "lsColumns2";
            this.lsColumns2.Size = new System.Drawing.Size(208, 132);
            this.lsColumns2.Sorted = true;
            this.lsColumns2.TabIndex = 22;
            this.lsColumns2.DoubleClick += new System.EventHandler(this.lsColumns2_DoubleClick);
            this.lsColumns2.SelectedIndexChanged += new System.EventHandler(this.lsColumns2_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(296, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(208, 23);
            this.label13.TabIndex = 29;
            this.label13.Text = "Columns to use in SQL and mapping:";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(16, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 23);
            this.label14.TabIndex = 28;
            this.label14.Text = "Table Columns:";
            // 
            // butAddHint
            // 
            this.butAddHint.Enabled = false;
            this.butAddHint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddHint.Location = new System.Drawing.Point(240, 24);
            this.butAddHint.Name = "butAddHint";
            this.butAddHint.Size = new System.Drawing.Size(40, 24);
            this.butAddHint.TabIndex = 26;
            this.butAddHint.Text = ">";
            this.butAddHint.Click += new System.EventHandler(this.butAddHint_Click);
            // 
            // butRemoveAllHint
            // 
            this.butRemoveAllHint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveAllHint.Location = new System.Drawing.Point(240, 96);
            this.butRemoveAllHint.Name = "butRemoveAllHint";
            this.butRemoveAllHint.Size = new System.Drawing.Size(40, 24);
            this.butRemoveAllHint.TabIndex = 25;
            this.butRemoveAllHint.Text = "<<";
            this.butRemoveAllHint.Click += new System.EventHandler(this.butRemoveAllHint_Click);
            // 
            // butRemoveHint
            // 
            this.butRemoveHint.Enabled = false;
            this.butRemoveHint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveHint.Location = new System.Drawing.Point(240, 48);
            this.butRemoveHint.Name = "butRemoveHint";
            this.butRemoveHint.Size = new System.Drawing.Size(40, 24);
            this.butRemoveHint.TabIndex = 27;
            this.butRemoveHint.Text = "<";
            this.butRemoveHint.Click += new System.EventHandler(this.butRemoveHint_Click);
            // 
            // butAddAllHint
            // 
            this.butAddAllHint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddAllHint.Location = new System.Drawing.Point(240, 72);
            this.butAddAllHint.Name = "butAddAllHint";
            this.butAddAllHint.Size = new System.Drawing.Size(40, 24);
            this.butAddAllHint.TabIndex = 24;
            this.butAddAllHint.Text = ">>";
            this.butAddAllHint.Click += new System.EventHandler(this.butAddAllHint_Click);
            // 
            // tabColMappingMode
            // 
            this.tabColMappingMode.Controls.Add(this.label25);
            this.tabColMappingMode.Controls.Add(this.butShowColsMapModeAttrib);
            this.tabColMappingMode.Controls.Add(this.butUpdateColMapMode);
            this.tabColMappingMode.Controls.Add(this.butCancel4);
            this.tabColMappingMode.Controls.Add(this.chkMapNonPublic);
            this.tabColMappingMode.Controls.Add(this.chkMapPublic);
            this.tabColMappingMode.Controls.Add(this.chkMappedOnly);
            this.tabColMappingMode.Location = new System.Drawing.Point(4, 40);
            this.tabColMappingMode.Name = "tabColMappingMode";
            this.tabColMappingMode.Size = new System.Drawing.Size(520, 244);
            this.tabColMappingMode.TabIndex = 3;
            this.tabColMappingMode.Text = "Mapping Mode";
            this.tabColMappingMode.ToolTipText = "Select which columns are to be used when mapping to database table.  This creates" +
                " a ColumnsMappingMode attribute declaration on this class.";
            // 
            // label25
            // 
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(268, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(116, 73);
            this.label25.TabIndex = 35;
            this.label25.Text = "This feature is obsolete.  Please do not use this.";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // butShowColsMapModeAttrib
            // 
            this.butShowColsMapModeAttrib.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butShowColsMapModeAttrib.Location = new System.Drawing.Point(32, 24);
            this.butShowColsMapModeAttrib.Name = "butShowColsMapModeAttrib";
            this.butShowColsMapModeAttrib.Size = new System.Drawing.Size(45, 23);
            this.butShowColsMapModeAttrib.TabIndex = 25;
            this.butShowColsMapModeAttrib.Text = "Show";
            this.butShowColsMapModeAttrib.Visible = false;
            this.butShowColsMapModeAttrib.Click += new System.EventHandler(this.butShowColsMapModeAttrib_Click);
            // 
            // butUpdateColMapMode
            // 
            this.butUpdateColMapMode.Location = new System.Drawing.Point(432, 216);
            this.butUpdateColMapMode.Name = "butUpdateColMapMode";
            this.butUpdateColMapMode.Size = new System.Drawing.Size(75, 23);
            this.butUpdateColMapMode.TabIndex = 7;
            this.butUpdateColMapMode.Text = "Create";
            this.butUpdateColMapMode.Click += new System.EventHandler(this.butUpdateColMapMode_Click);
            // 
            // butCancel4
            // 
            this.butCancel4.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel4.Location = new System.Drawing.Point(352, 216);
            this.butCancel4.Name = "butCancel4";
            this.butCancel4.Size = new System.Drawing.Size(75, 23);
            this.butCancel4.TabIndex = 6;
            this.butCancel4.Text = "Close";
            this.butCancel4.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // chkMapNonPublic
            // 
            this.chkMapNonPublic.Checked = true;
            this.chkMapNonPublic.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMapNonPublic.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkMapNonPublic.Location = new System.Drawing.Point(96, 88);
            this.chkMapNonPublic.Name = "chkMapNonPublic";
            this.chkMapNonPublic.Size = new System.Drawing.Size(104, 24);
            this.chkMapNonPublic.TabIndex = 2;
            this.chkMapNonPublic.Text = "Non-public";
            // 
            // chkMapPublic
            // 
            this.chkMapPublic.Checked = true;
            this.chkMapPublic.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMapPublic.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkMapPublic.Location = new System.Drawing.Point(96, 56);
            this.chkMapPublic.Name = "chkMapPublic";
            this.chkMapPublic.Size = new System.Drawing.Size(104, 24);
            this.chkMapPublic.TabIndex = 1;
            this.chkMapPublic.Text = "Public";
            // 
            // chkMappedOnly
            // 
            this.chkMappedOnly.Checked = true;
            this.chkMappedOnly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMappedOnly.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkMappedOnly.Location = new System.Drawing.Point(96, 24);
            this.chkMappedOnly.Name = "chkMappedOnly";
            this.chkMappedOnly.Size = new System.Drawing.Size(104, 24);
            this.chkMappedOnly.TabIndex = 0;
            this.chkMappedOnly.Text = "MappedOnly";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(240, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 32);
            this.label11.TabIndex = 21;
            this.label11.Text = "PK Member:";
            // 
            // lbPKMember
            // 
            this.lbPKMember.Location = new System.Drawing.Point(304, 80);
            this.lbPKMember.Name = "lbPKMember";
            this.lbPKMember.Size = new System.Drawing.Size(240, 32);
            this.lbPKMember.TabIndex = 17;
            this.lbPKMember.Text = "lbPKMember";
            // 
            // cmdReloadTable
            // 
            this.cmdReloadTable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdReloadTable.Location = new System.Drawing.Point(184, 71);
            this.cmdReloadTable.Name = "cmdReloadTable";
            this.cmdReloadTable.Size = new System.Drawing.Size(52, 23);
            this.cmdReloadTable.TabIndex = 22;
            this.cmdReloadTable.Text = "Reload";
            this.cmdReloadTable.Click += new System.EventHandler(this.cmdReloadTable_Click);
            // 
            // cmdShowTableMappingAtt
            // 
            this.cmdShowTableMappingAtt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowTableMappingAtt.Location = new System.Drawing.Point(500, 80);
            this.cmdShowTableMappingAtt.Name = "cmdShowTableMappingAtt";
            this.cmdShowTableMappingAtt.Size = new System.Drawing.Size(44, 23);
            this.cmdShowTableMappingAtt.TabIndex = 25;
            this.cmdShowTableMappingAtt.Text = "Show";
            this.cmdShowTableMappingAtt.Visible = false;
            this.cmdShowTableMappingAtt.Click += new System.EventHandler(this.cmdShowTableMappingAtt_Click);
            // 
            // cmdShowWebFormBuilder
            // 
            this.cmdShowWebFormBuilder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowWebFormBuilder.Location = new System.Drawing.Point(500, 56);
            this.cmdShowWebFormBuilder.Name = "cmdShowWebFormBuilder";
            this.cmdShowWebFormBuilder.Size = new System.Drawing.Size(44, 24);
            this.cmdShowWebFormBuilder.TabIndex = 25;
            this.cmdShowWebFormBuilder.Text = "Form";
            this.cmdShowWebFormBuilder.Visible = false;
            this.cmdShowWebFormBuilder.Click += new System.EventHandler(this.cmdShowWebFormBuilder_Click);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(352, 160);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(152, 40);
            this.label17.TabIndex = 22;
            this.label17.Text = "Click Create to launch collection class creation wizard.";
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Location = new System.Drawing.Point(432, 208);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Create";
            // 
            // label27
            // 
            this.label27.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label27.Location = new System.Drawing.Point(11, 96);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(282, 16);
            this.label27.TabIndex = 48;
            this.label27.Text = "Addin for Visual Studio 2005 (Netsoft USA Library 2)";
            // 
            // EntityBuilder
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.butCancel;
            this.ClientSize = new System.Drawing.Size(546, 408);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.cmdShowTableMappingAtt);
            this.Controls.Add(this.cmdShowWebFormBuilder);
            this.Controls.Add(this.cmdReloadTable);
            this.Controls.Add(this.tab);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbHelp);
            this.Controls.Add(this.cbTables);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbPKMember);
            this.Controls.Add(this.lbClassName);
            this.Controls.Add(this.label11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "EntityBuilder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Netsoft USA Entity Class Builder";
            this.TopMost = true;
            this.Closed += new System.EventHandler(this.EntityBuilder_Closed);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.EntityBuilder_Closing);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EntityBuilder_KeyPress);
            this.Load += new System.EventHandler(this.EntityBuilder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tab.ResumeLayout(false);
            this.tabColumnMapping.ResumeLayout(false);
            this.tabColumnMapping.PerformLayout();
            this.tabStoredProcs.ResumeLayout(false);
            this.tabDBMethods.ResumeLayout(false);
            this.tabChildren.ResumeLayout(false);
            this.tabChildren.PerformLayout();
            this.tabContainedObjects.ResumeLayout(false);
            this.tabBuildParamsMethods.ResumeLayout(false);
            this.tabCollections.ResumeLayout(false);
            this.tabOverrides.ResumeLayout(false);
            this.tabCodeGenOpt.ResumeLayout(false);
            this.tabSQLHint.ResumeLayout(false);
            this.tabColMappingMode.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void CreateClassMembers()
		{
			bool explicitAttribs = chkExplicitAttribs.Checked;
			CodeElement edLastElem = null;
			// Add all columns as member fields
			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				string colName = (string)lsMembers.Items[i];
				string memName = Util.NormalizeIdentifierName(colName, chkCamelNotation.Checked, txtPrefix.Text);
				CodeElement elem = Util.FindMemberForColumn(cls, colName, EnumStatementType.Free);

				if (elem != null)
				{
					if (elem.ProjectItem == cls.ProjectItem)
						edLastElem = elem;
				}
				DataColumn col = null;
				if (tbl != null)
					col = tbl.Columns[colName];
				if (col != null)
				{
					Type type = col.DataType;

					if (elem == null)
					{
						object insertPos = (int)0;		// add to start

						if (edLastElem != null)
							insertPos = edLastElem;

						EnvDTE.vsCMAccess accessLevel = EnvDTE.vsCMAccess.vsCMAccessPublic;
						switch (cbAccessLevel.SelectedIndex)
						{
							case 1:
								accessLevel = EnvDTE.vsCMAccess.vsCMAccessProject;
								break;
							case 2:
								accessLevel = EnvDTE.vsCMAccess.vsCMAccessProtected;
								break;
							case 3:
								accessLevel = EnvDTE.vsCMAccess.vsCMAccessPrivate;
								break;
						}

						CodeVariable var = cls.AddVariable(memName, 
							Util.GetVSNETTypeEnum(type),
							insertPos, 
							accessLevel, 
							null);

						edLastElem = (CodeElement)var;

						EditPoint edColMapAtt = null;
						// add column mapping attrib if necessary
						if (explicitAttribs || memName != colName)
							edColMapAtt = var.StartPoint.CreateEditPoint();
						
							//var.AddAttribute("ColumnMapping", 
							//	String.Format("\"{0}\"", colName),
							//	-1);

						if (edColMapAtt != null)
						{
							edColMapAtt.LineUp(1);
							edColMapAtt.EndOfLine();
							string valueForNullExp = Util.GetValueForNullExp(type, true);
							string extProps = Util.GetExtendedPropertiesForColumn(tbl.TableName, colName, var, col);
							if (extProps == null)
							{
								// make int's FK if specified
								if (chkIntsAreFKs.Checked && var.Type.TypeKind == vsCMTypeRef.vsCMTypeRefInt)
									extProps = "StereoType=DataStereoType.FK";	// declare
							}

							if (extProps != null)
								extProps = "," + extProps;
                            edColMapAtt.Insert(String.Format("\r\n\t\t[ColumnMapping({0}{1}{2})]", 
                                Util.MakeColumnIdent(this.tableName, colName, chkColumnNameConstants.Checked), 
                                valueForNullExp, extProps));
						}

						/*if (i == 0)
						{
							EditPoint ep = variable.StartPoint.CreateEditPoint();
							ep.LineUp(1);
							ep.EndOfLine();
							ep.Insert("\r\n\t\t#region Column Mapped Members");
						}
						if (i == tbl.Columns.Count - 1)
						{
							EditPoint ep = variable.EndPoint.CreateEditPoint();
							ep.Insert("\r\n\t\t#endregion");
						}*/

						if (chkCreateProps.Checked)
							Connect.Instance.BuildPropertyForField(col, cls, var as CodeElement, PropertyBuildMode.TypedGetSet, false);
					}
				}
			}

			if (edLastElem != null)
				edLastElem.EndPoint.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);

		}

		private void EnsureServerSideScriptProperty()
		{
			if (!chkEnsureServerScript.Checked)
				return;

			// ensures ServerScript property is available
			//   private ServerSideCalculationScript serverScript;
			//
			// public ServerSideCalculationScript serverScript
			// {  get; set; }

			CodeVariable serverScriptVar = Util.FindFirstMember(cls, "serverScript") as CodeVariable;
			if (serverScriptVar == null)
			{
				// add private sqlData member
				serverScriptVar = cls.AddVariable("serverScript",
					"ServerSideCalculationScript",
					0, 
					EnvDTE.vsCMAccess.vsCMAccessPrivate, 
					null);

				// Mark this as nonserialized
				Util.DeclareNonSerialized(serverScriptVar);
			}

			CodeProperty ServerScriptProp = Util.FindFirstMember(cls, "ServerScript") as CodeProperty;
			if (ServerScriptProp == null)
			{
				// add public ServerScript prop
				ServerScriptProp = cls.AddProperty("ServerScript", "ServerScript",
					"ServerSideCalculationScript",
					-1, 
					EnvDTE.vsCMAccess.vsCMAccessPublic, 
					null);

				// create get/set accessors for SqlData
				EditPoint ep = null;
				
				ep = ServerScriptProp.Getter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\t\tif (this.serverScript == null)\r\n"));
				ep.Insert(String.Format(
					"\t\t\t\t\tthis.serverScript = new ServerSideCalculationScript(this);\r\n",
					cls.Name));
				ep.Insert(String.Format("\t\t\t\treturn this.serverScript;"));

				ep = ServerScriptProp.Setter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\t\tthis.serverScript = value;\r\n"));
			}
		}

		public void EnsureSqlDataProp()
		{
            return;     // Never create sqldata.  !!! Implement service locator.
            /*
			if (!chkEnsureSqlData.Checked)
				return;

			// ensures SqlData property is available
			//   private SQLDataDirect sqlData;
			//
			// public SQLDataDirect SqlData
			// {  get; set; }

            CodeProperty SqlDataProp = Util.FindFirstMember(cls, "SqlData") as CodeProperty;
			if (SqlDataProp == null)
			{
				// add public SqlData prop
                SqlDataProp = cls.AddProperty("SqlData", "SqlData",
                    "SQLDataDirect", // this.extendsBaseEntity ? "override SQLDataDirect" : "SQLDataDirect",
					-1, 
					EnvDTE.vsCMAccess.vsCMAccessPublic, 
					null);

                if (this.extendsBaseEntity)
                {
                    ((CodeFunction2)SqlDataProp.Getter).OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;
                }

				// create get/set accessors for SqlData
				EditPoint ep = null;
				
				ep = SqlDataProp.Getter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\t\tif (this.sqlData == null)\r\n"));
				ep.Insert(String.Format(
					"\t\t\t\t\tthis.sqlData = SQLDataDirect.CreateSqlDataForType(typeof({0}));\r\n",
					cls.Name));
				ep.Insert(String.Format("\t\t\t\treturn this.sqlData;"));

				ep = SqlDataProp.Setter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\t\tthis.sqlData = value;\r\n"));
			}*/
		}

		private void CreateParameterizedMethods()
		{
			CodeFunction funcConst = null;
			CodeFunction funcLoad = null;
			CodeFunction funcExecuteReader = null;
			CodeFunction funcExecuteSQL = null;
			CodeFunction funcExecuteStoredProc = null;
			CodeFunction funcCalculateScript = null;
			CodeFunction funcNew = null;
			
			if (chkConstructor.Checked)
			{
				// find last constructor
				object insertPos = Util.FindLastMember(cls, cls.Name);

				if (insertPos == null)
					insertPos = 0;		// otherwise add to beginning of class

				// add the constructor with specified params
				funcConst = cls.AddFunction(cls.Name, EnvDTE.vsCMFunction.vsCMFunctionConstructor,
					EnvDTE.vsCMTypeRef.vsCMTypeRefOther,
					insertPos,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

			}

			if (chkCalculateScriptMethod.Checked)
			{
				EnsureServerSideScriptProperty();
				// add the calculate script method with specified parameters
				funcCalculateScript = cls.AddFunction("CalculateScript", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefObject,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

			}

			if (chkNewMethod.Checked)
			{
				// add the calculate script method with specified parameters
				funcNew = cls.AddFunction("New", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				funcNew.Comment = "Initializes the Entity Object's record status flags and members with the given parameters.";
			}

			if (chkLoad.Checked)
			{
				EnsureSqlDataProp();

				// add the load method with specified params
				funcLoad = cls.AddFunction("Load", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				funcLoad.Comment = "Loads the object specified by parameters from table";
			}

			if (chkExecuteReaderMethod.Checked)
			{
				EnsureSqlDataProp();

				// add the constructor with specified params
				funcExecuteReader = cls.AddFunction("ExecuteReader", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					"IDataReader",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				funcExecuteReader.Comment = "Runs a query on this table with specified parameters and returns a data reader";
			}

			if (chkExecuteSQL.Checked)
			{
				// EnsureSqlDataProp();  // ExecuteSQL creates a new SQLDataDirect

				funcExecuteSQL = cls.AddFunction("ExecuteSQL", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					"IDataReader",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				funcExecuteSQL.Comment = "Runs an SQL query with specified parameters and returns a data reader";
			}

			CodeClass targetCls = cls;
			CodeClass colCls = null;
			CodeClass elemCls = null;
			if (chkExecuteStoredProcMethod.Checked)
			{
				EnsureSqlDataProp();

				string methodName = Util.MakeMethodNameFromSPName(cbSprocName.Text);
				object returnType = "IDataReader";
				if (true) // check SP or SQL instead .. extendsBaseEntity)
				{
					methodName = spOptions.MethodName;
					returnType = spOptions.GetReturnType();
				}
				if (spOptions.resultUsage == EnumResultUsage.FillIntoCollection)
					if (spOptions.CollectionClassName != null)
					{
						colCls = Util.FindClassInProject(spOptions.CollectionClassName);
						targetCls = colCls;
						if (targetCls == null)
						{
							Connect.Instance.ShowDialog(this, "Can't find collection class " + spOptions.CollectionClassName);
						}
						else
						{
							elemCls = Util.GetElementClassOfCollection(colCls);
						}
					}

				if (targetCls != null)
				{
					funcExecuteStoredProc = targetCls.AddFunction(methodName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
						returnType,
						-1,
						EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);

					funcExecuteStoredProc.Comment = "Executes a stored procedure.";
				}
			}

			if (chkToStringMethod.Checked)
			{
				// add the ToString to display the given members
                CodeFunction2 func = (CodeFunction2)cls.AddFunction("ToString", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefString, // "override string",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

				func.Comment = "Returns a string representation of the class instance";

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);

				ep.Insert(String.Format("\t\t\tstring s = this.GetType().Name + \"\\r\\n\";\r\n"));
				ep.Insert("\t\t\ts += \"{\\r\\n\";\r\n");
				// display members
				for (int i = 0; i < lsParams.Items.Count; i++)
				{
					string member = (string)lsParams.Items[i];
					ep.Insert(String.Format("\t\t\ts += \"\t{0}= '\" + ReflectionHelper.GetMemberValueAsString(this, \"{0}\") + \"'\\r\\n\";\r\n", member));
				}
				ep.Insert("\t\t\ts += \"}\\r\\n\";\r\n");
				ep.Insert("\t\t\treturn s;\r\n");
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (funcConst != null 
				|| funcLoad != null 
				|| funcExecuteReader != null 
				|| funcExecuteSQL != null
				|| funcExecuteStoredProc != null
				|| funcCalculateScript != null
				|| funcNew != null)
			{
				//string pkMember = null;
				//if (funcLoadByPK != null)

				if (funcExecuteStoredProc != null)
				{
					if (true) //extendsBaseEntity)
						if (spOptions.resultUsage == EnumResultUsage.FillIntoCollection)
						{
							if (spOptions.CollectionClassName == null)
							{
								// Create on this class
								funcExecuteStoredProc.AddParameter("maxRecords", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
								funcExecuteStoredProc.AddParameter("collection", "System.Collections.IList", -1);
							}
							else
							{
								// Created on the specified collection class
								funcExecuteStoredProc.AddParameter("maxRecords", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
							}
						}
				}

				// add initNew param for constructor if any
				if (funcConst != null)
					if (lsParams.Items.Count == 0)
					{
						// Create a constructor with initNew
						funcConst.AddParameter("initNew", vsCMTypeRef.vsCMTypeRefBool, -1);
					}
				// add parameters
				for (int i = 0; i < lsParams.Items.Count; i++)
				{
					string param = (string)lsParams.Items[i];
					CodeVariable var = Util.FindFirstMember(cls, param) as CodeVariable;
					if (funcConst != null)
						funcConst.AddParameter(param, var.Type, -1);
					if (funcCalculateScript != null)
						funcCalculateScript.AddParameter(param, var.Type, -1);
					if (funcLoad != null)
						funcLoad.AddParameter(param, var.Type, -1);
					if (funcExecuteReader != null)
						funcExecuteReader.AddParameter(param, var.Type, -1);
					if (funcExecuteSQL != null)
						funcExecuteSQL.AddParameter(param, var.Type, -1);
					if (funcExecuteStoredProc != null)
						funcExecuteStoredProc.AddParameter(param, var.Type, -1);
					if (funcNew != null)
						funcNew.AddParameter(param, var.Type, -1);
				}

				// if no params were specified for CalculateScript, add a 'string expression' parameter
				if (funcCalculateScript != null)
					if (lsParams.Items.Count == 0)
						funcCalculateScript.AddParameter("expression", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);

				// load by pk parameter
				/*if (pkMember != null)
				{
					CodeVariable var = cls.Members.Item(pkMember) as CodeVariable;
					funcLoadByPK.AddParameter(pkMember, var.Type, -1);
				}*/

				EditPoint epConst = null;
				EditPoint epLoad = null;
				EditPoint epExecuteReader = null;
				EditPoint epExecuteSQL = null;
				EditPoint epExecuteStoredProc = null;
				EditPoint epNew = null;

				if (funcConst != null)
				{
					epConst = funcConst.StartPoint.CreateEditPoint();
					epConst.LineDown(2);
					epConst.StartOfLine();

					if (lsParams.Items.Count == 0)	// initNew param const
					{
						epConst.Insert(String.Format("\t\t\tif (initNew) // initialize record if requested\r\n"));
						epConst.Insert(String.Format("\t\t\t\tthis.NewRecord();\r\n"));
					}
					else
					{
						epConst.Insert(String.Format("\t\t\tthis.NewRecord(); // initialize record state\r\n"));
						// add assignment statements
						for (int i = 0; i < lsParams.Items.Count; i++)
						{
							string param = (string)lsParams.Items[i];
							epConst.Insert(String.Format("\t\t\tthis.{0} = {0};\r\n", param));
						}
					}

					epConst.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				string queryMems = "";
				for (int i = 0; i < lsParams.Items.Count; i++)
					queryMems += ", " + (string)lsParams.Items[i];
				queryMems = queryMems.Trim(',', ' ');

				string valuesArr = "{" + queryMems + "}";
				string paramsArr = "";
				for (int i = 0; i < lsParams.Items.Count; i++)
					paramsArr += ", \"" + (string)lsParams.Items[i] + "\"";
				paramsArr = "{" + paramsArr.Trim(',',' ') + "}";

				if (funcLoad != null)
				{
					epLoad = funcLoad.StartPoint.CreateEditPoint();
					epLoad.LineDown(2);
					epLoad.StartOfLine();
					Util.DeleteEditLine(epLoad);

					// Add load method code

					// use base Entity Class
					epLoad.Insert("\t\t\t// TODO: Specify stored procedure name correctly.\r\n");
					epLoad.Insert(String.Format("\t\t\treturn SqlData.SPExecReadObj(\"usp_Load\" + this.RootName, this, false, {0});", queryMems));

					epLoad.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				if (funcNew != null)
				{
					epNew = funcNew.StartPoint.CreateEditPoint();
					epNew.LineDown(2);
					epNew.StartOfLine();
					Util.DeleteEditLine(epNew);

					// Add new method code
					if (true) //extendsBaseEntity)
						epNew.Insert(String.Format("\t\t\tthis.NewRecord(); // initialize record state\r\n"));

					for (int i = 0; i < lsParams.Items.Count; i++)
					{
						epNew.Insert(String.Format("\t\t\tthis.{0} = {0};", (string)lsParams.Items[i]));
						if (i < lsParams.Items.Count - 1)
							epNew.Insert("\r\n");
					}

					epNew.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				if (funcCalculateScript != null)
				{
					EditPoint ep = funcCalculateScript.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					Util.DeleteEditLine(ep);

					if (lsParams.Items.Count == 0)
						ep.Insert(String.Format("\t\t\treturn this.ServerScript.Calculate(expression);"));
					else
						ep.Insert(String.Format("\t\t\treturn this.ServerScript.Calculate(\"2+2\"); // use the parameters to build the script, evaluate it, and return"));
					ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				if (funcExecuteReader != null)
				{
					epExecuteReader = funcExecuteReader.StartPoint.CreateEditPoint();
					epExecuteReader.LineDown(2);
					epExecuteReader.StartOfLine();
					Util.DeleteEditLine(epExecuteReader);

					// Add ExecuteReader method code

					if (true) //this.extendsBaseEntity)
					{
						// use base Entity Class
						epExecuteReader.Insert("\t\t\t// TODO: Specify stored procedure name correctly.\r\n");
						epExecuteReader.Insert(String.Format("\t\t\treturn SqlData.SPExecRead(\"usp_Read\" + this.RootName, {0});", queryMems));
					}
					
					epExecuteReader.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				if (funcExecuteSQL != null)
				{
					string tableName = Util.GetTableMappingForClass(cls);

					epExecuteSQL = funcExecuteSQL.StartPoint.CreateEditPoint();
					epExecuteSQL.LineDown(2);
					epExecuteSQL.StartOfLine();
					Util.DeleteEditLine(epExecuteSQL);

					// Add ExecuteSQL method code
					string where = "";
					for (int i = 0; i < lsParams.Items.Count; i++)
					{
						string param = (string)lsParams.Items[i];
						if (i > 0)
							where += " and ";
						where += param + "=@" + param;
					}

					// Add ExecuteSQL method code
					
					epExecuteSQL.Insert(String.Format("\t\t\treturn SqlData.ExecuteSQL(false, \"select * from [{0}] where \" +\r\n", tableName));
					epExecuteSQL.Insert(String.Format("\t\t\t\t\"{0}\",\r\n", where));
					epExecuteSQL.Insert(String.Format("\t\t\t\tnew string[] {0},\r\n", paramsArr));
					epExecuteSQL.Insert(String.Format("\t\t\t\tnew object[] {0} );", valuesArr));

					epExecuteSQL.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

					/*
					epExecuteSQL.Insert(String.Format("\t\t\tSQLParser sql = new SQLParser(\"select * from [{0}] where \" +\r\n", tableName));
					epExecuteSQL.Insert(String.Format("\t\t\t\t\"{0}\");\r\n", where));
					epExecuteSQL.Insert(String.Format("\t\t\tSQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);\r\n"));
					for (int i = 0; i < lsParams.Items.Count; i++)
					{
						string param = (string)lsParams.Items[i];
						epExecuteSQL.Insert(String.Format("\t\t\tsd.SQLCommand.Parameters[\"@{0}\"].Value = {0};\r\n", param));
					}
					epExecuteSQL.Insert(String.Format("\t\t\treturn sd.ExecuteReader();\r\n"));

					epExecuteSQL.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);*/
				}

				if (funcExecuteStoredProc != null)
				{
					string tableName = Util.GetTableMappingForClass(cls);

					epExecuteStoredProc = funcExecuteStoredProc.StartPoint.CreateEditPoint();
					epExecuteStoredProc.LineDown(2);
					epExecuteStoredProc.StartOfLine();
					Util.DeleteEditLine(epExecuteStoredProc);

					// Add ExecuteStoredProc method code

					if (true) //this.extendsBaseEntity)
					{
						// use base Entity Class
						// create the stored proc invoker method using the stored proc options
						string funcInvokerPart = spOptions.GetFuncInvokerPart();
						string selectedParams = null, selectedParamsArr = null, selectedValuesArr = null;
						if (spOptions.UseSPParams)  // special option to use the stored procedure parameters directly.
						{
							string[] prms = Util.GetStoredProcParameters(cbSprocName.Text);
							selectedParams = String.Join(", ", prms); 
							selectedParamsArr = "{ " + Util.JoinStrings(", ", prms, "\"{0}\"") + " }";
							selectedValuesArr = "{ " + String.Join(", ", prms) + " }";
						}
						else
						{
							selectedParams = queryMems;
							selectedParamsArr = paramsArr;
							selectedValuesArr = valuesArr;
						}
						string parameters = spOptions.GetParams(selectedParams, selectedParamsArr, selectedValuesArr);
						if (parameters == null)
							parameters = "/* procedure parameters */";
						else
							parameters = ", " + parameters;
						if (spOptions.resultUsage == EnumResultUsage.FillIntoCollection)
						{
							if (spOptions.CollectionClassName == null)
								parameters = parameters.Replace("@collection@", "collection");
							else
								parameters = parameters.Replace("@collection@", "this");		// fill the collection itself
						}
						string code = null;
						if (spOptions.createChildLoader)
							code = String.Format("\t\t\tthis.{0} = ({1}){1}.LoadChildCollection(\"{2}\", this, typeof({1}), {0}, forceReload{3});", "childMember", spOptions.CollectionClassName, cbSprocName.Text, queryMems);
						else
						{
							if (spOptions.resultUsage == EnumResultUsage.FillIntoCollection)
								epExecuteStoredProc.Insert(String.Format("\t\t\tthis.Clear();\r\n"));
							code = String.Format("\t\t\t{0}(\"{1}\"{2});", funcInvokerPart, cbSprocName.Text, parameters);
						}
						epExecuteStoredProc.Insert(code);
					}

					epExecuteStoredProc.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

					string proc = Util.GetStoredProcFromDB(cbSprocName.Text);
					if (proc == null)		// doesn't exist
					{
						// never recreate if the proc already exists
						Util.SetStoredProcOnDB(this, cbSprocName.Text, GenerateParameterizedSP(cbSprocName.Text), false, false);
					}

					// Create a cached (static) prop if asked for
					if (spOptions.resultUsage == EnumResultUsage.FillIntoCollection)
					{
						if (colCls != null && elemCls != null)
						{
							if (spOptions.createCachedProp)
							{
								CreateCollectionCachedMemberDlg.CreateCachedMember(colCls, elemCls, spOptions.MethodName);
							}
						}
					}

				}
				
			}

			chkConstructor.Checked = false;
			chkLoad.Checked = false;
			chkExecuteReaderMethod.Checked = false;
			chkExecuteSQL.Checked = false;
			chkToStringMethod.Checked = false;
			chkExecuteStoredProcMethod.Checked = false;
			chkCalculateScriptMethod.Checked = false;
			chkNewMethod.Checked = false;
			EnableButtons(tabBuildParamsMethods);
		}

		private void CreateDBMethods()
		{
			if (chkInsertMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Insert Method
				CodeFunction2 func = (CodeFunction2)cls.AddFunction("Insert", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindNew;

				func.Comment = "Inserts the object into table";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				if (true) //this.extendsBaseEntity)
				{
					ep.Insert(String.Format("\t\t\tInternalInsert();\r\n"));
					ep.Insert(String.Format("\t\t\tOnCompleteSave();"));
				}

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkReadMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Insert Method
				CodeFunction func = cls.AddFunction("Read", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Reads the object from the given source data reader";

				func.AddParameter("sourceReader", "IDataReader", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\treturn SqlData.ReadObj(sourceReader, this, true, false);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkLoadFromDataRowView.Checked)
			{
				// add Load from datarowview Method
				CodeFunction func = cls.AddFunction("Load", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Loads the object from the given DataRowView";

				func.AddParameter("rowView", "System.Data.DataRowView", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				//Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\tDataViewFiller.FillIntoObject(rowView, this, true, false);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkSaveToDataRowView.Checked)
			{
				// add Load from datarowview Method
				CodeFunction func = cls.AddFunction("Save", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Saves the object to the given DataRowView";

				func.AddParameter("rowView", "System.Data.DataRowView", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				//Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\tDataViewFiller.FillFromObject(rowView, this, true, false);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkReadColMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Insert Method
				CodeFunction func = cls.AddFunction("ReadCollection", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Reads multiple objects of this type from source data reader into the given collection";

				func.AddParameter("sourceReader", "IDataReader", -1);
				func.AddParameter("maxRecords", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("collection", "System.Collections.IList", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\treturn SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof({0}), true, false);", cls.Name));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkUpdateMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Update Method
                CodeFunction2 func = (CodeFunction2)cls.AddFunction("Update", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                //if (this.extendsBaseEntity)
                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindNew;

				func.Comment = "Updates the object into the table";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				if (true) //this.extendsBaseEntity)
				{
					ep.Insert(String.Format("\t\t\tInternalUpdate();\r\n"));
					ep.Insert(String.Format("\t\t\tOnCompleteSave();"));
				}

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkSaveMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Save Method
                //EnvDTE80.CodeFunction2 f;
                //f.OverrideKind = EnvDTE80.vsCMOverrideKind.vsCMOverrideKindNew;
                //cc.AddFunction("", EnvDTE80.
                CodeFunction2 func = (CodeFunction2)cls.AddFunction("Save", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                //if (this.extendsBaseEntity )
                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindNew;
                
				func.Comment = "Updates or Inserts the object into the table.  If the object is marked as 'new', it'll be inserted otherwise it'll be updated.";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
                if (Util.IsEntityWithDataAccess(cls))
                {
                    ep.Insert(String.Format("\t\t\t// If there are contained objects to be saved in transaction\r\n"));
                    ep.Insert(String.Format("\t\t\t// ensure transaction to use the passed transaction or to create one if there's no transaction;\r\n"));
                    ep.Insert(String.Format("\t\t\t// this.SqlData.EnsureTransaction();\r\n"));
                    ep.Insert(String.Format("\t\t\ttry\r\n"));
                    ep.Insert(String.Format("\t\t\t{0}\r\n", "{"));
                    ep.Insert(String.Format("\t\t\t\tbase.Save();\r\n"));
                    ep.Insert(String.Format("\t\t\t\t// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed\r\n"));
                    ep.Insert(String.Format("\t\t\t{0}\r\n", "}"));
                    ep.Insert(String.Format("\t\t\tcatch\r\n"));
                    ep.Insert(String.Format("\t\t\t{0}\r\n", "{"));
                    ep.Insert(String.Format("\t\t\t\t// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed\r\n"));
                    ep.Insert(String.Format("\t\t\t\t// Failure handling code here\r\n"));
                    ep.Insert(String.Format("\t\t\t\tthrow; // always re-throw exception to notify the client\r\n"));
                    ep.Insert(String.Format("\t\t\t{0}", "}"));
                }
                else
                {
                    ep.Insert(String.Format("\t\t\t// Transaction should be handled in the service class.\r\n"));
                    ep.Insert(String.Format("\t\t\tbase.Save();\r\n"));
                }

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkSynchronizeMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Synchronize Method
				CodeFunction2 func = (CodeFunction2)cls.AddFunction("Synchronize", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                //if (this.extendsBaseEntity)
                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindNew;

				func.Comment = "Updates/Inserts/Deletes/Loads a record depending on its status flags.";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();

				ep.Insert(String.Format("\t\t\tbase.Synchronize();"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkLoadByPKMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Delete(PK) Method
				CodeFunction func = cls.AddFunction("Load", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Loads the object specified by a PK value from table";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				CodeVariable[] vars = Util.FindVars(cls, pkMembers); // cls.Members.Item(pkMember)
				if (vars == null)
					Connect.Instance.ShowDialog(this, "Can't find PK member " + PKMembersStr);
				else
				{
					Util.AddMembersAsFuncParam(vars, func);
					//if (this.extendsBaseEntity)
					ep.Insert(String.Format("\t\t\treturn base.Load({0});", GetPKMembersCommaSep(null)));
				}
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkExistsByPK.Checked)
			{
				EnsureSqlDataProp();

				// add Exists(PK) Method
				CodeFunction func = cls.AddFunction("Exists", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Checks if the record with the specified id exists";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				CodeVariable[] vars = Util.FindVars(cls, pkMembers); // as CodeVariable; //cls.Members.Item(pkMember) as CodeVariable;
				if (vars == null)
					Connect.Instance.ShowDialog(this, "Can't find PK member " + PKMembersStr);
				else
				{
					Util.AddMembersAsFuncParam(vars, func);
					ep.Insert(String.Format("\t\t\treturn Convert.ToBoolean(SqlData.SPExecScalar(\"usp_Exists\" + this.RootName, {0}) );", GetPKMembersCommaSep(null) ));
				}
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkExists.Checked)
			{
				EnsureSqlDataProp();

				// add Exists Method
				CodeFunction func = cls.AddFunction("Exists", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Checks if the object exists in the table";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\treturn Convert.ToBoolean(SqlData.SPExecScalar(\"usp_Exists\" + this.RootName, {0}) );", GetPKMembersCommaSep("this.") ));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkDeleteByPKMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Delete(PK) Method
				CodeFunction func = cls.AddFunction("Delete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Deletes the object specified by a PK value from table";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				CodeVariable[] vars = Util.FindVars(cls, pkMembers); // as CodeVariable; //cls.Members.Item(pkMember) as CodeVariable;
				if (vars == null)
					Connect.Instance.ShowDialog(this, "Can't find PK member " + PKMembersStr);
				else
				{
					Util.AddMembersAsFuncParam(vars, func);
					ep.Insert(String.Format("\t\t\tbase.Delete({0});", GetPKMembersCommaSep(null) ));
				}
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkDeleteMethod.Checked)
			{
				EnsureSqlDataProp();

				// add Delete Method
				CodeFunction2 func = (CodeFunction2)cls.AddFunction("Delete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindNew;

				func.Comment = "Deletes this object from table";

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();

				if (true) //this.extendsBaseEntity)
				{
					ep.Insert(String.Format("\t\t\tInternalDelete();\r\n"));
					ep.Insert(String.Format("\t\t\tOnCompleteSave();"));
				}

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			chkAllDBMethods.Checked = false;
			chkAllUtilityMethods.Checked = false;
			chkAllDBMethods_CheckedChanged(this, new System.EventArgs());
			chkAllUtilityMethods_CheckedChanged(this, new System.EventArgs());
			/*
			chkReadColMethod.Checked = false;
			chkReadMethod.Checked = false;
			chkLoadByPKMethod.Checked = false;
			chkInsertMethod.Checked = false;
			chkUpdateMethod.Checked = false;
			chkSaveMethod.Checked = false;
			chkDeleteByPKMethod.Checked = false;
			chkDeleteMethod.Checked = false;

			chkLoadFromDataRowView.Checked = false;
			chkSaveToDataRowView.Checked = false;*/

			EnableButtons();
		}

		private void ReadSettings()
		{
			chkEnsureSqlData.Checked = Util.GetSetting(cls.Name, "EnsureSqlData", false); //!this.extendsBaseEntity);
			chkEnsureServerScript.Checked = Util.GetSetting(cls.Name, "EnsureServerScript", true);
			chkDeclareSPAtt.Checked = Util.GetSetting(cls.Name, "DeclareSPAtt", true);
		}

		private void WriteSettings()
		{
			Util.SetSetting(cls.Name, "EnsureSqlData", chkEnsureSqlData.Checked);
			Util.SetSetting(cls.Name, "EnsureServerScript", chkEnsureServerScript.Checked);
			Util.GetSetting(cls.Name, "DeclareSPAtt", chkDeclareSPAtt.Checked);
			Util.SaveFormPos(this);
		}

		private void EntityBuilder_Load(object sender, System.EventArgs e)
		{
			Util.LoadFormPos(this, false);
			this.Text += "    Class Name='" + cls.Name + "'";

            chkSynchronizeMethod.Visible = false; // this.extendsBaseEntity;

			GetTablePrototype();
			if (tbl == null)
			{
				//this.Close();
				//return;
			}

			CacheClassProperties();

			ReadSettings();

			DisplayHelp();
			cbAccessLevel.SelectedIndex = 3;		// private by default
			Util.FillTableNamesInCombo(cbTables, chkUpdateMethod.Checked);
			
			FillLists();

			EnableButtons();
		}

		public string TableName
		{
			get { return cbTables.Text; }
			set 
			{ 
				cbTables.Text = value;
			}
		}

		public static void BuildClass(CodeClass cls)
		{
			EntityBuilder bld = new EntityBuilder();
			bld.TableName = Util.GetTableMappingForClass(cls);
			bld.lbClassName.Text = cls.Name;
			//bld.extendsBaseEntity = Util.IsDerivedFromBaseEntity(cls);
			if (true) //bld.extendsBaseEntity)
			{
				bld.lbClassName.ForeColor = System.Drawing.Color.Navy;
				bld.lbClassName.Font = new Font(bld.lbClassName.Font, FontStyle.Bold);
				//bld.lbClassName.Text += ": BaseEntity";
				ToolTip tooltip = new ToolTip();
				tooltip.ShowAlways = true;
				//tooltip.SetToolTip(bld.lbClassName, "This class extends BaseEntity.  Methods will be generated based on the base class.");

				tooltip = new ToolTip();
				tooltip.ShowAlways = true;
				tooltip.SetToolTip(bld.butCreateSPLoadChild, "This button is enabled, if the stored procedure defined for this child hasn't yet been created.  Click this to create it.");
			}
			bld.cls = cls;
			
			bld.Show(); // ShowDialog(Connect.Instance);
		}

		private void butUpdateMembers_Click(object sender, System.EventArgs e)
		{
			try
			{
				CreateClassMembers();
				FillLists();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}


		private void GetTablePrototype()
		{
			try
			{
				tbl = Util.GetTablePrototype(cbTables.Text);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, String.Format("Can't access to table {0}.\r\n{1}", 
					cbTables.Text, ex.Message));																					 
				//this.Close();
			}
		}

		private void cbTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			GetTablePrototype();
			FillColumns();
		}

		private bool IsColumnMapped(string colName)
		{
			return lsMembers.Items.Contains(colName);
		}

		private bool IsColumnInSQLHint(string colName)
		{
			return lsSQLHintCols.Items.Contains(colName);
		}

		private void FillLists()
		{
			FillColMapMembers();
			FillColumns();
			FillAllFields();
		}

		private void FillColumns()
		{
			lsColumns.Items.Clear();
			lsColumns2.Items.Clear();

			if (tbl != null)
			{
				for (int i = 0; i < tbl.Columns.Count; i++)
				{
					string colName = tbl.Columns[i].ColumnName;
					if (!IsColumnMapped(colName))
					{
						lsColumns.Items.Add(colName);
					}

					if (!IsColumnInSQLHint(colName))
					{
						lsColumns2.Items.Add(colName);
					}
				}
			}
			ArrangeListByTableColumnOrder(lsColumns);
		}

		private void FillColMapMembers(CodeClass cls)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colName = Util.GetColMappingForVar(var, false);

					string joinRelation = Util.GetJoinRelationForVar(var);

					// if join relation, don't check for validity
					if (joinRelation == null || joinRelation == "")
					{
						if (colName != null)	// only if mapped
						{
							if (tbl != null && tbl.Columns.Contains(colName))
								lsMembers.Items.Add(tbl.Columns[colName].ColumnName);
							else
							{
								lsInvalidMappings.Items.Add(colName);
								chkShowInvalidMappings.Visible = true;
							}
						}
					}
				}
			}

			// fill the column mapping members in the bases too
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillColMapMembers(cls.Bases.Item(i) as CodeClass);
				}
			}
		}

		private void FillColMapMembers()
		{
			lsMembers.Items.Clear();
			lsInvalidMappings.Items.Clear();
			chkShowInvalidMappings.Visible = false;
			chkShowInvalidMappings.Checked = false;
			lsInvalidMappings.Visible = false;
			FillColMapMembers(cls);
		}

		private void FillOverridableAndOverriddenMethods()
		{
			//object[] noParams = new object[] {};
			lstOverriddenMethods.Items.Clear();
			lstOverridables.Items.Clear();
			for (int i = 0; i < allOverridables.Length; i++)
			{
				string method = allOverridables[i];
				CodeFunction func = Util.FindFirstMethod(false, cls, method, null);
				if (func != null)
					lstOverriddenMethods.Items.Add(method);		// overridden
				else
					lstOverridables.Items.Add(method);			// not overridden
			}
		}

		private void FillAllFields()
		{
			lsAllFields.Items.Clear();
			lsParams.Items.Clear();
			Util.FillFieldsAndParams(cls, lsAllFields, lsParams);
			ArrangeListByTableColumnOrder(lsAllFields, true);
		}

		private void FillCollectionClasses()
		{
			lsCollectionClasses.Items.Clear();
			object[] colClasses = Util.FindCollectionClassesInProject(cls.ProjectItem.ContainingProject, cls.Name);
			for (int i = 0; i < colClasses.Length; i++)
			{
				CodeClass colClass = colClasses[i] as CodeClass;
				if (colClass != null)
					lsCollectionClasses.Items.Add(colClass.Name);
			}
		}

		private void FillChildren()
		{
			lsChildren.Items.Clear();
			FillChildren(cls);
		}

		private void FillChildren(CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "ChildCollection", "SPLoadChild", "SimpleRelation"))
					lsChildren.Items.Add(elem.Name);
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillChildren(cls.Bases.Item(i) as CodeClass);
				}
			}
		}

		private void FillContainedEntityObjects()
		{
			lsContainedEntityObjects.Items.Clear();
			FillContainedEntityObjects(cls);
		}

		private void FillContainedEntityObjects(CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				CodeProperty prop = elem as CodeProperty;
				if (prop != null)
				{
					if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
					{
						if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "Contained"))
						{
							lsContainedEntityObjects.Items.Add(elem.Name);
						}
					}
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillContainedEntityObjects(cls.Bases.Item(i) as CodeClass);
				}
			}
		}

		private void FillParentObjects()
		{
			lsParentObjects.Items.Clear();
			FillParentObjects(cls);
		}

		private void FillParentObjects(CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				CodeProperty prop = elem as CodeProperty;
				if (prop != null)
				{
					if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
					{
						if (prop.Name.Length >= 6)
						if (prop.Name.Substring(0, 6).ToLower() == "parent")
						{
							lsParentObjects.Items.Add(prop.Name);
						}
					}
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillParentObjects(cls.Bases.Item(i) as CodeClass);
				}
			}
		}

		private void FillSprocNames()
		{
			cbSprocName.Items.Clear();
			string[] procs = Util.GetStoredProcsFromDB();
			cbSprocName.Items.AddRange(procs);
		}

		private void ArrangeListByTableColumnOrder(ListBox lst)
		{
			Util.ArrangeListByTableColumnOrder(tbl, cls, lst);
		}

		private void ArrangeListByTableColumnOrder(ListBox lst, bool memberNames)
		{
			Util.ArrangeListByTableColumnOrder(tbl, cls, lst, memberNames);
		}

		private void butAdd_Click(object sender, System.EventArgs e)
		{
			if (lsColumns.SelectedIndex < 0)
				return;
			lsMembers.Items.Add(lsColumns.Items[lsColumns.SelectedIndex]);
			int sel = lsColumns.SelectedIndex;
			lsColumns.Items.RemoveAt(sel);
			ArrangeListByTableColumnOrder(lsMembers);
			if (sel < lsColumns.Items.Count)
				lsColumns.SelectedIndex = sel;
			EnableButtons(tabColumnMapping);
		}

		private void butRemove_Click(object sender, System.EventArgs e)
		{
			if (lsMembers.SelectedIndex < 0)
				return;
			lsColumns.Items.Add(lsMembers.Items[lsMembers.SelectedIndex]);
			int sel = lsMembers.SelectedIndex;
			lsMembers.Items.RemoveAt(sel);
			ArrangeListByTableColumnOrder(lsColumns);
			if (sel < lsMembers.Items.Count)
				lsMembers.SelectedIndex = sel;
			EnableButtons(tabColumnMapping);
		}

		private void lsColumns_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabColumnMapping);
		}

		private void lsMembers_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabColumnMapping);

			int sel = lsMembers.SelectedIndex;
			if (sel < 0)
				return;

			string colName = (string)lsMembers.Items[sel];

			CodeElement elem = Util.FindMemberForColumn(cls, colName, EnumStatementType.Free);
			Util.MarkElement(cls, elem);
		}

		private void butAddAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsColumns.Items.Count; i++)
			{
				lsMembers.Items.Add(lsColumns.Items[i]);
			}
			lsColumns.Items.Clear();
			ArrangeListByTableColumnOrder(lsMembers);
			EnableButtons(tabColumnMapping);
		}

		private void butRemoveAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				lsColumns.Items.Add(lsMembers.Items[i]);
			}
			ArrangeListByTableColumnOrder(lsColumns);
			lsMembers.Items.Clear();
			EnableButtons(tabColumnMapping);
		}

		private void EnableButtons()
		{
			EnableButtons(null);
		}

		private void EnableButtons(TabPage tab)
		{
			if (tab == null || tab == tabColumnMapping)
			{
				butAdd.Enabled = lsColumns.SelectedIndex >= 0;
				butRemove.Enabled = lsMembers.SelectedIndex >= 0;
				butUpdateMembers.Enabled = lsMembers.Items.Count > 0;
			}

			if (tab == null || tab == tabSQLHint)
			{
				butAddHint.Enabled = lsColumns2.SelectedIndex >= 0;
				butRemoveHint.Enabled = lsSQLHintCols.SelectedIndex >= 0;
				butCreateSQLHintAttrib.Enabled = lsSQLHintCols.Items.Count > 0;
			}

			if (tab == null || tab == tabDBMethods)
			{
				chkLoadByPKMethod.Enabled = pkMembers != null;
				if (!chkLoadByPKMethod.Enabled)
					chkLoadByPKMethod.Checked = false;

				chkDeleteByPKMethod.Enabled = pkMembers != null;
				if (!chkDeleteByPKMethod.Enabled)
					chkDeleteByPKMethod.Checked = false;

				chkDeleteMethod.Enabled = pkMembers != null;
				if (!chkDeleteMethod.Enabled)
					chkDeleteMethod.Checked = false;

				chkUpdateMethod.Enabled = pkMembers != null;
				if (!chkUpdateMethod.Enabled)
					chkUpdateMethod.Checked = false;

				chkExistsByPK.Enabled = pkMembers != null;
				if (!chkExistsByPK.Enabled)
					chkExistsByPK.Checked = false;

				chkExists.Enabled = pkMembers != null;
				if (!chkExists.Enabled)
					chkExists.Checked = false;

				butCreateDBMethods.Enabled = 
					chkReadColMethod.Checked ||
					chkReadMethod.Checked ||
					chkLoadByPKMethod.Checked ||
					chkInsertMethod.Checked ||
					chkUpdateMethod.Checked ||
					chkSaveMethod.Checked ||
					chkDeleteByPKMethod.Checked ||
					chkDeleteMethod.Checked ||
					chkSynchronizeMethod.Checked ||

					chkLoadFromDataRowView.Checked ||
					chkSaveToDataRowView.Checked ||
					chkExists.Checked ||
					chkExistsByPK.Checked;
			}

			if (tab == null || tab == tabOverrides)
			{
				butAddOverridable.Enabled = lstOverridables.SelectedIndex >= 0;
				butRemoveOverridable.Enabled = lstOverriddenMethods.SelectedIndex >= 0;	
			}

			if (tab == null || tab == tabDBMethods)
			{
				cmdShowReadColMethod.Visible = Util.FindFirstMethod(false, cls, "ReadCollection", "IDataReader", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, "System.Collections.IList") != null;
				cmdShowReadMethod.Visible = Util.FindFirstMethod(false, cls, "Read", "IDataReader") != null;
				if (pkTypes != null)
				{
					cmdShowLoadByPKMethod.Visible = Util.FindFirstMethod(false, cls, "Load", pkTypes) != null;
					cmdShowDeleteByPKMethod.Visible = Util.FindFirstMethod(false, cls, "Delete", pkTypes) != null;
					cmdShowExistsByPK.Visible = Util.FindFirstMethod(false, cls, "Exists", pkTypes) != null;
				}
				else
				{
					cmdShowLoadByPKMethod.Visible = false;
					cmdShowDeleteByPKMethod.Visible = false;
					cmdShowExistsByPK.Visible = false;
				}
				cmdShowInsertMethod.Visible = Util.FindFirstMethod(false, cls, "Insert") != null;
				cmdShowUpdateMethod.Visible = Util.FindFirstMethod(false, cls, "Update") != null;
				cmdShowSaveMethod.Visible = Util.FindFirstMethod(false, cls, "Save") != null;
				cmdShowSynchronizeMethod.Visible = Util.FindFirstMethod(false, cls, "Synchronize") != null;
				cmdShowDeleteMethod.Visible = Util.FindFirstMethod(false, cls, "Delete") != null;
				butShowColsMapModeAttrib.Visible = Util.FindAttribute(cls.Attributes, "ColumnsMappingMode") != null;
				cmdShowSQLHintAttrib.Visible = Util.FindAttribute(cls.Attributes, "SQLHint") != null;
				cmdShowLoadFromDataRowView.Visible = Util.FindFirstMethod(false, cls, "Load", "System.Data.DataRowView") != null;
				cmdShowSaveToDataRowView.Visible = Util.FindFirstMethod(false, cls, "Save", "System.Data.DataRowView") != null;
				cmdShowToStringMethod.Visible = Util.FindFirstMethod(false, cls, "ToString") != null;

				cmdShowExists.Visible = Util.FindFirstMethod(false, cls, "Exists") != null;
			}

			lbPKMember.BackColor = System.Drawing.SystemColors.Control;

			if (tab == null)
			{
				if (pkMembers == null)
				{
					lbPKMember.Text = "(Not declared. Declare in the TableMapping attribute.)";
					lbPKMember.BackColor = System.Drawing.Color.Red;
					cmdShowTableMappingAtt.Visible = true;
				}
				else
				{
					lbPKMember.Text = PKMembersStr;
					string pkCol = Util.GetColMappingForMember(cls, pkMembers[0]);

					if (pkCol == null)
					{
						lbPKMember.Text += " (Field for PK Member not defined!)";
						lbPKMember.BackColor = System.Drawing.Color.Red;
					}
					else
					{
						lbPKMember.Text += "    PK Column: [" + pkCol + "]";
					}
					cmdShowTableMappingAtt.Visible = false;
				}

				bool bSqlData = (Util.FindFirstMember(cls, "sqlData") as CodeVariable != null)
					&& (Util.FindFirstMember(cls, "SqlData") as CodeProperty != null);

				butCreateSqlDataProp.Visible = !bSqlData;
			}

			cmdShowWebFormBuilder.Visible = !cmdShowTableMappingAtt.Visible;

			if (tab == null || tab == tabCollections)
			{
				cmdShowColBuilder.Enabled = lsCollectionClasses.SelectedIndex >= 0;
			}

			if (tab == null || tab == tabStoredProcs)
			{
				cmdCreateCRUDsps.Enabled = 
					chkSPforLoad.Checked ||
					chkSPforDelete.Checked ||
					chkSPforInsert.Checked ||
					chkSPforUpdate.Checked ||
					chkSPforExists.Checked ||
					chkAutoGenSPs.Checked;
			}

			if (tab == null || tab == tabBuildParamsMethods)
			{
				butAddParam.Enabled = lsAllFields.SelectedIndex >= 0;
				butRemoveParam.Enabled = lsParams.SelectedIndex >= 0;

				//chkConstructor.Enabled = lsParams.Items.Count > 0;
				//if (!chkConstructor.Enabled)
				//	chkConstructor.Checked = false;

				butCreateParamsMethods.Enabled = 
					chkToStringMethod.Checked
					|| chkCalculateScriptMethod.Checked
					|| chkNewMethod.Checked
					|| chkExecuteReaderMethod.Checked
					|| chkExecuteSQL.Checked
					|| chkLoad.Checked
					|| chkConstructor.Checked
					|| (chkExecuteStoredProcMethod.Checked 
					&& cbSprocName.Text != "");

				bool oldcbSprocNameVisible = cbSprocName.Visible;
				cbSprocName.Visible = chkExecuteStoredProcMethod.Checked;
				lbProcNameLabel.Visible = cbSprocName.Visible;
				butSelectSPTemplate.Visible = cbSprocName.Visible;
				if (cbSprocName.Visible)	// if newly made visible fill it
					if (cbSprocName.Visible != oldcbSprocNameVisible)
						FillSprocNames();
			}

			if (tab == null || tab == tabChildren)
			{
				butCreateSPLoadChild.Enabled = (lsChildren.SelectedIndex >= 0);// && (Util.GetStoredProcFromDB(txtSPForLoadChild.Text) == null);
				cmdShowChildColBuilder.Enabled = lsChildren.SelectedIndex >= 0;
			}

			if (tab == null || tab == tabContainedObjects)
			{
				cmdShowContainedClassBuilder.Enabled = lsContainedEntityObjects.SelectedIndex >= 0;
				cmdShowClassBuilderForParent.Enabled = lsParentObjects.SelectedIndex >= 0;
			}

            butCreateSPLoadChild.Visible = false;
		}

		// this takes time, so we seperate it and call only when needed
		private void EnableProcedureButtons()
		{
			// enable stored proc show buttons
			string spUpdate = Util.GetSPUpdateForClass(cls, true);
			string spInsert = Util.GetSPInsertForClass(cls, true);
			string spLoad = Util.GetSPLoadForClass(cls, true);

			cmdShowSPforLoad.Visible = Util.ExistsStoredProcFromDB(Util.GetSPLoadForClass(cls, true));
			cmdShowSPforUpdate.Visible = Util.ExistsStoredProcFromDB(spUpdate);
			cmdShowSPforInsert.Visible = Util.ExistsStoredProcFromDB(spInsert);
			cmdShowSPforDelete.Visible = Util.ExistsStoredProcFromDB(Util.GetSPDeleteForClass(cls, true));
			cmdShowSPforExists.Visible = Util.ExistsStoredProcFromDB(Util.GetSPExistsForClass(cls, true));
			butMismatchedInsertParams.Visible = cmdShowSPforInsert.Visible && !CheckSPInsertParams(mismatchedInsertParams);
			butMismatchedUpdateParams.Visible = cmdShowSPforUpdate.Visible && !CheckSPUpdateParams(mismatchedUpdateParams);
			butPossibleInvalidLoadSP.Visible = butMismatchedInsertParams.Visible || butMismatchedUpdateParams.Visible;
			butPossibleInvalidAutoGenSPs.Visible = chkAutoGenSPs.Enabled && (butMismatchedInsertParams.Visible || butMismatchedUpdateParams.Visible);
			
			ToolTip tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(butMismatchedInsertParams, String.Format("{0} has some invalid arguments!", spInsert));

			tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(butMismatchedUpdateParams, String.Format("{0} has some invalid arguments!", spUpdate));

			tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(butPossibleInvalidLoadSP, String.Format("Update/Insert invalid.  The returned columns of {0} could be invalid too!", spLoad));

			tooltip = new ToolTip();
			tooltip.ShowAlways = true;
			tooltip.SetToolTip(butPossibleInvalidAutoGenSPs, String.Format("Update/Insert invalid.  The auto-generated stored procedures could be invalid too!"));

			ArrayList spAutoGenAtts = Util.GetSPAutoGenAttributes(cls);
			if (spAutoGenAtts == null || spAutoGenAtts.Count == 0)
			{
				chkAutoGenSPs.Enabled = false;
				chkAutoGenSPs.Checked = false;
			}
			else
				chkAutoGenSPs.Enabled = true;

			txtPreviewCRUDsps.Text = "";
			lbCRUDspname.Text = "";
			cmdDropCRUDsp.Visible = false;
		}

		private void lsColumns_DoubleClick(object sender, System.EventArgs e)
		{
			butAdd_Click(sender, e);
		}

		private void lsMembers_DoubleClick(object sender, System.EventArgs e)
		{
			butRemove_Click(sender, e);
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void butAddParam_Click(object sender, System.EventArgs e)
		{
			if (lsAllFields.SelectedIndex < 0)
				return;
			lsParams.Items.Add(lsAllFields.Items[lsAllFields.SelectedIndex]);
			int sel = lsAllFields.SelectedIndex;
			lsAllFields.Items.RemoveAt(sel);
			if (sel < lsAllFields.Items.Count)
				lsAllFields.SelectedIndex = sel;
			EnableButtons(tabBuildParamsMethods);
		}

		private void butRemoveParam_Click(object sender, System.EventArgs e)
		{
			if (lsParams.SelectedIndex < 0)
				return;
			lsAllFields.Items.Add(lsParams.Items[lsParams.SelectedIndex]);
			int sel = lsParams.SelectedIndex;
			lsParams.Items.RemoveAt(sel);
			ArrangeListByTableColumnOrder(lsAllFields, true);
			if (sel < lsParams.Items.Count)
				lsParams.SelectedIndex = sel;
			EnableButtons(tabBuildParamsMethods);
		}

		private void lsAllFields_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabBuildParamsMethods);
		}

		private void lsParams_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabBuildParamsMethods);
		}

		private void lsAllFields_DoubleClick(object sender, System.EventArgs e)
		{
			butAddParam_Click(sender, e);
		}

		private void lsParams_DoubleClick(object sender, System.EventArgs e)
		{
			butRemoveParam_Click(sender, e);
		}

		private void DisplayHelp()
		{
			lbHelp.Text = tab.SelectedTab.ToolTipText;
		}

		private void tab_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DisplayHelp();

			if (tab.SelectedTab == tabCollections)
				FillCollectionClasses();
			if (tab.SelectedTab == tabStoredProcs)
			{
				EnableProcedureButtons();
			}
			if (tab.SelectedTab == tabChildren)
				FillChildren();
			if (tab.SelectedTab == tabOverrides)
			{
				FillOverridableAndOverriddenMethods();
				butCreateOverridingMethods.Enabled = false;
			}
			if (tab.SelectedTab == tabChildren)
			{
				txtSPForLoadChild.Text = "";
				butCreateSPLoadChild.Enabled = false;
			}
			if (tab.SelectedTab == tabContainedObjects)
			{
				FillContainedEntityObjects();
				FillParentObjects();
			}

			EnableButtons(tab.SelectedTab);
		}

		private void butCreateDBMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				CreateDBMethods();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkAllDBMethods_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkReadColMethod.Enabled)
				chkReadColMethod.Checked = chkAllDBMethods.Checked;
			if (chkReadMethod.Enabled)
				chkReadMethod.Checked = chkAllDBMethods.Checked;
			if (chkLoadByPKMethod.Enabled)
				chkLoadByPKMethod.Checked = chkAllDBMethods.Checked;
			if (chkInsertMethod.Enabled)
				chkInsertMethod.Checked = chkAllDBMethods.Checked;
			if (chkUpdateMethod.Enabled)
				chkUpdateMethod.Checked = chkAllDBMethods.Checked;
			if (chkSaveMethod.Enabled)
				chkSaveMethod.Checked = chkAllDBMethods.Checked;
			if (chkDeleteByPKMethod.Enabled)
				chkDeleteByPKMethod.Checked = chkAllDBMethods.Checked;
			if (chkDeleteMethod.Enabled)
				chkDeleteMethod.Checked = chkAllDBMethods.Checked;
			if (chkSynchronizeMethod.Visible && chkSynchronizeMethod.Enabled)
				chkSynchronizeMethod.Checked = chkAllDBMethods.Checked;

			EnableButtons(tabDBMethods);
		}

		private void EntityBuilder_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			//if (e.KeyChar == (char)27)
			//	Close()
		}

		private void butUpdateColMapMode_Click(object sender, System.EventArgs e)
		{
			try
			{
				//[ColumnsMappingMode(ColumnMappingModes.Public | ColumnMappingModes.NonPublic | ColumnMappingModes.MappedOnly)]

				CodeAttribute att = Util.FindAttribute(cls.Attributes, "ColumnsMappingMode");
				if (att != null)
				{
					try
					{
						att.Delete();
					}
					catch
					{
					}
				}

				EditPoint ep = null;
				//if (att == null)
				//{
				ep = cls.StartPoint.CreateEditPoint();
				ep.LineUp(1);
				ep.EndOfLine();
				//}
				/*else
				{
				
					ep = att.StartPoint.CreateEditPoint();
					ep.StartOfLine();
					Util.DeleteEditLine(ep);
				}*/

				string s = "";

				if (chkMappedOnly.Checked)
					s += "ColumnMappingModes.MappedOnly | ";
				if (chkMapPublic.Checked)
					s += "ColumnMappingModes.Public | ";
				if (chkMapNonPublic.Checked)
					s += "ColumnMappingModes.NonPublic";
				s = s.Trim(' ', '|');
				ep.Insert(String.Format("\r\n\t[ColumnsMappingMode({0})]", s));
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);

				EnableButtons(tabColMappingMode);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void cmdShowInsertMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(false, cls, "Insert") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowUpdateMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(false, cls, "Update") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowSaveMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(false, cls, "Save") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowReadColMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "ReadCollection", "IDataReader", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, "System.Collections.IList");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowReadMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Read", "IDataReader");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowDeleteByPKMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = null;
			if (pkTypes != null)
			{
				func = Util.FindFirstMethod(false, cls, "Delete", pkTypes);
				Util.MarkElement(cls, func as CodeElement);
			}
		}

		private void cmdShowDeleteMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Delete");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowLoadByPKMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = null;
			if (pkTypes != null)
			{
				func = Util.FindFirstMethod(false, cls, "Load", pkTypes);
				Util.MarkElement(cls, func as CodeElement);
			}
		}

		private void butShowColsMapModeAttrib_Click(object sender, System.EventArgs e)
		{
			Util.MarkAttribute(cls, "ColumnsMappingMode");
		}

		private void lsColumns2_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabSQLHint);
		}

		private void lsSQLHintCols_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabSQLHint);
		}

		private void butAddHint_Click(object sender, System.EventArgs e)
		{
			if (lsColumns2.SelectedIndex < 0)
				return;
			lsSQLHintCols.Items.Add(lsColumns2.Items[lsColumns2.SelectedIndex]);
			int sel = lsColumns2.SelectedIndex;
			lsColumns2.Items.RemoveAt(sel);
			if (sel < lsColumns2.Items.Count)
				lsColumns2.SelectedIndex = sel;
			EnableButtons(tabSQLHint);
		}

		private void butRemoveHint_Click(object sender, System.EventArgs e)
		{
			if (lsSQLHintCols.SelectedIndex < 0)
				return;
			lsColumns2.Items.Add(lsSQLHintCols.Items[lsSQLHintCols.SelectedIndex]);
			int sel = lsSQLHintCols.SelectedIndex;
			lsSQLHintCols.Items.RemoveAt(sel);
			if (sel < lsSQLHintCols.Items.Count)
				lsSQLHintCols.SelectedIndex = sel;
			EnableButtons(tabSQLHint);
		}

		private void butAddAllHint_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsColumns2.Items.Count; i++)
			{
				lsSQLHintCols.Items.Add(lsColumns2.Items[i]);
			}
			lsColumns2.Items.Clear();
			EnableButtons(tabSQLHint);
		}

		private void butRemoveAllHint_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsSQLHintCols.Items.Count; i++)
			{
				lsColumns2.Items.Add(lsSQLHintCols.Items[i]);
			}
			lsSQLHintCols.Items.Clear();
			EnableButtons(tabSQLHint);
		}

		private void butCreateSQLHintAttrib_Click(object sender, System.EventArgs e)
		{
			try
			{
				CodeAttribute att = Util.FindAttribute(cls.Attributes, "SQLHint");
				if (att != null)
				{
					try
					{
						att.Delete();
					}
					catch
					{
					}
				}

				EditPoint ep = null;
				ep = cls.StartPoint.CreateEditPoint();
				ep.LineUp(1);
				ep.EndOfLine();

				string s = "";

				for (int i = 0; i < lsSQLHintCols.Items.Count; i++)
				{
					if (i > 0) 
						s += ",";
					s += (string)lsSQLHintCols.Items[i];
				}

				ep.Insert(String.Format("\r\n\t[SQLHint(\"{0}\")]", s));
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);

				EnableButtons();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void lsColumns2_DoubleClick(object sender, System.EventArgs e)
		{
			butAddHint_Click(sender, e);
		}

		private void lsSQLHintCols_DoubleClick(object sender, System.EventArgs e)
		{
			butRemoveHint_Click(sender, e);
		}

		private void cmdShowSQLHintAttrib_Click(object sender, System.EventArgs e)
		{
			Util.MarkAttribute(cls, "SQLHint");
		}

		private void cmdFillFromColMapping_Click(object sender, System.EventArgs e)
		{
			lsSQLHintCols.Items.Clear();
			FillColumns();

			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				string colName = (string)lsMembers.Items[i];
				lsSQLHintCols.Items.Add(colName);
				lsColumns2.Items.Remove(colName);
			}
			EnableButtons(tabSQLHint);
		}

		private void CacheClassProperties()
		{
			pkMembers = Util.GetPKMembersForClass(cls);
			pkTypes = Util.GetMembersTypes(cls, pkMembers);
			pkColNames = Util.GetColMappingsForMembers(cls, pkMembers);
			tableName = Util.GetTableMappingForClass(cls);
		}

		private void cmdReloadTable_Click(object sender, System.EventArgs e)
		{
			try
			{
				GetTablePrototype();
				FillLists();
				FillCollectionClasses();
				EnableButtons();
				EnableProcedureButtons();

				CacheClassProperties();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void cmdShowTableMappingAtt_Click(object sender, System.EventArgs e)
		{
			Util.MarkAttribute(cls, "TableMapping");
		}

		private void cmdCreateTest_Click(object sender, System.EventArgs e)
		{
			CodeVariable[] pkvars = Util.FindVars(cls, pkMembers); // as CodeVariable;
			string tableName = Util.GetTableMappingForClass(cls);
			if (pkvars == null)
			{
				Connect.Instance.ShowDialog(null, "Field for PK Member not defined in the class");
				return;
			}
			string[] pkCols = Util.GetColMappingsForMembers(cls, pkMembers);

			CodeFunction func = cls.AddFunction("TestLoad", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,  // "static void",
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test Load method";

			// find a pkvalue from database

			DataTable tbl = null;
			try
			{
				DataSet ds = Util.ExecuteDataset(tableName,
					CommandType.Text, 
					"SELECT TOP 10 [" + String.Join(",", pkCols) + 
					"] FROM [" + tableName + "]");
				tbl = ds.Tables[0];
			}
			catch
			{
				// ignore
			}
								
			EditPoint ep = func.StartPoint.CreateEditPoint();

			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();
			ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", cls.Name));
			if (tbl != null)
			for (int i = 0; i < tbl.Rows.Count; i++)
			{
				object pkVal = tbl.Rows[i][0];		// already single column
				string spkVal = null;
				if (pkVal is string)
					spkVal = "\"" + (string)pkVal + "\"";
				else
					spkVal = Convert.ToString(pkVal);
				ep.Insert(String.Format("\t\t\tobj.Load({0});\r\n", spkVal));
				ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(obj); // access any fields/properties\r\n"));
			}

			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void cmdCreateTestForRead_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = cls.AddFunction("TestRead", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,   // "static void",		
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test Read method";

			EditPoint ep = func.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();
			ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\tIDataReader rdr = obj.SqlData.ExecuteReader(); // execute any reader\r\n"));
			ep.Insert(String.Format("\t\t\twhile (obj.Read(rdr))\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert(String.Format("\t\t\t\tSystem.Diagnostics.Debug.WriteLine(obj); // access any fields/properties\r\n"));
			ep.Insert("\t\t\t}\r\n");
			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void cmdCreateTestForReadCol_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = cls.AddFunction("TestReadCollection", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, // "static void",		
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test ReadCollection method";

			EditPoint ep = func.StartPoint.CreateEditPoint();

			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();
			ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\tSystem.Collections.ArrayList col = new System.Collections.ArrayList(); // may be a strongly typed collection instead\r\n"));
			ep.Insert(String.Format("\t\t\tIDataReader rdr = obj.SqlData.ExecuteReader(); // execute any reader\r\n"));
			ep.Insert(String.Format("\t\t\twhile (obj.ReadCollection(rdr, 3, col) > 0) // use any number of max records\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert("\t\t\t\t// col contains the read elements\r\n");
			ep.Insert(String.Format("\t\t\t\tSystem.Diagnostics.Debug.WriteLine(col.Count);\r\n"));
			ep.Insert("\t\t\t\t// access any collection elements and use it\r\n");
			ep.Insert(String.Format("\t\t\t\tforeach ({0} elem in col)\r\n", cls.Name));
			ep.Insert("\t\t\t\t{\r\n");
			ep.Insert("\t\t\t\t\tSystem.Diagnostics.Debug.WriteLine(elem); // access any fields/properties\r\n");
			ep.Insert("\t\t\t\t}\r\n");
			ep.Insert("\t\t\t\t// col.Clear(); // collection may be cleared for the next read\r\n");
			ep.Insert("\t\t\t}\r\n");
			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void chkDeleteMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons(tabDBMethods);
		}

		private void butCreateParamsMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (chkExecuteStoredProcMethod.Checked)
				{
					spOptions = new StoredProcedureOptions(this.cls);
					spOptions.MethodName = Util.MakeMethodNameFromSPName(cbSprocName.Text); // "Execute_" +
					if (!StoredProcOptionsDlg.SelectStoredProcOptions(spOptions))
						return;
				}

				CreateParameterizedMethods();
				FillLists();
				EnableButtons();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkConstructor_Click(object sender, System.EventArgs e)
		{
			EnableButtons(tabBuildParamsMethods);
		}

		private void EntityBuilder_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			WriteSettings();
		}

		private void butCreateSqlDataProp_Click(object sender, System.EventArgs e)
		{
			try
			{
				EnsureSqlDataProp();
				EnableButtons();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkAllUtilityMethods_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkLoadFromDataRowView.Enabled)
				chkLoadFromDataRowView.Checked = chkAllUtilityMethods.Checked;
			if (chkSaveToDataRowView.Enabled)
				chkSaveToDataRowView.Checked = chkAllUtilityMethods.Checked;
			if (chkSaveToDataRowView.Enabled)
				chkExists.Checked = chkAllUtilityMethods.Checked;
			if (chkSaveToDataRowView.Enabled)
				chkExistsByPK.Checked = chkAllUtilityMethods.Checked;

			EnableButtons(tabDBMethods);
		}

		private void cmdShowLoadFromDataRowView_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Load", "System.Data.DataRowView");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowSaveToDataRowView_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Save", "System.Data.DataRowView");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void butCreateCollectionClass_Click(object sender, System.EventArgs e)
		{
			try
			{
				Close();
				CollectionClassCreator.CreateCollectionClass(cls);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void lsCollectionClasses_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string selItem = (string)lsCollectionClasses.SelectedItem;
			if (selItem != null)
			{
				CodeClass colClass = Util.FindClassInProject(selItem);
				if (colClass != null)
				{
					colClass.ProjectItem.Open(Constants.vsViewKindCode);
					EditPoint ep = colClass.StartPoint.CreateEditPoint();
					ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);
				}
			}
			EnableButtons(tabCollections);
		}

		private void cmdShowColBuilder_Click(object sender, System.EventArgs e)
		{
			string selItem = (string)lsCollectionClasses.SelectedItem;
			if (selItem != null)
			{
				CodeClass colClass = Util.FindClassInProject(selItem);
				if (colClass != null)
				{
					this.Close();
					CollectionClassBuilder.BuildCollectionClass(colClass);
				}
			}
		}

		private void cmdShowWebFormBuilder_Click(object sender, System.EventArgs e)
		{
			this.Close();
			WebFormBuilder.BuildWebForm(this.cls);
		}

		private void cmdShowToStringMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "ToString");
			Util.MarkElement(cls, func as CodeElement);		
		}
			
		private void cmdCreateCRUDsps_Click(object sender, System.EventArgs e)
		{
			StringBuilder str = null;
			
			if (chkPreviewOnly.Checked)
				str = new StringBuilder();
			
			try
			{
				if (chkSPforLoad.Checked)
				{
					string spName = Util.GetSPLoadForClass(cls, true);
					if (spName != null && spName[0] != '*')	// manually managed
					{
						string sp = GenerateSPforLoad();
						if (str != null)
						{
							str.Append("\r\n\r\n");
							str.Append(sp);
						}
						else
							Util.SetStoredProcOnDB(this, spName, sp, chkRecreateCRUDsps.Checked, false);
						if (chkDeclareSPAtt.Checked)
							if (Util.GetSPLoadForClass(cls) != spName)
								Util.DeclareStoredProcAttribOnClass(cls, "SPLoad", spName);
					}
				}
				if (chkSPforExists.Checked)
				{
					string spName = Util.GetSPExistsForClass(cls, true);
					if (spName != null && spName[0] != '*')	// manually managed
					{
						string sp = GenerateSPforExists();
						if (str != null)
						{
							str.Append("\r\n\r\n");
							str.Append(sp);
						}
						else
							Util.SetStoredProcOnDB(this, spName, sp, chkRecreateCRUDsps.Checked, false);
						if (chkDeclareSPAtt.Checked)
							if (Util.GetSPExistsForClass(cls) != spName)
								Util.DeclareStoredProcAttribOnClass(cls, "SPExists", spName);
					}
				}
				if (chkSPforDelete.Checked)
				{
					string spName = Util.GetSPDeleteForClass(cls, true);
					if (spName != null && spName[0] != '*')	// manually managed
					{
						string sp = GenerateSPforDelete();
						if (str != null)
						{
							str.Append("\r\n\r\n");
							str.Append(sp);
						}
						else
							Util.SetStoredProcOnDB(this, spName, sp, chkRecreateCRUDsps.Checked, false);
						if (chkDeclareSPAtt.Checked)
							if (Util.GetSPDeleteForClass(cls) != spName)
								Util.DeclareStoredProcAttribOnClass(cls, "SPDelete", spName);
					}
				}
				if (chkSPforUpdate.Checked)
				{
					string spName = Util.GetSPUpdateForClass(cls, true);
					if (spName != null && spName[0] != '*')	// manually managed
					{
						string spForUpdate = GenerateSPforUpdate();
						if (spForUpdate == null)
							Connect.Instance.ShowDialog(this, "There are no columns to update for " + tableName, "EntityBuilder - Generage SP for Update");
						else
						{
							if (str != null)
							{
								str.Append("\r\n\r\n");
								str.Append(spForUpdate);
							}
							else
								Util.SetStoredProcOnDB(this, spName, spForUpdate, chkRecreateCRUDsps.Checked, false);
							if (chkDeclareSPAtt.Checked)
								if (Util.GetSPUpdateForClass(cls) != spName)
									Util.DeclareStoredProcAttribOnClass(cls, "SPUpdate", spName);
						}
					}
				}
				if (chkSPforInsert.Checked)
				{
					string spName = Util.GetSPInsertForClass(cls, true);
					if (spName != null && spName[0] != '*')	// manually managed
					{
						string sp = GenerateSPforInsert();
						if (str != null)
						{
							str.Append("\r\n\r\n");
							str.Append(sp);
						}
						else
							Util.SetStoredProcOnDB(this, spName, sp, chkRecreateCRUDsps.Checked, false);
						if (chkDeclareSPAtt.Checked)
							if (Util.GetSPInsertForClass(cls) != spName)
								Util.DeclareStoredProcAttribOnClass(cls, "SPInsert", spName);
					}
				}

				if (chkAutoGenSPs.Checked)
					if (!CreateAutoGenSPs(str))
						return;
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}

			chkAllStoredProcs.Checked = false;
			/*
			chkAllCRUDsps.Checked = false;
			chkSPforLoad.Checked = false;
			chkSPforDelete.Checked = false;
			chkSPforUpdate.Checked = false;
			chkSPforInsert.Checked = false;
			chkSPforExists.Checked = false;*/

			EnableButtons();
			EnableProcedureButtons();

			if (str != null)
			{
				string s = str.ToString();
				string fileName = Util.ProjectPath + "\\CreateSPs.sql";
				StreamWriter sw = File.CreateText(fileName);
				sw.Write(s);
				sw.Close();
				System.Diagnostics.Process.Start("NotePad.exe", fileName);
			}
		}

		private bool CreateAutoGenSPs(StringBuilder str)
		{
			string procs = null;
			ArrayList spAutoGenAttribs = Util.GetSPAutoGenAttributes(cls);
			for (int i = 0; i < spAutoGenAttribs.Count; i++)
			{
				CodeAttribute att = spAutoGenAttribs[i] as CodeAttribute;
				if (att != null)
				{
					string sp = null, tpl = null, args = null, manuallyManaged = null;
					SPGenerationInjections injections = null;
					Util.GetSPAutoDeclAttribValues(att, ref sp, ref tpl, ref args, ref injections, ref manuallyManaged);

					if (manuallyManaged == "true")
					{
						//string err = String.Format("Manually managed sp  '{1}' is skipped!", sp);
						//errorMsgs += "\r\n\r\n" + err;
						//AddWarningMsgToShowSP("/* " + err + " */\r\n");
						continue;
					}

					StoredProcTemplate spTpl = StoredProcTemplate.GetSPTemplate(this.SPTemplatesPath, tpl);
					if (spTpl == null)
					{
						// template not found
						Connect.Instance.ShowDialog(this, 
							String.Format("Procedure template {0} used by {1} not found!", tpl, sp), "Templated stored procedure generation error!");
						return false;
					}
					else
					{
						// template found
						Hashtable templateMap = StoredProcTemplate.GetSPTemplateMap(this.SPTemplatesPath);
						ArrayList arrReferredArgs = new ArrayList();
						TemplatedProcGenerator generator = new TemplatedProcGenerator(cls, templateMap, spTpl, sp, args, injections, arrReferredArgs);
						string sproc = generator.GenerateSP();
						if (generator.ParseError || generator.GenerationError)
						{
							Connect.Instance.ShowDialog(this, generator.ErrorString, "Templated stored procedure generation error!");
							return false;
						}
						else
						{
							if (str != null)
							{
								str.Append("\r\n\r\n");
								str.Append(sproc);
							}
							else
							if (Util.SetStoredProcOnDB(this, sp, sproc, chkRecreateCRUDsps.Checked, false))
								procs += "\r\n" + sp;
						}
					}
				}
			}

			if (procs == null)
				Connect.Instance.ShowDialog(this, "No auto-generated procedures have been created.", "Templated stored procedure generation");
			else
				Connect.Instance.ShowDialog(this, "These stored procedures have been created successfully:\r\n" + procs, "Templated stored procedure generation");

			return true;
		}

		private string MergeCols(bool includePK, bool makeParamNames, bool makeParamDecl)
		{
			return MergeCols(lsMembers, includePK, makeParamNames, makeParamDecl);
		}

		public bool IsPKMember(string memberName)
		{
			for (int i = 0; i < pkMembers.Length; i++)
				if (String.Compare(memberName, pkMembers[i] , true) == 0)
					return true;

			return false;
		}

		public bool IsPKColumn(string columnName)
		{
			for (int i = 0; i < pkColNames.Length; i++)
				if (String.Compare(columnName, pkColNames[i] , true) == 0)
					return true;

			return false;
		}

		private CodeElement GetElemForColumn(string colName, EnumStatementType statementType)
		{
			return Util.FindMemberForColumn(cls, colName, statementType);
		}

		private string MakeParamName(string colName)
		{
			CodeElement elem = Util.FindMemberForColumn(cls, colName, EnumStatementType.Free);
			if (elem != null)	// there's an element mapping this column, use its name as parameter name
				return "@" + elem.Name;
			else
				return Util.MakeParamName(colName);	
		}

		private string MergeCols(ListBox lsMembers, bool includePK, bool makeParamNames, bool makeParamDecl)
		{
			string s = "";
			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				string colName = (string)lsMembers.Items[i];
				if (includePK || !IsPKColumn(colName))
				{
					if (s != "")
						s += ", ";
					DataColumn dataCol = null;
					if (tbl != null)
						dataCol = tbl.Columns[colName];
					if (makeParamNames || makeParamDecl)
					{
						colName = MakeParamName(colName);	// make a param name from the column name
					}
					if (makeParamDecl)
					{
						string dbType = null;
						if (dataCol != null)
							dbType = Util.GetDBTypeForDataColumn(dataCol);
						s += String.Format("\r\n{0} {1}", colName, dbType);
					}
					else
					{
						if (makeParamNames)
							s += String.Format("{0}", colName);
						else
							s += String.Format("[{0}]", colName);
					}
				}
			}

			return s;
		}

		private string MergeParams()
		{
			string s = "";
			for (int i = 0; i < lsParams.Items.Count; i++)
			{
				string parName = (string)lsParams.Items[i];
				string colName = Util.GetColMappingForMember(cls, parName);
				if (s != "")
					s += ", ";
				DataColumn dataCol = null;
				try
				{
					dataCol = tbl.Columns[colName];
				}
				catch
				{
					// ignore
				}
				string dbType = null;
				if (dataCol != null)
				{	// the column exists
					dbType = Util.GetDBTypeForDataColumn(dataCol);
				}
				else
				{	// the column does not exist
					CodeVariable var = Util.FindFirstMember(cls, parName) as CodeVariable;
					if (var != null)
						dbType = Util.GetDBTypeForType(var.Type);
					else
						dbType = "varchar(255)";
				}
				s += String.Format("\r\n@{0} {1}", parName, dbType);
			}

			return s;
		}

		private string GenerateParameterizedSP(string spName)
		{
			string cols = MergeCols(true, false, false);
			DataColumn[] memberDataCols = null;
			if (tbl != null)
				memberDataCols = GetDataColumns(Util.GetStringArrayFromList(lsParams));
			//string pkDBType = Util.GetDBTypeForDataColumn(pkCol);
			string parDecls = MergeParams();
			string where = GetParamWhereDesc(memberDataCols);
			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] " +		// {0} sp name
				"{1}\r\n" +		// {1} = param decls
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"SELECT {2} FROM [{3}]\r\n"+	// {2} = columns, {3} = tablename
				"{4}\r\n"+
				"SET NOCOUNT OFF\r\n"
				, spName, 
				parDecls == null || parDecls == "" ? null : " ( " + parDecls + " )", 
				cols, 
				tableName, 
				where == null ? null : "WHERE " + where);

			return s;
		}

		private string GenerateSPforLoadChild(string spName, string childMember, string FKMember)
		{
			if (FKMember == null)
			{
				Connect.Instance.ShowDialog(this, "No foreign key is specified for " + childMember);
				return null;
			}
			string[] FKMembers = null;
			FKMembers = FKMember.Split(',');
			CodeElement elem = Util.FindFirstMember(cls, childMember);
			CodeProperty prop = elem as CodeProperty;
			if (prop == null)
			{
				Connect.Instance.ShowDialog(this, "Can't find property " + childMember);
				return null;
			}
			string colTypeName = Util.GetLastTerm(prop.Type.AsString);
			CodeClass childCol = Util.FindClassInProject(colTypeName);
			if (childCol == null)
			{
				Connect.Instance.ShowDialog(this, "Can't find collection type " + colTypeName);
				return null;
			}
			CodeClass elemClass = Util.GetElementClassOfCollection(childCol);
			if (elemClass == null)
			{
				Connect.Instance.ShowDialog(this, "Can't find element class defined for collection " + colTypeName);
				return null;
			}

			string childTableName = Util.GetTableMappingForClass(elemClass, true);
			//string[] mappedCols = Util.GetColMapMembers(elemClass, true, true);
			//string cols = Util.JoinStrings(", ", mappedCols, "[{0}]");
			string cols = null, joinClauses = null;
			Util.GetSelectableColumnsAndJoinClauses(elemClass, ref cols, ref joinClauses);

			string[] fkCols = Util.GetColMappingsForMembers(elemClass, FKMembers);
			for (int i = 0; i < fkCols.Length; i ++)
			{
				if (fkCols[i] == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find column mappings for " + FKMembers[i]);
					return null;
				}
			}
			
			DataTable childTbl = Util.GetTablePrototype(childTableName);
			if (childTbl == null)
			{
				Connect.Instance.ShowDialog(this, "Can't access child table " + childTableName);
				return null;
			}

			DataColumn[] datacols = Util.GetDataColumns(childTbl, fkCols);
			if (datacols == null)
			{
				Connect.Instance.ShowDialog(this, String.Format( "Can't find fk columns ({0}) in table {1}", FKMember, childTableName));
				return null;
			}

			// generate where [fk col] = fk
			string where = null;
			for (int i = 0; i < datacols.Length; i++)
			{
				DataColumn dataCol = datacols[i];
				if (i > 0)
					where += " and ";
				where += "[" + childTableName + "].[" + dataCol.ColumnName + "]=@" + FKMembers[i];
			}

			// param descs for fk
			string paramsDesc = null;
			for (int i = 0; i < datacols.Length; i++)
			{
				DataColumn dataCol = datacols[i];
				if (i > 0)
					paramsDesc += ", ";
				paramsDesc += "@" + FKMembers[i] + " " + Util.GetDBTypeForDataColumn(dataCol);
			}
			
			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (" +		// {0} sp name
				"{1} )\r\n" +		// {1} = param decls
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"SELECT {2} FROM [{3}]\r\n"+	// {2} = columns, {3} = childTableName
				joinClauses +				// include join clauses if any
				"WHERE\r\n"+
				"{4}\r\n"+
				"SET NOCOUNT OFF\r\n"
				, spName, paramsDesc, cols, childTableName, where);

			return s;
		}

		
		/* Use this as a guide to create the stored proc with joined columns.
		 * 
		 
		private string CreateJoinStatements()
		{
			
			
			Hashtable usedJoins = new Hashtable();
			foreach (DictionaryEntry colInfEntry in columnInfoMap)
			{
				ColumnInfo colInf = (ColumnInfo)colInfEntry.Value;
				if (colInf.IsJoinColumn)
				{
					if (!usedJoins.Contains(colInf.JoinTableRight))
					{
						usedJoins[colInf.JoinTableRight] = colInf.LeftJoinStatement;
					}
				}
			}

			StringBuilder joinClauses = new StringBuilder();
			bool anyJoins = false;
			foreach (DictionaryEntry joinEntry in usedJoins)
			{
				string join = (string)joinEntry.Value;
				joinClauses.Append(join);
				joinClauses.Append(' ');
				anyJoins = true;
			}

			if (!anyJoins)
				this.useJoinColumns = false;	// no longer try to detect the join columns

			return joinClauses.ToString();
		}*/

		public DataColumn[] GetDataColumns(string[] cols)
		{
			return Util.GetDataColumns(tbl, cols);
		}

		public string GetParamDescs(DataColumn[] datacols)
		{
			string s = null;
			for (int i = 0; i < datacols.Length; i++)
			{
				DataColumn dataCol = datacols[i];
				if (i > 0)
					s += ", ";
				s += MakeParamName(dataCol.ColumnName) + " " + Util.GetDBTypeForDataColumn(dataCol);
			}

			return s;
		}

		public string GetParamWhereDesc(DataColumn[] datacols)
		{
			string s = null;
			for (int i = 0; i < datacols.Length; i++)
			{
				DataColumn dataCol = datacols[i];
				if (i > 0)
					s += " and ";
				s += "[" + dataCol.Table.TableName + "].[" + dataCol.ColumnName + "]=" + MakeParamName(dataCol.ColumnName);
			}

			return s;
		}

		private string GenerateSPforLoad()
		{
			string spName = Util.GetSPLoadForClass(cls, true);

			DataColumn[] pkCols = null;
			if (tbl != null)
				 pkCols = GetDataColumns(pkColNames);

			string cols = null, joinClauses = null;
			Util.GetSelectableColumnsAndJoinClauses(cls, ref cols, ref joinClauses);

			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (\r\n" +		// {0} sp name
				"{1} )\r\n" +		// {1} = PK names and types
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"SELECT {2} FROM [{3}]\r\n" + 
				joinClauses +						// include join clauses if any
				"WHERE\r\n" +
				"{4}\r\n"+		// {4} = pk column name
				"SET NOCOUNT OFF\r\n"
				,	// {2} = columns, {3} = tablename
				spName, GetParamDescs(pkCols), cols, tableName, GetParamWhereDesc(pkCols));

			return s;
		}

		private string GenerateSPforExists()
		{
			string spName = Util.GetSPExistsForClass(cls, true);
			DataColumn[] pkCols = null;
			if (tbl != null)
				pkCols = GetDataColumns(pkColNames);
			
			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (\r\n" +		// {0} sp name
				"{1} )\r\n" +		// {1} = PK names and types
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"SELECT COUNT(*) FROM [{2}]\r\n"+	// {2} = tablename
				"WHERE\r\n" +
				"{3}\r\n"+		// {3} = pk column name
				"SET NOCOUNT OFF\r\n"
				, spName, GetParamDescs(pkCols), tableName, GetParamWhereDesc(pkCols));

			return s;
		}

		private string GenerateSPforDelete()
		{
			string spName = Util.GetSPDeleteForClass(cls, true);
			DataColumn[] pkCols = null;
			if (tbl != null)
				pkCols = GetDataColumns(pkColNames);
			
			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (\r\n" +		// {0} sp name
				"{1} )\r\n" +		// {1} = PK names and types
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"DELETE FROM [{2}]\r\n"+	// {2} = table name
				"WHERE\r\n" +
				"{3}\r\n"+		// {3} = pk column name
				"SET NOCOUNT OFF\r\n"
				, spName, GetParamDescs(pkCols), tableName, GetParamWhereDesc(pkCols));

			return s;
		}


		private string GenerateSPforUpdate()
		{
			string spName = Util.GetSPUpdateForClass(cls, true);
			DataColumn[] pkCols = null;
			if (tbl != null)
				pkCols = GetDataColumns(pkColNames);
			string parDecl = MergeCols(true, true, true);

			string setCols = "";
			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				string col = (string)lsMembers.Items[i];
				if (!IsPKColumn(col))	// if not PK
				{
					string parName  = null; //MakeParamName(col);

					
					CodeElement elem = GetElemForColumn(col, EnumStatementType.Update);
					if (elem == null)
						continue;
					try
					{
						parName = "@" + elem.Name;
					
						CodeVariable var = elem as CodeVariable;
						CodeAttribute colMapAtt = Util.GetColMappingAtt(var);

						// check sqlgen flags
						if (Util.IsColumnUpdatable(colMapAtt))
						{

							string injectUpdate = Util.GetParamFromAttrib(colMapAtt, "InjectUpdate", -1);

							string exp = null;
							if (injectUpdate != null && injectUpdate != "")
								exp = injectUpdate;
							else
								exp = parName;

							if (setCols != "")
								setCols += ", ";

							setCols += String.Format("[{0}]={1}", col, exp);
						}
					}
					catch(Exception ex)
					{
						Connect.Instance.ShowDialog(this, "An error occured for member " + col + "\r\n\r\n  " + ex.ToString());
						throw;
					}

				}
			}
			
			if (setCols == "" || setCols == null)
			{				
				return null;
			}

			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (\r\n" +		// {0} sp name
				"{2} )\r\n" +		// {1} = PK type   {2} = param decls
				"AS\r\n" +
				Util.spAutoGenRemark +
				//"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"UPDATE [{3}] SET\r\n"+	// {3} = table name
				"{4}\r\n"+	// {4} = set expressions
				"WHERE\r\n" +
				"{5}\r\n"+		// {5} = pk column name
				"" //SET NOCOUNT OFF\r\n"
				, spName, GetParamDescs(pkCols), parDecl, tableName, setCols, GetParamWhereDesc(pkCols));

			return s;
		}

		private string GenerateSPforInsert()
		{
			bool insertPK = Util.GetInsertPKForClass(cls);
			string spName = Util.GetSPInsertForClass(cls, true);
			string cols = null;//MergeCols(insertPK, false, false);
			string parDecls = MergeCols(insertPK, true, true);
			//string pars = MergeCols(insertPK, true, false);
			DataColumn[] pkCols = null;
			if (tbl != null)
				pkCols = GetDataColumns(pkColNames);

			string setCols = "";
			for (int i = 0; i < lsMembers.Items.Count; i++)
			{
				string col = (string)lsMembers.Items[i];
				if (insertPK || !IsPKColumn(col))	// if not PK
				{
					try
					{
						string parName = null; // MakeParamName(col);
					
						CodeElement elem = GetElemForColumn(col, EnumStatementType.Insert);
						if (elem == null)
							continue;
						parName = "@" + elem.Name;
						CodeVariable var = elem as CodeVariable;
						CodeAttribute colMapAtt = Util.GetColMappingAtt(var);

						// check sqlgen flags
						if (Util.IsColumnInsertable(colMapAtt))
						{

							string injectInsert = Util.GetParamFromAttrib(colMapAtt, "InjectInsert", -1);

							string exp = null;
							if (injectInsert != null && injectInsert != "")
								exp = injectInsert;
							else
								exp = parName;

							if (setCols != "")
								setCols += ", ";
							setCols += exp;

							if (cols != null)
								cols += ", ";
							cols += String.Format("[{0}]", col);
							
						}
					}
					catch(Exception ex)
					{
						Connect.Instance.ShowDialog(this, "An error occured for member " + col + "\r\n\r\n  " + ex.ToString());
						throw;
					}
				}
			}
			
			string s = String.Format("CREATE PROCEDURE [DBO].[{0}] (" +		// {0} sp name
				"{1} )\r\n" +		// {1} = param decls
				"AS\r\n" +
				Util.spAutoGenRemark +
				"SET NOCOUNT ON\r\n" +
				"SET ANSI_WARNINGS OFF \r\n"+
				"INSERT INTO [{2}]\r\n"+	// {2} = table name
				"({3})\r\n"+	// {3} = columns
				"VALUES ({4});\r\n" +  // {4} = parameters
				(insertPK ? "" : "\r\nSELECT @@IDENTITY\r\n") +
				"SET NOCOUNT OFF\r\n"
				, spName, parDecls, tableName, cols, setCols);

			return s;
		}

		private bool CheckSPInsertParams(ArrayList mismatchedParams)
		{
			/*string spInsert = Util.GetSPInsertForClass(cls);
			if( Util.GetStoredProcContentFromDB( spInsert ) != GenerateSPforInsert())
			{
				mismatchedParams.Add("SP out of date");
				return false;
			}
			return true;*/
			

			bool insertPK = Util.GetInsertPKForClass(cls);
			string spInsert = Util.GetSPInsertForClass(cls);
			if (spInsert != null)
				return CheckSPParamsByMappedCols(spInsert, insertPK, mismatchedParams, EnumStatementType.Insert);
			else
				return true;
		}

		private bool CheckSPUpdateParams(ArrayList mismatchedParams)
		{
			/*string spUpdate = Util.GetSPUpdateForClass(cls);
			if( Util.GetStoredProcContentFromDB( spUpdate ) != GenerateSPforUpdate())
			{
				mismatchedParams.Add("SP out of date");
				return false;
			}
			return true;*/

			
			string spUpdate = Util.GetSPUpdateForClass(cls);
			if (spUpdate != null)
				return CheckSPParamsByMappedCols(spUpdate, true, mismatchedParams, EnumStatementType.Update);
			else
				return true;
		}

		private bool CheckSPParamsByMappedCols(string spName, bool includePK, ArrayList mismatchedParams, EnumStatementType statementType)
		{
			mismatchedParams.Clear();
			string parDecls = MergeCols(includePK, true, false);
			string[] paramsMustBe = parDecls.Split(',');
			OleDbParameterCollection paramsExisting = Util.GetStoredProcParameterCollection(spName);
			//if (paramsMustBe.Length != paramsExisting.Count)
			//	return false;
			int paramCount = 0;
			for (int i = 0; i < paramsMustBe.Length; i ++)
			{
				string paramMustBe = paramsMustBe[i].Trim(' ', '@');

				// check param names
				//if (i >= paramsExisting.Count)
				//	mismatchedParams.Add(paramMustBe);		// parameter name mismatch
				//else
				//{
					///////
					
					
					//if (existingParamName != paramMustBe)
					//	mismatchedParams.Add(paramMustBe);		// parameter name mismatch
					//else
					//{
						if (tbl != null)
						{
							// check data types
							CodeVariable var = Util.FindFirstMember(cls, paramMustBe) as CodeVariable;
							CodeAttribute colMapAtt = Util.GetColMappingAtt(var);
							if (Util.IsStatementTypeSupportedByColumn(colMapAtt, statementType))
							{
								int iparam = paramCount;
								paramCount ++;

								if (paramCount > paramsExisting.Count)
									mismatchedParams.Add(paramMustBe);		// parameter name mismatch
								else
								{
									OleDbParameter existingParam = paramsExisting[iparam];
									string existingParamName = existingParam.ParameterName.Trim('@');

									if (existingParamName != paramMustBe)
										mismatchedParams.Add(paramMustBe);		// parameter name mismatch
									else
									{

										string colName = Util.GetColMappingForMember(cls, paramMustBe);
										// if the column can't be found, ignore it.  we're just checking the parameters of the sp
										// sp may be using the param for differently.
										if (colName != null)
											if (tbl.Columns.Contains(colName))
											{
												DataColumn col = tbl.Columns[colName];
												//if (existingParam.DbType.  col.DataType   
											}
									}
								}
							}

						}
					//}
				//}
				
			}

			return mismatchedParams.Count == 0;	// no prob if there's no mismatch
		}

		private void PreviewCRUDsp(string spName)
		{
			try
			{
				txtPreviewCRUDsps.Text = Util.GetStoredProcContentFromDB(spName);
				txtPreviewCRUDsps.Select(0, txtPreviewCRUDsps.Text.Length);
				txtPreviewCRUDsps.SelectionColor = System.Drawing.SystemColors.WindowText;
			}
			catch(Exception ex)
			{
				txtPreviewCRUDsps.Text = ex.Message;
			}
		}

		private void AddWarningMsgToSPPreview(string msg)
		{
			msg = "/* " + msg + " */\r\n";
			txtPreviewCRUDsps.Select(0, 0);
			txtPreviewCRUDsps.SelectionColor = System.Drawing.Color.Red;
			txtPreviewCRUDsps.SelectedText = msg; // + txtPreviewCRUDsps.Text;	
			//txtPreviewCRUDsps.Select(0, msg.IndexOf("*/") + 1);
			//txtPreviewCRUDsps.SelectionColor = System.Drawing.Color.Red;
		}

		private void cmdShowSPforLoad_Click(object sender, System.EventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPLoadForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			cmdDropCRUDsp.Visible = true;
			Util.MarkAttribute(cls, "SPLoad");
		}

		private void chkSPforDelete_Click(object sender, System.EventArgs e)
		{
			EnableButtons(tabStoredProcs);
		}

		private void cmdShowSPforInsert_Click(object sender, System.EventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPInsertForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			cmdDropCRUDsp.Visible = true;
			Util.MarkAttribute(cls, "SPInsert");
		}

		private void cmdShowSPforUpdate_Click(object sender, System.EventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPUpdateForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			cmdDropCRUDsp.Visible = true;
			Util.MarkAttribute(cls, "SPUpdate");
		}

		private void cmdShowSPforDelete_Click(object sender, System.EventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPDeleteForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			cmdDropCRUDsp.Visible = true;
			Util.MarkAttribute(cls, "SPDelete");
		}

		private void cmdDropCRUDsp_Click(object sender, System.EventArgs e)
		{
			if (Connect.Instance.ShowDialog(this, 
				String.Format("Do you really want to drop stored procedure '{0}'?", lbCRUDspname.Text),
				"Drop stored procedure", MessageBoxButtons.YesNo)
					!= DialogResult.Yes)
				return;


			Util.DropStoredProcOnDB(this, lbCRUDspname.Text);
			EnableButtons(tabStoredProcs);
			EnableProcedureButtons();
		}

		private void cmdShowExistsByPK_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = null;
			if (pkTypes != null)
			{
				func = Util.FindFirstMethod(false, cls, "Exists", pkTypes);
				Util.MarkElement(cls, func as CodeElement);
			}
		}

		private void cmdShowExists_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Exists");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowSPforExists_Click(object sender, System.EventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPExistsForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			cmdDropCRUDsp.Visible = true;
			Util.MarkAttribute(cls, "SPExists");
		}

		private void cbSprocName_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (cbSprocName.Text != "")
			{
				string[] spParams = Util.GetStoredProcParameters(cbSprocName.Text);
				if (spParams != null)
				{
					// remove all parameters selected
					butRemoveParamAll_Click(this, new EventArgs());

					// fill stored proc parameters to the parameters selected.
					string unmappedParams = null;
					for (int i = 0; i < spParams.Length; i++)
					{
						string paramName = spParams[i];
						int sel = lsAllFields.FindString(paramName);
						if (sel >= 0)
						{
							lsAllFields.SelectedIndex = sel;
							butAddParam_Click(this, new EventArgs());	// add the found param
						}
						else
						{
							if (unmappedParams != null)
								unmappedParams += ", ";
							unmappedParams += paramName;
						}
					}

					if (unmappedParams != null)
					{
						Connect.Instance.ShowDialog(this, "There are some parameter names that do not match any member names:\r\n\r\n  " + unmappedParams);
						//if (extendsBaseEntity)
						//	spOptions.UseSPParams = true;	// doesn't exist
					}

				}
			}

			EnableButtons(tabBuildParamsMethods);
		}

		private void cbSprocName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabBuildParamsMethods);
		}

		private void chkAllCRUDsps_Click(object sender, System.EventArgs e)
		{
			chkSPforLoad.Checked = chkAllCRUDsps.Checked;
			chkSPforDelete.Checked = chkAllCRUDsps.Checked;
			chkSPforUpdate.Checked = chkAllCRUDsps.Checked;
			chkSPforInsert.Checked = chkAllCRUDsps.Checked;
			EnableButtons(tabStoredProcs);
		}

		private void chkAllStoredProcs_CheckedChanged(object sender, System.EventArgs e)
		{
			chkSPforExists.Checked = chkAllStoredProcs.Checked;
			if (chkAutoGenSPs.Enabled)
				chkAutoGenSPs.Checked = chkAllStoredProcs.Checked;
			chkAllCRUDsps.Checked = chkAllStoredProcs.Checked;
			chkAllCRUDsps_Click(sender, e);
		}

		private void lsChildren_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int sel = lsChildren.SelectedIndex;
			if (sel < 0)
			{
				txtSPForLoadChild.Text = "";
				return;
			}

			string member = (string)lsChildren.Items[sel];

			CodeElement elem = Util.FindFirstMember(cls, member);
			Util.MarkElement(cls, elem);

			chkExecuteStoredProcMethod.Checked = true;
			string spName = null, fkMember = null, manuallyManaged = null;
			Util.GetSPLoadChildForProp(elem as CodeProperty, ref spName, ref fkMember, ref manuallyManaged);
			txtSPForLoadChild.Text = spName;
			cbSprocName.Text = spName;

			cbSprocName_SelectedIndexChanged(this, new EventArgs());
			FillSprocNames();
			EnableButtons(tabChildren);
		}

		private void cmdCreateChild_Click(object sender, System.EventArgs e)
		{
			try
			{
				//Close();
				ChildMemberCreator.CreateChildMember(this, cls);
				FillChildren();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void butCreateServerScriptProp_Click(object sender, System.EventArgs e)
		{
			try
			{
				EnsureSqlDataProp();
				EnableButtons();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkShowInvalidMappings_CheckedChanged(object sender, System.EventArgs e)
		{
			lsInvalidMappings.Visible = chkShowInvalidMappings.Checked;
		}

		private void lsInvalidMappings_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons(tabColumnMapping);

			int sel = lsInvalidMappings.SelectedIndex;
			if (sel < 0)
				return;

			string colName = (string)lsInvalidMappings.Items[sel];

			CodeElement elem = Util.FindMemberForColumn(cls, colName, EnumStatementType.Free);
			Util.MarkElement(cls, elem);
		}

		private void cmdShowSynchronizeMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(false, cls, "Synchronize");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void butAddParamAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsAllFields.Items.Count; i++)
			{
				lsParams.Items.Add(lsAllFields.Items[i]);
			}
			lsAllFields.Items.Clear();
			EnableButtons(tabBuildParamsMethods);
		}

		private void butRemoveParamAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsParams.Items.Count; i++)
			{
				lsAllFields.Items.Add(lsParams.Items[i]);
			}
			ArrangeListByTableColumnOrder(lsAllFields, true);
			lsParams.Items.Clear();
			EnableButtons(tabBuildParamsMethods);
		}

		private void butAddParamsOnlyMapped_Click(object sender, System.EventArgs e)
		{
			int pos = lsParams.SelectedIndex + 1;
			for (int i = lsAllFields.Items.Count - 1; i >= 0; i--)
			{
				string member = (string)lsAllFields.Items[i];
				if (Util.IsMemberMapped(cls, member))
				{
					lsParams.Items.Insert(pos, member);
					lsAllFields.Items.RemoveAt(i);
				}

			}
			EnableButtons(tabBuildParamsMethods);
		}

		private void butCreateOverridingMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				CreateOverridingMethods();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void butAddOverridable_Click(object sender, System.EventArgs e)
		{
			if (lstOverridables.SelectedIndex < 0)
				return;
			lstOverriddenMethods.Items.Add(lstOverridables.Items[lstOverridables.SelectedIndex]);
			int sel = lstOverridables.SelectedIndex;
			lstOverridables.Items.RemoveAt(sel);
			if (sel < lstOverridables.Items.Count)
				lstOverridables.SelectedIndex = sel;
			EnableButtons(tabOverrides);
			butCreateOverridingMethods.Enabled = true;
		}

		private void CreateOverridingMethods()
		{
			string spUpdate = Util.GetSPUpdateForClass(cls);
			if (spUpdate == null)
				spUpdate = "usp_Update" + this.cls.Name;
			string spInsert = Util.GetSPInsertForClass(cls);
			if (spInsert == null)
				spInsert = "usp_Insert" + this.cls.Name;

			for (int i = 0; i < lstOverriddenMethods.Items.Count; i++)
			{
				string methodName = (string)lstOverriddenMethods.Items[i];

				// check if this item is already overridden and skip it if so

                CodeFunction2 func = (CodeFunction2)Util.FindFirstMethod(false, cls, methodName, null);
				if (func == null) //it dosn't exist, override it
				{
					switch(methodName)
					{
						case "SPExecuteLoad":
						{
                            func = (CodeFunction2)cls.AddFunction("SPExecuteLoad", EnvDTE.vsCMFunction.vsCMFunctionFunction,
								EnvDTE.vsCMTypeRef.vsCMTypeRefBool, // "override bool",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Overrides the load operation for this Entity Object.  Implement this method to customize or optimize the load behavior.";

							func.AddParameter("keys", "object[]", -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							if (chkOverrideCRUDpassMembers.Checked)
								ep.Insert(String.Format("\t\t\treturn SqlData.SPExecReadObj(this.LoadProcName, this, false, keys);"));
							else
								ep.Insert(String.Format("\t\t\treturn SqlData.SPExecReadObj(this.LoadProcName, this, false, keys);"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "SPExecuteInsert":
						{
                            func = (CodeFunction2)cls.AddFunction("SPExecuteInsert", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefObject,  // "override object",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Overrides the insert operation for this Entity Object.  Implement this method to customize or optimize the insert behavior.";

							// no parameters
							//func.AddParameter("keys", "object[]", -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);

							if (chkOverrideCRUDpassMembers.Checked)
							{
								string spParams = Util.GetStoredProcParametersJoined(spInsert);
								if (spParams == null)
								{
									ep.Insert(String.Format("\t\t\t// WARNING: Stored procedure does not exist in the database, creating safe invoker"));
									ep.Insert(String.Format("\t\t\treturn SqlData.SPExecScalar(this.InsertProcName, this, false);"));
								}
								else
									ep.Insert(String.Format("\t\t\treturn SqlData.SPExecScalar(this.InsertProcName, {0});", spParams));
							}
							else
								ep.Insert(String.Format("\t\t\treturn SqlData.SPExecScalar(this.InsertProcName, this, false);"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}
						case "SPExecuteUpdate":
						{
                            func = (CodeFunction2)cls.AddFunction("SPExecuteUpdate", EnvDTE.vsCMFunction.vsCMFunctionFunction,
								EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Overrides the update operation for this Entity Object.  Implement this method to customize or optimize the update behavior.";

							//func.AddParameter("keys", "object[]", -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							if (chkOverrideCRUDpassMembers.Checked)
							{
								string spParams = Util.GetStoredProcParametersJoined(spUpdate);
								if (spParams == null)
								{
									ep.Insert(String.Format("\t\t\t// WARNING: Stored procedure does not exist in the database, creating safe invoker"));
									ep.Insert(String.Format("\t\t\tSqlData.SPExecNonQuery(this.UpdateProcName, this, false);"));
								}
								else
									ep.Insert(String.Format("\t\t\tSqlData.SPExecNonQuery(this.UpdateProcName, {0});", spParams ));
							}
							else
								ep.Insert(String.Format("\t\t\tSqlData.SPExecNonQuery(this.UpdateProcName, this, false);"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}
						case "SPExecuteDelete":
						{
                            func = (CodeFunction2)cls.AddFunction("SPExecuteDelete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Overrides the delete operation for this Entity Object.  Implement this method to customize or optimize the delete behavior.";

							func.AddParameter("keys", "object[]", -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							if (chkOverrideCRUDpassMembers.Checked)
								ep.Insert(String.Format("\t\t\tSqlData.SPExecNonQuery(this.DeleteProcName, keys);"));
							else
								ep.Insert(String.Format("\t\t\tSqlData.SPExecNonQuery(this.DeleteProcName, keys);"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}
						case "InternalSave":
						{
                            func = (CodeFunction2)cls.AddFunction("InternalSave", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Override this function to save contained child and other objects.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Save the contained objects that must be saved first.\r\n"));
							ep.Insert(String.Format("\t\t\t// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object\r\n"));
							ep.Insert(String.Format("\t\t\t// if (this.IsMarkedForDeletion)\t// may be necessary to check if this object must be deleted first\r\n"));
							ep.Insert(String.Format("\t\t\t// {0}\r\n", "{"));
							ep.Insert(String.Format("\t\t\t//\tbase.InternalSave();	// in that case, delete the base first\r\n"));
							ep.Insert(String.Format("\t\t\t//\tContainedObject.MarkDel();\t// then allow the deletion of the conatined object\r\n"));
							ep.Insert(String.Format("\t\t\t// {0}\r\n", "}"));
							ep.Insert(String.Format("\t\t\t// ContainedObject.Save();\r\n"));
							ep.Insert(String.Format("\t\t\t// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created\r\n"));
							ep.Insert(String.Format("\t\t\tbase.InternalSave();\r\n"));
							ep.Insert(String.Format("\t\t\t// Save the child collections here."));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "InternalLoad":
						{
                            func = (CodeFunction2)cls.AddFunction("InternalLoad", EnvDTE.vsCMFunction.vsCMFunctionFunction,
								EnvDTE.vsCMTypeRef.vsCMTypeRefBool,   // "override bool",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Override this function to load child and other objects that must be loaded with this object.";

							func.AddParameter("keys", "params object[]", -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Do pre-load operations here.\r\n"));
							ep.Insert(String.Format("\t\t\tbool result = base.InternalLoad(keys);\r\n"));
							ep.Insert(String.Format("\t\t\t// Do post-load operations here.\r\n"));
							//ep.Insert(String.Format("\t\t\t// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed"));
							ep.Insert(String.Format("\t\t\treturn result;"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "OnCompleteSave":
						{
                            func = (CodeFunction2)cls.AddFunction("OnCompleteSave", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Override this to do custom post-save operations other than DB operations.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// IsNewlyInsertedInDB, IsNewlyDeletedInDB, IsNewlyUpdatedInDB flags are available.\r\n"));
							ep.Insert(String.Format("\t\t\tbase.OnCompleteSave();\r\n"));
							ep.Insert(String.Format("\t\t\t// IsNewlyInsertedInDB, IsNewlyDeletedInDB, IsNewlyUpdatedInDB flags are reset."));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "FillFromReader":
						{
                            func = (CodeFunction2)cls.AddFunction("FillFromReader", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.";

							func.AddParameter("sourceRdr", "IDataReader", -1);
							func.AddParameter("ignoreAssignmentError", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Fill members for the given source reader record.\r\n"));
							ep.Insert(String.Format("\t\t\tbase.FillFromReader(sourceRdr, ignoreAssignmentError);"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "NewRecord":
						{
                            func = (CodeFunction2)cls.AddFunction("NewRecord", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Override this to initialize members for a new Entity Object to be inserted into DB.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\tbase.NewRecord();\r\n"));
							ep.Insert(String.Format("\t\t\t// Initialize members here.\r\n"));
							ep.Insert(String.Format("\t\t\t// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "InternalInsert":
						{
                            func = (CodeFunction2)cls.AddFunction("InternalInsert", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefObject, //  "override object",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Do pre and post-insert operations of the object here.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Do pre-insert operations here (set members before insert, insert/update extra records etc).\r\n"));
							ep.Insert(String.Format("\t\t\tobject pk = base.InternalInsert(); // always call this to ensure record flags gets updated properly.\r\n"));
							ep.Insert(String.Format("\t\t\t// Do post-insert operations here (set members after insert, insert/update extra records etc).\r\n"));
							ep.Insert(String.Format("\t\t\treturn pk; // Always return primary key in case it gets generated automatically"));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "InternalUpdate":
						{
                            func = (CodeFunction2)cls.AddFunction("InternalUpdate", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Do pre and post-update operations of the object here.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Do pre-update operations here (set members before update, insert/update extra records etc).\r\n"));
							ep.Insert(String.Format("\t\t\tbase.InternalUpdate(); // always call this to ensure record flags gets updated properly.\r\n"));
							ep.Insert(String.Format("\t\t\t// Do post-insert operations here (set members after update, insert/update extra records etc)."));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

						case "InternalDelete":
						{
                            func = (CodeFunction2)cls.AddFunction("InternalDelete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //  "override void",
								-1,
								EnvDTE.vsCMAccess.vsCMAccessProtected,
								null);

                            func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

							func.Comment = "Do pre and post-delete operations of this object here.";

							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\t// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).\r\n"));
							ep.Insert(String.Format("\t\t\tbase.InternalDelete(); // always call this to ensure record flags gets updated properly.\r\n"));
							ep.Insert(String.Format("\t\t\t// Do post-delete operations here (set members after delete, insert/update/delete extra records etc)."));

							ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

							break;
						}

					}
				}
			}
		}

		private void lstOverridables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string method = (string)lstOverridables.SelectedItem;
			if (method != null)
			{
				CodeFunction func = Util.FindFirstMethod(false, cls, method, null);
				Util.MarkElement(cls, func as CodeElement);
			}
			EnableButtons(tabOverrides);
		}

		private void lstOverriddenMethods_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string method = (string)lstOverriddenMethods.SelectedItem;
			if (method != null)
			{
				CodeFunction func = Util.FindFirstMethod(false, cls, method, null);
				Util.MarkElement(cls, func as CodeElement);
			}
			EnableButtons(tabOverrides);
		}

		private void lstOverridables_DoubleClick(object sender, System.EventArgs e)
		{
			butAddOverridable_Click(this, new EventArgs());
		}

		private void lstOverriddenMethods_DoubleClick(object sender, System.EventArgs e)
		{
			butRemoveOverridable_Click(this, new EventArgs());
		}

		private void butRemoveOverridable_Click(object sender, System.EventArgs e)
		{
			if (lstOverriddenMethods.SelectedIndex < 0)
				return;
			lstOverridables.Items.Add(lstOverriddenMethods.Items[lstOverriddenMethods.SelectedIndex]);
			int sel = lstOverriddenMethods.SelectedIndex;
			lstOverriddenMethods.Items.RemoveAt(sel);
			if (sel < lstOverriddenMethods.Items.Count)
				lstOverriddenMethods.SelectedIndex = sel;
			EnableButtons(tabOverrides);
		}

		private bool EditSP(string spName)
		{
			this.Visible = false;
			try
			{
				return StoredProcDlg.EditStoredProc(spName);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
				return false;
			}
			finally
			{
				this.Visible = true;
			}
		}

		private void lbProcNameLabel_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			EditSP(cbSprocName.Text);
		}

		private void lbCRUDspname_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			//this.Visible = false;
			try
			{
				if (EditSP(lbCRUDspname.Text))
				{
					PreviewCRUDsp(lbCRUDspname.Text);
					EnableButtons(tabStoredProcs);
					EnableProcedureButtons();
				}
			}
			finally
			{
				//this.Visible = true;
			}
		}

		private void butCreateSPLoadChild_Click(object sender, System.EventArgs e)
		{
			string member = (string)lsChildren.SelectedItem;
			if (member == null)
				return;

			CodeElement elem = Util.FindFirstMember(cls, member);
			if (elem == null)
				return;
			chkExecuteStoredProcMethod.Checked = true;
			string spName = null, fkMember = null, manuallyManaged = null;
			if (!Util.GetSPLoadChildForProp(elem as CodeProperty, ref spName, ref fkMember, ref manuallyManaged))
			{
				Connect.Instance.ShowDialog(this, "No SPLoadChild attribute defined for " + member);
				return;
			}

			if (manuallyManaged == "true")
			{
				Connect.Instance.ShowDialog(this, "The SPLoadChild attribute for " + member + " is manually managed.  Ignoring.");
				return;
			}

			cbSprocName.Text = spName;
			butRemoveAll_Click(this, new EventArgs());

			for (int i = 0; i < pkMembers.Length; i++)
			{
				string pkmember = pkMembers[i];
				int sel = lsAllFields.FindString(pkmember);
				if (sel >= 0)
				{
					lsAllFields.SelectedIndex = sel;
					butAddParam_Click(this, new EventArgs());	// add the found param
				}
			}

			//tab.SelectedTab = tabBuildParamsMethods;

			bool recreate = false;
			string proc = Util.GetStoredProcFromDB(cbSprocName.Text);
			if (proc != null)
				if (Connect.Instance.ShowDialog(this, String.Format("Stored procedure '{0}' already exists. Recreate it?", cbSprocName.Text), null, MessageBoxButtons.YesNo) == DialogResult.Yes)
					recreate = true;
			
			if (Util.SetStoredProcOnDB(this, cbSprocName.Text, GenerateSPforLoadChild(cbSprocName.Text, member, fkMember), recreate, false))
			{
				EnableButtons(tabBuildParamsMethods);
				EditSP(cbSprocName.Text);
			}
		}

		private void lbSPLoadChild_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			EditSP(txtSPForLoadChild.Text);
			EnableButtons(tabChildren);
		}

		private void butEnsureAllChildLoaderSPs_Click(object sender, System.EventArgs e)
		{
			string procs = null;
			for (int i = 0; i < lsChildren.Items.Count; i++)
			{
				string member = (string)lsChildren.Items[i];
				CodeElement elem = Util.FindFirstMember(cls, member);
				if (elem != null)
				{
					string spName = null, fkMember = null, manuallyManaged = null;
					Util.GetSPLoadChildForProp(elem as CodeProperty, ref spName, ref fkMember, ref manuallyManaged);

					if (manuallyManaged == "true")
						continue;		// just ignore if manually managed.

					string proc = Util.GetStoredProcFromDB(spName);
					if (proc == null)
					{
						if (Util.SetStoredProcOnDB(this, spName, GenerateSPforLoadChild(spName, member, fkMember), false, false))
						{
							if (procs != null)
								procs += ",\r\n";
							procs += spName;
						}
					}
				}
				EnableButtons(tabBuildParamsMethods);

				if (procs == null)
					Connect.Instance.ShowDialog(this, "No child loader SPs created.");
				else
					Connect.Instance.ShowDialog(this, "Following child loader SPs have been created:\r\n" + procs);
			}

			
		}

		private void cmdCreateContainedEntityObject_Click(object sender, System.EventArgs e)
		{
			try
			{
				//Close();
				ContainedEntityObjectCreator.CreateConatinedEntityObject(this, this.cls);
				FillContainedEntityObjects();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
			
		}

		private void lsContainedEntityObjects_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string member = (string)lsContainedEntityObjects.SelectedItem;
			if (member == null)
				return;
			CodeElement elem = Util.FindFirstMember(cls, member);
			Util.MarkElement(cls, elem);
			EnableButtons(tabContainedObjects);
		}

		private void lsCollectionClasses_DoubleClick(object sender, System.EventArgs e)
		{
			cmdShowColBuilder_Click(this, new EventArgs());
		}

		private void cmdShowChildColBuilder_Click(object sender, System.EventArgs e)
		{
			string selItem = (string)lsChildren.SelectedItem;
			if (selItem != null)
			{
				CodeProperty prop = Util.FindFirstMember(cls, selItem) as CodeProperty;
				if (prop == null)
					return;
				string clsName = Util.GetLastTerm(prop.Type.AsString);
				CodeClass ccls = Util.FindClassInProject(clsName);
				if (ccls != null)
				{
					this.Close();
					CollectionClassBuilder.BuildCollectionClass(ccls);
				}
			}
		}

		private void cmdShowContainedClassBuilder_Click(object sender, System.EventArgs e)
		{
			string selItem = (string)lsContainedEntityObjects.SelectedItem;
			if (selItem != null)
			{
				CodeProperty prop = Util.FindFirstMember(cls, selItem) as CodeProperty;
				if (prop == null)
					return;
				string clsName = Util.GetLastTerm(prop.Type.AsString);
				CodeClass ccls = Util.FindClassInProject(clsName);
				if (ccls != null)
				{
					this.Close();
					EntityBuilder.BuildClass(ccls);
				}
			}
		}

		private void cmdShowClassBuilderForParent_Click(object sender, System.EventArgs e)
		{
			string selItem = (string)lsParentObjects.SelectedItem;
			if (selItem != null)
			{
				CodeProperty prop = Util.FindFirstMember(cls, selItem) as CodeProperty;
				if (prop == null)
					return;
				string clsName = Util.GetLastTerm(prop.Type.AsString);
				CodeClass ccls = Util.FindClassInProject(clsName);
				if (ccls != null)
				{
					if (Util.DerivesFromClass(ccls, "Entity"))
					{
						this.Close();
						EntityBuilder.BuildClass(ccls);
					}
					else if (Util.DerivesFromClass(ccls, "EntityCollectionClass"))
					{
						this.Close();
						CollectionClassBuilder.BuildCollectionClass(ccls);
					}
				}
			}
		}

		private void lsParentObjects_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string member = (string)lsParentObjects.SelectedItem;
			if (member == null)
				return;
			CodeElement elem = Util.FindFirstMember(cls, member);
			Util.MarkElement(cls, elem);
			EnableButtons(tabContainedObjects);
		}

		private void butMismatchedInsertParams_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPInsertForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			AddWarningMsgToSPPreview(
				"The stored procedure doesn't accept the following parameters:\r\n" +
				String.Join(", ", (string[])mismatchedInsertParams.ToArray(typeof(string)) )
				+ "\r\n");
		}

		private void butMismatchedUpdateParams_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPUpdateForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			AddWarningMsgToSPPreview(
				"The stored procedure doesn't accept the following parameters:\r\n" +
				String.Join(", ", (string[])mismatchedUpdateParams.ToArray(typeof(string)) )
				+ "\r\n");
		}

		private void butCreateCRUDTester_Click(object sender, System.EventArgs e)
		{
			CreateCRUDTesterDlg.CreateCRUDTester(this);
		}

		private void butPossibleInvalidLoadSP_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			lbCRUDspname.Text = Util.GetSPLoadForClass(cls, true);
			PreviewCRUDsp(lbCRUDspname.Text);
			AddWarningMsgToSPPreview(
				"Warning: Insert/Update operation seems to be invalid.  This method could be returning invalid columns too."
				+ "\r\n");
		}

		private void butManageAutoGenSPs_Click(object sender, System.EventArgs e)
		{
			this.Visible = false;
			try
			{
				AutoGeneratedStoredProcsDlg.ManageAutoGeneratedStoredProcs(this);
			}
			finally
			{
				//this.Visible = true;
			}
		}

		private void butPossibleInvalidAutoGenSPs_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			butManageAutoGenSPs_Click(this, new EventArgs());
		}

		public void GotoCreateMethodForSP(string spName)
		{
			if (!this.Visible)
				this.Visible = true;
			tab.SelectedTab = tabBuildParamsMethods;
			chkExecuteStoredProcMethod.Checked = true;
			FillSprocNames();
			cbSprocName.Text = spName;
			cbSprocName_SelectedIndexChanged(this, new EventArgs());
			EnableButtons(tabBuildParamsMethods);
		}

		private void butSelectSPTemplate_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			butManageAutoGenSPs_Click(this, new EventArgs());
		}

		private void butShowContainmentModel_Click(object sender, System.EventArgs e)
		{
			ContainmentModel.Display(this.cls);
		}

		private void butShowContainmentBuilder2_Click(object sender, System.EventArgs e)
		{
			ContainmentModel.Display(this.cls);
		}

		private void EntityBuilder_Closed(object sender, System.EventArgs e)
		{
			Util.NAR(this.cls);
		}

	}
}
