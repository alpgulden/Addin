using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;
using EnvDTE80;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class EntityCreator : System.Windows.Forms.Form
	{
		private CodeClass cls;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbTables;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox chkRemovePluralS;
		private System.Windows.Forms.CheckBox chkUnmappedTablesOnly;
		private System.Windows.Forms.CheckBox chkDeriveFromBaseEntity;
		private System.Windows.Forms.ComboBox cbBaseClass;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Button butAlterColumns;
        private CheckBox chkColumnNameConstants;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public EntityCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EntityCreator));
            this.label1 = new System.Windows.Forms.Label();
            this.cbTables = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.butCancel = new System.Windows.Forms.Button();
            this.butCreate = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtClassName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkRemovePluralS = new System.Windows.Forms.CheckBox();
            this.chkUnmappedTablesOnly = new System.Windows.Forms.CheckBox();
            this.chkDeriveFromBaseEntity = new System.Windows.Forms.CheckBox();
            this.cbBaseClass = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.butAlterColumns = new System.Windows.Forms.Button();
            this.chkColumnNameConstants = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Table:";
            // 
            // cbTables
            // 
            this.cbTables.Location = new System.Drawing.Point(96, 104);
            this.cbTables.Name = "cbTables";
            this.cbTables.Size = new System.Drawing.Size(288, 21);
            this.cbTables.TabIndex = 2;
            this.cbTables.SelectedIndexChanged += new System.EventHandler(this.cbTables_SelectedIndexChanged);
            this.cbTables.TextChanged += new System.EventHandler(this.cbTables_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(160, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 48);
            this.label2.TabIndex = 3;
            this.label2.Text = "Please select a table to create Entity Class for.";
            // 
            // butCancel
            // 
            this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel.Location = new System.Drawing.Point(112, 248);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 4;
            this.butCancel.Text = "Close";
            // 
            // butCreate
            // 
            this.butCreate.Location = new System.Drawing.Point(200, 248);
            this.butCreate.Name = "butCreate";
            this.butCreate.Size = new System.Drawing.Size(75, 23);
            this.butCreate.TabIndex = 5;
            this.butCreate.Text = "Create";
            this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // txtClassName
            // 
            this.txtClassName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClassName.Location = new System.Drawing.Point(96, 128);
            this.txtClassName.Name = "txtClassName";
            this.txtClassName.Size = new System.Drawing.Size(288, 20);
            this.txtClassName.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 23);
            this.label3.TabIndex = 10;
            this.label3.Text = "Class Name";
            // 
            // chkRemovePluralS
            // 
            this.chkRemovePluralS.Checked = true;
            this.chkRemovePluralS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemovePluralS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkRemovePluralS.Location = new System.Drawing.Point(96, 160);
            this.chkRemovePluralS.Name = "chkRemovePluralS";
            this.chkRemovePluralS.Size = new System.Drawing.Size(144, 16);
            this.chkRemovePluralS.TabIndex = 12;
            this.chkRemovePluralS.Text = "Remove Plural \'s\'";
            this.chkRemovePluralS.CheckedChanged += new System.EventHandler(this.chkRemovePluralS_CheckedChanged);
            // 
            // chkUnmappedTablesOnly
            // 
            this.chkUnmappedTablesOnly.Checked = true;
            this.chkUnmappedTablesOnly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUnmappedTablesOnly.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkUnmappedTablesOnly.Location = new System.Drawing.Point(96, 72);
            this.chkUnmappedTablesOnly.Name = "chkUnmappedTablesOnly";
            this.chkUnmappedTablesOnly.Size = new System.Drawing.Size(176, 24);
            this.chkUnmappedTablesOnly.TabIndex = 13;
            this.chkUnmappedTablesOnly.Text = "List Unmapped Tables Only";
            this.chkUnmappedTablesOnly.CheckedChanged += new System.EventHandler(this.chkUnmappedTablesOnly_CheckedChanged);
            // 
            // chkDeriveFromBaseEntity
            // 
            this.chkDeriveFromBaseEntity.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkDeriveFromBaseEntity.Location = new System.Drawing.Point(96, 176);
            this.chkDeriveFromBaseEntity.Name = "chkDeriveFromBaseEntity";
            this.chkDeriveFromBaseEntity.Size = new System.Drawing.Size(168, 24);
            this.chkDeriveFromBaseEntity.TabIndex = 14;
            this.chkDeriveFromBaseEntity.Text = "Derive from BaseEntity";
            this.chkDeriveFromBaseEntity.CheckedChanged += new System.EventHandler(this.chkDeriveFromBaseEntity_CheckedChanged);
            // 
            // cbBaseClass
            // 
            this.cbBaseClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaseClass.Location = new System.Drawing.Point(110, 221);
            this.cbBaseClass.Name = "cbBaseClass";
            this.cbBaseClass.Size = new System.Drawing.Size(272, 21);
            this.cbBaseClass.TabIndex = 15;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(8, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // butAlterColumns
            // 
            this.butAlterColumns.Location = new System.Drawing.Point(344, 152);
            this.butAlterColumns.Name = "butAlterColumns";
            this.butAlterColumns.Size = new System.Drawing.Size(40, 16);
            this.butAlterColumns.TabIndex = 18;
            this.butAlterColumns.Text = "AlterColumns";
            this.butAlterColumns.Visible = false;
            this.butAlterColumns.Click += new System.EventHandler(this.butAlterColumns_Click);
            // 
            // chkColumnNameConstants
            // 
            this.chkColumnNameConstants.Checked = true;
            this.chkColumnNameConstants.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkColumnNameConstants.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkColumnNameConstants.Location = new System.Drawing.Point(96, 199);
            this.chkColumnNameConstants.Name = "chkColumnNameConstants";
            this.chkColumnNameConstants.Size = new System.Drawing.Size(150, 16);
            this.chkColumnNameConstants.TabIndex = 32;
            this.chkColumnNameConstants.Text = "Column Name Constants";
            // 
            // EntityCreator
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(394, 283);
            this.Controls.Add(this.chkColumnNameConstants);
            this.Controls.Add(this.butAlterColumns);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.cbBaseClass);
            this.Controls.Add(this.chkDeriveFromBaseEntity);
            this.Controls.Add(this.chkUnmappedTablesOnly);
            this.Controls.Add(this.chkRemovePluralS);
            this.Controls.Add(this.txtClassName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.butCreate);
            this.Controls.Add(this.butCancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbTables);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EntityCreator";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Netsoft USA Entity Class Creator";
            this.TopMost = true;
            this.TextChanged += new System.EventHandler(this.cbTables_TextChanged);
            this.Load += new System.EventHandler(this.EntityCreator_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		public static void CreateEntity()
		{
			EntityCreator dcb = new EntityCreator();
			if (dcb.ShowDialog(Connect.Instance) == DialogResult.OK)
			{		
				if (dcb.cls != null)
				{
					EntityBuilder.BuildClass(dcb.cls);
				}
			}
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				//NewCSharpFile.cs
                cls = Connect.Instance.AddClassToCurrentProject(txtClassName.Text, chkDeriveFromBaseEntity.Checked ? (string)cbBaseClass.SelectedItem : null);
                ProjectItem prjItem = cls.ProjectItem;
                CodeNamespace ns = cls.Namespace;
				DataTable tbl = Util.GetTablePrototype(cbTables.Text);
				string pk = null;
			
				if (tbl.PrimaryKey.Length == 1)
					pk = tbl.PrimaryKey[0].ColumnName;
				else
				{
					// detect from db
					pk = Util.GetPrimaryKey(cbTables.Text);
				}

				Util.AddReference(prjItem.ContainingProject, "NetsoftUSA.Model");

				// add:   using NetsoftUSA.Model;
				EditPoint ep = ns.StartPoint.CreateEditPoint();
                ep.MoveToLineAndOffset(1, 1);
				//ep.EndOfLine();
                ep.Insert("\r\nusing System;\r\n\r\n");
				ep.Insert("\r\nusing NetsoftUSA.Model;\r\n\r\n");

				if (cls != null)
				{
					//if (chkDeriveFromBaseEntity.Checked)
						//cls.AddBase((string)cbBaseClass.SelectedItem, -1);

					string tableName = cbTables.Text;

					cls.Comment = String.Format("Entity Class that wraps the entity access functionality to table [{0}]", tableName);

					EditPoint edColMapAtt = cls.StartPoint.CreateEditPoint();
					edColMapAtt.LineUp(1);
					edColMapAtt.EndOfLine();
					string pars = String.Format("\"{0}\"", tableName);
					string pkMember = null;
					if (pk != null)
					{
						pkMember = Util.NormalizeIdentifierName(pk, true, "");
						pars += String.Format(",\"{0}\"", pkMember);
					}

                    edColMapAtt.Insert(String.Format("\r\n\t//[ServiceClass(\"{0}\")]    // Declare your business service class here..", cls.Name + "Service" ));
					edColMapAtt.Insert(String.Format("\r\n\t[TableMapping({0})]", pars));
                    edColMapAtt.Insert(String.Format("\r\n\t[GenerateDBTable(\"{0}\")]", tableName));
                    edColMapAtt.Insert(String.Format("\r\n\t[Serializable]"));

					if (pk != null)
					{
						Type type = tbl.Columns[pk].DataType;
						// add pk member
						CodeVariable var = cls.AddVariable(pkMember, 
							Util.GetVSNETTypeEnum(type),
							0, 
							EnvDTE.vsCMAccess.vsCMAccessPrivate, 
							null);

						EditPoint epColMap = var.StartPoint.CreateEditPoint();
						epColMap.LineUp(1);
						epColMap.EndOfLine();
						//string valueForNullExp = Util.GetValueForNullExp(type, true);
						string valueForNullExp = null;
						if (type == typeof(int))
							valueForNullExp = ",(int)0";
						else if (type == typeof(long))
							valueForNullExp = ",(long)0";
						else if (type == typeof(short))
							valueForNullExp = ",(short)0";
						epColMap.Insert(String.Format("\r\n\t\t[ColumnMapping({0}{1})]",
                            Util.MakeColumnIdent(tableName, pk, chkColumnNameConstants.Checked), 
                            valueForNullExp));

						Connect.Instance.BuildPropertyForField(cls, var as CodeElement, PropertyBuildMode.TypedGetSet);
					}
				}

				prjItem.Save(null);
				prjItem.Open(Constants.vsViewKindCode);
				DialogResult = DialogResult.OK;

				Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseEntity.Checked);
				Util.SetSetting("__ClassManager", "BaseEntity", (string)cbBaseClass.SelectedItem);

				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			chkDeriveFromBaseEntity.Checked = Util.GetSetting("__ClassManager", "DeriveFromBaseEntity", false);
			Util.FillTableNamesInCombo(cbTables, chkUnmappedTablesOnly.Checked);
			//FillBases();
			string baseEntity = (string)Util.GetSetting("__ClassManager", "BaseEntity", "Entity");
			int i = cbBaseClass.FindStringExact(baseEntity);
			cbBaseClass.SelectedIndex = i;
		}

		private void SetClassName()
		{
			string clsName = Util.NormalizeClassName(cbTables.Text);

			if (chkRemovePluralS.Checked)
			{
				// if the table name has a plural 's', remove it
				clsName = Util.MakeSingular(clsName);
			}
			txtClassName.Text = clsName;
		}

		private void cbTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetClassName();
		}

		private void chkRemovePluralS_CheckedChanged(object sender, System.EventArgs e)
		{
			SetClassName();
		}

		private void cbTables_TextChanged(object sender, System.EventArgs e)
		{
			SetClassName();
		}

		private void chkUnmappedTablesOnly_CheckedChanged(object sender, System.EventArgs e)
		{
			Util.FillTableNamesInCombo(cbTables, chkUnmappedTablesOnly.Checked);
		}

		private void FillBases()
		{
			cbBaseClass.Enabled = chkDeriveFromBaseEntity.Checked;
			if (chkDeriveFromBaseEntity.Checked)
			{
				if (cbBaseClass.Items.Count == 0)
				{
					try
					{
						object[] Entityes = Util.FindClassesWithBaseInProject("Entity");
						cbBaseClass.Items.Clear();
						cbBaseClass.Items.Add("Entity");
						Util.FillClassNames(cbBaseClass, Entityes, false, false);
					}
					catch(Exception ex)
					{
						Connect.Instance.ShowDialog(this, ex.Message);
					}
				}
			}
		}

		private void chkDeriveFromBaseEntity_CheckedChanged(object sender, System.EventArgs e)
		{
			FillBases();
		}

		private void butAlterColumns_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < cbTables.Items.Count; i++)
			{
				string tblName = (string)cbTables.Items[i];
				DataTable tbl = Util.GetTablePrototype(tblName);
				if (tbl.Columns.Contains("InActive"))
				{
					DataColumn col = tbl.Columns["InActive"];
					if (col != null && col.DataType == typeof(bool))
					{
						Util.RenameColumn(tblName, col.ColumnName, "Active");
						Util.AlterColumn(tblName, "Active", "bit not null");
					}
				}
				
			}
		}

	}
}
