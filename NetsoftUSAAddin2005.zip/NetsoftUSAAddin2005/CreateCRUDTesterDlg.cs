using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class CreateCRUDTesterDlg : System.Windows.Forms.Form
	{
		private EntityBuilder dcb;
		private CodeClass cls;
		//private StoredProcedureOptions options;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TextBox txtMethodName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtIterations;
		private System.Windows.Forms.CheckBox chkCreate;
		private System.Windows.Forms.CheckBox chkRead;
		private System.Windows.Forms.CheckBox chkUpdate;
		private System.Windows.Forms.CheckBox chkDelete;
		private System.Windows.Forms.CheckBox chkCreateInstaceEachItr;
		private System.Windows.Forms.CheckBox chkCreateDebugMessages;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CreateCRUDTesterDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CreateCRUDTesterDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtMethodName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtIterations = new System.Windows.Forms.TextBox();
			this.chkCreate = new System.Windows.Forms.CheckBox();
			this.chkRead = new System.Windows.Forms.CheckBox();
			this.chkUpdate = new System.Windows.Forms.CheckBox();
			this.chkDelete = new System.Windows.Forms.CheckBox();
			this.chkCreateInstaceEachItr = new System.Windows.Forms.CheckBox();
			this.chkCreateDebugMessages = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(208, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Select test method creation options.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(96, 240);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(176, 240);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtMethodName
			// 
			this.txtMethodName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMethodName.Location = new System.Drawing.Point(112, 72);
			this.txtMethodName.Name = "txtMethodName";
			this.txtMethodName.Size = new System.Drawing.Size(248, 20);
			this.txtMethodName.TabIndex = 7;
			this.txtMethodName.Text = "TestCRUDOperations";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 72);
			this.label1.Name = "label1";
			this.label1.TabIndex = 8;
			this.label1.Text = "Method Name:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 96);
			this.label3.Name = "label3";
			this.label3.TabIndex = 10;
			this.label3.Text = "Iterations:";
			// 
			// txtIterations
			// 
			this.txtIterations.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtIterations.Location = new System.Drawing.Point(112, 96);
			this.txtIterations.MaxLength = 6;
			this.txtIterations.Name = "txtIterations";
			this.txtIterations.Size = new System.Drawing.Size(64, 20);
			this.txtIterations.TabIndex = 9;
			this.txtIterations.Text = "1";
			// 
			// chkCreate
			// 
			this.chkCreate.Checked = true;
			this.chkCreate.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkCreate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreate.Location = new System.Drawing.Point(248, 128);
			this.chkCreate.Name = "chkCreate";
			this.chkCreate.TabIndex = 11;
			this.chkCreate.Text = "Create   (Insert)";
			// 
			// chkRead
			// 
			this.chkRead.Checked = true;
			this.chkRead.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkRead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkRead.Location = new System.Drawing.Point(248, 152);
			this.chkRead.Name = "chkRead";
			this.chkRead.TabIndex = 12;
			this.chkRead.Text = "Read  (Load)";
			// 
			// chkUpdate
			// 
			this.chkUpdate.Checked = true;
			this.chkUpdate.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkUpdate.Location = new System.Drawing.Point(248, 176);
			this.chkUpdate.Name = "chkUpdate";
			this.chkUpdate.TabIndex = 13;
			this.chkUpdate.Text = "Update";
			// 
			// chkDelete
			// 
			this.chkDelete.Checked = true;
			this.chkDelete.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkDelete.Location = new System.Drawing.Point(248, 200);
			this.chkDelete.Name = "chkDelete";
			this.chkDelete.TabIndex = 14;
			this.chkDelete.Text = "Delete";
			// 
			// chkCreateInstaceEachItr
			// 
			this.chkCreateInstaceEachItr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateInstaceEachItr.Location = new System.Drawing.Point(16, 128);
			this.chkCreateInstaceEachItr.Name = "chkCreateInstaceEachItr";
			this.chkCreateInstaceEachItr.Size = new System.Drawing.Size(200, 24);
			this.chkCreateInstaceEachItr.TabIndex = 15;
			this.chkCreateInstaceEachItr.Text = "Create instance for each iteration";
			// 
			// chkCreateDebugMessages
			// 
			this.chkCreateDebugMessages.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateDebugMessages.Location = new System.Drawing.Point(16, 152);
			this.chkCreateDebugMessages.Name = "chkCreateDebugMessages";
			this.chkCreateDebugMessages.Size = new System.Drawing.Size(200, 24);
			this.chkCreateDebugMessages.TabIndex = 16;
			this.chkCreateDebugMessages.Text = "Create debug messages";
			// 
			// CreateCRUDTesterDlg
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(370, 271);
			this.Controls.Add(this.chkCreateDebugMessages);
			this.Controls.Add(this.chkCreateInstaceEachItr);
			this.Controls.Add(this.chkDelete);
			this.Controls.Add(this.chkUpdate);
			this.Controls.Add(this.chkRead);
			this.Controls.Add(this.chkCreate);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtIterations);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtMethodName);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CreateCRUDTesterDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Test Method Creator for CRUD Operations ";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.CreateCRUDTesterDlg_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool CreateCRUDTester(EntityBuilder dcb)
		{
			CreateCRUDTesterDlg cct = new CreateCRUDTesterDlg();
			cct.dcb = dcb;
			cct.cls = dcb.Class;
			if (cct.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				CodeFunction func = cls.AddFunction(txtMethodName.Text, EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,    // "static void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
                func.IsShared = true;

				func.Comment = "Use this function to test CRUD operations on this class";

				EditPoint ep = func.StartPoint.CreateEditPoint();

				ep.LineUp(1);
				ep.EndOfLine();
				ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

				ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(3);
				ep.StartOfLine();
				if (!chkCreateInstaceEachItr.Checked)
					ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", cls.Name));
				ep.Insert(String.Format("\t\t\tfor (int i = 0; i < {0}; i++)\r\n", txtIterations.Text));
				ep.Insert(String.Format("\t\t\t{0}\r\n", "{"));
				if (chkCreateInstaceEachItr.Checked)
					ep.Insert(String.Format("\t\t\t\t{0} obj = new {0}();  // Use appropriate constructor\r\n", cls.Name));
				if (chkCreate.Checked)
				{
					ep.Insert(String.Format("\t\t\t\tobj.NewRecord();\r\n"));
					ep.Insert(String.Format("\t\t\t\t// Do other initializations on the object;\r\n"));
					ep.Insert(String.Format("\t\t\t\tobj.Save();\r\n"));
					if (chkCreateDebugMessages.Checked)
						ep.Insert(String.Format("\t\t\t\tDebug.WriteLine(\"Saved {0} PK=\"+obj.PKString);\r\n", cls.Name));
				}
				if (chkRead.Checked)
				{
					ep.Insert(String.Format("\t\t\t\tDebug.Assert(obj.Load(), \"Load failed for {0} PK=\"+obj.PKString);\r\n", cls.Name));
					if (chkCreateDebugMessages.Checked)
						ep.Insert(String.Format("\t\t\t\tDebug.WriteLine(\"Loaded {0} PK=\"+obj.PKString);\r\n", cls.Name));
				}
				if (chkUpdate.Checked)
				{
					ep.Insert(String.Format("\t\t\t\t// do some change in the properties\r\n"));
					ep.Insert(String.Format("\t\t\t\tobj.Save();\r\n"));
					if (chkCreateDebugMessages.Checked)
						ep.Insert(String.Format("\t\t\t\tDebug.WriteLine(\"Updated {0} PK=\"+obj.PKString);\r\n", cls.Name));
				}
				if (chkDelete.Checked)
				{
					ep.Insert(String.Format("\t\t\t\tobj.MarkDel();  // Mark for deletion\r\n"));
					ep.Insert(String.Format("\t\t\t\tobj.Save();  // Delete it\r\n"));
					if (chkCreateDebugMessages.Checked)
						ep.Insert(String.Format("\t\t\t\tDebug.WriteLine(\"Deleted {0} PK=\"+obj.PKString);\r\n", cls.Name));
				}
				ep.Insert(String.Format("\t\t\t{0}\r\n", "}"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

				DialogResult = DialogResult.OK;
				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void CreateCRUDTesterDlg_Load(object sender, System.EventArgs e)
		{
			
		}

		private void rbFillIntoObjects_CheckedChanged(object sender, System.EventArgs e)
		{
			
		}

	}

}
