using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class WebFormCreator : System.Windows.Forms.Form
	{
		private Project dataProject;
		private Solution solution;

		private CodeClass Entity;
		private CodeClass pageClass;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbEntity;
		private System.Windows.Forms.ComboBox cbProject;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtPageName;
		private System.Windows.Forms.TextBox txtSummary;
		private System.Windows.Forms.ComboBox cbEntityRef;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.CheckBox chkLoadDataMethod;
		private System.Windows.Forms.CheckBox chkSaveDataMethod;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cbLanguageClass;
		private System.Windows.Forms.CheckBox chkUseInfragistics;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox cbBasePageClass;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public WebFormCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WebFormCreator));
			this.label1 = new System.Windows.Forms.Label();
			this.cbEntity = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cbProject = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtPageName = new System.Windows.Forms.TextBox();
			this.txtSummary = new System.Windows.Forms.TextBox();
			this.cbEntityRef = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.chkLoadDataMethod = new System.Windows.Forms.CheckBox();
			this.chkSaveDataMethod = new System.Windows.Forms.CheckBox();
			this.label6 = new System.Windows.Forms.Label();
			this.cbLanguageClass = new System.Windows.Forms.ComboBox();
			this.chkUseInfragistics = new System.Windows.Forms.CheckBox();
			this.cbBasePageClass = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 104);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Entity Class:";
			// 
			// cbEntity
			// 
			this.cbEntity.Location = new System.Drawing.Point(136, 104);
			this.cbEntity.Name = "cbEntity";
			this.cbEntity.Size = new System.Drawing.Size(288, 21);
			this.cbEntity.TabIndex = 2;
			this.cbEntity.SelectedIndexChanged += new System.EventHandler(this.cbTables_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(152, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(280, 88);
			this.label2.TabIndex = 3;
			this.label2.Text = "Create a web form for the given Entity Class.  The web form will use the NetsoftUSA" +
				".WebForms and NetsoftUSA.Model libraries and derive from BasePage.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 368);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 368);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Target Web Project:";
			// 
			// cbProject
			// 
			this.cbProject.Location = new System.Drawing.Point(136, 128);
			this.cbProject.Name = "cbProject";
			this.cbProject.Size = new System.Drawing.Size(288, 21);
			this.cbProject.TabIndex = 2;
			this.cbProject.SelectedIndexChanged += new System.EventHandler(this.cbProject_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 152);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(112, 23);
			this.label4.TabIndex = 10;
			this.label4.Text = "Page Name:";
			// 
			// txtPageName
			// 
			this.txtPageName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPageName.Location = new System.Drawing.Point(136, 152);
			this.txtPageName.Name = "txtPageName";
			this.txtPageName.Size = new System.Drawing.Size(288, 20);
			this.txtPageName.TabIndex = 13;
			this.txtPageName.Text = "";
			this.txtPageName.TextChanged += new System.EventHandler(this.txtPageName_TextChanged);
			// 
			// txtSummary
			// 
			this.txtSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtSummary.Location = new System.Drawing.Point(16, 304);
			this.txtSummary.Multiline = true;
			this.txtSummary.Name = "txtSummary";
			this.txtSummary.ReadOnly = true;
			this.txtSummary.Size = new System.Drawing.Size(408, 56);
			this.txtSummary.TabIndex = 14;
			this.txtSummary.Text = "";
			// 
			// cbEntityRef
			// 
			this.cbEntityRef.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbEntityRef.Items.AddRange(new object[] {
																"Only this Entity Class",
																"All classes in the data layer"});
			this.cbEntityRef.Location = new System.Drawing.Point(136, 176);
			this.cbEntityRef.Name = "cbEntityRef";
			this.cbEntityRef.Size = new System.Drawing.Size(288, 21);
			this.cbEntityRef.TabIndex = 15;
			this.cbEntityRef.SelectedIndexChanged += new System.EventHandler(this.cbEntityRef_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 176);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(136, 23);
			this.label5.TabIndex = 10;
			this.label5.Text = "This page is bindable to:";
			// 
			// chkLoadDataMethod
			// 
			this.chkLoadDataMethod.Checked = true;
			this.chkLoadDataMethod.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkLoadDataMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkLoadDataMethod.Location = new System.Drawing.Point(16, 256);
			this.chkLoadDataMethod.Name = "chkLoadDataMethod";
			this.chkLoadDataMethod.Size = new System.Drawing.Size(120, 24);
			this.chkLoadDataMethod.TabIndex = 16;
			this.chkLoadDataMethod.Text = "LoadData Method";
			// 
			// chkSaveDataMethod
			// 
			this.chkSaveDataMethod.Checked = true;
			this.chkSaveDataMethod.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkSaveDataMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkSaveDataMethod.Location = new System.Drawing.Point(136, 256);
			this.chkSaveDataMethod.Name = "chkSaveDataMethod";
			this.chkSaveDataMethod.Size = new System.Drawing.Size(120, 24);
			this.chkSaveDataMethod.TabIndex = 16;
			this.chkSaveDataMethod.Text = "SaveData Method";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 200);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(112, 23);
			this.label6.TabIndex = 0;
			this.label6.Text = "Language Class:";
			// 
			// cbLanguageClass
			// 
			this.cbLanguageClass.Location = new System.Drawing.Point(136, 200);
			this.cbLanguageClass.Name = "cbLanguageClass";
			this.cbLanguageClass.Size = new System.Drawing.Size(288, 21);
			this.cbLanguageClass.TabIndex = 2;
			this.cbLanguageClass.SelectedIndexChanged += new System.EventHandler(this.cbLanguageClass_SelectedIndexChanged);
			// 
			// chkUseInfragistics
			// 
			this.chkUseInfragistics.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkUseInfragistics.Location = new System.Drawing.Point(16, 280);
			this.chkUseInfragistics.Name = "chkUseInfragistics";
			this.chkUseInfragistics.Size = new System.Drawing.Size(280, 24);
			this.chkUseInfragistics.TabIndex = 17;
			this.chkUseInfragistics.Text = "Use Netsoft Wrappers for Infragistics Controls";
			this.chkUseInfragistics.CheckedChanged += new System.EventHandler(this.chkUseInfragistics_CheckedChanged);
			// 
			// cbBasePageClass
			// 
			this.cbBasePageClass.Location = new System.Drawing.Point(136, 224);
			this.cbBasePageClass.Name = "cbBasePageClass";
			this.cbBasePageClass.Size = new System.Drawing.Size(288, 21);
			this.cbBasePageClass.TabIndex = 18;
			this.cbBasePageClass.SelectedIndexChanged += new System.EventHandler(this.cbBasePageClass_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(16, 224);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(112, 23);
			this.label7.TabIndex = 19;
			this.label7.Text = "Base Page Class:";
			// 
			// WebFormCreator
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(434, 399);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.cbBasePageClass);
			this.Controls.Add(this.chkUseInfragistics);
			this.Controls.Add(this.chkLoadDataMethod);
			this.Controls.Add(this.cbEntityRef);
			this.Controls.Add(this.txtSummary);
			this.Controls.Add(this.txtPageName);
			this.Controls.Add(this.cbProject);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbEntity);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.chkSaveDataMethod);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.cbLanguageClass);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "WebFormCreator";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Web Form Creator";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static CodeClass CreateWebForm(Project dataProject, string EntityName)
		{
			WebFormCreator wfc = new WebFormCreator();
			wfc.dataProject = dataProject;
			wfc.cbEntity.Text = EntityName;
			if (wfc.ShowDialog() == DialogResult.OK)
			{		
				return wfc.pageClass;
			}
			return null;
		}

		private void EnableButtons()
		{
			butCreate.Enabled = (cbEntity.Text != "")
				&& (cbProject.Text != "")
				&& (txtPageName.Text != "")
				&& (cbBasePageClass.Text != "");
		}

		private void FillLanguageClasses()
		{
			// lang classes in the web proj
			Project webProject = Util.FindProjectInSolution(solution, cbProject.Text);
			object[] classes = Util.FindClassesWithBaseInProject(webProject, "Language");
			Util.FillClassNames(cbLanguageClass, classes, true, true);

			// append lang classes in the data proj
			classes = Util.FindClassesWithBaseInProject(dataProject, "Language");
			Util.FillClassNames(cbLanguageClass, classes, false, true);
		}

		private void FillBasePageClasses()
		{
			// lang classes in the web proj
			Project webProject = Util.FindProjectInSolution(solution, cbProject.Text);
			object[] classes = Util.FindClassesWithBaseInProject(webProject, "BasePage");
			cbBasePageClass.Items.Clear();
			cbBasePageClass.Items.Add("NetsoftUSA.WebForms.BasePage");
			cbBasePageClass.Items.Add("NetsoftUSA.InfragisticsWeb.BasePage");
			Util.FillClassNames(cbBasePageClass, classes, false, false);
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				SaveSettings();
				Project webProject = Util.FindProjectInSolution(solution, cbProject.Text);
				if (webProject == null)
				{
					Connect.Instance.ShowDialog(this, String.Format("Can't find target project {0}!", cbProject.Text));
					return;
				}

				Entity = Util.FindClassInProject(dataProject, cbEntity.Text);
				if (Entity == null)
				{
					Connect.Instance.ShowDialog(this,
						String.Format("Can't find Entity Class {0} in project {1}", 
						cbEntity.Text,
						dataProject.Name));
					return;
				}

				CodeClass langClass = null;
				if (cbLanguageClass.Text != "")
				{
					langClass = Util.FindClassInProject(cbLanguageClass.Text);
					if (langClass == null)
					{
						Connect.Instance.ShowDialog(this,
							String.Format("Can't find language class {0} in project {1}", 
							cbLanguageClass.Text,
							dataProject.Name));
						return;
					}
				}

				string pageName = txtPageName.Text;
			
				pageClass = Connect.Instance.AddWebForm(webProject, pageName, Entity, cbEntityRef.SelectedIndex == 1, chkUseInfragistics.Checked, cbBasePageClass.Text);
				if (pageClass != null)
				{
					if (chkLoadDataMethod.Checked || chkLoadDataMethod.Checked)
					{
						// create private object declaration for this type
						CodeVariable var = pageClass.AddVariable("data", 
							Entity.Name,
							0,
							EnvDTE.vsCMAccess.vsCMAccessPrivate,
							null);

						// create a public accessor for the data
						CodeProperty prop = pageClass.AddProperty(
							Entity.Name, 
							Entity.Name, 
							Entity.Name, 
							-1, EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);

						prop.Comment = "Gets/Sets the Entity Object for the page.  When set, it also caches the object and updates the controls";
						EditPoint ep = null;
						ep = prop.Getter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);
						ep.Insert(String.Format("\t\t\t\treturn data;"));
						ep = prop.Getter.StartPoint.CreateEditPoint();
						Util.MergeFollowingLine(ep, 3);

						ep = prop.Setter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						ep.Insert("\t\t\t\tdata = value;\r\n");
						ep.Insert("\t\t\t\ttry\r\n");
						ep.Insert("\t\t\t\t{\r\n");
						ep.Insert("\t\t\t\t\tthis.UpdateFromObject(this.Controls, data);  // update controls for the given control collection\r\n");
						ep.Insert("\t\t\t\t// other object-to-control methods if any\r\n");
						ep.Insert("\t\t\t\t}\r\n");
						ep.Insert("\t\t\t\tcatch(Exception ex)\r\n");
						ep.Insert("\t\t\t\t{\r\n");
						ep.Insert("\t\t\t\t\tthis.RaisePageException(ex);  // notify the page about the error\r\n");
						ep.Insert("\t\t\t\t}\r\n");
						ep.Insert(String.Format("\t\t\t\tthis.CacheObject(typeof({0}), data);  // cache object using the caching method declared on the page\r\n", Entity.Name));

						// Add ReadControls method
						CodeFunction func = pageClass.AddFunction("ReadControls", 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						func.Comment = "Reads control values into the Entity Object and validates them.  Returns false if there's any problem";
						ep = func.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);

						ep.Insert("\t\t\ttry\r\n");
						ep.Insert("\t\t\t{\t//customize this method for this specific page\r\n");
						ep.Insert("\t\t\t\tthis.UpdateToObject(this.Controls, data);	// controls-to-object\r\n");
						ep.Insert("\t\t\t\t// other object-to-control methods if any\r\n");
						//ep.Insert("\t\t\t\tthis.Validate();	// Validation called after data is saved into object\r\n");
						ep.Insert("\t\t\t\treturn this.IsValid;	// Return validation result\r\n");
						ep.Insert("\t\t\t}\r\n");
						ep.Insert("\t\t\tcatch(Exception ex)\r\n");
						ep.Insert("\t\t\t{\r\n");
						ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
						ep.Insert("\t\t\t\treturn false;\r\n");
						ep.Insert("\t\t\t}");
					}

					if (chkLoadDataMethod.Checked)
					{
						string pkMember = Util.GetPKMemberForClass(Entity);
						CodeVariable varPK = Util.FindFirstMember(Entity, pkMember) as CodeVariable;
						if (varPK == null)
						{
							//Connect.Instance.ShowDialog(this, "Field for PK Member not defined in the class.  Ignoring.");
						}
						string tableName = Util.GetTableMappingForClass(Entity);
						string pkCol = Util.GetColMappingForMember(Entity, pkMember);

						DataTable tbl = null;
						try
						{
							DataSet ds = Util.ExecuteDataset(tableName,
								CommandType.Text, 
								"SELECT TOP 1 [" + pkCol + 
								"] FROM [" + tableName + "]");
							tbl = ds.Tables[0];
						}
						catch(Exception)
						{
							//Connect.Instance.ShowDialog(this, ex.Message + "\r\nIgnoring.");
						}

						CodeFunction func = pageClass.AddFunction("LoadData", 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method from Page_Load or anytime you want to load data";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\tbool result = true;\r\n");
							ep.Insert(String.Format("\t\t\t{0} data = new {0}();\r\n", Entity.Name));
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\t// use any load method here\r\n");
							if (tbl != null && tbl.Rows.Count > 0)
							{
								object pkVal = tbl.Rows[0][0];		// already single column
								string spkVal = null;
								if (pkVal is string)
									spkVal = "\"" + (string)pkVal + "\"";
								else
									spkVal = Convert.ToString(pkVal);
								ep.Insert(String.Format("\t\t\t\tresult = data.Load({0});\r\n", spkVal));
							}
							else
								ep.Insert("\t\t\t\tresult = data.Load();\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
							ep.Insert("\t\t\t\tresult = false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tfinally\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\t//data.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert(String.Format("\t\t\tthis.{0} = data;\r\n", Entity.Name));
							ep.Insert("\t\t\treturn result;");
						}

						if (func != null)		// insert LoadData(); statement in the Page_Load
						{
							func = Util.FindFirstMember(pageClass, "Page_Load") as CodeFunction;
							if (func != null)
							{
								EditPoint ep = func.EndPoint.CreateEditPoint();
								ep.LineUp(1);
								ep.EndOfLine();
							
								ep.Insert("\r\n");
								ep.Insert("\t\t\tif (!this.IsPostBack)\r\n");
								ep.Insert("\t\t\t\tthis.LoadData();\r\n");
								ep.Insert("\t\t\telse\r\n");
								ep.Insert(String.Format("\t\t\t\tdata = ({0})this.LoadObject(typeof({0}));\r\n", Entity.Name));
							}
						}
					}

					if (chkSaveDataMethod.Checked)
					{
						CodeFunction func = pageClass.AddFunction("SaveData", 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method when you want to retrieve data from controls and save them to table.";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\t// data from controls to object\r\n");
							ep.Insert("\t\t\t\tif (!this.ReadControls())\r\n");
							ep.Insert("\t\t\t\t\treturn false;\r\n");
							ep.Insert("\t\t\t\tdata.Save(); // update or insert to db \r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);\r\n");
							ep.Insert("\t\t\t\treturn false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\treturn true;");
						}

					}

					Util.DeclareMainEntityAttrib(pageClass, Entity);
					if (langClass != null)
					{
						Util.DeclareMainLanguageClassAttrib(pageClass, langClass);
					}

				}
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		
			//DialogResult = DialogResult.OK;
			//Close();
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			cbEntityRef.SelectedIndex = 0;
			solution = Connect.Instance.applicationObject.Solution;

			// fill all Entity Classes in the data layer project
			cbEntity.Items.Clear();
			object[] classes = Util.FindEntityesInProject(dataProject);
			for (int i = 0; i < classes.Length; i++)
			{
				cbEntity.Items.Add(((CodeClass)classes[i]).Name);
			}

			// fill all projects
			cbProject.Items.Clear();
			for (int i = 1; i <= solution.Projects.Count; i ++)
			{
				cbProject.Items.Add(solution.Projects.Item(i).Name);
			}

			if (cbProject.Text == "")
				cbProject.Text = Connect.Instance.CurrentProject.Name;

			SetPageName();
			LoadSettings();
			SetSummary();

			txtPageName.Focus();

			FillBasePageClasses();

			string basePageClass = (string)Util.GetSetting("__WebFormCreator", "BasePageClass", "NetsoftUSA.WebForms.BasePage");
			int found = cbBasePageClass.FindStringExact(basePageClass);
			cbBasePageClass.SelectedIndex = found;

			EnableButtons();
		}

		private void LoadSettings()
		{
			cbProject.Text = (string)Util.GetSetting(@"__WebFormCreator\Projects", dataProject.FullName, cbProject.Text);
			chkUseInfragistics.Checked = Util.GetSetting(@"__WebFormCreator", "UseInfragistics", false);
		}

		private void SaveSettings()
		{
			Util.SetSetting(@"__WebFormCreator\Projects", dataProject.FullName, cbProject.Text);
			Util.SetSetting(@"__WebFormCreator", "UseInfragistics", chkUseInfragistics.Checked);
			Util.SetSetting(@"__WebFormCreator", "BasePageClass", cbBasePageClass.Text);
		}

		private void SetPageName()
		{
			txtPageName.Text = Util.NormalizeClassName(cbEntity.Text) + "Form";
		}

		private void SetSummary()
		{
			txtSummary.Text = String.Format("{0}.aspx and {0}.aspx.cs will be create in "
				+ "the project {1} when you click 'Create'.", txtPageName.Text, cbProject.Text);
		}

		private void cbTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetPageName();
			SetSummary();
			EnableButtons();
		}

		private void txtPageName_TextChanged(object sender, System.EventArgs e)
		{
			SetSummary();
		}

		private void cbProject_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			FillLanguageClasses();
			FillBasePageClasses();
			SetSummary();
			EnableButtons();
		}

		private void cbEntityRef_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbLanguageClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void chkUseInfragistics_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkUseInfragistics.Checked)
			{
				if (cbBasePageClass.Text == "NetsoftUSA.WebForms.BasePage")
					cbBasePageClass.Text = "NetsoftUSA.InfragisticsWeb.BasePage";
			}
			else
			{
				if (cbBasePageClass.Text == "NetsoftUSA.InfragisticsWeb.BasePage")
					cbBasePageClass.Text = "NetsoftUSA.WebForms.BasePage";
			}
		}

		private void cbBasePageClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

	}
}
