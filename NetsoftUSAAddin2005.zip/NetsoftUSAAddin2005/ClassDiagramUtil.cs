using System;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text;
using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using System.ComponentModel.Design;
using EnvDTE;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.EnterpriseTools.Shell;
using Microsoft.VisualStudio.EnterpriseTools.ArtifactModel.Clr;
using Microsoft.VisualStudio.EnterpriseTools.ClassDesigner.PresentationModel;

namespace NetsoftUSAAddin2005
{
    public static class ClassDiagramUtil
    {

        /// <summary>
        /// Given the code element, and fullName show the class in class diagram.
        /// </summary>
        /// <param name="codeElement"></param>
        /// <param name="typeFullName"></param>
        public static void ShowTypeInDiagram(CodeElement codeElement, string typeFullName)
        {
            Debug.Assert(codeElement != null);
            if (typeFullName == null)
                typeFullName = codeElement.FullName;

            IViewInClassDiagram viewClassDiagram = Connect.Instance.ServiceProvider.GetService(typeof(IViewInClassDiagram)) as IViewInClassDiagram;
            Debug.Assert(viewClassDiagram != null);

            IVsSolution solution = Connect.Instance.ServiceProvider.GetService(typeof(IVsSolution)) as IVsSolution;
            Debug.Assert(solution != null);

            if (viewClassDiagram != null && solution != null)
            {
                IVsHierarchy hierarchy = null;
                ErrorHandler.ThrowOnFailure(solution.GetProjectOfUniqueName(
                    codeElement.ProjectItem.ContainingProject.UniqueName, out hierarchy));
                Debug.Assert(hierarchy != null);

                if (hierarchy != null)
                {
                    TypeNameInfo[] typeNames = new TypeNameInfo[] { new TypeNameInfo(typeFullName) };
                    viewClassDiagram.ViewTypesInDiagram(hierarchy, typeNames);
                }
            }
        }

        /// <summary>
        /// Get the selection service
        /// </summary>
        /// <returns></returns>
        public static IMonitorSelectionService SelectionService
        {
            get { return Connect.Instance.ServiceProvider.GetService(typeof(IMonitorSelectionService)) as IMonitorSelectionService; }
        }

        /// <summary>
        /// Get the current diagram document view
        /// </summary>
        public static DiagramDocView CurrentDiagramDocument
        {
            get 
            {
                IMonitorSelectionService svc = SelectionService;
                if (svc == null)
                    return null;
                return svc.CurrentDocumentView as DiagramDocView; 
            }
        }


        /// <summary>
        /// Gets the document data from the selection
        /// </summary>
        public static ModelingDocData CurrentDiagramDocumentData
        {
            get 
            {
                DiagramDocView docView = CurrentDiagramDocument;
                if (docView == null)
                    return null;

                return docView.DocData as ModelingDocData; 
            }
        }

        /// <summary>
        /// Gets the store from the selection
        /// </summary>
        public static Store CurrentDiagramDocumentDataStore
        {
            get 
            {
                ModelingDocData docData = CurrentDiagramDocumentData;
                if (docData == null)
                    return null;
                return docData.Store;
            }
        }

        /// <summary>
        /// Gets the current desinger view of the class diagram.
        /// </summary>
        public static VSDiagramView CurrentDiagramDesigner
        {
            get
            {
                DiagramDocView docView = CurrentDiagramDocument;
                if (docView == null)
                    return null;
                return docView.CurrentDesigner;
            }
        }

        public static DiagramClientView CurrentDiagramClientDesigner
        {
            get
            {
                VSDiagramView dview = CurrentDiagramDesigner;
                if (dview == null)
                    return null;
                return dview.DiagramClientView;
            }
        }

        public static Diagram CurrentDiagram
        {
            get
            {
                DiagramDocView docView = CurrentDiagramDocument;
                if (docView == null)
                    return null;
                return docView.CurrentDiagram;
            }
        }

        public static ClassDiagram CurrentClassDiagram
        {
            get
            {
                return CurrentDiagram as ClassDiagram;
            }
        }

        /// <summary>
        /// Get the currently selected shapes in the diagram.
        /// </summary>
        public static SelectedShapesCollection CurrentDiagramSelectedShapes
        {
            get
            {
                VSDiagramView des = CurrentDiagramDesigner;
                if (des == null)
                    return null;
                return des.Selection;
            }
        }

        /// <summary>
        /// Get the top level diaram items of the selected shape.
        /// </summary>
        public static DiagramItemCollection CurrentDiagramSelectedShapeTopItems
        {
            get
            { 
                SelectedShapesCollection selShapes = CurrentDiagramSelectedShapes;
                if (selShapes == null)
                    return null;
                return CurrentDiagramSelectedShapes.TopLevelItems;
            }
        }

        /// <summary>
        /// Get the primary item in the current diagram selection.
        /// </summary>
        public static DiagramItem CurrentDiagramSelectedPrimaryItem
        {
            get
            {
                SelectedShapesCollection shapes = CurrentDiagramSelectedShapes;
                if (shapes == null)
                    return null;
                return shapes.PrimaryItem;
            }
        }

        /// <summary>
        /// Select the fields of the shape that match the given name.
        /// </summary>
        /// <param name="item"></param>
        /// <param name="name"></param>
        public static void SelectSubFieldRepresentedElements(DiagramDocView docView, DiagramItem item, string name)
        {
            Debug.Assert(item != null);
            if (item == null) return;

            ClrTypeShape typeShape = item.Shape as ClrTypeShape;
            Debug.Assert(typeShape != null);
            if (typeShape == null) return;

            foreach (ShapeElement child in typeShape.NestedChildShapes)
            {
                CDCompartment compartment = child as CDCompartment;
                if (compartment != null)
                {
                    for (int i = 0; i < compartment.ListField.GetItemCount(compartment); i++)
                    {
                        ICollection rmels = compartment.GetSubFieldRepresentedElements(compartment.ListField, new ListItemSubField(i));
                        foreach (Member member in rmels)
                        {
                            if (member.Name == name)
                            {
                                docView.CurrentDesigner.Selection.Set(
                                    new DiagramItem(
                                        compartment,
                                        compartment.ListField,
                                        new ListItemSubField(i)));
                                return;
                            }
                        }
                    }
                }
            }
            return;
        }

        public static object FindFirstSelection(Type t)
        {
            return FindFirstSelection(null, t);
        }

        public static object FindFirstSelection(IList selectionObjects, Type t)
        {
            if (selectionObjects == null)
                selectionObjects = CurrentDiagramSelectedShapes.TopLevelItems as IList;
            if (selectionObjects == null)
                return null;
            for (int i = 0; i < selectionObjects.Count; i++)
            {
                object obj = selectionObjects[i];
                DiagramItem di = obj as DiagramItem;
                if (di != null)
                    obj = di.Shape;
                if ( t.IsInstanceOfType(obj) )
                    return obj;
            }
            return null;
        }

        /// <summary>
        /// Invokes in-place editing on the given shape.
        /// </summary>
        /// <param name="shape">Shape to edit.</param>
        public static void InPlaceEdit(ShapeElement shape)
        {
            if (shape == null) throw new ArgumentNullException("shape");

            DiagramClientView diagramClientView = CurrentDiagramClientDesigner;
            Debug.Assert(diagramClientView != null);
            if (diagramClientView != null)
            {
                foreach (ShapeField field in shape.ShapeFields)
                {
                    if (field.CanEditValue(shape, diagramClientView))
                    {
                        // this is the name edit field - do in-place edit now!
                        field.EditValue(shape, diagramClientView);
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// Finds a shape for specified type on the diagram.
        /// </summary>
        /// <param name="type">Type to find a shape for.</param>
        /// <returns>Type shape or null if not found.</returns>
        public static ClrTypeShape FindTypeOnDiagram(ClrType type)
        {
            if (type == null) throw new ArgumentNullException("type");

            ClassDiagram diagram = CurrentClassDiagram;
            foreach (ShapeElement shape in diagram.NestedChildShapes)
            {
                ClrTypeShape typeShape = shape as ClrTypeShape;
                if (typeShape != null && typeShape.AssociatedType == type)
                {
                    return typeShape;
                }
            }
            return null;
        }

        /// <summary>
        /// Finds visible member item in specified type shape.
        /// </summary>
        /// <param name="typeShape">Type shape to search.</param>
        /// <param name="member">Member to search for.</param>
        /// <returns>DiagramItem representing the member or null if not found.</returns>
        public static DiagramItem FindMemberItem(ShapeElement typeShape, Member member)
        {
            if (typeShape == null) throw new ArgumentNullException("typeShape");
            if (member == null) throw new ArgumentNullException("member");

            foreach (ShapeElement child in typeShape.NestedChildShapes)
            {
                CDCompartment compartment = child as CDCompartment;
                if (compartment != null)
                {
                    for (int i = 0; i < compartment.ListField.GetItemCount(compartment); i++)
                    {
                        ICollection rmels = compartment.GetSubFieldRepresentedElements(compartment.ListField, new ListItemSubField(i));
                        foreach (Member rmember in rmels)
                        {
                            if (rmember == member)
                            {
                                return new DiagramItem(compartment, compartment.ListField, new ListItemSubField(i));
                            }
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Enumerates all selected types shapes if there's at least one
        /// type shape selected or all type shapes on the diagram if diagram is selected.
        /// </summary>
        public static IEnumerable<ClrTypeShape> EnumerateSelectedTypes()
        {
            object sel = FindFirstSelection(typeof(ClassDiagram));
            if (sel != null)
            {
                ClassDiagram diagram = CurrentClassDiagram;
                foreach (ShapeElement shape in diagram.NestedChildShapes)
                {
                    ClrTypeShape typeShape = shape as ClrTypeShape;
                    if (typeShape != null)
                        yield return typeShape;
                }
            }
            else
            {
                DiagramItemCollection selectedObjects = CurrentDiagramSelectedShapeTopItems;
                foreach (object component in selectedObjects)
                {
                    ClrTypeShape typeShape = component as ClrTypeShape;
                    if (typeShape != null)
                        yield return typeShape;
                }
            }
        }

        /// <summary>
        /// Add derived type for the currently selected type.
        /// </summary>
        public static void AddDerivedType()
        {
            AddDerivedType(null);
        }

        /// <summary>
        /// Add derived type for the given base type shape.
        /// </summary>
        /// <param name="baseTypeShape"></param>
        public static void AddDerivedType(ClrTypeShape baseTypeShape)
        {
            string transactionName = "AddDerivedType";
            
            ClassDiagram diagram = CurrentClassDiagram;

            if (baseTypeShape == null)
                baseTypeShape = FindFirstSelection(typeof(ClrTypeShape)) as ClrTypeShape;

            if (baseTypeShape == null)
                return;

            ClrType baseType = baseTypeShape.AssociatedType as ClrType;
            Debug.Assert(baseType != null && baseType.Parent != null);

            if (baseType != null && baseType.Parent != null)
            {
                ClrTypeShape derivedTypeShape = null;
                ClrType derivedType = null;

                Store store = CurrentDiagramDocumentDataStore;
                using (Transaction t = store.TransactionManager.BeginTransaction(transactionName))
                {
                    // Create derived type.
                    AttributeAssignment[] assignments = new AttributeAssignment[] {
						new AttributeAssignment(
							ClrElement.NameMetaAttributeGuid,
							baseType.Parent.GetUniqueChildName(ClrClass.MetaClassGuid, baseType.Name),
							store)
					};
                    derivedType = store.ElementFactory.CreateElement(typeof(ClrClass), assignments) as ClrType;
                    derivedType.Parent = baseType.Parent;
                    derivedType.AddBaseType(baseType);

                    
                    // Create and place the shape on diagram.
                    int cnt = 0;
                    double y = baseTypeShape.AbsoluteBounds.Bottom;
                    while (y > 0)
                    {
                        y -= diagram.GridSize;
                        cnt++;
                    }
                    y = (cnt + 2) * diagram.GridSize;
                    PointD location = new PointD(baseTypeShape.Location.X, y);
                    derivedTypeShape = diagram.AddTypeOnDiagram(derivedType, location);
                    derivedTypeShape.IsExpanded = true; // since this is a new shape, it should be expanded

                    t.Commit();
                }

                // Generate abstract class and interface stubs as needed.
                Debug.Assert(derivedType != null);
                if (derivedType != null)
                {
                    ClrClass baseClass = baseType as ClrClass;
                    if (baseClass != null && baseClass.InheritanceModifier == TypeInheritanceModifier.Abstract)
                    {
                        using (Transaction t = store.TransactionManager.BeginTransaction("Implement Abstract Class"))
                        {
                            baseType.Language.GenerateAbstractBaseStubs(derivedType);
                            t.Commit();
                        }
                    }
                }

                // Let the user to change derived type name.
                Debug.Assert(derivedTypeShape != null);
                if (derivedTypeShape != null)
                {
                    InPlaceEdit(derivedTypeShape);
                }
            }
        }

        public static void ShowMemberTypes()
        {
            ClassDiagram diagram = CurrentClassDiagram;
            DiagramItemCollection items = CurrentDiagramSelectedShapeTopItems;

            List<ShapeElement> newShapes = new List<ShapeElement>();

            foreach (object di in items)
            {
                Member member = di as Member;
                if (member != null && member.MemberType != null)
                {
                    ClrTypeShape typeShape = FindTypeOnDiagram(member.MemberType);
                    if (typeShape == null)
                    {
                        PointD location = PointD.Empty;
                        ClrTypeShape parentType = FindTypeOnDiagram(member.ClrType);
                        Debug.Assert(parentType != null);
                        if (parentType != null)
                        {
                            location = new PointD(
                                parentType.AbsoluteBounds.Right + diagram.GridSize,
                                parentType.Location.Y);
                        }
                        typeShape = diagram.AddTypeOnDiagram(member.MemberType, location);
                    }
                    if (typeShape != null)
                    {
                        newShapes.Add(typeShape);
                    }
                }
            }
            if (newShapes.Count > 0)
            {
                SelectAndShowShapes(newShapes);
            }
        }

        /// <summary>
        /// Makes given shapes selected and visible to the user.
        /// </summary>
        /// <param name="shapes">Shapes to select and ensure visible.</param>
        public static void SelectAndShowShapes(ICollection<ShapeElement> shapes)
        {
            if (shapes == null) throw new ArgumentNullException("shapes");
            if (shapes.Count > 0)
            {
                DiagramClientView diagramClientView = CurrentDiagramClientDesigner;
                Debug.Assert(diagramClientView != null);
                if (diagramClientView != null)
                {
                    RectangleD? bounds = null;
                    DiagramItemCollection diagramItems = new DiagramItemCollection();
                    foreach (ShapeElement shape in shapes)
                    {
                        Debug.Assert(shape != null);
                        if (shape != null)
                        {
                            diagramItems.Add(new DiagramItem(shape));
                            if (bounds.HasValue)
                                bounds = RectangleD.Union(shape.AbsoluteBoundingBox, bounds.Value);
                            else
                                bounds = shape.AbsoluteBoundingBox;
                        }
                    }
                    if (diagramItems.Count > 0)
                    {
                        diagramClientView.Selection.Set(diagramItems);
                        if (bounds.HasValue)
                        {
                            diagramClientView.EnsureVisible(bounds.Value);
                        }
                    }
                }
            }
        }

    }
}
