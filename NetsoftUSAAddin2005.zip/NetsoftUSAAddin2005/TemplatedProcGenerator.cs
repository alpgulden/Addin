
using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;


namespace NetsoftUSAAddin2005
{
	public enum EnumStatementType
	{
		Free = 0,
		Select = 1,
		Update = 2,
		Insert = 3,
		Delete = 4
	}

	public class SPGenerationInjections
	{
		public string InjectPreOperation;
		public string InjectPostOperation;
		public string InjectWhere;
		public string InjectParameters;
		public string InjectOrderBy;
	}

	/// <summary>
	/// Summary description for TemplatedProcGenerator.
	/// </summary>
	public class TemplatedProcGenerator
	{
		//public static Hashtable templateMap;

		// sample macro:   @COLUMNSFOR[2-3]@    @TABLENAMEFOR[1]@  @PARAMDECLFOR[ALL]@
		protected const string MacroMatchRegex = @"@(?<term>[0-9a-zA-Z\-_.:~,\[\]]+)@";

		private CodeClass cls;		// class to work on
		bool insertPK = false;
		private string tableName;
		private DataTable tbl;		// table prototype
		private StoredProcTemplate spTpl;
		private Hashtable templateMap;		// all other templates can be given, so that nested templates could be run
		private string spName;
		private string argsExp;
		private string[] args;
		private SPGenerationInjections injections;
		private string[] mappedMembers;
		private string[] pkMembers;
		private string[] nonPKMembers;
		private Hashtable pkMembersMap;
		private string[] selectableMembers;
		private string[] updatableMembers;
		private string[] insertableMembers;
		private ArrayList terms;
		private int startTerm = 0;		// from the start
		private int endTerm = -1;		// to the end

		private int argsStart = 1;		// the @ARGSSTART@ macro defines at wich arg number the args start.
										// all args are accessible by number
										// but this determines what args the @ARGS@ macro and the like will return

		private ArrayList arrReferredArgs;

		private string errorString = null;
		private bool parseError = false;		// true, if there's any parse error
		private bool generationError = false;		// true, if there's any generation error

		public TemplatedProcGenerator(CodeClass cls, Hashtable templateMap, StoredProcTemplate spTpl, string spName, string argsExp, SPGenerationInjections injections, ArrayList arrReferredArgs)
		{
			this.injections = injections;
			if (arrReferredArgs != null)
				this.arrReferredArgs = arrReferredArgs;
			else
				this.arrReferredArgs = new ArrayList();
			this.cls = cls;
			this.insertPK = Util.GetInsertPKForClass(cls);
			this.templateMap = templateMap;
			this.tableName = Util.GetTableMappingForClass(cls, true);
			this.spTpl = spTpl;
			this.spName = spName;
			this.argsExp = argsExp;

			if (argsExp == null || argsExp == "")
				args = new string[0];
			else
				args = Util.SplitString(argsExp, new char[] { ',' }, new char[] { ' ' });

			mappedMembers = Util.GetColMapMembers(cls, true, false);
		}

		public SPGenerationInjections Injections
		{
			get 
			{
				return this.injections;
			}
		}

		public int ArgsStart
		{
			get { return this.argsStart; }
			set { this.argsStart = value; }
		}

		public void AddUsedArg(object argnum)
		{
			arrReferredArgs.Add(argnum);
		}

		public ArrayList Terms	// parsed terms can be directly given
		{
			get { return this.terms; }
			set { this.terms = value; }
		}

		public void SetParsedTermsAndRange(ArrayList terms, int startTerm, int endTerm)
		{
			this.terms = terms;
			this.startTerm = startTerm;
			this.endTerm = endTerm;
		}

		public static string GetArgsUsedString(ArrayList arrReferredArgs)
		{
			Hashtable ht = new Hashtable();
			for (int i = 0; i < arrReferredArgs.Count; i++)
				ht[arrReferredArgs[i]] = arrReferredArgs[i];
			object[] args = new object[ht.Count];
			int j = 0;
			foreach (DictionaryEntry de in ht)
			{
				args[j] = de.Key;
				j++;
			}

			Array.Sort(args);

			string[] sargs = new string[args.Length];
			
			for (int i = 0; i < sargs.Length; i++)
				sargs[i] = Convert.ToString( args[i] );

			return Util.JoinStrings(", ", sargs, "[{0}]");
		}

		private void FindPKMembers()
		{
			if (pkMembersMap != null)
				return;

			pkMembers = Util.GetPKMembersForClass(cls);
			pkMembersMap = new Hashtable();
			for (int i = 0; i < pkMembers.Length; i++)
			{
				string pkField = pkMembers[i];
				pkMembersMap[pkField] = Util.FindFirstMember(cls, pkField);
			}
		}

		private bool IsPK(string memberName)
		{
			FindPKMembers();
			if (pkMembersMap.ContainsKey(memberName))
				return true;
			else
				return false;
		}

		public bool ParseError
		{
			get
			{
				return this.parseError;
			}
		}

		public bool GenerationError
		{
			get
			{
				return this.generationError;
			}
		}

		public string[] Errors
		{
			get
			{
				if (!this.generationError && !this.parseError)
					return null;

				ArrayList errs = new ArrayList();
				for (int i = 0; i < terms.Count; i++)
				{
					SPMacro macro = terms[i] as SPMacro;
					if (macro != null)
					{
						if (macro.parseError != null)
							errs.Add(macro.ParseError);
						else
						{
							if (macro.generationError != null)
								errs.Add(macro.GenerationError);
						}
					}
				}

				return (string[])errs.ToArray(typeof(string));
			}
		}

		public string ErrorString
		{
			get
			{
				if (this.errorString == null)
				{
					string[] errs = this.Errors;
					if (errs != null)
						this.errorString = String.Join("\r\n", errs);
				}
				return this.errorString;
			}
		}

		public CodeClass Class
		{
			get { return cls; }
		}

		public string[] Args
		{
			get
			{
				return this.args;
			}
		}

		public string TableName
		{
			get
			{
				return tableName;
			}
		}

		public string[] PKMembers
		{
			get
			{
				FindPKMembers();
				return this.pkMembers;
			}
		}

		public string[] NonPKMembers
		{
			get
			{
				if (nonPKMembers == null)
				{
					ArrayList arr = new ArrayList();
					for (int i = 0; i < mappedMembers.Length; i++)
						if (!IsPK(mappedMembers[i]))
							arr.Add(mappedMembers[i]);

					nonPKMembers = (string[])arr.ToArray(typeof(string));
				}
				return nonPKMembers;
			}
		}

		public string[] MappedMembers
		{
			get
			{
				return mappedMembers;
			}
		}

		public string[] InjectedParameters
		{
			get
			{
				string[] arr = Util.SplitString(this.injections.InjectParameters, new char[] { ',' }, new char[] { ' ' } );
				if (arr != null)
				{
					for (int i = 0; i < arr.Length; i++)
					{
						arr[i] = String.Format("'" + arr[i] + "'");
					}
				}
				return arr;
			}
		}

		// if logic is true members of given type are returned, if logic is false others returned
		public string[] GetMappedMembersOfType(object type, bool logic)
		{
			return GetMembersOfType(cls, mappedMembers, type, logic);
		}

		// if logic is true members of given type are returned, if logic is false others returned
		public static string[] GetMembersOfType(CodeClass cls, string[] members, object type, bool logic)
		{
			ArrayList arr = new ArrayList();
			for (int i = 0; i < members.Length; i++)
			{
				if (type is string)
				{
					string stype = (string)type;
					if ((Util.GetMemberType(cls, members[i] ).AsFullName == stype) == logic)
						arr.Add(members[i]);
				}
				else
				{
					vsCMTypeRef typref = (vsCMTypeRef)type;
					if ((Util.GetMemberType(cls, members[i] ).TypeKind == typref) == logic)
						arr.Add(members[i]);
				}
			}

			return (string[])arr.ToArray(typeof(string));
		}

		public CodeClass FindClass(string className)
		{
			return Util.FindClassInProject(cls.ProjectItem.ContainingProject, className);
		}

		public string[] SelectableMembers
		{
			get
			{
				if (selectableMembers == null)
					selectableMembers = GetMembersBySQLGenFlags(EnumStatementType.Select);
				return selectableMembers;
			}
		}

		public string[] InsertableMembers
		{
			get
			{
				if (insertableMembers == null)
					insertableMembers = GetMembersBySQLGenFlags(EnumStatementType.Insert);
				return insertableMembers;
			}
		}

		public string[] UpdatableMembers
		{
			get
			{
				if (updatableMembers == null)
					updatableMembers = GetMembersBySQLGenFlags(EnumStatementType.Update);
				return updatableMembers;
			}
		}

		public string[] PKColumns
		{
			get
			{
				return GetColMappingsForMembers(this.PKMembers);
			}
		}

		private bool IsMemberUsedForStatementType(CodeVariable var, EnumStatementType statementType)
		{
			// check SQLGenerationFlags and see this column is to be skipped for
			// the given type of statement

			CodeAttribute colMapAtt = Util.GetColMappingAtt(var);
			if (colMapAtt == null)
				return false;		// no mapping

			string sqlGenFlagsExp = Util.GetParamFromAttrib(colMapAtt, "SQLGen", 3);
			ArrayList sqlGenFlags = Util.ParseFlags(sqlGenFlagsExp, true);
				
			switch (statementType)
			{
				case EnumStatementType.Select:
					if (Util.FindStringInArray(sqlGenFlags, "NoSelect") >= 0)
						return false;
					break;
				case EnumStatementType.Insert:
					if (!this.insertPK)
					{
						// if this is pk, then don't use in insert
						if (IsPK(var.Name))
							return false;
					}
					if (Util.HasJoinRelation(colMapAtt))
						return false;
					if (Util.FindStringInArray(sqlGenFlags, "NoInsert") >= 0)
						return false;
					if (Util.FindStringInArray(sqlGenFlags, "NoInsertUpdate") >= 0)
						return false;
					break;
				case EnumStatementType.Update:
					if (IsPK(var.Name))
						return false;
					if (Util.HasJoinRelation(colMapAtt))
						return false;
					if (Util.FindStringInArray(sqlGenFlags, "NoUpdate") >= 0)
						return false;
					if (Util.FindStringInArray(sqlGenFlags, "NoInsertUpdate") >= 0)
						return false;
					break;
			}

			return true;	// use it
		}

		public string[] GetMembersBySQLGenFlags(EnumStatementType statementType)
		{
			ArrayList arr = new ArrayList();

			for (int i = 0; i < mappedMembers.Length; i++)
			{
				string member = (string)mappedMembers[i];
				CodeVariable var = Util.FindFirstMember(cls, member) as CodeVariable;
				if (var != null)
				{
					if (IsMemberUsedForStatementType(var, statementType))
						arr.Add(var.Name);
				}
			}
			return (string[])arr.ToArray(typeof(string));
		}

		public string[] JoinedMembers
		{
			get
			{
				ArrayList arr = new ArrayList();

				for (int i = 0; i < mappedMembers.Length; i++)
				{
					string member = (string)mappedMembers[i];
					CodeVariable var = Util.FindFirstMember(cls, member) as CodeVariable;
					if (var != null)
					{
						CodeAttribute att = Util.GetColMappingAtt(var);
						if (Util.HasJoinRelation(att))
							arr.Add(var.Name);
					}
				}
				return (string[])arr.ToArray(typeof(string));
			}
		}

		public bool GetDataColumnOrExpressionForMember(string memberName, EnumStatementType statementType, ref DataColumn col, ref string expression)
		{
			string colName = GetColMappingForMember(memberName);
			if (colName == null)
				return false;

			col = tbl.Columns[colName];
			string fullColumnName = String.Format("[{0}].[{1}]", tbl.TableName, colName);
			if (statementType != EnumStatementType.Free)
			{
				CodeVariable var = Util.FindFirstMember(cls, memberName) as CodeVariable;
				CodeAttribute colMapAtt = Util.GetColMappingAtt(var);
				if (colMapAtt == null)
					return false;		// no mapping

				if (!IsMemberUsedForStatementType(var, statementType))
				{
					col = null;
					return true;	// no error, just skip the column
				}

				// Check SQL injection attributes for this specific type of statement
				switch (statementType)
				{
					case EnumStatementType.Select:
					{
						string injectSelect = Util.GetParamFromAttrib(colMapAtt, "InjectSelect", -1);
						if (injectSelect != null && injectSelect != "")
						{
							expression = String.Format(injectSelect, fullColumnName, memberName);
							return true;	// return with the injected expression
						}
						break;
					}
					case EnumStatementType.Update:
					{
						string injectUpdate = Util.GetParamFromAttrib(colMapAtt, "InjectUpdate", -1);
						if (injectUpdate != null && injectUpdate != "")
						{
							expression = String.Format(injectUpdate, fullColumnName, memberName);
							return true;	// return with the injected expression
						}
						break;
					}
					case EnumStatementType.Insert:
					{
						string injectInsert = Util.GetParamFromAttrib(colMapAtt, "InjectInsert", -1);
						if (injectInsert != null && injectInsert != "")
						{
							expression = String.Format(injectInsert, fullColumnName, memberName);
							return true;	// return with the injected expression
						}
						break;
					}

				}

			}

			// if column not found, return with error
			if (col == null)
				return false;
			else
				return true;
			
		}

		public string GetInjectSearchForMember(string memberName)
		{
			CodeVariable var = Util.FindFirstMember(cls, memberName) as CodeVariable;
			CodeAttribute colMapAtt = Util.GetColMappingAtt(var);
			if (colMapAtt == null)
				return null;
			return Util.GetParamFromAttrib(colMapAtt, "InjectSearch", -1);
		}

		public DataColumn GetDataColumnForMember(string memberName)
		{
			string colName = GetColMappingForMember(memberName);
			if (colName == null)
				return null;
			return tbl.Columns[colName];
		}

		public DataColumn GetDataColumn(string colName)
		{
			return tbl.Columns[colName];
		}

		public string[] GetColMappingsForMembers(string[] memberNames)
		{
			return Util.GetColMappingsForMembers(cls, memberNames);
		}

		public string GetColMappingForMember(string memberName)
		{
			return Util.GetColMappingForMember(cls, memberName);
		}

		public string SPName
		{
			get
			{
				return this.spName;
			}
		}

		public DataTable Table
		{
			get
			{
				return this.tbl;
			}
		}

		public override string ToString()
		{
			if (this.terms == null)
				terms = Parse();

			//Debug.WriteLine(terms.Count);
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < terms.Count; i++)
			{
				sb.Append(String.Format("[{0}]: {1}\r\n", i, terms[i]));
			}
			return sb.ToString();
		}

		public string GenerateSP()
		{
			try
			{
				tbl = Util.GetTablePrototype(this.tableName);
			}
			catch(Exception ex)
			{
				this.errorString = "error accessing table [" + this.tableName + "]\r\n" + ex.Message;
				this.generationError = true;
				return null;
			}

			if (this.terms == null)
				terms = Parse();
			//Debug.WriteLine(terms.Count);
			StringBuilder sb = new StringBuilder();
			for (int i = this.startTerm; i < (this.endTerm < 0 ? terms.Count : this.endTerm); i++)
			{
				SPMacro macro = terms[i] as SPMacro;
				if (macro != null)
				{
					if (macro.macro == "REPEAT")
					{
						// expect static text
						if (i + 1 >= terms.Count || !(terms[i + 1] is string))
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						string repBlock = (string)terms[i + 1];
						// expect DELIMIT
						if (i + 2 >= terms.Count)
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						SPMacro macroDelimit = terms[i + 2] as SPMacro;
						if (macroDelimit == null || macroDelimit.macro != "DELIMIT")
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						if (i + 3 >= terms.Count || !(terms[i + 3] is string))
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						string delimBlock = (string)terms[i + 3];
						// expect ENDREPEAT
						if (i + 4 >= terms.Count)
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						SPMacro macroEndrepeat = terms[i + 4] as SPMacro;
						if (macroEndrepeat == null || macroEndrepeat.macro != "ENDREPEAT")
						{
							macro.generationError = "invalid REPEAT-DELIMIT-ENDREPEAT block";
							this.generationError = true;
							continue;
						}
						macro.repeatBlock = repBlock;
						macro.macroDelimit = macroDelimit;
						macro.delimBlock = delimBlock;
						macro.macroEndrepeat = macroEndrepeat;
						i += 4;	// skip 4 terms
					}
					else if (macro.macro == "SWITCH")
					{
						string substitutedMacroArgs = macro.GenArgSubstitutes(false);
						string defaultText = null;
						// check for default static text between @SWITCH[arg]@ and @CASE[x]@
						if (i + 1 < terms.Count && terms[i + 1] is string)	// a default static text is provided
						{
							defaultText = (string)terms[i + 1];
							i++;
						}

						// find the correct CASE
						bool switchEnded = false;
						bool caseFound = false;
						for (int j = i + 1; j < terms.Count; j++)
						{
							// expect CASE
							SPMacro macroCase = terms[j] as SPMacro;
							if (macroCase == null)
							{
								macro.generationError = "invalid SWITCH-CASE-ENDSWITCH block";
								this.generationError = true;
								continue;
							}

							if (macroCase.macro == "ENDSWITCH")
							{
								i = j; // + 1;
								switchEnded = true;
								break;	// finished
							}

							if (macroCase.macro != "CASE")
							{
								macro.generationError = "invalid SWITCH-CASE-ENDSWITCH block";
								this.generationError = true;
								continue;
							}

							// expect static text
							if (j + 1 >= terms.Count || !(terms[j + 1] is string))
							{
								macro.generationError = "invalid SWITCH-CASE-ENDSWITCH block";
								this.generationError = true;
								continue;
							}

							string caseText = (string)terms[j + 1];
							j++;		// the next static items used
							// check case condition
							if (substitutedMacroArgs == macroCase.macroarg)
							{
								// the switch's substituted arguments match the exact value of case
								// render this
								macro.switchedBlock = caseText;
								caseFound = true;
								continue;		// just continue until ENDSWITCH
							}
							// 
						}

						if (!switchEnded)
						{
							i = terms.Count;		// deliberately end the switch block
							if (macro.generationError == null)	// if there's not already an error
								macro.generationError = "ENDSWITCH expected";
							this.generationError = true;
						}

						if (!caseFound)
						{
							// use default text if specified
							if (defaultText != null)
								macro.switchedBlock = defaultText;
						}
						// end of SWITCH macro check
					}

					// generate macro's expression
					// if the macro has a subject class, then generate in that class' context
					if (macro.subjectClass != null)
					{
						TemplatedProcGenerator generator = new TemplatedProcGenerator(macro.subjectClass, templateMap, this.spTpl, this.spName, this.argsExp, macro.ParentGenerator.Injections, arrReferredArgs);
						generator.argsStart = this.argsStart;		// let the sub-generator use the same argsstart

						macro.subjectClassName = null;
						macro.subjectClass = null;		// nullify these to prevent recursion
						generator.SetParsedTermsAndRange(this.terms, i, i + 1);
						macro.ParentGenerator = generator;
						string result = generator.GenerateSP();
						if (generator.ParseError || generator.GenerationError)
						{
							macro.generationError = generator.ErrorString;
						}
						sb.Append(result);
					}
					else
						sb.Append(macro.GenerateSPExpression());
					if (macro.generationError != null)
						this.generationError = true;
				}
				else
					sb.Append(terms[i]);
			}
			return sb.ToString();
		}

		//
		private ArrayList Parse()
		{
			Regex regex = new Regex( MacroMatchRegex , 
				RegexOptions.Compiled);
			Match match;
			string expression = spTpl.sproc;
			ArrayList list = new ArrayList();
			int lastpos = 0;
			int ipos = 0;
			string stat = null;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string term = match.Groups["term"].Value;
				ipos = match.Groups["term"].Index - 1;
				int ilen = term.Length;
				if (ilen > 0)
				{
					stat = expression.Substring(lastpos, ipos - lastpos);
					if (stat.Length > 0)
						list.Add(stat);	// add chars before

					SPMacro macro = new SPMacro(this, term);
					if (macro.parseError != null)
						parseError = true;
					list.Add(macro);	// add item name
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			stat = expression.Substring(lastpos, ipos - lastpos); //add chars after
			if (stat.Length > 0)
				list.Add(stat);

			return list;
		}

		public bool RunNestedTemplate(SPMacro macro, ref string result)
		{
			if (templateMap == null)
			{
				// error!  the templates can't be accessed.
				macro.generationError = "can't find other templates!";
				return false;
			}

			// look for a template with the macro's name; like @SelectByPK.sptpl@
			StoredProcTemplate tpl = templateMap[macro.macro] as StoredProcTemplate;
			if (tpl == null)		// the template was not found.
				return false;

			string args = null;
			if (macro.argDefined)
				args = macro.GenArgSubstitutes();	// pass the macro processed arguments to the nested-template. things like 1-2, MAPPED etc can be used
			else
				args = this.argsExp;		// no [] definition in the macro, pass the args of this template to the nested-template
			TemplatedProcGenerator generator = new TemplatedProcGenerator(cls, templateMap, tpl, this.spName, args, macro.ParentGenerator.Injections, arrReferredArgs);

			result = generator.GenerateSP();
			if (generator.ParseError || generator.GenerationError)
			{
				macro.generationError = "Nested template " + macro.macro + " has errors:\r\n" +
					generator.ErrorString;
			}

			return true;
		}

	}

	public class SPMacro
	{
		private TemplatedProcGenerator gen = null;
		public string parseError;		// set to an error message if there's any parse error
		public string generationError;	// set when GenerateSPExpression method is called and there's an error
		public string expression;
		
		// parsed terms
		public string macro;			// actual macro name like TABLENAME, COLUMNS, PARAMDECL
		public string subjectClassName; // subject class name
		public CodeClass subjectClass;	// subject class
		public string aliasForTheTableName;	// an alias may have been specified to be used with the table
		public string macroarg;		// full macro arguement
		public bool argDefined;		// [ defined or not
		public ArrayList macroargs;		// macro args parsed into an array
		public ArrayList macroargsExcluded;	// to be excluded

		// these terms are passed in the generation phase
		public string repeatBlock;
		public SPMacro macroDelimit;
		public string delimBlock;
		public SPMacro macroEndrepeat;
		
		public string switchedBlock;		// the block that's selected by switch to be rendered

		public SPMacro(TemplatedProcGenerator gen, string expression)
		{
			this.gen = gen;
			this.expression = expression;
			Parse();
		}

		public TemplatedProcGenerator ParentGenerator
		{
			get { return this.gen; }
			set { this.gen = value; }
		}

		public string ParseError
		{
			get
			{
				return String.Format("Parse error in {0}: {1}", this.macro, this.parseError);
			}
		}

		public string GenerationError
		{
			get
			{
				return String.Format("Generation error in {0}: {1}", this.macro, this.generationError);
			}
		}

		private void ParseMacroAndSubjectClass(string expression)
		{
			int argnum = 0;
			this.subjectClass = null;
			this.subjectClassName = null;
			int index = expression.IndexOf(':');	// parse  SubjectClassName:MACRO  pair
			if (index < 0)
			{
				this.macro = expression;
				return;	
			}

			// a subject class is given, that class will be used for this macro term
			this.subjectClassName = expression.Substring(0, index);
			this.macro = expression.Substring(index + 1);

			if (this.subjectClassName != null)
			{
				// check if an alias was specified
				index = this.subjectClassName.IndexOf(',');
				if (index >= 0)		//  an alias was specified after ,
				{
					this.aliasForTheTableName = subjectClassName.Substring(index + 1);
					this.subjectClassName = subjectClassName.Substring(0, index);
					if (this.aliasForTheTableName.Length == 0)
					{
						this.parseError = "an empty alias was specified";
						this.aliasForTheTableName = null;
					}
					else
					{
						// an alias was specified, substitute it if an argument number was specified
						argnum = 0;
						try
						{
							argnum = int.Parse(this.aliasForTheTableName);
							if (argnum == 0)
							{
								this.parseError = "invalid arg number 0 specified for alias";
								this.aliasForTheTableName = null;
							}
						}
						catch
						{
							// a direct alias
						}
						if (argnum > 0)
						{
							// a valid argument number specified:  @,1:COLUMNNAMES@   ->  1 is the arg number to be used for alias
							gen.AddUsedArg(argnum);
							int iarg = argnum - 1;
							if (iarg >= 0 && iarg < gen.Args.Length)
								this.aliasForTheTableName = gen.Args[argnum - 1];
							else
							{
								// invalid argument index
								this.parseError = String.Format("invalid arg number {0} specified for alias", argnum);
								this.aliasForTheTableName = null;
							}
						}

					}
				}
			}

			if (this.subjectClassName.Length == 0)
			{
				this.subjectClassName = null;
				return;
			}
			// ignore this:  may be used like @,alias:COLUMNAMES@
			/*if (this.subjectClassName == null || this.subjectClassName == "")
			{	
				this.parseError = "subject class name must precede ':'";
				this.subjectClassName = null;
				return;
			}*/

			// a classname was specified, it is either direct name or an arg
			// substitute subjectClassName if a valid argument number was specified.
			argnum = 0;
			try
			{
				argnum = int.Parse(this.subjectClassName);
				if (argnum == 0)
				{
					this.parseError = "invalid arg number 0";
					this.subjectClassName = null;
					return;
				}
			}
			catch
			{
				// a direct class name
			}
			if (argnum > 0)
			{
				// a valid argument number specified:  1:COLUMNNAMES   ->  1 is the arg number to be used for class name
				gen.AddUsedArg(argnum);
				int iarg = argnum - 1;
				if (iarg >= 0 && iarg < gen.Args.Length)
					this.subjectClassName = gen.Args[argnum - 1];
				else
				{
					// invalid argument index
					this.parseError = String.Format("invalid arg number {0}", argnum);
					this.subjectClassName = null;
					return;
				}
			}

			if (this.subjectClassName == gen.Class.Name)
			{
				// if this is the same class, just skip this
				this.subjectClassName = null;
				return;
			}
			this.subjectClass = gen.FindClass(this.subjectClassName);
			if (this.subjectClass == null)
			{
				this.parseError = String.Format("subject class '{0}' not found!", this.subjectClassName);
				this.subjectClassName = null;
				return;
			}
			// subject class found
		}

		private void Parse()
		{
			// parse macro arguments
			int ibropen = expression.IndexOf('[');
			int ibrclose = expression.IndexOf(']');
			if (ibropen < 0)
			{
				if (ibrclose >= 0)
					this.parseError = "[ expected before ]";
				ParseMacroAndSubjectClass(expression);
				argDefined = false;
				return;
			}
			argDefined = true;
			// there's [, expect ]
			if (ibrclose < 0)
			{
				this.parseError = "] expected after [";
				ibrclose = 0;	// all
			}
			if (ibrclose != 0 && ibrclose < ibropen)
			{
				this.parseError = "] expected after [";
				ibrclose = 0;	// all
			}
			ParseMacroAndSubjectClass( expression.Substring(0, ibropen) );
			if (ibropen + 1 < expression.Length)
			{
				if (ibrclose == 0)
					macroarg = expression.Substring(ibropen + 1);
				else
					macroarg = expression.Substring(ibropen + 1, ibrclose - ibropen - 1);
				macroarg = macroarg.Trim();
			}
			else
				macroarg = "";
			
			ParseArgs(macroarg, ref macroargs, ref macroargsExcluded);
		
			// end of parsing
		}

		public ArrayList ParseArgs(string macroarg, ref ArrayList macroArgs, ref ArrayList macroargsExcluded)
		{
			macroargs = null;
			macroargsExcluded = null;

			if (macroarg != "")
			{
				macroargs = new ArrayList();
				macroargsExcluded = new ArrayList();
				string[] macroargterms = macroarg.Split(',');		// split each term	 COLUMNS[1,2,3]
				for (int i = 0; i < macroargterms.Length; i++)
				{
					string macroargterm = macroargterms[i].Trim();
					bool excludedTerm = false;	// check if exclude operator is used ~    like   ~1-2,~MAPPED
					if (macroargterm.Length >= 1 && macroargterm[0] == '~')
					{
						excludedTerm = true;
						macroargterm = macroargterm.Substring(1);
					}
					string[] dashterms = macroargterm.Split('-');
					if (dashterms.Length > 1)
					{
						// a range of arg numbers like 1-4
						string start = dashterms[0].Trim();
						string end = dashterms[1].Trim();
						if (dashterms.Length > 2)
							this.parseError = "extra - in marco";
						int istart = 0;
						int iend = 0;
						try
						{
							istart = int.Parse(start);
							if (end == "")
								this.parseError = "arg range not specified fully";
							else
								iend = int.Parse(end);
						}
						catch
						{
							this.parseError = "invalid argument range";
						}
					
						if (istart > 0)
						{
							if (istart > iend)
							{
								this.parseError = "inverse range specification";
								// swap
								int tmp = istart;
								istart = iend;
								iend = tmp;
							}
							for (int argnum = istart; argnum <= iend; argnum++)
							{
								if (excludedTerm)
									macroargsExcluded.Add(argnum);
								else
									macroargs.Add(argnum);
								gen.AddUsedArg(argnum);
							}
						}

					}
					else
					{
						// single arg
						int argnum = 0;
						try
						{
							argnum = int.Parse(macroargterm);
							if (argnum == 0)
								this.parseError = "invalid arg number 0";
						}
						catch
						{
							// not a number, add it as is.  it could be something like ALL
							if (excludedTerm)
								macroargsExcluded.Add(macroargterm);
							else
								macroargs.Add(macroargterm);
						}
						if (argnum > 0)
						{
							// add arg number
							if (excludedTerm)
								macroargsExcluded.Add(argnum);
							else
								macroargs.Add(argnum);
							gen.AddUsedArg(argnum);
						}

					}

				}
				
			}	// end of macro arg parsing
			return macroargs;
		}

		public override string ToString()
		{
			string args = null;
			if (this.macroargs != null)
			{
				for (int i = 0; i < macroargs.Count; i++)
				{
					if (args != null)
						args += ",";
					args += this.macroargs[i];
				}
			}
			return String.Format("macro='{0}' args='{1}'   {2}\r\nexpression: {3}", this.macro, args, this.parseError, this.GenerateSPExpression());
		}

		private void ARGSSTARTmacro()
		{
			if (macroargs == null || macroargs.Count != 1)
			{
				this.generationError = "argument number required";
				return;
			}
			object val = macroargs[0];
			if (!(val is int))
			{
				this.generationError = "argument number required";
				return;
			}
			gen.ArgsStart = (int)val;
			if (gen.ArgsStart < 1)
			{
				this.generationError = "invalid argument start number specified";
				gen.ArgsStart = 1;
			}
		}

		public string GenerateSPExpression()
		{
			// each macro treats to the arguments differently
			switch (this.macro)
			{
				case "":		// use the args directly
					return GenArgSubstitutes();

				case "ARGSSTART":
					ARGSSTARTmacro();
					return null;
				case "PROCNAME":
					if (macroargs != null)
						this.generationError = "no argument required";
					return "dbo." + gen.SPName;
				case "TABLENAME":
					if (macroargs != null)
						this.generationError = "no argument required";
					return "[" + gen.TableName + "]";
				case "AUTOGENREMARK":
					return Util.spAutoGenRemark;

				case "NAMES":			// arg1, arg2	-- the raw args as is
					return GenRawNames();

				case "PARAMNAMES":			// @param1, @param2
					return GenParamDecls(true, false);
				case "PARAMDECLS":			// @param1 int, @param2 varchar(20)
					return GenParamDecls(true, true);
				case "PARAMTYPES":			// int, varchar(20)
					return GenParamDecls(false, true);
					
				case "VARDECLS":			// declare @arg3 int\r\ndeclare @arg4 char
					return GenVarDecls(true);
				case "VARNAMES":			// @arg3, @arg4
					return GenVarDecls(false);

				case "COLUMNNAMES":			// [column1], [column2]
					return GenColumnDecls(true, false, EnumStatementType.Free, false);
				case "COLUMNDECLS":			// [column1] int, [column2] varchar(20)
					return GenColumnDecls(true, true, EnumStatementType.Free, false);
				case "COLUMNTYPES":			// int, varchar(20)
					return GenColumnDecls(false, true, EnumStatementType.Free, false);

				case "SELECTCOLUMNS":			// [column1], [column2]
					return GenColumnDecls(true, false, EnumStatementType.Select, false);

				case "INSERTVALUES":			// @column1, @column2, getDate()
					return GenColumnDecls(true, false, EnumStatementType.Insert, true);

				case "UPDATEEXPRESSIONS":			// [column1], [column2]
					return GenColumnDecls(true, false, EnumStatementType.Update, true);

				// filtering
				case "ANDEQUALS":
					return GenColumnExpressions("=", " AND ", true, false);
				case "OREQUALS":
					return GenColumnExpressions("=", " OR ", true, false);

				case "ANDISNULL":
					return GenColumnExpressions(" IS NULL", " AND ", false, false);
				case "ORISNULL":
					return GenColumnExpressions(" IS NULL", " OR ", false, false);

				// generic search
				case "ANDSEARCHOPERATORS":
					return GenColumnExpressions("SEARCHOPERATOR", " AND ", true, false);
				case "ANDSEARCHOPERATORSOPTIONAL":
					return GenColumnExpressions("SEARCHOPERATOR", " AND ", true, true);
				case "ORSEARCHOPERATORS":
					return GenColumnExpressions("SEARCHOPERATOR", " OR ", true, false);
				case "ORSEARCHOPERATORSOPTIONAL":
					return GenColumnExpressions("SEARCHOPERATOR", " OR ", true, true);

				// like derivatives
				case "ANDCONTAINS":
					return GenColumnExpressions("CONTAINS", " AND ", true, false);
				case "ORCONTAINS":
					return GenColumnExpressions("CONTAINS", " OR ", true, false);

				case "ANDSTARTSWITH":
					return GenColumnExpressions("STARTSWITH", " AND ", true, false);
				case "ORSTARTSWITH":
					return GenColumnExpressions("STARTSWITH", " OR ", true, false);

				case "ANDENDSWITH":
					return GenColumnExpressions("ENDSWITH", " AND ", true, false);
				case "ORENDSWITH":
					return GenColumnExpressions("ENDSWITH", " OR ", true, false);

				// arithmetic
				case "ANDLESSTHAN":
					return GenColumnExpressions("<", " AND ", true, false);
				case "ORLESSTHAN":
					return GenColumnExpressions("<", " OR ", true, false);

				case "ANDGREATERTHAN":
					return GenColumnExpressions(">", " AND ", true, false);
				case "ORGREATERTHAN":
					return GenColumnExpressions(">", " OR ", true, false);

				case "ANDLESSTHANOREQUALS":
					return GenColumnExpressions("<=", " AND ", true, false);
				case "ORLESSTHANOREQUALS":
					return GenColumnExpressions("<=", " OR ", true, false);

				case "ANDGREATERTHANOREQUALS":
					return GenColumnExpressions(">=", " AND ", true, false);
				case "ORGREATERTHANOREQUALS":
					return GenColumnExpressions(">=", " OR ", true, false);

				case "COMMAEQUALS":
					return GenColumnExpressions("=", ", ", true, false);

				// optional filtering
				case "ANDEQUALSOPTIONAL":
					return GenColumnExpressions("=", " AND ", true, true);
				case "OREQUALSOPTIONAL":
					return GenColumnExpressions("=", " OR ", true, true);

				case "ANDISNULLOPTIONAL":
					return GenColumnExpressions(" IS NULL", " AND ", false, true);
				case "ORISNULLOPTIONAL":
					return GenColumnExpressions(" IS NULL", " OR ", false, true);

					// like derivatives
				case "ANDCONTAINSOPTIONAL":
					return GenColumnExpressions("CONTAINS", " AND ", true, true);
				case "ORCONTAINSOPTIONAL":
					return GenColumnExpressions("CONTAINS", " OR ", true, true);

				case "ANDSTARTSWITHOPTIONAL":
					return GenColumnExpressions("STARTSWITH", " AND ", true, true);
				case "ORSTARTSWITHOPTIONAL":
					return GenColumnExpressions("STARTSWITH", " OR ", true, true);

				case "ANDENDSWITHOPTIONAL":
					return GenColumnExpressions("ENDSWITH", " AND ", true, true);
				case "ORENDSWITHOPTIONAL":
					return GenColumnExpressions("ENDSWITH", " OR ", true, true);

				// arithmetic
				case "ANDLESSTHANOPTIONAL":
					return GenColumnExpressions("<", " AND ", true, true);
				case "ORLESSTHANOPTIONAL":
					return GenColumnExpressions("<", " OR ", true, true);

				case "ANDGREATERTHANOPTIONAL":
					return GenColumnExpressions(">", " AND ", true, true);
				case "ORGREATERTHANOPTIONAL":
					return GenColumnExpressions(">", " OR ", true, true);

				case "ANDLESSTHANOREQUALSOPTIONAL":
					return GenColumnExpressions("<=", " AND ", true, true);
				case "ORLESSTHANOREQUALSOPTIONAL":
					return GenColumnExpressions("<=", " OR ", true, true);

				case "ANDGREATERTHANOREQUALSOPTIONAL":
					return GenColumnExpressions(">=", " AND ", true, true);
				case "ORGREATERTHANOREQUALSOPTIONAL":
					return GenColumnExpressions(">=", " OR ", true, true);

				case "COMMAEQUALSOPTIONAL":
					return GenColumnExpressions("=", ", ", true, true);

					// block functions:
				case "REPEAT":				// repeat the following static section
					return GenRepeatBlocks();
				case "DELIMIT":				// delimit each one with the following static section
					this.generationError = "REPEAT must precede DELIMIT";
					return null;
				case "ENDREPEAT":			// end of repeat
					this.generationError = "REPEAT-DELIMIT must precede ENDREPEAT";
					return null;

				case "SWITCH":				// switch following static section according to the given arg's value:  @SWITCH[1]@  
					return GenSwitchBlock();
				case "CASE":				// check if the SWITCH arg equals CASE's macro argument
					this.generationError = "SWITCH must precede CASE";
					return null;
				case "ENDSWITCH":			// end of switch
					this.generationError = "SWITCH-CASE must precede ENDSWITCH";
					return null;

					// sql injection macros for sp generation
				case "INJECTPREOPERATION":
					return gen.Injections.InjectPreOperation;
				case "INJECTPOSTOPERATION":
					return gen.Injections.InjectPostOperation;
				case "INJECTWHERE":
					return gen.Injections.InjectWhere;
				case "INJECTORDERBY":
					return gen.Injections.InjectOrderBy;
				case "INJECTPARAMETERS":
					return gen.Injections.InjectParameters;

				default:
				{
					// check if this a nested template call!
					// the macro name can be used to refer to other templates.
					// if that's the case, the macro args are used to pass args to the template.
					string nestedMacroResult = null;
					if (gen.RunNestedTemplate(this, ref nestedMacroResult))
						return nestedMacroResult;
					else
					{
						this.generationError = "unknown macro";
						return null;
					}
				}
			}
		}

		private ArrayList GetArgsSubstituted()
		{
			ArrayList arrIncluded = GetArgsSubstituted(this.macroargs);
			if (this.macroargsExcluded != null && this.macroargsExcluded.Count > 0)
			{
				ArrayList arrExcluded = GetArgsSubstituted(this.macroargsExcluded);
				Hashtable tblExcluded = new Hashtable();
				for (int i = 0; i < arrExcluded.Count; i++)
					tblExcluded[arrExcluded[i]] = i;
				ArrayList arrSubtracted = new ArrayList();
				for (int i = 0; i < arrIncluded.Count; i++)
				{
					object o = arrIncluded[i];
					if (!tblExcluded.ContainsKey(o))
						arrSubtracted.Add(o);
				}
				return arrSubtracted;
			}
			else
				return arrIncluded;
		}

		private ArrayList GetArgsSubstituted(ArrayList argNums)
		{
			ArrayList argsSubs = new ArrayList();
			FillArgsSubstituted(argNums, argsSubs);
			return argsSubs;
		}

		private void FillArgsSubstituted(object type, bool logic, ArrayList args)
		{
			string[] filteredMembers = TemplatedProcGenerator.GetMembersOfType(gen.Class , gen.Args, type, logic);
			Util.AddRangeToArrayList(args, filteredMembers);
		}

		private void FillArgsSubstituted(ArrayList argNums, ArrayList args)
		{
			if (argNums == null)
			{
				// add all template args
				for (int i = gen.ArgsStart - 1; i < gen.Args.Length; i++)
				{
					args.Add( gen.Args[i] );
				}
			}
			else
			{
				// add the specified args only
				for (int i = 0; i < argNums.Count; i++)
				{
					object argnum = argNums[i];
					if (argnum is string)
					{
						string argns = (string)argnum;
						switch (argns)
						{
							case "":
							case "ARGS":
								FillArgsSubstituted(null, args);
								break;

							case "STRINGARGS":		// all string args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefString, true, args);
								break;
							case "NONSTRINGARGS":	// all non-string args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefString, false, args);
								break;
							case "INTARGS":			// all int args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefInt, true, args);
								break;
							case "NONINTARGS":		// all non-int args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefInt, false, args);
								break;
							case "BOOLARGS":		// all bool args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefBool, true, args);
								break;
							case "NONBOOLARGS":		// all non-bool args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefBool, false, args);
								break;
							case "FLOATARGS":		// all float args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefFloat, true, args);
								break;
							case "NONFLOATARGS":		// all non-float args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefFloat, false, args);
								break;
							case "DECIMALARGS":		// all decimal args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefDecimal, true, args);
								break;
							case "NONDECIMALARGS":		// all non-decimal args
								FillArgsSubstituted(vsCMTypeRef.vsCMTypeRefDecimal, false, args);
								break;
							case "DATEARGS":		// all decimal args
								FillArgsSubstituted("System.DateTime", true, args);
								break;
							case "NONDATEARGS":		// all non-decimal args
								FillArgsSubstituted("System.DateTime", false, args);
								break;

							case "PK":
								Util.AddRangeToArrayList(args, gen.PKMembers);
								break;
							case "NONPK":
								Util.AddRangeToArrayList(args, gen.NonPKMembers);
								break;
							case "MAPPED":		// all columns in the table
								Util.AddRangeToArrayList(args, gen.MappedMembers);
								break;
							case "INJECTED":		// all injected parameters
								Util.AddRangeToArrayList(args, gen.InjectedParameters);
								break;

							case "MAPPEDSTRINGS":		// all string columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefString, true));
								break;
							case "MAPPEDNONSTRINGS":		// all non-string columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefString, false));
								break;
							case "MAPPEDINTS":		// all int columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefInt, true));
								break;
							case "MAPPEDNONINTS":		// all non-int columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefInt, false));
								break;
							case "MAPPEDBOOLS":		// all bool columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefBool, true));
								break;
							case "MAPPEDNONBOOLS":		// all non-bool columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefBool, false));
								break;
							case "MAPPEDFLOATS":		// all float columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefFloat, true));
								break;
							case "MAPPEDNONFLOATS":		// all non-float columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefFloat, false));
								break;
							case "MAPPEDDECIMALS":		// all decimal columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefDecimal, true));
								break;
							case "MAPPEDNONDECIMALS":		// all non-decimal columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType(vsCMTypeRef.vsCMTypeRefDecimal, false));
								break;
							case "MAPPEDDATES":		// all decimal columns in the table
								args.AddRange(gen.GetMappedMembersOfType("System.DateTime", true));
								break;
							case "MAPPEDNONDATES":		// all non-decimal columns in the table
								Util.AddRangeToArrayList(args, gen.GetMappedMembersOfType("System.DateTime", false));
								break;

							case "SELECTABLES":
								Util.AddRangeToArrayList(args, gen.SelectableMembers);
								break;
							case "JOINED":
								Util.AddRangeToArrayList(args, gen.JoinedMembers);
								break;
							case "INSERTABLES":
								Util.AddRangeToArrayList(args, gen.InsertableMembers);
								break;
							case "UPDATABLES":
								Util.AddRangeToArrayList(args, gen.UpdatableMembers);
								break;
							default:
								args.Add(argns);
								break;
						}
					}
					else 
					{
						// int argnum
						int iarg = (int)argnum - 1;
						if (iarg >= 0 && iarg < gen.Args.Length)
							args.Add( gen.Args[iarg] );		// add the specified template argument
						// ignore otherwise
					}
				}
			}
					
		}

		public bool GetDataColumnOrExpressionForMember(string memberName, EnumStatementType statementType, ref DataColumn col, ref string expression)
		{
			bool res = gen.GetDataColumnOrExpressionForMember(memberName, statementType, ref col, ref expression);
			if (!res) 
				this.generationError = String.Format("column for member {0}.{1} not found in table", gen.Class.Name, memberName);
			return res;
		}

		public DataColumn GetDataColumnForMember(string memberName)
		{
			DataColumn col = gen.GetDataColumnForMember(memberName);
			if (col == null)
				this.generationError = String.Format("column for member {0}.{1} not found in table", gen.Class.Name, memberName);
			return col;
		}

		public DataColumn GetDataColumn(string colName)
		{
			DataColumn col = gen.GetDataColumn(colName);
			if (col == null)
				this.generationError = String.Format("column {0}.{1} not found in table", gen.Class.Name, colName);
			return col;
		}

		public string GetDBTypeForCol(DataColumn col)
		{
			string dbType = Util.GetDBTypeForDataColumn(col);
			if (dbType == null)
				return "varchar(255)";
			else
				return dbType;
		}

		public string GetDBTypeForMember(string memberName)
		{
			DataColumn col = GetDataColumn(memberName);
			return GetDBTypeForCol(col);
		}

		private static string MergeDecl(string term1, string term2, string delimiter)
		{
			if (term1 == null)
				return term2;
			if (term2 == null)
				return term1;
			return term1 + delimiter + term2;
		}

		private static string Merge(string s, string sadd, string delimiter)
		{
			if (s != null)
				s += delimiter;
			return s + sadd;
		}

		// ------ Actual generation functions

		public string GenArgSubstitutes(bool blankAfterComma)
		{
			ArrayList args = GetArgsSubstituted();
			string comma = blankAfterComma ? ", " : ",";
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injections = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injections);
				s = Merge(s, arg, comma);
			}
			return s;
		}

		public string GenArgSubstitutes()
		{
			return GenArgSubstitutes(true);
		}

		private string GenRawNames()
		{
			ArrayList args = GetArgsSubstituted();
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injection = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injection);
				s = Merge(s, arg, ", ");		// directly names
			}
			return s;
		}

		private string GenParamDecls(bool name, bool type)
		{
			ArrayList args = GetArgsSubstituted();
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string argDef = (string)args[i];
				string arg = null, baseMember = null, injection = null;
				ParseArgDef(argDef, ref arg, ref baseMember, ref injection);
				string sname = name ? "@" + arg : null;
				string stype = null;
				if (injection != null)		// if INJECTED was specified, the arg will go directly
				{
					s = Merge(s, injection, ", ");
				}
				else
				{
					stype = type ? GetDBTypeForMember(baseMember) : null;
					s = Merge(s, MergeDecl(sname, stype, " "), ", ");
				}
			}
			return s;
		}

		private string GenVarDecls(bool fulldecl)
		{
			ArrayList args = GetArgsSubstituted();
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injection = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injection);
				if (fulldecl)
				{
					if (injection != null)
						s = Merge(s, "declare @" + arg + " " + injection, "\r\n");
					else
						s = Merge(s, "declare @" + arg + " " + GetDBTypeForMember(baseMember), "\r\n");
				}
				else
					s = Merge(s, "@" + arg, ", ");
			}
			return s;
		}

		public static void ParseArgDef(string argDef, ref string arg, ref string baseMember, ref string injection)
		{
			arg = null;
			baseMember = null;
			if (argDef == null)
				return;
			if (argDef.Substring(0, 1) == "'")
			{
				injection = argDef.Trim('\'');
				return;
			}
			string[] terms = argDef.Split(':');
			arg = terms[0];
			if (terms.Length > 1)
				baseMember = terms[1];
			else
				baseMember = arg;
		}

		private string GenColumnDecls(bool name, bool type, EnumStatementType statementType, bool useParamNames)
		{
			string tableName = gen.TableName;
			if (this.aliasForTheTableName != null)
				tableName = this.aliasForTheTableName;
			ArrayList args = GetArgsSubstituted();
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injection = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injection);
				DataColumn col = null;
				string injectExpression = null;
				if (GetDataColumnOrExpressionForMember(baseMember, statementType, ref col, ref injectExpression))
				{
					string sterm = null;
					string colName = null;
					if (col != null)
						colName = useParamNames ? "@" + arg : "[" + tableName + "].[" + col.ColumnName + "]";
					if (injectExpression != null)
					{
						// inject specified, use it
						sterm = injectExpression;
					}
					else
					{
						// no inject, use the column
						if (col != null)
						{
							string sname = name ? colName : null;
							string stype = type ? GetDBTypeForCol(col) : null;
							sterm = MergeDecl(sname, stype, " ");
						}
					}

					if (sterm != null)
					{
						if (statementType == EnumStatementType.Update)
						{
							// create set expressions
							if (col != null)
							{
								sterm = "[" + tableName + "].[" + col.ColumnName + "]" + " = " + sterm;
							}
						}
						s = Merge(s, sterm, ", ");
					}
				}
			}
			return s;
		}

		private string GenColumnExpressions(string oprtr, string delimiter, bool param, bool optional)
		{
			string tableName = gen.TableName;
			if (this.aliasForTheTableName != null)
				tableName = this.aliasForTheTableName;
			ArrayList args = GetArgsSubstituted();
			string s = null;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injection = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injection);
				DataColumn col = GetDataColumnForMember(baseMember);
				if (col != null)
				{
					string left = String.Format("[{0}].[{1}]", tableName, col.ColumnName);
					string exp = null;

					// try to get InjectSearch from the argument, if not found, get it from the base member
					string injectSearch = gen.GetInjectSearchForMember(arg);
					if (injectSearch == null)
					{
						injectSearch = gen.GetInjectSearchForMember(baseMember);
					}

					if (injectSearch != null)
					{
						// use injected clause instead of generating
						exp = String.Format(injectSearch, left, arg);	// use the injected search clause
						if (exp != null)
						{
							// put the expression in paranthesis if necessary
							if (exp.Length > 0)
								if (exp.Substring(0, 1) != "(")
									exp = String.Format("({0})", exp);
						}
					}
					else
					{
						// generate a search expression
						string op = oprtr;
						if (oprtr == "SEARCHOPERATOR")
						{
							// detect operator from data type
							if (col.DataType == typeof(string))
								op = "STARTSWITH";
							else
								op = "=";
						}

						switch (op)
						{
							case "CONTAINS":
								exp = left + " LIKE '%'+@" + arg + "+'%'";
								break;
							case "STARTSWITH":
								exp = left + " LIKE @" + arg + "+'%'";
								break;
							case "ENDSWITH":
								exp = left + " LIKE '%'+@" + arg;
								break;
							default:
								if (param)
								{
									if (col.DataType == typeof(DateTime))
										exp = String.Format("dbo.TruncDate({0}){1}@{2}", left, op, arg);
									else
										exp = left + op + "@" + arg;
								}
								else
									exp = left + op;
								break;
						}

					}

					if (optional)
						exp = String.Format("(@{0} is NULL OR {1})", arg, exp);
					s = Merge(s, exp, delimiter);
				}
			}
			return s;
		}

		private string GenRepeatBlocks()
		{
			ArrayList args = GetArgsSubstituted();
			string s = null;
			string tableName = gen.TableName;
			string tableOrAlias = gen.TableName;
			if (this.aliasForTheTableName != null)
				tableName = this.aliasForTheTableName;
			for (int i = 0; i < args.Count; i++)
			{
				string arg = null, baseMember = null, injection = null;
				ParseArgDef((string)args[i], ref arg, ref baseMember, ref injection);
				string dbType = GetDBTypeForMember(baseMember);
				DataColumn col = GetDataColumnForMember(baseMember);
				string colName = null;
				if (col != null)
					colName = col.ColumnName;		// raw column name
				string rep = null;
				try
				{
					rep = String.Format(this.repeatBlock, arg, colName, dbType, tableName, tableOrAlias);
				}
				catch(Exception ex)
				{
					this.generationError = ex.Message;
				}
				string delim = null;
				try
				{
					delim = String.Format(this.delimBlock, arg, colName, dbType, tableName, tableOrAlias);
				}
				catch(Exception ex)
				{
					this.generationError = ex.Message;
				}

				s = Merge(s, rep, delim);
			}
			return s;
		}

		private string GenSwitchBlock()
		{
			return this.switchedBlock;
		}

	}

}
