using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for StoredProcDlg.
	/// </summary>
	public class StoredProcDlg : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtSPName;
		private System.Windows.Forms.RichTextBox txtSPContent;
		private System.Windows.Forms.Button butDrop;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public StoredProcDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(StoredProcDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtSPName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtSPContent = new System.Windows.Forms.RichTextBox();
			this.butDrop = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(304, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Edit and save the stored procedure code.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(152, 304);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(240, 304);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Save";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtSPName
			// 
			this.txtSPName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtSPName.Location = new System.Drawing.Point(112, 72);
			this.txtSPName.Name = "txtSPName";
			this.txtSPName.ReadOnly = true;
			this.txtSPName.Size = new System.Drawing.Size(352, 20);
			this.txtSPName.TabIndex = 7;
			this.txtSPName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 72);
			this.label1.Name = "label1";
			this.label1.TabIndex = 8;
			this.label1.Text = "Procedure:";
			// 
			// txtSPContent
			// 
			this.txtSPContent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtSPContent.Location = new System.Drawing.Point(8, 104);
			this.txtSPContent.Name = "txtSPContent";
			this.txtSPContent.Size = new System.Drawing.Size(456, 192);
			this.txtSPContent.TabIndex = 10;
			this.txtSPContent.Text = "";
			this.txtSPContent.WordWrap = false;
			// 
			// butDrop
			// 
			this.butDrop.Location = new System.Drawing.Point(384, 304);
			this.butDrop.Name = "butDrop";
			this.butDrop.TabIndex = 11;
			this.butDrop.Text = "Drop";
			this.butDrop.Click += new System.EventHandler(this.butDrop_Click);
			// 
			// StoredProcDlg
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(474, 335);
			this.Controls.Add(this.butDrop);
			this.Controls.Add(this.txtSPContent);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtSPName);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "StoredProcDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Stored Procedure Editor";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.StoredProcDlg_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool EditStoredProc(string spName)
		{
			StoredProcDlg spdlg = new StoredProcDlg();
			spdlg.SPName = spName;
			if (spdlg.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		public string SPName
		{
			get
			{
				return this.txtSPName.Text;
			}
			set
			{
				this.txtSPName.Text = value;
			}
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				DialogResult = DialogResult.OK;

				//Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseEntity.Checked);
				if (!Util.SetStoredProcOnDB(this, SPName, txtSPContent.Text, true, false))
					return;

				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void StoredProcDlg_Load(object sender, System.EventArgs e)
		{
			txtSPContent.Text = Util.GetStoredProcContentFromDB(SPName);
			//txtSPContent.Select(1, 10);
			//txtSPContent.SelectionColor = System.Drawing.Color.Navy;
		}

		private void butDrop_Click(object sender, System.EventArgs e)
		{
			if (Connect.Instance.ShowDialog(this, 
				String.Format("Do you really want to drop stored procedure '{0}'?", SPName),
				"Drop stored procedure", MessageBoxButtons.YesNo)
				!= DialogResult.Yes)
				return;

			DialogResult = DialogResult.OK;

			Util.DropStoredProcOnDB(this, SPName);
			Close();
		}

	}

}
