using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class ValueMappingPropertyOptionsDlg : System.Windows.Forms.Form
	{
		private CodeClass dataCls;
		private ValueMapperOptions options;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbCollectionClass;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbLookupMethodForGet;
		private System.Windows.Forms.ComboBox cbLookupMethodForSet;
		private System.Windows.Forms.TextBox txtPropertyName;
		private System.Windows.Forms.ComboBox cbStaticMember;
		private System.Windows.Forms.Label label6;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ValueMappingPropertyOptionsDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ValueMappingPropertyOptionsDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.cbCollectionClass = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.cbLookupMethodForGet = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cbLookupMethodForSet = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtPropertyName = new System.Windows.Forms.TextBox();
			this.cbStaticMember = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select options to create a mapping property that looks up a value in colle" +
				"ction and maps it to a value found in an element\'s member.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(160, 216);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 6;
			this.butCancel.Text = "Cancel";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(240, 216);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// cbCollectionClass
			// 
			this.cbCollectionClass.Location = new System.Drawing.Point(136, 112);
			this.cbCollectionClass.Name = "cbCollectionClass";
			this.cbCollectionClass.Size = new System.Drawing.Size(280, 21);
			this.cbCollectionClass.TabIndex = 1;
			this.cbCollectionClass.TextChanged += new System.EventHandler(this.cbCollectionClass_TextChanged);
			this.cbCollectionClass.SelectedIndexChanged += new System.EventHandler(this.cbCollectionClass_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(14, 115);
			this.label1.Name = "label1";
			this.label1.TabIndex = 12;
			this.label1.Text = "Collection Type:";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(14, 161);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 13;
			this.label4.Text = "Lookup method for get:";
			// 
			// cbLookupMethodForGet
			// 
			this.cbLookupMethodForGet.Location = new System.Drawing.Point(136, 160);
			this.cbLookupMethodForGet.Name = "cbLookupMethodForGet";
			this.cbLookupMethodForGet.Size = new System.Drawing.Size(280, 21);
			this.cbLookupMethodForGet.TabIndex = 3;
			this.cbLookupMethodForGet.TextChanged += new System.EventHandler(this.cbLookupMethodForGet_TextChanged);
			this.cbLookupMethodForGet.SelectedIndexChanged += new System.EventHandler(this.cbLookupMethodForGet_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(14, 185);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(136, 23);
			this.label5.TabIndex = 17;
			this.label5.Text = "Lookup method for set:";
			// 
			// cbLookupMethodForSet
			// 
			this.cbLookupMethodForSet.Location = new System.Drawing.Point(136, 184);
			this.cbLookupMethodForSet.Name = "cbLookupMethodForSet";
			this.cbLookupMethodForSet.Size = new System.Drawing.Size(280, 21);
			this.cbLookupMethodForSet.TabIndex = 4;
			this.cbLookupMethodForSet.TextChanged += new System.EventHandler(this.cbLookupMethodForSet_TextChanged);
			this.cbLookupMethodForSet.SelectedIndexChanged += new System.EventHandler(this.cbLookupMethodForSet_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(14, 91);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 25;
			this.label3.Text = "Property Name:";
			// 
			// txtPropertyName
			// 
			this.txtPropertyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPropertyName.Location = new System.Drawing.Point(136, 88);
			this.txtPropertyName.Name = "txtPropertyName";
			this.txtPropertyName.Size = new System.Drawing.Size(280, 20);
			this.txtPropertyName.TabIndex = 0;
			this.txtPropertyName.Text = "";
			this.txtPropertyName.TextChanged += new System.EventHandler(this.txtPropertyName_TextChanged);
			// 
			// cbStaticMember
			// 
			this.cbStaticMember.Location = new System.Drawing.Point(136, 136);
			this.cbStaticMember.Name = "cbStaticMember";
			this.cbStaticMember.Size = new System.Drawing.Size(280, 21);
			this.cbStaticMember.TabIndex = 2;
			this.cbStaticMember.TextChanged += new System.EventHandler(this.cbStaticMember_TextChanged);
			this.cbStaticMember.SelectedIndexChanged += new System.EventHandler(this.cbStaticMember_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(14, 139);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(136, 23);
			this.label6.TabIndex = 26;
			this.label6.Text = "Get From Static Member:";
			// 
			// ValueMappingPropertyOptionsDlg
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(426, 247);
			this.Controls.Add(this.cbStaticMember);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtPropertyName);
			this.Controls.Add(this.cbLookupMethodForSet);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.cbLookupMethodForGet);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbCollectionClass);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label6);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ValueMappingPropertyOptionsDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Value Mapping Property Options";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.LookupMemberOptionsDlg_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool Display(CodeClass dataCls, ValueMapperOptions options)
		{
			ValueMappingPropertyOptionsDlg vmpo = new ValueMappingPropertyOptionsDlg();
			vmpo.dataCls = dataCls;
			vmpo.options = options;
			if (vmpo.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				CodeClass colCls = Util.FindClassInProject(dataCls.ProjectItem.ContainingProject, cbCollectionClass.Text);
				if (colCls == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find collection class " + cbLookupMethodForGet.Text, "Value Mapping Property Options");
					return;
				}

				CodeFunction funcGet = null;
				CodeFunction funcSet = null;

				if (cbLookupMethodForGet.Text != "")
				{
					funcGet = Util.FindFirstMember(colCls, cbLookupMethodForGet.Text) as CodeFunction;
					if (funcGet == null)
					{
						Connect.Instance.ShowDialog(this, "Can't find method " + cbLookupMethodForGet.Text, "Value Mapping Property Options");
						return;
					}
				}
				
				if (cbLookupMethodForSet.Text != "")
				{
					funcSet = Util.FindFirstMember(colCls, cbLookupMethodForSet.Text) as CodeFunction;
					if (funcSet == null)
					{
						Connect.Instance.ShowDialog(this, "Can't find method " + cbLookupMethodForSet.Text, "Value Mapping Property Options");
						return;
					}
				}

				DialogResult = DialogResult.OK;

				//Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseEntity.Checked);

				options.propertyName = txtPropertyName.Text;
				options.collectionClass = cbCollectionClass.Text;
				options.staticMember = cbStaticMember.Text;
				if (funcGet != null)
					options.type = funcGet.Type;
				options.lookupMethodForGet = cbLookupMethodForGet.Text;
				options.lookupMethodForSet = cbLookupMethodForSet.Text;

				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}


		private void LookupMemberOptionsDlg_Load(object sender, System.EventArgs e)
		{
			//ToolTip tooltip = new ToolTip();
			//tooltip.ShowAlways = true;
			//tooltip.SetToolTip(cbCollectionClass, "If you select a collection type, the method will be created on the selected collection.");

			txtPropertyName.Text = options.propertyName;
			cbCollectionClass.Text = options.collectionClass;
			cbStaticMember.Text = options.staticMember;
			cbLookupMethodForGet.Text = options.lookupMethodForGet;
			cbLookupMethodForSet.Text = options.lookupMethodForSet;

			object[] colClasses = Util.FindCollectionClassesInProject(dataCls.ProjectItem.ContainingProject, null);
			for (int i = 0; i < colClasses.Length; i++)
			{
				CodeClass colClass = colClasses[i] as CodeClass;
				if (colClass != null)
					cbCollectionClass.Items.Add(colClass.Name);
			}
		}

		private void cbCollectionClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			cbLookupMethodForGet.Items.Clear();
			cbLookupMethodForSet.Items.Clear();
			cbStaticMember.Items.Clear();
			string colClass = (string)cbCollectionClass.SelectedItem;
			if (colClass == null)
				return;

			CodeClass colCls = Util.FindClassInProject(dataCls.ProjectItem.ContainingProject, cbCollectionClass.Text);
			if (colCls == null)
				return;

			CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
			if (elemCls == null)
				return;

			FillLookupMethods(colCls, cbLookupMethodForGet);
			FillLookupMethods(colCls, cbLookupMethodForSet);
			FillStaticProps(colCls, elemCls, cbStaticMember);

			EnableButtons();
		}

		private void FillStaticProps(CodeClass cls, CodeClass elemCls, ComboBox cb)
		{
			for (int i = 1; i <= cls.Members.Count; i++)
			{
				CodeProperty prop = cls.Members.Item(i) as CodeProperty;
				if (prop != null)
				{
					//if (Util.IsPropertyStatic(prop))
					if (prop.Type.TypeKind == vsCMTypeRef.vsCMTypeRefCodeType)
						if (cls.FullName == prop.Type.AsString)
							cb.Items.Add(prop.Name);
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
					FillStaticProps(cls.Bases.Item(i) as CodeClass, elemCls, cb);
			}
		}

		private void FillLookupMethods(CodeClass colCls, ComboBox cb)
		{
			for (int i = 1; i <= colCls.Members.Count; i++)
			{
				CodeFunction func = colCls.Members.Item(i) as CodeFunction;
				if (func != null)
				{
					cb.Items.Add(func.Name);
				}
			}

			if (colCls.Bases != null)
			{
				for (int i = 1; i <= colCls.Bases.Count; i++)
					FillLookupMethods(colCls.Bases.Item(i) as CodeClass, cb);
			}
		}

		private void EnableButtons()
		{
			butCreate.Enabled = txtPropertyName.Text != "" &&
				cbCollectionClass.Text != "" &&
				cbStaticMember.Text != "";
		}

		private void txtPropertyName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbStaticMember_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbLookupMethodForGet_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbLookupMethodForSet_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbCollectionClass_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbStaticMember_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbLookupMethodForGet_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbLookupMethodForSet_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

	}

	public class ValueMapperOptions
	{
		public string propertyName;
		public string collectionClass;
		public string staticMember;
		public string lookupMethodForGet;
		public string lookupMethodForSet;
		public CodeTypeRef type;		// the Get method's return type
	}
}
