using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for LanguageClassBuilder.
	/// </summary>
	public class LanguageClassBuilder : System.Windows.Forms.Form
	{
		private CodeClass cls;
		private DataSet dsMessages;
		private DataView dvMessages;
		private string langIDcolumn;
		private string messageColumn;
		private string selectedMsgID;
		private bool mappingChanged = false;


		string[] dropFormats = {
								   "@{0}@",
								   "{0}",
								   "\"@{0}@\"",
								   "[FieldDescription(\"@{0}@\")]",
								   "<ns:OBLabel TextToTranslate=\"@{0}@\" runat=server></ns:OBLabel>",
								   "<ns:OBButton TextToTranslate=\"@{0}@\" runat=server></ns:OBButton>",
								   "<nsi:WebButton TextToTranslate=\"@{0}@\" runat=server></nsi:WebButton>",
								   "<ns:OBLinkButton TextToTranslate=\"@{0}@\" runat=server></ns:OBLinkButton>",
								   "<ns:OBHyperLink TextToTranslate=\"@{0}@\" runat=server></ns:OBHyperLink>",
								   "<ns:OBLiteral TextToTranslate=\"@{0}@\" runat=server></ns:OBLiteral>"
							   };

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lbTableName;
		private System.Windows.Forms.DataGrid grid;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lbMsgIDcolumn;
		private System.Windows.Forms.ListBox lsMappedMessages;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button butSave;
		private System.Windows.Forms.Button butAdd;
		private System.Windows.Forms.Button butRemove;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.CheckedListBox chkMsgLangs;
		private System.Windows.Forms.Label lbMsgID;
		private System.Windows.Forms.TextBox txtMsgIDfilter;
		private System.Windows.Forms.TextBox txtLangIDfilter;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label;
		private System.Windows.Forms.TextBox txtMsgFilter;
		private System.Windows.Forms.CheckBox chkEditMode;
		private System.Windows.Forms.Button cmdShow;
		private System.Windows.Forms.ComboBox cbDropStyle;
		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn2;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn3;
		private System.Windows.Forms.CheckBox chkNullMessagesOnly;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LanguageClassBuilder()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LanguageClassBuilder));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butSave = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lbTableName = new System.Windows.Forms.Label();
			this.grid = new System.Windows.Forms.DataGrid();
			this.dataGridTableStyle1 = new System.Windows.Forms.DataGridTableStyle();
			this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn2 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn3 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.label3 = new System.Windows.Forms.Label();
			this.lbMsgIDcolumn = new System.Windows.Forms.Label();
			this.lsMappedMessages = new System.Windows.Forms.ListBox();
			this.label4 = new System.Windows.Forms.Label();
			this.butAdd = new System.Windows.Forms.Button();
			this.butRemove = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.chkMsgLangs = new System.Windows.Forms.CheckedListBox();
			this.lbMsgID = new System.Windows.Forms.Label();
			this.txtMsgIDfilter = new System.Windows.Forms.TextBox();
			this.txtLangIDfilter = new System.Windows.Forms.TextBox();
			this.label = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.txtMsgFilter = new System.Windows.Forms.TextBox();
			this.chkEditMode = new System.Windows.Forms.CheckBox();
			this.cmdShow = new System.Windows.Forms.Button();
			this.cbDropStyle = new System.Windows.Forms.ComboBox();
			this.chkNullMessagesOnly = new System.Windows.Forms.CheckBox();
			((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.Location = new System.Drawing.Point(272, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Table:";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(288, 40);
			this.label2.TabIndex = 3;
			this.label2.Text = "Manages messages in the data table and maps them to the language class members.";
			// 
			// butCancel
			// 
			this.butCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(16, 344);
			this.butCancel.Name = "butCancel";
			this.butCancel.Size = new System.Drawing.Size(64, 23);
			this.butCancel.TabIndex = 6;
			this.butCancel.Text = "Close";
			this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
			// 
			// butSave
			// 
			this.butSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butSave.Enabled = false;
			this.butSave.Location = new System.Drawing.Point(80, 344);
			this.butSave.Name = "butSave";
			this.butSave.Size = new System.Drawing.Size(64, 23);
			this.butSave.TabIndex = 7;
			this.butSave.Text = "Save";
			this.butSave.Click += new System.EventHandler(this.butSave_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// lbTableName
			// 
			this.lbTableName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbTableName.Location = new System.Drawing.Point(352, 48);
			this.lbTableName.Name = "lbTableName";
			this.lbTableName.Size = new System.Drawing.Size(104, 23);
			this.lbTableName.TabIndex = 12;
			this.lbTableName.Text = "TableName";
			// 
			// grid
			// 
			this.grid.AllowSorting = false;
			this.grid.AlternatingBackColor = System.Drawing.Color.Gainsboro;
			this.grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grid.BackColor = System.Drawing.Color.Silver;
			this.grid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.grid.CaptionBackColor = System.Drawing.Color.DarkSlateBlue;
			this.grid.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
			this.grid.CaptionForeColor = System.Drawing.Color.White;
			this.grid.CaptionVisible = false;
			this.grid.DataMember = "";
			this.grid.FlatMode = true;
			this.grid.ForeColor = System.Drawing.Color.Black;
			this.grid.GridLineColor = System.Drawing.Color.White;
			this.grid.HeaderBackColor = System.Drawing.Color.DarkGray;
			this.grid.HeaderForeColor = System.Drawing.Color.Black;
			this.grid.LinkColor = System.Drawing.Color.DarkSlateBlue;
			this.grid.Location = new System.Drawing.Point(8, 120);
			this.grid.Name = "grid";
			this.grid.ParentRowsBackColor = System.Drawing.Color.Black;
			this.grid.ParentRowsForeColor = System.Drawing.Color.White;
			this.grid.ReadOnly = true;
			this.grid.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
			this.grid.SelectionForeColor = System.Drawing.Color.White;
			this.grid.Size = new System.Drawing.Size(288, 216);
			this.grid.TabIndex = 3;
			this.grid.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
																							 this.dataGridTableStyle1});
			this.grid.DoubleClick += new System.EventHandler(this.grid_DoubleClick);
			this.grid.CurrentCellChanged += new System.EventHandler(this.grid_CurrentCellChanged);
			this.grid.MouseMove += new System.Windows.Forms.MouseEventHandler(this.grid_MouseMove);
			// 
			// dataGridTableStyle1
			// 
			this.dataGridTableStyle1.DataGrid = this.grid;
			this.dataGridTableStyle1.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
																												  this.dataGridTextBoxColumn1,
																												  this.dataGridTextBoxColumn2,
																												  this.dataGridTextBoxColumn3});
			this.dataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridTableStyle1.MappingName = "";
			// 
			// dataGridTextBoxColumn1
			// 
			this.dataGridTextBoxColumn1.Format = "";
			this.dataGridTextBoxColumn1.FormatInfo = null;
			this.dataGridTextBoxColumn1.MappingName = "";
			this.dataGridTextBoxColumn1.Width = 200;
			// 
			// dataGridTextBoxColumn2
			// 
			this.dataGridTextBoxColumn2.Format = "";
			this.dataGridTextBoxColumn2.FormatInfo = null;
			this.dataGridTextBoxColumn2.MappingName = "";
			this.dataGridTextBoxColumn2.Width = 75;
			// 
			// dataGridTextBoxColumn3
			// 
			this.dataGridTextBoxColumn3.Format = "";
			this.dataGridTextBoxColumn3.FormatInfo = null;
			this.dataGridTextBoxColumn3.MappingName = "";
			this.dataGridTextBoxColumn3.Width = 500;
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label3.Location = new System.Drawing.Point(272, 72);
			this.label3.Name = "label3";
			this.label3.TabIndex = 14;
			this.label3.Text = "MsgID Column:";
			// 
			// lbMsgIDcolumn
			// 
			this.lbMsgIDcolumn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lbMsgIDcolumn.Location = new System.Drawing.Point(352, 72);
			this.lbMsgIDcolumn.Name = "lbMsgIDcolumn";
			this.lbMsgIDcolumn.TabIndex = 15;
			this.lbMsgIDcolumn.Text = "MsgIDcolumn";
			// 
			// lsMappedMessages
			// 
			this.lsMappedMessages.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lsMappedMessages.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lsMappedMessages.Location = new System.Drawing.Point(320, 136);
			this.lsMappedMessages.Name = "lsMappedMessages";
			this.lsMappedMessages.Size = new System.Drawing.Size(128, 145);
			this.lsMappedMessages.Sorted = true;
			this.lsMappedMessages.TabIndex = 4;
			this.lsMappedMessages.DoubleClick += new System.EventHandler(this.lsMappedMessages_DoubleClick);
			this.lsMappedMessages.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lsMappedMessages_MouseMove);
			this.lsMappedMessages.SelectedIndexChanged += new System.EventHandler(this.lsMappedMessages_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label4.Location = new System.Drawing.Point(320, 120);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 17;
			this.label4.Text = "Mapped Messages:";
			// 
			// butAdd
			// 
			this.butAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.butAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.butAdd.Location = new System.Drawing.Point(296, 136);
			this.butAdd.Name = "butAdd";
			this.butAdd.Size = new System.Drawing.Size(24, 23);
			this.butAdd.TabIndex = 18;
			this.butAdd.Text = ">";
			this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
			// 
			// butRemove
			// 
			this.butRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.butRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.butRemove.Location = new System.Drawing.Point(296, 160);
			this.butRemove.Name = "butRemove";
			this.butRemove.Size = new System.Drawing.Size(24, 23);
			this.butRemove.TabIndex = 18;
			this.butRemove.Text = "<";
			this.butRemove.Click += new System.EventHandler(this.butRemove_Click);
			// 
			// butCreate
			// 
			this.butCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butCreate.Location = new System.Drawing.Point(320, 344);
			this.butCreate.Name = "butCreate";
			this.butCreate.Size = new System.Drawing.Size(112, 23);
			this.butCreate.TabIndex = 8;
			this.butCreate.Text = "Create Mappings";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// chkMsgLangs
			// 
			this.chkMsgLangs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.chkMsgLangs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.chkMsgLangs.CheckOnClick = true;
			this.chkMsgLangs.Enabled = false;
			this.chkMsgLangs.Location = new System.Drawing.Point(320, 288);
			this.chkMsgLangs.Name = "chkMsgLangs";
			this.chkMsgLangs.Size = new System.Drawing.Size(128, 47);
			this.chkMsgLangs.TabIndex = 5;
			this.chkMsgLangs.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chkMsgLangs_ItemCheck);
			// 
			// lbMsgID
			// 
			this.lbMsgID.Location = new System.Drawing.Point(88, 75);
			this.lbMsgID.Name = "lbMsgID";
			this.lbMsgID.Size = new System.Drawing.Size(72, 23);
			this.lbMsgID.TabIndex = 21;
			this.lbMsgID.Text = "Message ID:";
			// 
			// txtMsgIDfilter
			// 
			this.txtMsgIDfilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMsgIDfilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMsgIDfilter.Location = new System.Drawing.Point(152, 72);
			this.txtMsgIDfilter.Name = "txtMsgIDfilter";
			this.txtMsgIDfilter.Size = new System.Drawing.Size(104, 20);
			this.txtMsgIDfilter.TabIndex = 1;
			this.txtMsgIDfilter.Text = "";
			this.txtMsgIDfilter.TextChanged += new System.EventHandler(this.txtMsgIDfilter_TextChanged);
			// 
			// txtLangIDfilter
			// 
			this.txtLangIDfilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtLangIDfilter.Location = new System.Drawing.Point(56, 72);
			this.txtLangIDfilter.Name = "txtLangIDfilter";
			this.txtLangIDfilter.Size = new System.Drawing.Size(24, 20);
			this.txtLangIDfilter.TabIndex = 0;
			this.txtLangIDfilter.Text = "";
			this.txtLangIDfilter.TextChanged += new System.EventHandler(this.txtMsgIDfilter_TextChanged);
			// 
			// label
			// 
			this.label.Location = new System.Drawing.Point(8, 75);
			this.label.Name = "label";
			this.label.Size = new System.Drawing.Size(48, 23);
			this.label.TabIndex = 24;
			this.label.Text = "LangID:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 98);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(88, 23);
			this.label7.TabIndex = 21;
			this.label7.Text = "Message Filter:";
			// 
			// txtMsgFilter
			// 
			this.txtMsgFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMsgFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMsgFilter.Location = new System.Drawing.Point(88, 96);
			this.txtMsgFilter.Name = "txtMsgFilter";
			this.txtMsgFilter.Size = new System.Drawing.Size(208, 20);
			this.txtMsgFilter.TabIndex = 2;
			this.txtMsgFilter.Text = "";
			this.txtMsgFilter.TextChanged += new System.EventHandler(this.txtMsgIDfilter_TextChanged);
			// 
			// chkEditMode
			// 
			this.chkEditMode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.chkEditMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkEditMode.Location = new System.Drawing.Point(224, 344);
			this.chkEditMode.Name = "chkEditMode";
			this.chkEditMode.Size = new System.Drawing.Size(88, 24);
			this.chkEditMode.TabIndex = 25;
			this.chkEditMode.Text = "Edit Mode";
			this.chkEditMode.CheckedChanged += new System.EventHandler(this.chkEditMode_CheckedChanged);
			// 
			// cmdShow
			// 
			this.cmdShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cmdShow.Location = new System.Drawing.Point(144, 344);
			this.cmdShow.Name = "cmdShow";
			this.cmdShow.Size = new System.Drawing.Size(72, 23);
			this.cmdShow.TabIndex = 26;
			this.cmdShow.Text = "Show Class";
			this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
			// 
			// cbDropStyle
			// 
			this.cbDropStyle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.cbDropStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbDropStyle.Items.AddRange(new object[] {
															 "Drop as @msgID@",
															 "Drop as msgID",
															 "Drop as \"msgID\"",
															 "Drop as FieldDescription",
															 "Drop as OBLabel",
															 "Drop as OBButton",
															 "Drop as WebButton",
															 "Drop as OBLinkButton",
															 "Drop as OBHyperLink",
															 "Drop as OBLiteral"});
			this.cbDropStyle.Location = new System.Drawing.Point(320, 96);
			this.cbDropStyle.Name = "cbDropStyle";
			this.cbDropStyle.Size = new System.Drawing.Size(128, 21);
			this.cbDropStyle.TabIndex = 27;
			// 
			// chkNullMessagesOnly
			// 
			this.chkNullMessagesOnly.Location = new System.Drawing.Point(152, 43);
			this.chkNullMessagesOnly.Name = "chkNullMessagesOnly";
			this.chkNullMessagesOnly.Size = new System.Drawing.Size(136, 24);
			this.chkNullMessagesOnly.TabIndex = 28;
			this.chkNullMessagesOnly.Text = "Null-messages only";
			this.chkNullMessagesOnly.CheckedChanged += new System.EventHandler(this.chkNullMessagesOnly_CheckedChanged);
			// 
			// LanguageClassBuilder
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(456, 374);
			this.Controls.Add(this.cbDropStyle);
			this.Controls.Add(this.cmdShow);
			this.Controls.Add(this.txtMsgFilter);
			this.Controls.Add(this.txtLangIDfilter);
			this.Controls.Add(this.txtMsgIDfilter);
			this.Controls.Add(this.label);
			this.Controls.Add(this.lbMsgID);
			this.Controls.Add(this.chkMsgLangs);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.lsMappedMessages);
			this.Controls.Add(this.butAdd);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lbMsgIDcolumn);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.grid);
			this.Controls.Add(this.lbTableName);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butSave);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.butRemove);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.chkEditMode);
			this.Controls.Add(this.chkNullMessagesOnly);
			this.MaximizeBox = false;
			this.Name = "LanguageClassBuilder";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Netsoft USA Language Class Builder";
			this.TopMost = true;
			this.Resize += new System.EventHandler(this.LanguageClassBuilder_Resize);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.LanguageClassBuilder_Closing);
			this.Load += new System.EventHandler(this.LanguageClassBuilder_Load);
			this.Activated += new System.EventHandler(this.LanguageClassBuilder_Activated);
			((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		public static void BuildLanguageClass(CodeClass cls)
		{
			LanguageClassBuilder lcb = new LanguageClassBuilder();

			CodeAttribute att = Util.FindAttribute(cls, "LanguageTable");
			if (att != null)
			{
				lcb.lbTableName.Text = Util.GetParamFromAttrib(att, "TableName", 0); 
				lcb.lbMsgIDcolumn.Text = Util.GetParamFromAttrib(att, "MsgIDcolumn", 1); 
				lcb.langIDcolumn = Util.GetParamFromAttrib(att, "LangIDcolumn", 2);
				lcb.messageColumn = Util.GetParamFromAttrib(att, "MessageColumn", 3);
			}
			lcb.cls = cls;

			lcb.Show();
		}

		private void EnableButtons()
		{
			butAdd.Enabled = grid.CurrentRowIndex >= 0;
			butRemove.Enabled = lsMappedMessages.SelectedIndex >= 0;
		}

		private DataGridColumnStyle GetColumnStyle(string colName)
		{
			return null;
			/*
			DataGridTableStyle tblStyle = null;
			DataGridColumnStyle colStyle = null;
			if (grid.TableStyles.Count == 0)
			{
				tblStyle = new DataGridTableStyle(true);

				colStyle = new DataGridTextBoxColumn();
				colStyle.MappingName = colName;
				tblStyle.GridColumnStyles.Add(colStyle);
				grid.TableStyles.Add(tblStyle);
			}
			else
				tblStyle = grid.TableStyles[0];

			colStyle = tblStyle.GridColumnStyles[colName];
			return colStyle;*/
		}

		private bool RetrieveMessages()
		{
			try
			{
				DataSet ds = Util.ExecuteDataset("Messages", CommandType.Text, "select * from [" + lbTableName.Text + "]");
				dsMessages = ds;
				dvMessages = ds.Tables[0].DefaultView;
				dvMessages.Sort = lbMsgIDcolumn.Text; // + "," + messageColumn;
				
				ds.Tables[0].Columns[lbMsgIDcolumn.Text].AllowDBNull = false;
				ds.Tables[0].Columns[langIDcolumn].AllowDBNull = false;
				//for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
				//{
				//	ds.Tables[0].Columns[i].AllowDBNull = false;
				//}

				//GetColumnStyle(this.messageColumn).Width = 200;
				grid.TableStyles[0].MappingName = dvMessages.Table.TableName;
				grid.TableStyles[0].AlternatingBackColor = System.Drawing.Color.LightGray;
				grid.TableStyles[0].AllowSorting = false;
				grid.TableStyles[0].GridColumnStyles[0].MappingName = lbMsgIDcolumn.Text;
				grid.TableStyles[0].GridColumnStyles[0].HeaderText = lbMsgIDcolumn.Text;
				grid.TableStyles[0].GridColumnStyles[1].MappingName = langIDcolumn;
				grid.TableStyles[0].GridColumnStyles[1].HeaderText = langIDcolumn;
				grid.TableStyles[0].GridColumnStyles[2].MappingName = messageColumn;
				grid.TableStyles[0].GridColumnStyles[2].HeaderText = messageColumn;
				grid.DataSource = dvMessages;
			}
			catch(Exception ex)
			{
				 Connect.Instance.ShowDialog(this, "Error accessing message table.\r\n" + ex.Message);
				this.Close();
				return false;
			}
			return true;
		}

		private void FillMessageIDs()
		{
			lsMappedMessages.Items.Clear();
			mappingChanged = false;
			if (dvMessages == null)
				return;
			FillMessageIDs(cls);
		}

		private void FillMessageIDs(CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable) // ||
					//elem.Kind == EnvDTE.vsCMElement.vsCMElementProperty)
				{
					string msgID = elem.Name;
					if (dvMessages.Find(msgID) < 0)
						msgID = "?" + msgID;		// not in the table!
					lsMappedMessages.Items.Add(msgID);
				}
			}

			for (int i = 1; i <= cls.Bases.Count; i++)
				FillMessageIDs(cls.Bases.Item(i) as CodeClass);
		}

		private void FillPossibleLangs()
		{
			chkMsgLangs.Items.Clear();
			if (dvMessages == null)
				return;
			for (int i = 0; i < dvMessages.Count; i++)
			{
				string langID = Convert.ToString(dvMessages[i][langIDcolumn]);
				if (langID != null)
					if (!chkMsgLangs.Items.Contains(langID))
						chkMsgLangs.Items.Add(langID);
			}
		}

		private void LanguageClassBuilder_Load(object sender, System.EventArgs e)
		{
			cbDropStyle.SelectedIndex = 0;
			Util.LoadFormPos(this, true);
			this.Text += "    Class Name='" + cls.Name + "'";

			EnableButtons();
			if (!RetrieveMessages())
				return;
			FillPossibleLangs();
			FillMessageIDs();

			this.TopMost = true;
		}

		private void WriteSettings()
		{
			//til.SetSetting(cls.Name, "EnsureSqlData", chkEnsureSqlData.Checked);
			//Util.SetSetting(cls.Name, "EnsureServerScript", chkEnsureServerScript.Checked);
			Util.SaveFormPos(this);
		}

		private void LanguageClassBuilder_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (dsMessages != null)
			{
				DataTable chg = dsMessages.Tables[0].GetChanges();
				if (chg != null && chg.Rows.Count > 0)
				{
					DialogResult res = Connect.Instance.ShowDialog(this, "There are some changes in the messages.  Do you want to save before closing?", "Closing", MessageBoxButtons.YesNo);
					if (res == DialogResult.Cancel)
					{
						e.Cancel = true;
						return;
					}
					if (res == DialogResult.Yes)
					{
						butSave_Click(this, new EventArgs());
						chg = dsMessages.Tables[0].GetChanges();
						if (chg != null && chg.Rows.Count > 0)
						{
							e.Cancel = true;
							return;
						}
					}
				}

				if (mappingChanged)
				{
					DialogResult res = Connect.Instance.ShowDialog(this, "There are some new mapped messages.  Do you want to create these mappings?", "Closing", MessageBoxButtons.YesNo);
					if (res == DialogResult.Cancel)
					{
						e.Cancel = true;
						return;
					}
					if (res == DialogResult.Yes)
						butCreate_Click(this, new EventArgs());
				}
			}
			WriteSettings();
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void AddRowToMapping(int irow)
		{
			if (dvMessages == null)
				return;
			if (irow >= 0)
			{
				DataRowView row = dvMessages[irow];
				string msgID = Convert.ToString(row[lbMsgIDcolumn.Text]);
				if (!lsMappedMessages.Items.Contains(msgID))
				{
					lsMappedMessages.Items.Add(msgID);
					mappingChanged = true;
				}
			}
		}

		private void butAdd_Click(object sender, System.EventArgs e)
		{
			if (dsMessages == null)
				return;

			int irow = grid.CurrentRowIndex;
			AddRowToMapping(irow);

			// add all selected 
			for (int i = 0; i < dvMessages.Count; i++)
			{
				if (grid.IsSelected(i))
					AddRowToMapping(i);
			}
		}

		private bool MsgLangExists(string msgID, string langID)
		{
			string filter = String.Format("{0}='{1}' and {2}='{3}'", lbMsgIDcolumn.Text, msgID, langIDcolumn, langID);
			if (dsMessages != null)
			{
				if (dsMessages.Tables[0].Select(filter).Length > 0)
					return true;
			}
			return false;
		}

		private void CreateMsgLang(string msgID, string langID)
		{
			if (dvMessages == null)
				return;
			DataRowView row = dvMessages.AddNew();
			row[lbMsgIDcolumn.Text] = msgID;
			row[langIDcolumn] = langID;
			row[messageColumn] = "";
			row.EndEdit();
			//int irow = dvMessages.Find(new object[] { msgID, langID } );
			//row
			//grid.CurrentCell = new DataGridCell(irow, 2);
		}

		private void EnsureMsgLang(string msgID, string langID)
		{
			if (!MsgLangExists(msgID, langID))
				CreateMsgLang(msgID, langID);
		}

		private void SetAvailableMsgLangs()
		{
			chkMsgLangs.ClearSelected();
			int sel =lsMappedMessages.SelectedIndex;
			if (sel < 0)
				return;

			string msgID = selectedMsgID; // (string)lsMappedMessages.Items[sel];
			msgID = msgID.Trim('?');
			for (int i = 0; i < chkMsgLangs.Items.Count; i++)
			{
				string langID = (string)chkMsgLangs.Items[i];
				if (MsgLangExists(msgID, langID))
					chkMsgLangs.SetItemCheckState(i, CheckState.Checked);
				else
					chkMsgLangs.SetItemCheckState(i, CheckState.Unchecked);
			}
		}

		private void SetAvailableMsgLangs(string msgID)
		{
			chkMsgLangs.ClearSelected();
			int sel =lsMappedMessages.SelectedIndex;
			if (sel < 0)
				return;

			for (int i = 0; i < chkMsgLangs.Items.Count; i++)
			{
				string langID = (string)chkMsgLangs.Items[i];
				if (MsgLangExists(msgID, langID))
					chkMsgLangs.SetItemCheckState(i, CheckState.Checked);
				else
					chkMsgLangs.SetItemCheckState(i, CheckState.Unchecked);
			}
		}

		private void lsMappedMessages_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (dvMessages == null)
				return;

			try
			{
				string msgID = (string)lsMappedMessages.SelectedItem;
				if (msgID != null)
				{
					msgID = msgID.Trim('?');
					selectedMsgID = msgID;

					int irow = dvMessages.Find(msgID);
					if (irow >= 0)
						grid.CurrentRowIndex = irow;

					CodeElement elem = Util.FindFirstMember(cls, msgID);
					Util.MarkElement(cls, elem);
				}
				SetAvailableMsgLangs();

				EnableButtons();
			}
			catch
			{
			}
		}

		private void butRemove_Click(object sender, System.EventArgs e)
		{
			int sel = lsMappedMessages.SelectedIndex;
			if (sel >= 0)
			{
				lsMappedMessages.Items.RemoveAt(sel);
				if (sel < lsMappedMessages.Items.Count)
					lsMappedMessages.SelectedIndex = sel;
			}
		}

		private void lsMappedMessages_DoubleClick(object sender, System.EventArgs e)
		{
			butRemove_Click(sender, e);
		}

		private void grid_DoubleClick(object sender, System.EventArgs e)
		{
			butAdd_Click(sender, e);		
		}



		private void butSave_Click(object sender, System.EventArgs e)
		{
			//if (Connect.Instance.ShowDialog(this, "Save changes to the table?", "Save Messages", MessageBoxButtons.YesNo) != DialogResult.Yes)
			//	return;

			try
			{
				if (dsMessages != null)
				{
					string sql = String.Format("select * from [{0}]", lbTableName.Text);
					OleDbDataAdapter da = new OleDbDataAdapter(sql, Util.ProjectConnection);
					OleDbCommandBuilder cb = new OleDbCommandBuilder(da);
					cb.QuotePrefix = "[";
					cb.QuoteSuffix = "]";

					da.DeleteCommand = cb.GetDeleteCommand();
					da.UpdateCommand = cb.GetUpdateCommand();
					da.InsertCommand = cb.GetInsertCommand();
					da.Update(dsMessages, "Messages");
					FillPossibleLangs();
					Connect.Instance.ShowDialog(this, "Messages saved.");
				}
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, "Error saving messages!\r\n" + ex.Message);
			}

			
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				for (int i = 0; i < lsMappedMessages.Items.Count; i++)
				{
					string msgID = (string)lsMappedMessages.Items[i];
					if (msgID.IndexOf('?') < 0)		// only if the message does exist!
					{
						CodeElement elem = Util.FindFirstMember(cls, msgID);
						if (elem == null)
						{
							CodeVariable var = cls.AddVariable(msgID, 
								EnvDTE.vsCMTypeRef.vsCMTypeRefString, 
								-1, 
								EnvDTE.vsCMAccess.vsCMAccessPublic, 
								null);
						}
					}
				}
				mappingChanged = false;
				FillMessageIDs();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkMsgLangs_ItemCheck(object sender, System.Windows.Forms.ItemCheckEventArgs e)
		{
			//int sel = lsMappedMessages.SelectedIndex;
			//string msgID = (string)lsMappedMessages.SelectedItem;
			//msgID = msgID.Trim('?');
			string msgID = selectedMsgID;
			if (msgID != null)
			{
				if (e.NewValue == CheckState.Checked)
				{
					string langID = (string)chkMsgLangs.Items[e.Index];
					if (!MsgLangExists(msgID, langID))
					{
						CreateMsgLang(msgID, langID);
						//lsMappedMessages.Items[sel] = msgID;
						SetAvailableMsgLangs();
					}
				}
			}
		}

		private string processQuote(string s)
		{
			return s.Replace("'", "''");
		}

		private void txtMsgIDfilter_TextChanged(object sender, System.EventArgs e)
		{
			if (dvMessages == null)
				return;

			string filter = String.Format("{0} like '%{1}%'", this.langIDcolumn, processQuote(txtLangIDfilter.Text));
			filter += String.Format(" and {0} like '%{1}%'", lbMsgIDcolumn.Text, processQuote(txtMsgIDfilter.Text));

			if (chkNullMessagesOnly.Checked)
				filter += String.Format(" and {0} is null", this.messageColumn);
			else
				filter += String.Format(" and {0} like '%{1}%'", this.messageColumn, processQuote(txtMsgFilter.Text));

			try
			{
				dvMessages.RowFilter = filter;
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message, "Filtering Error");
			}
		}

		private void grid_CurrentCellChanged(object sender, System.EventArgs e)
		{
			if (dvMessages == null)
				return;
		
			int irow = grid.CurrentRowIndex;
			if (irow >= 0)
			{
				string msgID = Convert.ToString(dvMessages[irow][lbMsgIDcolumn.Text]);
				selectedMsgID = msgID;
				int sel = lsMappedMessages.FindString(msgID);
				if (sel >= 0)
					lsMappedMessages.SelectedIndex = sel;
				
				SetAvailableMsgLangs(msgID);

				int icol = grid.CurrentCell.ColumnNumber;
				if (dvMessages.Table.Columns[icol].ColumnName == langIDcolumn)
					if (dvMessages[irow][icol] == DBNull.Value)
					{
						// find the language that's not used
						for (int i = 0; i < chkMsgLangs.Items.Count; i++)
						{
							if (!chkMsgLangs.GetItemChecked(i))
							{
								dvMessages[irow][icol] = (string)chkMsgLangs.Items[i];
								break;
							}
						}
					}
			}
			EnableButtons();
		}

		private void chkEditMode_CheckedChanged(object sender, System.EventArgs e)
		{
			grid.ReadOnly = !chkEditMode.Checked;
			chkMsgLangs.Enabled = chkEditMode.Checked;
			if (chkEditMode.Checked)
				butSave.Enabled = true;
		}

		private string FormatDropText(string s)
		{
			string format = (string)dropFormats[ cbDropStyle.SelectedIndex ];
			return String.Format(format, s);
		}

		private void lsMappedMessages_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			bool leftBut = (e.Button & MouseButtons.Left) == MouseButtons.Left;
			bool rightBut = (e.Button & MouseButtons.Right) == MouseButtons.Right;
			if (leftBut || rightBut && e.Clicks == 1)
			{
				//this.lsMappedMessages.
				//string s = (string)this.lsMappedMessages.SelectedItem;
				int indexOfItemUnderMouseToDrag = lsMappedMessages.IndexFromPoint(e.X, e.Y);
				if (indexOfItemUnderMouseToDrag != ListBox.NoMatches)
				{
					string s = (string)lsMappedMessages.Items[indexOfItemUnderMouseToDrag];
					if (s != null && s != "")
					{
						if (leftBut)
							s = FormatDropText(s);
						this.DoDragDrop(s, DragDropEffects.Copy);
					}
				}
			}
		}

		private void grid_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (dvMessages == null)
				return;

			if (dvMessages.Count == 0)
				return;

			bool leftBut = (e.Button & MouseButtons.Left) == MouseButtons.Left;
			bool rightBut = (e.Button & MouseButtons.Right) == MouseButtons.Right;
			if (leftBut || rightBut)
			{
				Rectangle rec = grid.GetCurrentCellBounds();
				if (rec.Contains(new Point(e.X, e.Y)))
				{
					int irow = grid.CurrentRowIndex;
					if (irow >= 0)
					{
						string msgID = Convert.ToString(dvMessages[irow][lbMsgIDcolumn.Text]);
						int sel = lsMappedMessages.FindString(msgID);
						if (sel >= 0)
						{
							DataGridCell cell = grid.CurrentCell;
							if (cell.ColumnNumber == 0)
							{
								string s = msgID;
								if (s != null && s != "")
								{
									if (leftBut)
										s = FormatDropText(s);
									this.DoDragDrop(s, DragDropEffects.Copy);
								}
							}
							else
							{
								string s = Convert.ToString( dvMessages[irow][cell.ColumnNumber] );
								this.DoDragDrop(s, DragDropEffects.Copy);
							}
						}
					}
				}
			}
		}

		private void cmdShow_Click(object sender, System.EventArgs e)
		{
			Util.ShowClass(this.cls);
		}

		private void LanguageClassBuilder_Activated(object sender, System.EventArgs e)
		{
			this.TopMost = true;
		}

		private void LanguageClassBuilder_Resize(object sender, System.EventArgs e)
		{
			try
			{
				int width = grid.Width - 60 - 30;
				grid.TableStyles[0].GridColumnStyles[0].Width = (int)(width * 0.3);
				grid.TableStyles[0].GridColumnStyles[1].Width = 30;
				grid.TableStyles[0].GridColumnStyles[2].Width = (int)(width * 0.7);
			}
			catch
			{
				// ignore
			}
		}

		private void chkNullMessagesOnly_CheckedChanged(object sender, System.EventArgs e)
		{
			txtMsgIDfilter_TextChanged(sender, e);
		}
	}
}
