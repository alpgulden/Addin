using System;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text;
using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using System.ComponentModel.Design;
using EnvDTE;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.EnterpriseTools.Shell;
using Microsoft.VisualStudio.EnterpriseTools.ArtifactModel.Clr;
using Microsoft.VisualStudio.EnterpriseTools.ClassDesigner.PresentationModel;


using System.Text.RegularExpressions;

namespace NetsoftUSAAddin2005
{

    public class MethodParamInfo
    {
        public EnvDTE80.CodeParameter2 param;
        public bool bIn;
        public bool bOut;
        public bool isEntity;
        public bool isCollection;
        public System.CodeDom.FieldDirection directionDTO = System.CodeDom.FieldDirection.In;
        public System.CodeDom.FieldDirection direction = System.CodeDom.FieldDirection.In;

        public MethodParamInfo(EnvDTE80.CodeParameter2 param)
        {
            this.param = param;
            foreach (EnvDTE.CodeAttribute attr in param.Attributes)
            {
                if (attr.Name == "In")
                    this.bIn = true;
                if (attr.Name == "Out")
                    this.bOut = true;
            }

            if ((param.ParameterKind & EnvDTE80.vsCMParameterKind.vsCMParameterKindOut) != 0)
                this.direction = System.CodeDom.FieldDirection.Out;
            else if ((param.ParameterKind & EnvDTE80.vsCMParameterKind.vsCMParameterKindRef) != 0)
                this.direction = System.CodeDom.FieldDirection.Ref;

            if (this.InOutSpecified)
            {
                this.directionDTO = this.bOut ? System.CodeDom.FieldDirection.Ref : System.CodeDom.FieldDirection.In;
                if (this.direction != System.CodeDom.FieldDirection.In)
                { 
                    // both [In]/[out] and out/ref used together!  throw
                    throw new Exception(String.Format("Parameter {0} of method {1} declares {2}.  Use only one type of direction declaration.", param.Name, param.Parent.Name, this.InOutDeclarationString));
                }
            }
            else
            {
                this.directionDTO = this.direction;
            }

            this.isCollection = Util.IsCollectionClass(param.Type);
            this.isEntity = Util.IsEntity(param.Type);
        }

        public bool IsEntityOrCollection
        {
            get { return this.isEntity | this.isCollection; }
        }

        public string InOutDeclarationString
        {
            get
            {
                bool doubleDecl = false;
                string decl = null;
                if (bIn)
                {
                    if (bOut)
                        decl = "[In, Out]";
                    else
                        decl = "[In]";
                }
                else
                {
                    if (bOut)
                        decl = "[Out]";
                }

                string csDecl = null;

                if (this.direction != System.CodeDom.FieldDirection.In)
                    csDecl = direction.ToString().ToLower();

                string s = null;
                if (decl != null)
                    s += decl;
                if (csDecl != null)
                {
                    if (s != null)
                    {
                        s += ", ";
                        doubleDecl = true;
                    }
                    s += "C# " + csDecl;
                }

                if (doubleDecl)
                    s += " (Double declaration!)";

                if (s == null)
                    s = "C# in";
                return s;
            }
        }

        /// <summary>
        /// If [In] or [Out] is not specified, the c# out or ref declarations are used..
        /// </summary>
        public bool InOutNotSpecified
        {
            get { return !bIn && !bOut; }
        }

        /// <summary>
        /// If [In] or [Out] is specified
        /// </summary>
        public bool InOutSpecified
        {
            get { return bIn || bOut; }
        }

        
    }

    public enum PropertyBuildMode
    {
        TypedGetSet = 0,
        Formatter = 1,
        Validator = 2
    }

    public enum FormatterPropertyKind
    {
        Default = 0,
        UseConvert = 1,
        UseAsIs = 2,
        NoImplementation = 3,
        Currency = 4,
        ShortDate = 5,
        USSSN = 6,
        USSSNInt = 7,
        USZipCode = 8,
        USZipCodeInt = 9,
        USPhoneNumber = 10,
        USPhoneNumberInt = 11,
        Int = 12,
        IntThousands = 13,
        Float = 14,
        FloatThousands = 15,
        Double = 16,
        DoubleThousands = 17,
        Decimal = 18,
        DecimalThousands = 19,
        Email = 20,
        URL = 21,
        Password = 22,
        USState = 23,
        IntLookup = 24,
        StringLookup = 25,
        Gender = 26
        //CreditCard
    }

	/// <summary>
	/// Summary description for Util.
	/// </summary>
	public class Util
	{
		protected const string DBExtPropMatch = "{(?<prop>[^{]+)}";

		// possible Entity Class attributes.
		// used to detect Entity Classes in the code.
		public static string[] EntityAttribs = 
			{ "TableMapping", "ColumnsMappingMode", "SQLHint" };
		public static string[] collectionClassAttribs = 
			{ "ElementType" };
		public static char[] blankChars = new char[] { ' ', '\t', '\r', '\n' };

		public static string spAutoGenRemark = "/*\r\n" +
			"**\r\n" +
			"**  Automatically generated by Netsoft USA Addin.\r\n" +
			"**\r\n" +
			"*/\r\n";

		/// <summary>
		/// Release COM object.
		/// </summary>
		/// <param name="o"></param>
		public static void NAR(object o)
		{
			try
			{
				//System.Runtime.InteropServices.Marshal.ReleaseComObject(o);
			}
			catch {}
			finally
			{
				o = null;
			}
		}

		public static void SetSetting(string relPath, string name, object val)
		{
			Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NetsoftUSA\Addin\Options\" + relPath, true);
			if (key == null)
				key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\NetsoftUSA\Addin\Options\" + relPath);
			key.SetValue(name, val);
		}

		public static object GetSetting(string relPath, string name, object defaultVal)
		{
			Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NetsoftUSA\Addin\Options\" + relPath, true);
			if (key == null)
				key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\NetsoftUSA\Addin\Options\" + relPath);

			object val = key.GetValue(name);
			if (val == null)
			{
				key.SetValue(name, defaultVal);
				return defaultVal;
			}
			return val;
		}

		public static bool GetSetting(string relPath, string name, bool defaultVal)
		{
			return Convert.ToBoolean( GetSetting(relPath, name, Convert.ToInt32(defaultVal)) );
		}

		public static void SetSetting(string relPath, string name, bool val)
		{
			SetSetting(relPath, name, Convert.ToInt32(val));
		}

		public static void LoadFormPos(System.Windows.Forms.Form form, bool loadsize)
		{
			string key = "__" + form.Name;
			form.Left = (int)Util.GetSetting(key, "Left", form.Left);
			form.Top = (int)Util.GetSetting(key, "Top", form.Top);
			if (loadsize)
			{
				form.Width = (int)Util.GetSetting(key, "Width", form.Width);
				form.Height = (int)Util.GetSetting(key, "Height", form.Height);
			}
		}

		public static void SaveFormPos(System.Windows.Forms.Form form)
		{
			string key = "__" + form.Name;
			Util.SetSetting(key, "Left", form.Left);
			Util.SetSetting(key, "Top", form.Top);
			Util.SetSetting(key, "Width", form.Width);
			Util.SetSetting(key, "Height", form.Height);
		}

		public static string ProjectPath
		{
			get
			{
				string s = Connect.Instance.CurrentProject.FullName;
				return Path.GetDirectoryName(s);
			}
		}

        public static string SolutionPath
        {
            get
            {
                string s = Connect.Instance.Solution2.FullName;
                return Path.GetDirectoryName(s);
            }
        }

		public static string CompleteProjectFilePath(string fileName)
		{
			string s = ProjectPath;
			return s + "\\" + fileName;
		}

        public static string CompleteSolutionFilePath(string fileName)
        {
            string s = SolutionPath;
            return s + "\\" + fileName;
        }

		public static string ProjectItemsTemplatePath
		{
			get
			{
                return Connect.Instance.Solution2.ProjectItemsTemplatePath(VSLangProj.PrjKind.prjKindCSharpProject);
				//return Connect.Instance.applicationObject.Solution.ProjectItemsTemplatePath(
					//VSLangProj.PrjKind.prjKindCSharpProject);
			}
		}

		public static string CompleteProjectItemTemplatePath(string templateName)
		{
            return Connect.Instance.Solution2.GetProjectItemTemplate(templateName, "CSharp");
			//string s = ProjectItemsTemplatePath;
			//return s + "\\" + fileName;
		}

		public static string ProjectConnectionString
		{
			get
			{
				return CompleteSolutionFilePath("NetsoftUSAAddinConnect.udl");
			}
		}

		public static OleDbConnection ProjectConnection
		{
			get
			{
				while (true)
				{
					try
					{
						OleDbConnection cnn = new OleDbConnection("File Name=" + ProjectConnectionString);
						cnn.Open();
						return cnn;
					}
					catch
					{
						string file = ProjectConnectionString;
						if (!File.Exists(file))
						{
							File.CreateText(file).Close();
						}
						System.Diagnostics.Process.Start(file);

						if (Connect.Instance.ShowDialog(null,
							"Project connection must be defined in " 
							+ file + ".  Define the connection in the opened udl file."
							+ "\r\nRetry?", 
							"Project Connection", 
							System.Windows.Forms.MessageBoxButtons.YesNo) != 
							System.Windows.Forms.DialogResult.Yes)
						{
							return null;
						}
					}
				}
			}
		}

		public static DataSet ExecuteDataset(string targetTable, CommandType commandType, string commandText, params object[] parameters)
		{
			DataSet ds = new DataSet();
			OleDbCommand cmd = new OleDbCommand();
			cmd.Connection = ProjectConnection;
			if (cmd.Connection == null)
				return null; 
			try
			{
				cmd.CommandType = commandType;
				cmd.CommandText = commandText;

				OleDbDataAdapter da = new OleDbDataAdapter(cmd);
			
				if (parameters != null)
					for (int i = 0; i < parameters.Length; i++)
					{
						object param = parameters[i];
						if (param is OleDbParameter)
							cmd.Parameters.Add(param);
						else
							cmd.Parameters.Add("@p"+i.ToString(), param);
					}

				if (targetTable != null)
					da.Fill(ds, targetTable);
				else
					da.Fill(ds);
			}
			finally
			{
				cmd.Connection.Close();
			}

			return ds;
		}

		public static int ExecuteNonQuery(CommandType commandType, string commandText, params object[] parameters)
		{
			OleDbCommand cmd = new OleDbCommand();
			cmd.Connection = ProjectConnection;
			if (cmd.Connection == null)
				return 0; 
			try
			{
				cmd.CommandType = commandType;
				cmd.CommandText = commandText;

				//OleDbDataAdapter da = new OleDbDataAdapter(cmd);
			
				if (parameters != null)
					for (int i = 0; i < parameters.Length; i++)
					{
						object param = parameters[i];
						if (param is OleDbParameter)
							cmd.Parameters.Add(param);
						else
							cmd.Parameters.Add("@p"+i.ToString(), param);
					}

				return cmd.ExecuteNonQuery();
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public static object GetVSNETTypeEnum(Type type)
		{
			if (type == typeof(void))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefVoid;
			if (type == typeof(bool))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefBool;
			if (type == typeof(byte))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefByte;
			if (type == typeof(char))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefChar;
			if (type == typeof(double))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefDouble;
			if (type == typeof(float))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefFloat;
			if (type == typeof(int))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefInt;
			if (type == typeof(long))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefLong;
			if (type == typeof(short))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefShort;
			if (type == typeof(string))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefString;
			if (type == typeof(DateTime))
				return "DateTime";
			if (type == typeof(object))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefObject;
			if (type == typeof(Array))
				return EnvDTE.vsCMTypeRef.vsCMTypeRefArray;

			return type.Name;
		}

		public static string NormalizeClassName(string name)
		{
			return NormalizeIdentifierName(name, false, "");
		}

		public static string CapitalizeString(string s, bool cap, bool lowerRest)
		{
			if (s == null)
				return s;

			if (s.Length == 0)
				return s;

			string firstLet = s.Substring(0, 1);

			string rest = s.Substring(1);
			if (lowerRest)
				rest = rest.ToLower();
			if (cap)
				s = firstLet.ToUpper() + rest;
			else
				s = firstLet.ToLower() + rest;

			return s;
		}

		public static string NormalizeIdentifierName(string name, bool camelNotation, string prefix)
		{
			if (camelNotation)
			{
				string[] terms = name.Split(' ', '_', '/', '-');
				if (terms.Length == 1)
					name = CapitalizeString(name, false, false);
				else
				{
					for (int i = 0; i < terms.Length; i++)
						terms[i] = CapitalizeString(terms[i], i > 0, true);
					name = string.Join("", terms);
				}
			}
			else
			{
				name = name.Replace(" ", "_");
				name = name.Replace("/", "_");
				name = name.Replace("-", "_");
			}
			return prefix + name;
		}

		public static DataTable GetTablePrototype(string tableName)
		{
			string sql = "SELECT * FROM [" + tableName + "] WHERE 1=2";
			DataSet ds = Util.ExecuteDataset(tableName, CommandType.Text, 
				sql, null);

			FillTableColumnInfo(ds.Tables[0]);

			return ds.Tables[0];
		}

		public static void AlterColumn(string tableName, string columnName, string definition)
		{
			string sql = "ALTER TABLE [" + tableName + "] ALTER COLUMN [" + columnName + "] " + definition;
			if ( Util.ExecuteNonQuery (CommandType.Text, sql) > 0)
				Debug.WriteLine("FAILED:  " + sql);
			else
				Debug.WriteLine(sql);
		}

		public static void AddColumn(string tableName, string columnName, string definition)
		{
			string sql = "ALTER TABLE [" + tableName + "] ADD [" + columnName + "] " + definition;
			if ( Util.ExecuteNonQuery (CommandType.Text, sql) > 0)
				Debug.WriteLine("FAILED:  " + sql);
			else
				Debug.WriteLine(sql);
		}

		public static void DropColumn(string tableName, string columnName)
		{
			string sql = "ALTER TABLE [" + tableName + "] DROP COLUMN [" + columnName + "]";
			if ( Util.ExecuteNonQuery (CommandType.Text, sql) > 0)
				Debug.WriteLine("FAILED:  " + sql);
			else
				Debug.WriteLine(sql);
		}

		public static void RenameColumn(string tableName, string columnName, string newColumnName)
		{
			string sql = "sp_rename '" + tableName + ".[" + columnName + "]', '" + newColumnName + "', 'COLUMN'";
			if ( Util.ExecuteNonQuery (CommandType.Text, sql) > 0)
				Debug.WriteLine("FAILED:  " + sql);
			else
				Debug.WriteLine(sql);
		}

		public static void FillTableColumnInfo(DataTable table)
		{
			DataSet dsCols = Util.ExecuteDataset(null, 
				CommandType.StoredProcedure, "[dbo].[sp_columns]", new OleDbParameter("@table_name", table.TableName));
			if (dsCols != null)
			{
				DataTable tblCols = dsCols.Tables[0];
				for (int i = 0; i < table.Columns.Count; i++)
				{
					DataColumn col = table.Columns[i];
					if (true) //col.DataType == typeof(string) || col.DataType == typeof(byte[]))
					{
						string colName = col.ColumnName;
						DataRow[] rows = tblCols.Select("[COLUMN_NAME]='" + colName + "'");
						if (rows != null)
							if (rows.Length > 0)
							{
								DataRow row = rows[0];
								if (col.DataType == typeof(string))
									col.MaxLength = (int)row["LENGTH"];
								col.ExtendedProperties["TYPE_NAME"] = row["TYPE_NAME"];
								col.ExtendedProperties["PRECISION"] = row["PRECISION"];
								col.ExtendedProperties["LENGTH"] = row["LENGTH"];
								col.ExtendedProperties["SCALE"] = row["SCALE"];
								
								try
								{
									col.AllowDBNull = Convert.ToBoolean(row["NULLABLE"]);
								}
								catch
								{
								}
							}
					}
				}
			}
		}

		public static string GetColumnDescriptionFromDB(string tblName, string colName)
		{
			string sql = String.Format("SELECT * FROM ::FN_LISTEXTENDEDPROPERTY('MS_Description', 'User', 'dbo', 'TABLE', '{0}', 'COLUMN', '{1}')",
				tblName, colName);
			DataSet ds = Util.ExecuteDataset(null, 
				CommandType.Text, sql);
			if (ds != null)
			{
				DataTable tbl = ds.Tables[0];
				for (int i = 0; i < tbl.Rows.Count; i ++)
				{
					DataRow row = tbl.Rows[i];
					return Convert.ToString(row["value"]);
				}
			}

			return null;
		}

		/// <summary>
		/// Parse extended properties included in the MS_Description property of a column.
		/// e.g.:
		///			Description = "Social Security Number{StereoType=USSSN}"
		/// </summary>
		/// <param name="s"></param>
		/// <param name="desc"></param>
		/// <param name="extproperties"></param>
		public static void ParseColumnDescription(string s, out string desc, Hashtable extproperties)
		{
			Regex regex = new Regex(DBExtPropMatch, 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			string substituted = "";
			Match match;
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(s); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string prop = match.Groups["prop"].Value;
				ipos = match.Groups["prop"].Index - 1;
				int ilen = prop.Length;
				if (ilen > 0)
				{
					substituted += s.Substring(lastpos, ipos - lastpos);
					string[] terms = Util.SplitString(prop, new char[] { '=' }, new char[] { ' ' });
					if (terms.Length > 1)
						extproperties[terms[0]] = terms[1];
					else
					{
						extproperties["StereoType"] = terms[0];		// it must be the stereotype specified
					}
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = s.Length;
			substituted += s.Substring(lastpos, ipos - lastpos);
			desc = substituted.Trim();
		}

		public static string GetExtendedPropertiesForColumn(string tblName, string colName, CodeVariable var, DataColumn col)
		{
			string colDesc = GetColumnDescriptionFromDB(tblName, colName);
			if (colDesc == null)
				return null;
			string desc;
			Hashtable extprops = new Hashtable();
			ParseColumnDescription(colDesc, out desc, extprops);

			string s = null;
			foreach (DictionaryEntry di in extprops)
			{
				if (s != null)
					s += ",";
				string key = (string)di.Key;
				s += key;
				s += "=";
				string sval = (string)di.Value;
				if (key == "StereoType")
				{
					if (sval.IndexOf('.') < 0)
						sval = "DataStereoType." + sval;
				}
				s += sval;
			}
			return s;
		}

		public static string GetDescForColumn(string tblName, string colName)
		{
			string colDesc = GetColumnDescriptionFromDB(tblName, colName);
			if (colDesc == null)
				return null;
			string desc;
			Hashtable extprops = new Hashtable();
			ParseColumnDescription(colDesc, out desc, extprops);
			return desc;
		}

		public static string[] GetStoredProcsFromDB()
		{
			ArrayList arr = new ArrayList();
			DataSet dsCols = Util.ExecuteDataset(null, 
				CommandType.StoredProcedure, "[dbo].[sp_stored_procedures]");
			if (dsCols != null)
			{
				DataTable tbl = dsCols.Tables[0];
				for (int i = 0; i < tbl.Rows.Count; i ++)
				{
					DataRow row = tbl.Rows[i];
					string proc = Convert.ToString(row["PROCEDURE_NAME"]);
					proc = proc.Split(';')[0];
					arr.Add(proc);
				}
			}
			return (string[])arr.ToArray(typeof(string));
		}

		public static string GetStoredProcFromDB(string spName)
		{
			DataSet dsCols = Util.ExecuteDataset(null, 
				CommandType.StoredProcedure, "[dbo].[sp_stored_procedures]", new OleDbParameter("@sp_name", spName));
			if (dsCols != null)
			{
				DataTable tbl = dsCols.Tables[0];
				if (tbl.Rows.Count > 0)
					return spName;
			}
			return null;
		}

		public static string GetStoredProcContentFromDB(string spName)
		{
			DataSet dsCols = null;
			try
			{
				dsCols = Util.ExecuteDataset(null, 
					CommandType.StoredProcedure, "[dbo].[sp_helptext]", new OleDbParameter("@sp_name", spName));
			}
			catch
			{
			}
			if (dsCols != null)
			{
				DataTable tbl = dsCols.Tables[0];
				if (tbl.Rows.Count > 0)
				{
					string s = "";
					for (int i = 0; i < tbl.Rows.Count; i++)
					{
						s += Convert.ToString(tbl.Rows[i][0]);
					}
					return s;
				}
			}
			return null;
		}

		public static bool ExistsStoredProcFromDB(string spName)
		{
			try
			{
				string sp = GetStoredProcFromDB(spName);
				if (sp == null)
					return false;
				else
					return true;
			}
			catch
			{
				return false;
			}
		}

		public static bool SetStoredProcOnDB(System.Windows.Forms.Form callingForm, string spName, string spText, bool recreate, bool throwExp)
		{
			if (spText != null)
			{
				if (ExistsStoredProcFromDB(spName))
				{
					if (!recreate)		// if recreate not specified alter!
						return false;

					if (spText.Substring(0, 7).ToUpper() == "CREATE ")
						spText = "ALTER " + spText.Substring(7);
				}

				OleDbCommand cmd = new OleDbCommand();
				cmd.Connection = Util.ProjectConnection;
				if (cmd.Connection == null)
					return false;

				try
				{
					cmd.CommandText = spText;
					cmd.ExecuteNonQuery();
				}
				catch(Exception ex)
				{
					if (throwExp)
						throw;
					Connect.Instance.ShowDialog(callingForm, String.Format("Can't create stored procedure\r\n{0}\r\n\r\n{1}", 
						spText,
						ex.Message));
				}
				finally
				{
					cmd.Connection.Close();
				}
				return true;
			}
			
			return false;
		}

		public static void DropStoredProcOnDB(System.Windows.Forms.Form callingForm, string spName)
		{
			OleDbCommand cmd = new OleDbCommand();
			cmd.Connection = Util.ProjectConnection;
			if (cmd.Connection == null)
				return;
			
			cmd.CommandText = "DROP PROCEDURE " + spName;
			try
			{
				cmd.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(callingForm, String.Format("Can't drop stored procedure\r\n{0}", 
					ex.Message));
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public static string[] GetStoredProcParameters(string spName)
		{
			OleDbCommand cmd = new OleDbCommand(spName, Util.ProjectConnection);
			if (cmd.Connection == null)
				return null;

			try
			{
				cmd.CommandType = CommandType.StoredProcedure;
				OleDbCommandBuilder.DeriveParameters(cmd);
				cmd.Parameters.RemoveAt(0);		// remove return value param

				string[] spParams = new string[cmd.Parameters.Count];
				for (int i = 0; i < cmd.Parameters.Count; i++)
				{
					spParams[i] = cmd.Parameters[i].ParameterName.Trim('@');
				}
				return spParams;
			}
			catch
			{
				return null;
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public static OleDbParameterCollection GetStoredProcParameterCollection(string spName)
		{
			OleDbCommand cmd = new OleDbCommand(spName, Util.ProjectConnection);
			if (cmd.Connection == null)
				return null;

			try
			{
				cmd.CommandType = CommandType.StoredProcedure;
				OleDbCommandBuilder.DeriveParameters(cmd);
				cmd.Parameters.RemoveAt(0);		// remove return value param
				return cmd.Parameters;
			}
			catch
			{
				return null;
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public static string GetStoredProcParametersJoined(string spName)
		{
			return String.Join(", ", GetStoredProcParameters(spName));
		}

		public static string GetStoredProcParametersAsParams(string spName)
		{
			return Util.JoinStrings(", ", GetStoredProcParameters(spName), "@{0}");
		}

		public static void FillTableNamesInCombo(System.Windows.Forms.ComboBox cb, bool unmappedOnly)
		{
			cb.Items.Clear();
			cb.Items.AddRange(GetTableNames(unmappedOnly));
		}

		public static void FillTableColumnsInCombo(DataTable tbl, System.Windows.Forms.ComboBox cb)
		{
			cb.Items.Clear();
			foreach (DataColumn col in tbl.Columns)
				cb.Items.Add(col.ColumnName);
		}

		public static void FillClassNames(System.Windows.Forms.ListBox list, object[] classes, bool clear)
		{
			if (clear)
				list.Items.Clear();
			for (int i = 0; i < classes.Length; i++)
			{
				CodeClass cls = (CodeClass)classes[i];
				list.Items.Add(cls.Name);
			}
		}

		public static void FillClassNames(System.Windows.Forms.ComboBox list, object[] classes, bool clear, bool withAssemblyName)
		{
			if (clear)
				list.Items.Clear();
			for (int i = 0; i < classes.Length; i++)
			{
				CodeClass cls = (CodeClass)classes[i];
				if (withAssemblyName)
				{
					string assemblyName = cls.ProjectItem.ContainingProject.Name;
					list.Items.Add(cls.Name + "," + assemblyName);
				}
				else
					list.Items.Add(cls.Name);
			}
		}

		public static object[] GetTableNames(bool unmappedOnly)
		{
			ArrayList arr = new ArrayList();
			DataSet ds = Util.ExecuteDataset("tables", CommandType.StoredProcedure, "sp_tables", null);
			DataTable tbl = ds.Tables[0];
			
			Hashtable classTableMappings = null;

			if (unmappedOnly)
				classTableMappings = Util.FindClassTableMappingsInProject();

			for (int i = 0; i < tbl.Rows.Count; i ++)
			{
				DataRow row = tbl.Rows[i];

				string type = ((string)row["TABLE_TYPE"]).ToUpper();
				string tblName = (string)row["TABLE_NAME"];

				if (type == "TABLE")
				{
					if (unmappedOnly && classTableMappings != null)
					{
						if (!classTableMappings.ContainsValue(tblName))
							arr.Add(tblName);
					}
					else
						arr.Add(tblName);
				}
			}

			return (object[])arr.ToArray(typeof(object));
		}

		public static string[] GetPrimaryKeys(string tableName)
		{
			ArrayList arr = new ArrayList();
			//OleDbParameterCollection pars = new OleDbParameterCollection();
			//pars.Add("@tableName", tableName);
			DataSet ds = Util.ExecuteDataset("keys", CommandType.StoredProcedure, "sp_pkeys",
				tableName);
			DataTable tbl = ds.Tables[0];
			for (int i = 0; i < tbl.Rows.Count; i ++)
			{
				DataRow row = tbl.Rows[i];

				string colName = ((string)row["COLUMN_NAME"]);

				arr.Add(colName);
			}

			string[] keys = new string[arr.Count];
			arr.CopyTo(keys);
			return keys;
		}

		public static string GetPrimaryKey(string tableName)
		{
			string[] keys = GetPrimaryKeys(tableName);
			if (keys == null)
				return null;
			if (keys.Length > 0)
				return keys[0];
			return null;
		}

		public static string[] ParseAttribExpression(string s)
		{
			ArrayList arr = new ArrayList();
			string word = "";
			bool inQuote = false;
			for (int i = 0; i < s.Length; i++)
			{
				switch (s[i])
				{
					case '\"':
						word += s[i].ToString();
						inQuote = !inQuote;
						break;
					case ',':
						if (inQuote)
							word += s[i].ToString();
						else
						{
							arr.Add(word);
							word = "";
						}
						break;
					default:
						word += s[i].ToString();
						break;
				}
			}
			if (word != "")
				arr.Add(word);
			string[] terms = new string[arr.Count];
			arr.CopyTo(terms);
			return terms;
		}

		// parse an attribute declaration line and find the paramName given
		// if paramName not found, use the index specified to access the parameter
		// without name
		public static string GetParamFromAttrib(CodeAttribute att, string paramName, int paramIndex)
		{
			string[] terms = ParseAttribExpression(att.Value);

			string sval = null;

			for (int i = 0; i < terms.Length; i++)
			{
				sval = terms[i].Trim();
				if (sval[0] != '\"')
				{
					int eqIndex = sval.IndexOf('=');
					if (eqIndex >= 0)
					{
						string left = sval.Substring(0, eqIndex).Trim();
						string right = sval.Substring(eqIndex + 1);
						if (left == paramName)
							return right.Trim(' ').Trim('\"');
					}
				}
			}

			if (paramIndex >= 0 && paramIndex < terms.Length)
			{
				sval = terms[paramIndex].Trim();

				if (sval.Length >= 2)
					if (sval.IndexOf('\"', 1, sval.Length - 2) < 0)
						if (sval.IndexOf('=') >= 0)
							return null;   // this may be another param with name
			
				return sval.Trim(' ').Trim('\"');
				/*
				if (sval.Length > 0)
				{
					if (sval[0] == '\"')
						return sval.Trim(' ').Trim('\"');
				}*/
			}

			return null;
		}

		/*
		public static string GetParamFromAttrib(CodeAttribute att, string paramName, int paramIndex)
		{
			string[] terms = att.Value.Split(',');
			string sval = null;

			if (paramIndex < terms.Length)
			{
				sval = terms[paramIndex].Trim();
			
				if (sval.Length > 0)
				{
					if (sval[0] == '\"')
						return sval.Trim('\"');
				}
			}

			sval = att.Value.Trim();
			int i = sval.IndexOf(paramName + "=");
			if (i >= 0)
			{
				string s = sval.Substring(i + paramName.Length + 1);
				s = s.Split(',')[0].Trim();
				return s.Trim('\"');
			}
				
			// return as is
			if (paramIndex < terms.Length)
			{
				sval = terms[paramIndex].Trim();
			
				return sval;
			}

			return null;
		}*/

		/// <summary>
		/// Parse an expression in the from "somthing.flag1|somthing.flag2|somthing.flag3"
		/// </summary>
		public static ArrayList ParseFlags(string exp, bool afterDot)
		{
			ArrayList arr = new ArrayList();
			if (exp != null)
			{
				string[] terms =  exp.Split('|', '&');
				for (int i = 0; i < terms.Length; i++)
				{
					string s = terms[i].Trim();
					if (afterDot)
						s = Util.GetLastTerm(s);
					arr.Add(s);
				}
			}
			return arr;
		}

		public static int FindStringInArray(ArrayList arr, string s)
		{
			if (arr == null)
				return -1;
			for (int i = 0; i < arr.Count; i++)
				if ((string)arr[i] == s)
					return i;

			return -1;
		}

		public static CodeAttribute FindAttribute(CodeClass cls, string attribName)
		{
            if (cls == null)
                return null;
			CodeAttribute att = FindAttribute(cls.Attributes, attribName);
			if (att != null)
				return att;

			// try base class

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					att = FindAttribute(cls.Bases.Item(i) as CodeClass, attribName);
					if (att != null)
						return att;
				}
			}

			return null;
		}

		public static CodeAttribute FindAttribute(CodeElements attribs, string attribName)
		{
			for (int i = 1; i <= attribs.Count; i++)
			{
				CodeAttribute att = attribs.Item(i) as CodeAttribute;
				if (att.Name == attribName)
					return att;
			}
			return null;
		}

		public static string GetFullClassName(CodeClass cls)
		{
			return cls.FullName + "," + cls.ProjectItem.ContainingProject.Name;
		}

		public static bool IsMemberMapped(CodeClass cls, string memName)
		{
			string colName = Util.GetColMappingForMember(cls, memName, false);
			if (colName != null && colName != "")
				return true;
			else
				return false;
		}

		public static string GetColMappingForMember(CodeClass cls, string memberName)
		{
			return GetColMappingForMember(cls, memberName, true);
		}

		public static string GetColMappingForMember(CodeClass cls, string memberName, bool useMemberName)
		{
			CodeVariable var = Util.FindFirstMember(cls, memberName) as CodeVariable;
			if (var != null)
				return Util.GetColMappingForVar(var, useMemberName);
			CodeProperty prop = Util.FindFirstMember(cls, memberName) as CodeProperty;
			if (prop != null)
				return Util.GetColMappingForProp(prop, useMemberName);
			return null;
		}

		public static string[] GetColMappingsForMembers(CodeClass cls, string[] memberNames)
		{
			if (memberNames == null)
				return null;
			string[] cols = new string[memberNames.Length];
			for (int i = 0; i < memberNames.Length; i++)
				cols[i] = GetColMappingForMember(cls, memberNames[i]);

			return cols;
		}

		public static CodeAttribute GetColMappingAtt(CodeVariable var)
		{
			if (var == null)
				return null;
			CodeAttribute att = FindAttribute(var.Attributes, "ColumnMapping");
			return att;
		}

		public static string GetColMappingForVar(CodeVariable var, bool UseMemberName)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ColumnMapping");
			if (att == null)
				if (UseMemberName)
					return var.Name;
				else
					return null;
			string colName = Util.GetParamFromAttrib(att, "ColumnName", 0);
			
			if (colName == null)
				if (UseMemberName)
					return var.Name;

			return GetLastTerm(colName);
		}

		public static string GetColMappingForVar(CodeVariable var)
		{
			return GetColMappingForVar(var, true);
		}

		public static string GetColMappingForProp(CodeProperty prop)
		{
			return GetColMappingForProp(prop, true);
		}

		public static string GetColMappingForProp(CodeProperty prop, bool UseMemberName)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "ColumnMapping");
			if (att == null)
				if (UseMemberName)
					return prop.Name;
				else
					return null;
			string colName = Util.GetParamFromAttrib(att, "ColumnName", 0);
			if (colName == null)
				if (UseMemberName)
					return prop.Name;
			return colName;
		}

		public static bool HasJoinRelation(CodeAttribute att)
		{
			if (att == null)
				return false;
			string j = Util.GetParamFromAttrib(att, "JoinRelation", -1);
			return j != null && j != "";
		}

		public static string GetJoinRelationForVar(CodeVariable var)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ColumnMapping");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "JoinRelation", -1);
		}

		public static string GetJoinRelationForProp(CodeProperty prop)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "ColumnMapping");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "JoinRelation", -1);
		}

		public static bool GetSPLoadChildForProp(CodeProperty prop, ref string spName, ref string fkMembers, ref string manuallyManaged)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "SPLoadChild");
			if (att == null)
				return false;
			spName = Util.GetParamFromAttrib(att, "spName", 0);
			fkMembers = Util.GetParamFromAttrib(att, "fkMembers", 1);
			manuallyManaged = Util.GetParamFromAttrib(att, "ManuallyManaged", -1);
			return true;
		}

		public static string GetDeclaredValueForNullForVar(CodeVariable var)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ColumnMapping");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "ValueForNull", 1);
		}

		//

		public static CodeTypeRef GetCodeTypeRefForMember(CodeElement member)
		{
			CodeVariable var = member as CodeVariable;
			if (var != null)
				return var.Type;
			CodeProperty prop = member as CodeProperty;
			if (prop != null)
				return prop.Type;
			return null;
		}

		public static string GetStereoTypeForMember(CodeClass cls, string memberName)
		{
			CodeVariable var = Util.FindFirstMember(cls, memberName) as CodeVariable;
			if (var != null)
				return Util.GetStereoTypeForVar(var);
			CodeProperty prop = Util.FindFirstMember(cls, memberName) as CodeProperty;
			if (prop != null)
				return Util.GetStereoTypeForProp(prop);
			return null;
		}

		public static string GetStereoTypeForMember(CodeElement member)
		{
			CodeVariable var = member as CodeVariable;
			if (var != null)
				return Util.GetStereoTypeForVar(var);
			CodeProperty prop = member as CodeProperty;
			if (prop != null)
				return Util.GetStereoTypeForProp(prop);
			return null;
		}

		public static string GetStereoTypeForVar(CodeVariable var)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ColumnMapping");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "StereoType", -1);
		}

		public static string GetStereoTypeForProp(CodeProperty prop)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "ColumnMapping");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "StereoType", -1);
		}
		//

		public static string GetElementTypeForClass(CodeClass cls)
		{
			if (cls == null)
				return null;
			CodeAttribute att = FindAttribute(cls, "ElementType");		// checks base classes too
			if (att == null)
				return null;
			string elemType = Util.GetParamFromAttrib(att, "ElementType", 0);
			if (elemType == null)
				return null;
			int i = elemType.IndexOf("typeof(");
			if (i < 0)
				return null;
			elemType = elemType.Substring(6).Trim('(', ')');
			return elemType;
		}

		public static string GetTableMappingForClass(CodeClass cls, bool useDefault)
		{
			if (cls == null)
				return null;
			CodeAttribute att = FindAttribute(cls, "TableMapping");  // checks base classes too
			if (att == null)
				if (useDefault)
					return cls.Name;
				else
					return null;
			string tableName = Util.GetParamFromAttrib(att, "TableName", 0);
			if (tableName == null)
				if (useDefault)
					return cls.Name;
				else
					return null;
			return tableName;
		}

		public static string GetTableMappingForClass(CodeClass cls)
		{
			return GetTableMappingForClass(cls, true);
		}

		public static CodeElements GetAttributes(CodeElement elem)
		{
			CodeVariable var = elem as CodeVariable;
			if (var != null)
				return var.Attributes;
			CodeProperty prop = elem as CodeProperty;
			if (prop != null)
				return prop.Attributes;
			CodeClass cls = elem as CodeClass ;
			if (cls != null)
				return cls.Attributes;
			return null;
		}

		public static string GetFieldValuesForClassMember(CodeClass cls, string memberName)
		{
			CodeElement elem = FindFirstMember(cls, memberName);
			if (elem == null)
				return null;
			return GetFieldValuesForClassMember(elem);
		}

		public static string GetFieldValuesForClassMember(CodeElement elem)
		{
			CodeElements attribs = GetAttributes(elem);
			if (attribs == null)
				return null;
			CodeAttribute att = FindAttribute(attribs, "FieldValuesMember");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "fieldValuesMember", 0);
		}

		public static string GetFieldDescriptionForClassMember(CodeClass cls, string memberName, bool useDefault)
		{
			CodeElement elem = FindFirstMember(cls, memberName);
			if (elem == null)
				return null;
			return GetFieldDescriptionForClassMember(elem, useDefault);
		}

		public static string GetFieldDescriptionForClassMember(CodeElement elem, bool useDefault)
		{
			CodeElements attribs = GetAttributes(elem);
			string desc = null;
			if (attribs != null)
			{
				CodeAttribute att = FindAttribute(attribs, "FieldDescription");
				if (att != null)
					desc = Util.GetParamFromAttrib(att, "Description", 0);
			}
			if (desc == null)
				if (useDefault)
					desc = elem.Name;
			return desc;
		}

		public static string GetInputMaskForMember(CodeElement elem)
		{
			CodeElements attribs = GetAttributes(elem);
			if (attribs != null)
			{
				CodeAttribute att = FindAttribute(attribs, "FieldDescription");
				if (att != null)
					return Util.GetParamFromAttrib(att, "InputMask", -1);
			}
			return null;
		}

		public static string GetSPDeclarationForClass(CodeClass cls, string attribName)
		{
			CodeAttribute att = FindAttribute(cls, attribName);
			if (att == null)
				return null;
			string spName = Util.GetParamFromAttrib(att, "spName", 0);
			string ManuallyManaged = Util.GetParamFromAttrib(att, "ManuallyManaged", -1);
			if (ManuallyManaged != "true")
				return spName;
			else
				return "*" + spName + "*";	// manually managed sp returns "spName*"
		}

		public static string GetSPExistsForClass(CodeClass cls, bool useDefault)
		{
			string sp = GetSPExistsForClass(cls);
			if (sp == null)
				if (useDefault)
					sp = MakeSPExistsByPKName(cls.Name);
			return sp;
		}

		public static string GetSPExistsForClass(CodeClass cls)
		{
			return GetSPDeclarationForClass(cls, "SPExists");
		}

		public static string GetSPLoadForClass(CodeClass cls, bool useDefault)
		{
			string sp = GetSPLoadForClass(cls);
			if (sp == null)
				if (useDefault)
					sp = MakeSPLoadByPKName(cls.Name);
			return sp;
		}

		public static string GetSPLoadForClass(CodeClass cls)
		{
			return GetSPDeclarationForClass(cls, "SPLoad");
		}

		public static string GetSPDeleteForClass(CodeClass cls)
		{
			return GetSPDeclarationForClass(cls, "SPDelete");
		}

		public static string GetSPDeleteForClass(CodeClass cls, bool useDefault)
		{
			string sp = GetSPDeleteForClass(cls);
			if (sp == null)
				if (useDefault)
					sp = MakeSPDeleteName(cls.Name);
			return sp;
		}

		public static string GetSPUpdateForClass(CodeClass cls)
		{
			return GetSPDeclarationForClass(cls, "SPUpdate");
		}

		public static string GetSPUpdateForClass(CodeClass cls, bool useDefault)
		{
			string sp = GetSPUpdateForClass(cls);
			if (sp == null)
				if (useDefault)
					sp = MakeSPUpdateName(cls.Name);
			return sp;
		}

		public static string GetSPInsertForClass(CodeClass cls)
		{
			return GetSPDeclarationForClass(cls, "SPInsert");
		}

		public static string GetSPInsertForClass(CodeClass cls, bool useDefault)
		{
			string sp = GetSPInsertForClass(cls);
			if (sp == null)
				if (useDefault)
					sp = MakeSPInsertName(cls.Name);
			return sp;
		}

		public static bool GetMainLanguageClassForForm(CodeClass clsPage, ref string assemblyName, ref string className)
		{
			CodeAttribute att = FindAttribute(clsPage, "MainLanguageClass");
			if (att == null)
				return false;
			className = Util.GetParamFromAttrib(att, "ClassName", 0);
			if (className == null)
				return false;
			string[] terms = className.Split(',');
			if (terms.Length > 1)
				assemblyName = terms[1].Trim();
			else
				assemblyName = clsPage.ProjectItem.ContainingProject.Name;
			className = Util.GetLastTerm(terms[0]).Trim();
			return true;
		}

		public static CodeClass GetMainLanguageClassForForm(CodeClass clsPage)
		{
			if (clsPage == null)
				return null;
			string assemblyName = null;
			string languageClass = null;
			if (Util.GetMainLanguageClassForForm(clsPage, ref assemblyName, ref languageClass))
			{
				Project prj = FindProjectInSolution(assemblyName);
				if (prj == null)
					return null;
				CodeClass cls = FindClassInProject(prj, languageClass);
				NAR(prj);
				return cls;
			}
			return null;
		}

		public static bool GetMainEntityForForm(CodeClass clsPage, ref string assemblyName, ref string className)
		{
			CodeAttribute att = FindAttribute(clsPage, "MainEntity");
			if (att == null)
				return false;
			className = Util.GetParamFromAttrib(att, "ClassName", 0);
			if (className == null)
				return false;
			string[] terms = className.Split(',');
			if (terms.Length > 1)
				assemblyName = terms[1].Trim(' ');
			else
				assemblyName = clsPage.ProjectItem.ContainingProject.Name;
			className = Util.GetLastTerm(terms[0].Trim(' '));
			return true;
		}

		public static CodeClass GetMainEntityForForm(CodeClass clsPage)
		{
			if (clsPage == null)
				return null;
			string assemblyName = null;
			string Entity = null;
			if (Util.GetMainEntityForForm(clsPage, ref assemblyName, ref Entity))
			{
				Project prj = FindProjectInSolution(assemblyName);
				if (prj == null)
					return null;
				CodeClass cls = FindClassInProject(prj, Entity);
				NAR(prj);
				return cls;
			}
			return null;
		}

		public static void DeclareNonSerialized(CodeVariable var)
		{
			// Mark this as nonserialized
			EditPoint ep = var.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert("\r\n\t\t[NonSerialized]");
		}

		public static void DeclareContainedAttrib(CodeProperty prop)
		{
			EditPoint ep = prop.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[Contained]"));
		}

        public static void DeclareChildCollectionAttrib(CodeProperty prop, CodeClass childEntityType, string fk)
        {
            EditPoint ep = prop.StartPoint.CreateEditPoint();
            ep.LineUp(1);
            ep.EndOfLine();
            ep.Insert(String.Format("\r\n\t\t[ChildCollection(typeof({0}), \"{1}\")]", childEntityType.Name, fk));
        }

		public static void DeclareSimpleRelationAttrib(CodeProperty prop, string pk, string fk)
		{
			EditPoint ep = prop.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[SimpleRelation(\".[{0}]\", \".[{1}]\")]", pk, fk));
		}

		public static void DeclareSPLoadChildAttrib(CodeProperty prop, string sp, string fk)
		{
			EditPoint ep = prop.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[SPLoadChild(\"{0}\", \"{1}\")]", sp, fk));
		}

		public static void DeclareMainEntityAttrib(CodeClass pageClass, CodeClass Entity)
		{
			EditPoint ep = pageClass.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			string assemblyName = Entity.ProjectItem.ContainingProject.Name;
			ep.Insert(String.Format("\r\n\t[MainEntity(\"{0},{1}\")]", Entity.FullName, assemblyName));
		}

		public static void DeclareMainLanguageClassAttrib(CodeClass pageClass, CodeClass languageClass)
		{
			EditPoint ep = pageClass.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			string assemblyName = languageClass.ProjectItem.ContainingProject.Name;
			ep.Insert(String.Format("\r\n\t[MainLanguageClass(\"{0},{1}\")]", languageClass.FullName, assemblyName));
		}

		public static void DeclareStoredProcAttribOnClass(CodeClass cls, string attribName, string spName)
		{
			EditPoint ep = cls.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t[{0}(\"{1}\")]", attribName, spName ));
		}

		public static void DeclareSPAutoGenAttribOnClass(CodeClass cls, string spName, string templateName, string args, SPGenerationInjections injections)
		{
			EditPoint ep = cls.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			string s = String.Format("\r\n\t[SPAutoGen(\"{0}\",\"{1}\",\"{2}\"", spName, templateName, args );
			if (injections != null)
			{
				if (injections.InjectPreOperation != null && injections.InjectPreOperation != "")
				{
					//string inject = s.Replace("\r\n", "\\");
					s += ", InjectPreOperation=\"" + injections.InjectPreOperation + "\"";
				}
				if (injections.InjectPostOperation != null && injections.InjectPostOperation != "")
					s += ", InjectPostOperation=\"" + injections.InjectPostOperation + "\"";
				if (injections.InjectWhere != null && injections.InjectWhere != "")
					s += ", InjectWhere=\"" + injections.InjectWhere + "\"";
				if (injections.InjectOrderBy != null && injections.InjectOrderBy != "")
					s += ", InjectOrderBy=\"" + injections.InjectOrderBy + "\"";
				if (injections.InjectParameters != null && injections.InjectParameters != "")
					s += ", InjectParameters=\"" + injections.InjectParameters + "\"";
			}
			ep.Insert(s + ")]");
		}

		public static void DeclareValidatorMemberAttrib(CodeElement elem, CodeProperty validatorProp)
		{
			EditPoint ep = elem.StartPoint.CreateEditPoint();
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[ValidatorMember(\"{0}\")]", validatorProp.Name));
		}

		public static string GetSuggestedControlTypeForFormatterProp(FormatterPropBuildOptions fmtBuildOptions, FormatterPropertyKind kind)
		{
			switch (kind)
			{
				case FormatterPropertyKind.Currency:
					return "Macro=EnumControlTypeMacros.Currency";
				case FormatterPropertyKind.Decimal:
					return "Macro=EnumControlTypeMacros.Double";
				case FormatterPropertyKind.DecimalThousands:
					return "Macro=EnumControlTypeMacros.DoubleThousands";
				case FormatterPropertyKind.Double:
					return "Macro=EnumControlTypeMacros.Double";
				case FormatterPropertyKind.DoubleThousands:
					return "Macro=EnumControlTypeMacros.DoubleThousands";
				case FormatterPropertyKind.Float:
					return "Macro=EnumControlTypeMacros.Double";
				case FormatterPropertyKind.FloatThousands:
					return "Macro=EnumControlTypeMacros.DoubleThousands";
				case FormatterPropertyKind.Int:
					return "Macro=EnumControlTypeMacros.Int";
				case FormatterPropertyKind.IntLookup:
					return "Macro=EnumControlTypeMacros.IntLookup";
				case FormatterPropertyKind.StringLookup:
					return "Macro=EnumControlTypeMacros.StringLookup";
				case FormatterPropertyKind.IntThousands:
					return "Macro=EnumControlTypeMacros.IntThousands";

				case FormatterPropertyKind.ShortDate:
					return "Macro=EnumControlTypeMacros.ShortDate";
				case FormatterPropertyKind.USPhoneNumber:
				case FormatterPropertyKind.USPhoneNumberInt:
					return "Macro=EnumControlTypeMacros.USPhoneNumber";
				case FormatterPropertyKind.USSSN:
				case FormatterPropertyKind.USSSNInt:
					return "Macro=EnumControlTypeMacros.USSSN";
				case FormatterPropertyKind.USZipCode:
				case FormatterPropertyKind.USZipCodeInt:
					return "Macro=EnumControlTypeMacros.USZipCode";
				case FormatterPropertyKind.Email:
					return "Macro=EnumControlTypeMacros.Email";
				case FormatterPropertyKind.URL:
					return "Macro=EnumControlTypeMacros.URL";
				case FormatterPropertyKind.Password:
					return "Macro=EnumControlTypeMacros.Password";
				case FormatterPropertyKind.USState:
					return "Macro=EnumControlTypeMacros.USState";
				case FormatterPropertyKind.Gender:
					return "Macro=EnumControlTypeMacros.Gender";
				default:
					return null;		// no suggestion !
			}
		}

		public static void DeclareControlTypeAttribOnProp(CodeProperty prop, CodeVariable var, DataColumn dataCol, PropertyBuildMode mode, FormatterPropBuildOptions fmtBuildOptions, FormatterPropertyKind kind)
		{
			Type type = null;
			string valueForNullDecl = "";
			if (dataCol != null)
				type = dataCol.DataType;
			EditPoint epCtlTypeAtt = prop.StartPoint.CreateEditPoint();
			epCtlTypeAtt.LineUp(1);
			epCtlTypeAtt.EndOfLine();
			bool macroUsed = false;
			string suggestedCtlType = null;
			switch (mode)
			{
				case PropertyBuildMode.Formatter:
					suggestedCtlType = Util.GetSuggestedControlTypeForFormatterProp(fmtBuildOptions, kind);
					if (suggestedCtlType != null)
						macroUsed = true;
					else
						suggestedCtlType = "EnumControlTypes.TextBox|EnumControlTypes.ComboBox";	// suggest textbox for control types
					break;
				case PropertyBuildMode.TypedGetSet:
					suggestedCtlType = Util.GetSuggestedControlTypeForFormatterProp(fmtBuildOptions, kind);
					if (suggestedCtlType != null)
						macroUsed = true;
					else
						suggestedCtlType = Util.GetSuggestedControlTypeForVar(var);

					// if valuefornull explicityly declared on the colum mapping,
					// use it in the controltype
					valueForNullDecl = Util.GetDeclaredValueForNullForVar(var);
					if (valueForNullDecl != null)
						valueForNullDecl = ", ValueForNull=" + valueForNullDecl;
					break;
			}

			if (suggestedCtlType != null)
			{
				string clientVlds = "";
				string maxLength = "";
				string isrequired = "";
				if (macroUsed)
				{
					// already declared by the ControlType(Macro=..
					if (!dataCol.AllowDBNull)
						isrequired = ", IsRequired=true";
				}
				else
				{	// Macro not used
					if (dataCol != null)
					{
						if (!dataCol.AllowDBNull)
							clientVlds += "EnumClientValidators.Required";
						clientVlds += "|" + GetSuggestedClientValidatorsForType(type);

						clientVlds = clientVlds.Trim('|');

						if (clientVlds != "")
							clientVlds = ", ClientValidators=" + clientVlds;
						//}
					}
				}

				if (dataCol != null)
				{
					if (dataCol.MaxLength > 0)
						maxLength = ", MaxLength=" + dataCol.MaxLength.ToString();
				}

				epCtlTypeAtt.Insert(String.Format("\r\n\t\t[ControlType({0}{1}{2}{3}{4})]", suggestedCtlType, valueForNullDecl, clientVlds, isrequired, maxLength ));
			}
		}

		public static void DeclareFieldDescription(CodeProperty prop, CodeVariable var, DataColumn dataCol)
		{
			string tblName = null;
			if (dataCol != null)
				if (dataCol.Table != null)
					tblName = dataCol.Table.TableName;

			if (tblName != null)
			{
				string desc = GetDescForColumn(tblName, dataCol.ColumnName);
				if (desc != null && desc.Length > 0)
				{
					EditPoint ep = prop.StartPoint.CreateEditPoint();
					ep.LineUp(1);
					ep.EndOfLine();
					ep.Insert(String.Format("\r\n\t\t[FieldDescription(\"{0}\")]", desc));
				}
			}
		}

		public static string GetSuggestedClientValidatorsForType(Type type)
		{
			if (type == typeof(Int16) ||
				type == typeof(Int32) ||
				type == typeof(byte))
				return "EnumClientValidators.Integer";
			//if (type == typeof(bool))
			//	return "Integer";
			if (type == typeof(float) ||
				type == typeof(double))
				return "EnumClientValidators.Double";
			if (type == typeof(decimal))
				return "EnumClientValidators.Currency";
			if (type == typeof(DateTime ))
				return "EnumClientValidators.Date";

			return "";
		}

		public static string GetPKMemberForClass(CodeClass cls)
		{
			CodeAttribute att = FindAttribute(cls, "TableMapping");
			if (att == null)
				return null;
			string PKMemberName = Util.GetParamFromAttrib(att, "PKMemberName", 1);
			return PKMemberName;
		}

		public static string[] GetPKMembersForClass(CodeClass cls)
		{
			string pkmem = GetPKMemberForClass(cls);
			if (pkmem == null)
				return null;
			else
				return pkmem.Split(',');
		}

		public static bool GetInsertPKForClass(CodeClass cls)
		{
			CodeAttribute att = FindAttribute(cls, "TableMapping");
			if (att == null)
				return false;
			string insertPK = Util.GetParamFromAttrib(att, "InsertPK", 2);
			if (insertPK != "true" && insertPK != "false")
				return false;
			else
				return Convert.ToBoolean(insertPK);
		}

		public static CodeTypeRef GetMemberType(CodeClass cls, string memberName)
		{
			if (memberName != null)
			{
				CodeVariable var = Util.FindFirstMember(cls, memberName) as CodeVariable;
				if (var != null)
					return var.Type;
			}
			return null;
		}

		public static CodeTypeRef[] GetMembersTypes(CodeClass cls, string[] memberNames)
		{
			if (memberNames == null)
				return null;
			CodeTypeRef[] ctrs = new CodeTypeRef[memberNames.Length];
			for (int i = 0; i < memberNames.Length; i++)
			{
				ctrs[i] = GetMemberType(cls, memberNames[i]);
			}
			return ctrs;
		}

		public static Type GetTypeForCodeTypeRef(CodeTypeRef typeRef)
		{
			Type t = null;
			try
			{
				t = Type.GetType(typeRef.AsFullName);
			}
			catch
			{
				
			}

			if (t == null)
				t = typeof(string);
			return t;
		}

		public static CodeElement FindMemberForColumn(CodeClass cls, string colName, EnumStatementType statementType)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colMapping =  GetColMappingForVar(var);

					if (colName == colMapping)
					{
						// check if the statement type is supported by the column.. whether NoInsert, NoUpdate, NoSelect, ..
						CodeAttribute colMapAtt = Util.GetColMappingAtt(var);
						// check sqlgen flags
						if (Util.IsStatementTypeSupportedByColumn(colMapAtt, statementType))
						{
							return elem;
						}
					}
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					CodeElement elem = FindMemberForColumn(cls.Bases.Item(i) as CodeClass, colName, statementType);
					if (elem != null)
						return elem;
				}
			}

			return null;
		}

		public static CodeElement FindLastMappedColumn(CodeClass cls)
		{
			return FindLastMappedColumn(null, cls);
		}

		public static CodeElement FindLastMappedColumn(DataTable tbl, CodeClass cls)
		{
			CodeElement lastElem = null;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colMapping =  GetColMappingForVar(var);

					if (tbl != null)
					{
						if (tbl.Columns.Contains(colMapping))	// mapped
							lastElem = elem;
					}
					else
						lastElem = elem;
				}
			}

			return lastElem;
		}

		public static CodeElement FindLastMember(CodeClass cls, string memberName)
		{
			CodeElement lastElem = null;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (memberName == elem.Name)
					lastElem = elem;
			}

			return lastElem;
		}

		public static CodeElement FindFirstMember(CodeClass cls, string memberName)
		{
			return FindFirstMember(true, cls, memberName);
		}

		public static CodeElement FindFirstMember(bool queryBases, CodeClass cls, string memberName)
		{
            if (cls == null)
                return null;

			CodeElement elem = FindCodeElementByName(cls.Members, memberName);
			if (elem != null)
				return elem;
			if (queryBases)
			{
				if (cls.Bases != null)
				{
					for (int i = 1; i <= cls.Bases.Count; i++)
					{
						elem = FindFirstMember(cls.Bases.Item(i) as CodeClass, memberName);
						if (elem != null)
							return elem;
					}
				}
			}
			return null;
		}

		public static CodeProperty FindIndexer(CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Name == "this")
					return elem as CodeProperty;
			}

			return null;
		}

		/*
		public static CodeFunction FindFirstMethod(CodeClass cls, string methodName, int paramCount)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementFunction)
				{
					if (elem.Name == methodName)
					{
						CodeFunction func = elem as CodeFunction;
						if (func != null)
							if (func.Parameters.Count == paramCount)
								return func;
					}
				}
			}
			return null;
		}*/

		public static string GetLastTerm(string Identifier)
		{
			if (Identifier == null)
				return null;
			string[] terms = Identifier.Split('.');
			if (terms.Length > 1)
				return terms[terms.Length - 1].Trim();
			return Identifier.Trim();
		}

		public static bool CompareTypes(object type1, CodeTypeRef type2)
		{
			string st = type1 as string;
			EnvDTE.vsCMTypeRef tr = EnvDTE.vsCMTypeRef.vsCMTypeRefOther;
			if (st == null)
			{
				CodeTypeRef ctr =type1 as CodeTypeRef;
				if (ctr != null)
					return GetLastTerm(ctr.AsString) == GetLastTerm(type2.AsString);

				if (type1 == null)
					return type2 == null;

				tr = (EnvDTE.vsCMTypeRef)type1;
				return tr == type2.TypeKind;
			}

			return GetLastTerm(st) == GetLastTerm(type2.AsString);
		}

		public static CodeFunction FindFirstMethodAll(bool queryBases, CodeClass cls, string methodName)
		{
			return FindFirstMethod(cls, methodName, null);
		}

		public static CodeFunction FindFirstMethod(CodeClass cls, string methodName, params object[] paramTypes)
		{
			return FindFirstMethod(true, cls, methodName, paramTypes);
		}

		public static CodeFunction FindFirstMethod(bool queryBases, CodeClass cls, string methodName, params object[] paramTypes)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementFunction)
				{
					if (elem.Name == methodName)
					{
						CodeFunction func = elem as CodeFunction;
						if (func != null)
						{
							if (paramTypes == null)
								return func;

							if (func.Parameters.Count == paramTypes.Length)
							{
								bool paramsMatch = true;
								for (int j = 0; j < paramTypes.Length; j++)
								{
									if (!Util.CompareTypes(paramTypes[j], (func.Parameters.Item(j + 1) as CodeParameter).Type))
									{
										paramsMatch = false;
										break;
									}
								}

								if (paramsMatch)
									return func;
							}
						}
					}
				}
			}

			// check bases
			if (queryBases)
			{
				if (cls.Bases != null)
				{
					for (int i = 1; i <= cls.Bases.Count; i++)
					{
						CodeFunction func = FindFirstMethod(queryBases, cls.Bases.Item(i) as CodeClass, methodName, paramTypes);
						if (func != null)
							return func;
					}
				}
			}
			return null;
		}

		public static ArrayList FindSelectedCodeElements(CodeClass cls, TextSelection selection, EnvDTE.vsCMElement kind, bool onlyOne)
		{
			return FindSelectedCodeElements(cls, selection, new EnvDTE.vsCMElement[] { kind }, onlyOne);
		}

		public static ArrayList FindSelectedCodeElements(CodeClass cls, TextSelection selection, EnvDTE.vsCMElement[] kinds, bool onlyOne)
		{
			ArrayList arr = new ArrayList();
			bool containedSel = false;
			ArrayList arrKinds = new ArrayList(kinds);
			if (cls != null)
			{
				if (selection.TopPoint.AbsoluteCharOffset == selection.BottomPoint.AbsoluteCharOffset)
				{
					containedSel = true;
				}
				for (int i = 1; i <= cls.Members.Count; i ++)
				{
					CodeElement elem = cls.Members.Item(i);
					//Debug.WriteLine((int)elem.Kind);
					if (arrKinds.Contains(elem.Kind))
					{
						if (containedSel)
						{
							if (selection.ActivePoint.AbsoluteCharOffset >= elem.StartPoint.AbsoluteCharOffset)
								if (selection.ActivePoint.AbsoluteCharOffset <= elem.EndPoint.AbsoluteCharOffset)
								{
									arr.Add(elem);
									if (onlyOne)
										break;
								}
						}
						else
						{
							int selTop = selection.TopPoint.AbsoluteCharOffset;
							int selBottom = selection.BottomPoint.AbsoluteCharOffset;
							if (selTop > selBottom)
							{
								// reversed
								selBottom = selection.TopPoint.AbsoluteCharOffset;
								selTop = selection.BottomPoint.AbsoluteCharOffset;
							}
							if (elem.StartPoint.AbsoluteCharOffset >= selTop)
								if (elem.StartPoint.AbsoluteCharOffset <= selBottom)
								{
									arr.Add(elem);
									if (onlyOne)
										break;
								}
						}
					}
				}
			}

			return arr;
		}

		public static void MarkElement(CodeClass cls, CodeElement elem)
		{
			if (elem != null)
			{
				try
				{
					//elem.StartPoint.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
					TextSelection selection = 
						(TextSelection) cls.ProjectItem.Document.Selection;
					selection.MoveToPoint(elem.StartPoint, false);
					selection.MoveToPoint(elem.EndPoint, true);
				}
				catch
				{
					// ignore
				}
			}
		}

		public static void DeleteElement(CodeClass cls, CodeElement elem)
		{
			if (elem != null)
			{
				try
				{
					//elem.StartPoint.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
					TextSelection selection = 
						(TextSelection) cls.ProjectItem.Document.Selection;
					selection.MoveToPoint(elem.StartPoint, false);
					selection.MoveToPoint(elem.EndPoint, true);
					selection.Delete(1);
				}
				catch
				{
					// ignore
				}
			}
		}

		public static void SelectBetween(TextSelection selection, EditPoint ep1, EditPoint ep2)
		{
			selection.MoveToPoint(ep1, false);
			selection.MoveToPoint(ep2, true);
		}

		public static void SelectElement(TextSelection selection, CodeElement elem)
		{
			SelectBetween(selection, 
				elem.StartPoint.CreateEditPoint(), 
				elem.EndPoint.CreateEditPoint());
		}

		public static void MarkAttribute(CodeClass cls, string attName)
		{
			CodeAttribute att = Util.FindAttribute(cls, attName);
			if (att != null)
			{
				TextSelection selection = 
					(TextSelection) cls.ProjectItem.Document.Selection;
				selection.MoveToPoint(cls.StartPoint, false);
				selection.FindText("class " + cls.Name, 0);
				selection.MoveToPoint(cls.StartPoint, true);
			}
		}

		public static CodeClass GetElementClassOfCollection(CodeClass clsCol)
		{
			string elemType = Util.GetElementTypeForClass(clsCol);
			if (elemType != null)
				return Util.FindClassInProject(clsCol.ProjectItem.ContainingProject, elemType);

			return null;
		}

		public static void ShowClass(CodeClass cls)
		{
			if (cls != null)
			{
				try
				{
					cls.ProjectItem.Open(EnvDTE.Constants.vsViewKindCode);
					EditPoint ep = cls.StartPoint.CreateEditPoint();
					ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);
				}
				catch
				{
					// ignore
				}
			}
		}

		public static void ShowClass(string className)
		{
			if (className != null)
			{
				CodeClass cls = Util.FindClassInProject(className);
				ShowClass(cls);
			}
		}

		public static void ShowElementClassOfCollection(CodeClass clsCol)
		{
			CodeClass elemClass = Util.GetElementClassOfCollection(clsCol);
			ShowClass(elemClass);
		}

		public static void DeleteEditLine(EditPoint ep)
		{
			while (!ep.AtEndOfLine)
				ep.Delete(1);
		}

		public static void MergeFollowingLine(EditPoint ep)
		{
			ep.EndOfLine();
			while (ep.GetText(1).IndexOfAny(blankChars) >= 0)
				ep.Delete(1);
			ep.Insert(" ");
		}

		public static void MergeFollowingLine(EditPoint ep, int count)
		{
			for ( ; count > 0; count --)
				MergeFollowingLine(ep);
		}

		public static bool HasAnyOfAttributes(CodeClass cls, params string[] attributes)
		{
			bool att = HasAnyOfAttributes(cls.Attributes, attributes);
			if (att)
				return true;

			// try base class

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					att = HasAnyOfAttributes(cls.Bases.Item(i) as CodeClass, attributes);
					if (att)
						return true;
				}
			}

			return false;
		}

		public static bool HasAnyOfAttributes(CodeElements attribCollection, params string[] attributes)
		{
			if (attributes.Length == 0)
				return true;
			if (attribCollection == null)
				return false;
			for (int i = 0; i < attributes.Length; i++)
			{
				if (FindAttribute(attribCollection, attributes[i]) != null)
					return true;
			}
			return false;
		}

		public static bool HasBaseClass(CodeClass cls, string baseClassName)
		{
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					string clsName = cls.Bases.Item(i).Name;
					if (clsName == baseClassName)
						return true;
				}
			}
			return false;
		}

		public static bool DerivesFromClass(CodeClass cls, string baseClassName)
		{
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					CodeClass baseClass = cls.Bases.Item(i) as CodeClass;
					if (baseClass != null)
					{
						string clsName = cls.Bases.Item(i).Name;
                        if (CompareClassIdentifierAgainstRootName(clsName, baseClassName))
							return true;
						else
						{
							// Does the base class derive from the given classname
							if (DerivesFromClass(baseClass, baseClassName))
								return true;
						}
					}
				}
			}
			return false;
		}

        /*
        public static bool DerivesFromClass(CodeTypeDeclaration cls, string baseClassName)
        {
            if (cls.BaseTypes != null)
            {
                for (int i = 1; i <= cls.BaseTypes.Count; i++)
                {
                    CodeTypeReference baseClass = cls.BaseTypes[i];
                    if (baseClass != null)
                    {
                        string clsName = cls.BaseTypes[i].BaseType;
                        if (CompareClassIdentifierAgainstRootName(clsName, baseClassName))
                            return true;
                        else
                        {
                            // Does the base class derive from the given classname
                            if (DerivesFromClass(baseClass, baseClassName))
                                return true;
                        }
                    }
                }
            }
            return false;
        }*/

        public static string GetRootClassIdentifier(string clsName)
        {
            // if this is a template specifier, just chop it
            int i = clsName.IndexOf('<');

            if (i >= 0)
                return clsName.Substring(0, i);
            else
                return clsName;
        }

        public static bool CompareClassIdentifierAgainstRootName(string clsName1, string rootName2)
        { 
            return GetRootClassIdentifier(clsName1) == rootName2;
        }

		public static bool ClassHasSPNameOrTemplate(CodeClass cls, string spTpl, string spName)
		{
			ArrayList arr = GetSPAutoGenAttributes(cls);
			if (arr == null)
				return false;

			for (int i = 0; i < arr.Count; i++)
			{
				CodeAttribute att = arr[i] as CodeAttribute;
				bool spNameOK = true;
				bool spTplOK = true;

				if (spName != null && spName != "")	// if empty ignore
				{
					string attSpName = Util.GetParamFromAttrib(att, null, 0);
					if (attSpName == null)
						attSpName = "";

					if ( attSpName.IndexOf(spName) < 0 )
						spNameOK = false;
				}

				if (spTpl != null && spTpl != "")	// if empty ignore
				{
					string attSpTpl = Util.GetParamFromAttrib(att, null, 1);
					if (attSpTpl == null)
						attSpTpl = "";

					if ( attSpTpl.IndexOf(spTpl) < 0 )
						spTplOK = false;
				}

				if (spNameOK && spTplOK)		// if both matched, or was ignored, return true.
					return true;

			}
			return false;
		}

		public static CodeClass FindClassInProject(string name)
		{
            if (name == null)
                return null;
			string[] terms = name.Split(',');
			if (terms.Length > 1)
			{
				Project prj = Util.FindProjectInSolution(terms[1].Trim());
				CodeClass cls = FindClassInProject(prj, terms[0].Trim());
				NAR(prj);
				return cls;
			}
			else
				return FindClassInProject((Project)null, name);
		}

        public static CodeInterface FindInterfaceInProject(string name)
        {
            if (name == null)
                return null;
            string[] terms = name.Split(',');
            if (terms.Length > 1)
            {
                Project prj = Util.FindProjectInSolution(terms[1].Trim());
                CodeInterface cls = FindInterfaceInProject(prj, terms[0].Trim());
                NAR(prj);
                return cls;
            }
            else
                return FindInterfaceInProject((Project)null, name);
        }

		public static CodeClass FindClassForDocument(string documentName)
		{
			Window window = Connect.Instance.applicationObject.Windows.Item(documentName);// + ".cs");
			if (window == null)
			{
				//window = Connect.Instance.applicationObject.Windows.Item(documentName + ".cs");
				//string prjPath = Path.GetDirectoryName(Connect.Instance.CurrentProject.FullName);
				//window = Connect.Instance.applicationObject.ItemOperations.OpenFile(prjPath + "\\" + documentName + ".cs", Constants.vsViewKindCode);
				//if (window == null)
				return null;
			}
			ProjectItem prjItem = window.ProjectItem;
			if (prjItem == null)
				return null;
			CodeNamespace ns = Util.FindCodeNamespace(prjItem.FileCodeModel.CodeElements); //.Item(1) as CodeNamespace;
			if (ns == null)
				return null;
			CodeClass cls = ns.Members.Item(1) as CodeClass;
			return cls;
		}

		public static CodeClass FindClassForDocument(Document document)
		{
			if (document == null)
				return null;
			return FindClassForDocument(document.Name);
		}

		public static Project FindProjectInSolution(string name)
		{
			return FindProjectInSolution(Connect.Instance.applicationObject.Solution, name);
		}

		public static Project FindProjectInSolution(Solution solution, string name)
		{
			for (int i = 1; i <= solution.Projects.Count; i++)
				if (solution.Projects.Item(i).Name == name)
					return solution.Projects.Item(i);
			return null;
		}

		public static CodeClass FindClassInProject(Project prj, string name)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;

			CodeClass cls = FindClassInProject(prj.ProjectItems, name);
			NAR(prj);
			return cls;
		}

        public static CodeInterface FindInterfaceInProject(Project prj, string name)
        {
            if (prj == null)
                prj = Connect.Instance.CurrentProject;

            CodeInterface cls = FindInterfaceInProject(prj.ProjectItems, name);
            NAR(prj);
            return cls;
        }

        public static CodeNamespace FindNamespaceInProject(Project prj, string name)
        {
            if (prj == null)
                prj = Connect.Instance.CurrentProject;

            CodeNamespace ns = FindNamespaceInProject(prj.ProjectItems, name);
            NAR(prj);
            return ns;
        }

		public static CodeClass FindClassInProject(ProjectItems prjItems, string name)
		{
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				FileCodeModel fcm = prjItem.FileCodeModel;
				if (prjItem != null && fcm != null)
				{
					CodeElements codeElements = fcm.CodeElements;
					for (int j = 1; j <= codeElements.Count; j++)
					{
                        CodeClass cls = null;

                        //CodeNamespace ns = Util.FindCodeNamespace(prjItem.FileCodeModel.CodeElements); //.Item(j) as CodeNamespace;
                        /*cls = codeElements.Item(j) as CodeClass;
                        if (cls != null)
                        {
                            if (cls.Name == name)
                                return cls;
                            NAR(cls);
                        }*/

                        //if (!codeElements.Item(j).IsCodeType)
                        //    continue;
                        CodeNamespace ns = codeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
                            if (CodeDomUtil.IsAutogeneratedNamespace(ns.FullName))
                                continue;
                            try
                            {
                                cls = FindCodeElementByName(ns.Members, name) as CodeClass;
                            }
                            catch(Exception ex)
                            {
                                throw ex;
                            }
							if (cls != null)
						        return cls;

							NAR(ns);
						}
					}
					NAR(codeElements);
				}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						CodeClass cls = FindClassInProject(prjItem.ProjectItems, name);
						if (cls != null)
							return cls;
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					CodeClass cls = FindClassInProject(prjItem.SubProject, name);
					if (cls != null)
						return cls;
				}
				NAR(prjItem);
				NAR(fcm);
			}
			return null;
		}

        public static CodeNamespace FindNamespaceInProject(ProjectItems prjItems, string name)
        {
            // walk on project items
            for (int i = 1; i <= prjItems.Count; i++)
            {
                ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
                // walk on the namespaces
                FileCodeModel fcm = prjItem.FileCodeModel;
                if (prjItem != null && fcm != null)
                {
                    CodeElements codeElements = fcm.CodeElements;
                    for (int j = 1; j <= codeElements.Count; j++)
                    {
                        CodeNamespace ns = codeElements.Item(j) as CodeNamespace;
                        if (ns != null)
                        {
                            //if (CodeDomUtil.IsAutogeneratedNamespace(ns.FullName))
                              //  continue;

                            if (ns.FullName == name)
                                return ns;

                            NAR(ns);
                        }
                    }
                    NAR(codeElements);
                }

                // recurse into the sub folder items
                if (prjItem.ProjectItems != null)
                    if (prjItem.ProjectItems.Count > 0)
                    {
                        CodeNamespace ns = FindNamespaceInProject(prjItem.ProjectItems, name);
                        if (ns != null)
                            return ns;
                    }

                // recurse into the sub projects
                if (prjItem != null && prjItem.SubProject != null)
                {
                    CodeNamespace ns = FindNamespaceInProject(prjItem.SubProject, name);
                    if (ns != null)
                        return ns;
                }
                NAR(prjItem);
                NAR(fcm);
            }
            return null;
        }

        /// <summary>
        /// Search for the given namespace in all the referred projects
        /// </summary>
        /// <param name="mainProj"></param>
        /// <param name="referredNamespace"></param>
        /// <returns></returns>
        public static CodeNamespace FindReferencedNamespace(Project mainProj, string referredNamespace)
        {
            VSLangProj.VSProject vsp = mainProj.Object as VSLangProj.VSProject;
            // Project specific references are expected to be at the end, we iterate backwards for efficiency.
            for (int i = vsp.References.Count; i >= 1; i--)
            {
                VSLangProj.Reference rfr = vsp.References.Item(i);
                if (rfr != null)
                {
                    Project prj = rfr.SourceProject;
                    if (prj != null)
                    {
                        CodeNamespace ns = FindNamespaceInProject(prj, referredNamespace);
                        if (ns != null)
                            return ns;
                    }
                }
            }

            return null;
        }

        public static Project FindReferencedProjectForNamespace(Project mainProj, string referredNamespace)
        {
            CodeNamespace ns = FindReferencedNamespace(mainProj, referredNamespace);
            if (ns == null)
                return null;
            return ns.ProjectItem.ContainingProject;
        }

        public static CodeElement FindCodeElementByName(CodeElements elems, string name)
        {
            try
            {
                for (int i = 1; i <= elems.Count; i++)
                {
                    CodeElement elem = elems.Item(i);
                    if (elem.Name == name)
                        return elem;
                }
            }
            catch (COMException comEx)
            {
                return null;
            }
            return null;
        }

        public static CodeInterface FindInterfaceInProject(ProjectItems prjItems, string name)
        {
            // walk on project items
            for (int i = 1; i <= prjItems.Count; i++)
            {
                ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
                // walk on the namespaces
                FileCodeModel fcm = prjItem.FileCodeModel;
                if (prjItem != null && fcm != null)
                {
                    CodeElements codeElements = fcm.CodeElements;
                    for (int j = 1; j <= codeElements.Count; j++)
                    {
                        CodeInterface cls = null;

                        //CodeNamespace ns = Util.FindCodeNamespace(prjItem.FileCodeModel.CodeElements); //.Item(j) as CodeNamespace;
                        /*cls = codeElements.Item(j) as CodeClass;
                        if (cls != null)
                        {
                            if (cls.Name == name)
                                return cls;
                            NAR(cls);
                        }*/

                        //if (!codeElements.Item(j).IsCodeType)
                        //    continue;
                        CodeNamespace ns = codeElements.Item(j) as CodeNamespace;
                        if (ns != null)
                        {
                            if (CodeDomUtil.IsAutogeneratedNamespace(ns.FullName))
                                continue;
                            //for (int j = 0; j < 
                            try
                            {
                                cls = FindCodeElementByName(ns.Members, name) as CodeInterface;
                            }
                            catch(Exception ex)
                            {
                                throw ex;
                            }
                            if (cls != null)
                                return cls;

                            NAR(ns);
                        }
                    }
                    NAR(codeElements);
                }

                // recurse into the sub folder items
                if (prjItem.ProjectItems != null)
                    if (prjItem.ProjectItems.Count > 0)
                    {
                        CodeInterface cls = FindInterfaceInProject(prjItem.ProjectItems, name);
                        if (cls != null)
                            return cls;
                    }

                // recurse into the sub projects
                if (prjItem != null && prjItem.SubProject != null)
                {
                    CodeInterface cls = FindInterfaceInProject(prjItem.SubProject, name);
                    if (cls != null)
                        return cls;
                }
                NAR(prjItem);
                NAR(fcm);
            }
            return null;
        }

		public static object[] FindCollectionClassesInProject(Project prj, string elemType)
		{
			ArrayList arr = new ArrayList();
			if (prj == null)
				prj = Connect.Instance.CurrentProject;

			FindCollectionClassesInProject(arr, prj.ProjectItems, elemType);

			return (object[])arr.ToArray(typeof(object));
		}

		public static void FindCollectionClassesInProject(ArrayList arr, ProjectItems prjItems, string elemType)
		{
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem.FileCodeModel != null)
				{
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
                            if (CodeDomUtil.IsAutogeneratedNamespace(ns.FullName))
                                continue;
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
								if (cls != null)
								{
                                    //if (Util.IsCollectionClass(cls))
                                      //  arr.Add(cls);
									string etype = Util.GetElementTypeForClass(cls);
									if ((elemType == null && etype != null) || (elemType != null && etype == elemType))
										arr.Add(cls);
								}
							}
						}
					}
				}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
						FindCollectionClassesInProject(arr, prjItem.ProjectItems, elemType);

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
					FindCollectionClassesInProject(arr, prjItem.ProjectItems, elemType);


			}
		}


		// find all collection classes
		public static object[] FindCollectionClassesInProject()
		{
			return FindClassesWithAttribsInProject(Util.collectionClassAttribs);
		}

		public static object[] FindEntityesInProject()
		{
            return FindClassesWithBaseInProject("Entity"); // FindClassesWithAttribsInProject((Project)null, Util.EntityAttribs);
		}

		// find all Entity Classes
		public static object[] FindEntityesInProject(Project prj)
		{
            return FindClassesWithBaseInProject(prj, "Entity"); // FindClassesWithAttribsInProject(prj, Util.EntityAttribs);
		}

		public static object[] FindClassesWithAttribsInProject(params string[] attributes)
		{
			return FindClassesWithAttribsInProject((Project)null, attributes);
		}

		public static object[] FindClassesWithAttribsInProject(Project prj, params string[] attributes)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;
			return FindClassesWithAttribsInProject(prj.ProjectItems, attributes);
		}

		public static object[] FindClassesWithBaseInProject(string baseClass)
		{
			return FindClassesWithBaseInProject((Project)null, baseClass);
		}

		public static object[] FindClassesWithSPTemplateAndSPName(string spTpl, string spName)
		{
			return FindClassesWithSPTemplateAndSPName((Project)null, spTpl, spName);
		}
		
		public static object[] FindClassesMappedToTableInProject(string tableName)
		{
			return FindClassesMappedToTableInProject((Project)null, tableName);
		}

		public static Hashtable FindClassTableMappingsInProject()
		{
			return FindClassTableMappingsInProject((Project)null);
		}

		public static object[] FindClassesWithBaseInProject(Project prj, string baseClass)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;
			return FindClassesWithBaseInProject(prj.ProjectItems, baseClass);
		}

		public static object[] FindClassesWithSPTemplateAndSPName(Project prj, string spTpl, string spName)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;
			return FindClassesWithSPTemplateAndSPName(prj.ProjectItems, spTpl, spName);
		}

		public static object[] FindClassesMappedToTableInProject(Project prj, string tableName)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;
			return FindClassesMappedToTableInProject(prj.ProjectItems, tableName);
		}

		public static Hashtable FindClassTableMappingsInProject(Project prj)
		{
			if (prj == null)
				prj = Connect.Instance.CurrentProject;
			return FindClassTableMappingsInProject(prj.ProjectItems);
		}

		public static object[] FindClassesWithAttribsInProject(ProjectItems prjItems, params string[] attributes)
		{
			ArrayList arr = new ArrayList();
		
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem != null && prjItem.FileCodeModel != null)
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
								if (cls != null)
								{
									if (HasAnyOfAttributes(cls, attributes))		// uses the derived too
										arr.Add(cls);
								}
							}
						}
					}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						object[] classes = FindClassesWithAttribsInProject(prjItem.ProjectItems, attributes);
						if (classes != null)
							arr.AddRange(classes);
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					object[] classes = FindClassesWithAttribsInProject(prjItem.SubProject, attributes);
					if (classes != null)
						arr.AddRange(classes);
				}
			}
			return (object[])arr.ToArray(typeof(object));
		}

		public static object[] FindClassesWithBaseInProject(ProjectItems prjItems, string baseClass)
		{
			ArrayList arr = new ArrayList();
		
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem != null && prjItem.FileCodeModel != null)
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
								if (cls != null)
								{
									if (DerivesFromClass(cls, baseClass))
										arr.Add(cls);
								}
							}
						}
					}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						object[] classes = FindClassesWithBaseInProject(prjItem.ProjectItems, baseClass);
						if (classes != null)
							arr.AddRange(classes);
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					object[] classes = FindClassesWithBaseInProject(prjItem.SubProject, baseClass);
					if (classes != null)
						arr.AddRange(classes);
				}
			}
			return (object[])arr.ToArray(typeof(object));
		}

		public static object[] FindClassesWithSPTemplateAndSPName(ProjectItems prjItems, string spTpl, string spName)
		{
			ArrayList arr = new ArrayList();
		
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem != null && prjItem.FileCodeModel != null)
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
								if (cls != null)
								{
									if (ClassHasSPNameOrTemplate(cls, spTpl, spName))
										arr.Add(cls);
								}
							}
						}
					}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						object[] classes = FindClassesWithSPTemplateAndSPName(prjItem.ProjectItems, spTpl, spName);
						if (classes != null)
							arr.AddRange(classes);
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					object[] classes = FindClassesWithSPTemplateAndSPName(prjItem.SubProject, spTpl, spName);
					if (classes != null)
						arr.AddRange(classes);
				}
			}
			return (object[])arr.ToArray(typeof(object));
		}

		public static object[] FindClassesMappedToTableInProject(ProjectItems prjItems, string tableName)
		{
			ArrayList arr = new ArrayList();
		
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem != null && prjItem.FileCodeModel != null)
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
								if (cls != null)
								{
									string tblMap = Util.GetTableMappingForClass(cls, false);
									if (String.Compare(tblMap, tableName, true) == 0)
										arr.Add(cls);
								}
							}
						}
					}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						object[] classes = FindClassesMappedToTableInProject(prjItem.ProjectItems, tableName);
						if (classes != null)
							arr.AddRange(classes);
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					object[] classes = FindClassesMappedToTableInProject(prjItem.SubProject, tableName);
					if (classes != null)
						arr.AddRange(classes);
				}
			}
			return (object[])arr.ToArray(typeof(object));
		}

		public static Hashtable FindClassTableMappingsInProject(ProjectItems prjItems)
		{
			Hashtable map = new Hashtable();
		
			// walk on project items
			for (int i = 1; i <= prjItems.Count; i++)
			{
				ProjectItem prjItem = prjItems.Item(i) as ProjectItem;
				// walk on the namespaces
				if (prjItem != null && prjItem.FileCodeModel != null)
					for (int j = 1; j <= prjItem.FileCodeModel.CodeElements.Count; j++)
					{
						CodeNamespace ns = prjItem.FileCodeModel.CodeElements.Item(j) as CodeNamespace;
						if (ns != null)
						{
							for (int k = 1; k <= ns.Members.Count; k++)
							{
								CodeClass cls = ns.Members.Item(k) as CodeClass;
                                
								if (cls != null)
								{
                                    if (Util.IsEntity(cls))
                                    {
                                        string tblMap = Util.GetTableMappingForClass(cls, false);
                                        map[cls.Name] = tblMap;
                                    }
								}
							}
						}
					}

				// recurse into the sub folder items
				if (prjItem.ProjectItems != null)
					if (prjItem.ProjectItems.Count > 0)
					{
						Hashtable subMap = FindClassTableMappingsInProject(prjItem.ProjectItems);
						if (subMap != null)
							MergeHashtable(map, subMap);
					}

				// recurse into the sub projects
				if (prjItem != null && prjItem.SubProject != null)
				{
					Hashtable subMap = FindClassTableMappingsInProject(prjItem.SubProject);
					if (subMap != null)
						MergeHashtable(map, subMap);
				}
			}
			return map;
		}

		public static void MergeHashtable(Hashtable targetMap, Hashtable sourceMap)
		{
			foreach (DictionaryEntry de in sourceMap)
			{
				targetMap[de.Key] = de.Value;
			}
		}

		public static string GetControlTypeMacroForMember(CodeVariable var)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ControlType");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "Macro", -1);
		}

		public static string GetControlTypeMacroForMember(CodeProperty prop)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "ControlType");
			if (att == null)
				return null;
			return Util.GetParamFromAttrib(att, "Macro", -1);
		}

		public static string GetControlTypeMacroForMember(CodeElement elem)
		{
			CodeVariable var = elem as CodeVariable;
			if (var != null)
				return GetControlTypeMacroForMember(var);

			CodeProperty prop = elem as CodeProperty;
			if (prop != null)
				return GetControlTypeMacroForMember(prop);

			return null;
		}

		public static string GetControlTypeFromMacro(string macro)
		{
			if (macro != null)
			{
				switch(GetLastTerm(macro))
				{
					case "USState":
					case "Gender":
					case "StringLookup":
					case "IntLookup":
						return "EnumControlTypes.ComboBox|EnumControlTypes.TextBox";
					default:
						return "EnumControlTypes.TextBox|EnumControlTypes.ComboBox";
				}
			}
			return null;
		}

		public static string GetControlTypeForMember(CodeVariable var)
		{
			CodeAttribute att = FindAttribute(var.Attributes, "ControlType");
			if (att == null)
				return null;
			string ctlType = Util.GetParamFromAttrib(att, "ControlType", 0);
			if (ctlType == null)
			{
				string macro = Util.GetParamFromAttrib(att, "Macro", -1);
				ctlType = GetControlTypeFromMacro(macro);
			}
			return ctlType;
		}

		public static string GetControlTypeForMember(CodeProperty prop)
		{
			CodeAttribute att = FindAttribute(prop.Attributes, "ControlType");
			if (att == null)
				return null;
			string ctlType = Util.GetParamFromAttrib(att, "ControlType", 0);
			if (ctlType == null)
			{
				string macro = Util.GetParamFromAttrib(att, "Macro", -1);
				ctlType = GetControlTypeFromMacro(macro);
			}
			return ctlType;
		}

		public static string GetControlTypeForMember(CodeElement elem)
		{
			CodeVariable var = elem as CodeVariable;
			if (var != null)
				return GetControlTypeForMember(var);

			CodeProperty prop = elem as CodeProperty;
			if (prop != null)
				return GetControlTypeForMember(prop);

			return null;
		}

		public static string GetControlTypeForMember(CodeElement elem, bool useDefault)
		{
			string ctlType = GetControlTypeForMember(elem);
			if (useDefault)
				if (ctlType == null)
					ctlType = "EnumControlTypes.TextBox";

			return ctlType;
		}

		public static ArrayList GetClientValidationsForMember(CodeClass cls, string name, bool useDefault)
		{
			return GetClientValidationsForMember(Util.FindFirstMember(cls, name), useDefault);
		}

		public static ArrayList GetClientValidationsForMember(CodeElement elem, bool useDefault)
		{
			ArrayList flags = null;
			if (useDefault)
				flags = new ArrayList();

			CodeElements attribs = GetAttributes(elem);
			if (attribs == null)
				return flags;
			CodeAttribute att = FindAttribute(attribs, "ControlType");
			if (att == null)
				return flags;
			string exp = Util.GetParamFromAttrib(att, "ClientValidators", -1);
			flags = ParseFlags(exp, true);
			return flags;
		}
		
		public static object[] FindMembersForAttribs(CodeClass cls, params string[] attributes)
		{
			return FindMembersForAttribs(cls, 
				EnvDTE.vsCMAccess.vsCMAccessPrivate | 
				EnvDTE.vsCMAccess.vsCMAccessProtected | 
				EnvDTE.vsCMAccess.vsCMAccessProject |
				EnvDTE.vsCMAccess.vsCMAccessPublic, attributes);
		}

		public static object[] FindMembersForAttribs(CodeClass cls, EnvDTE.vsCMAccess access, params string[] attributes)
		{
			ArrayList arr = new ArrayList();
			FindMembersForAttribs(cls, access, arr, attributes);
			return (object[])arr.ToArray(typeof(object));
		}


		public static void FindMembersForAttribs(CodeClass cls, EnvDTE.vsCMAccess access, ArrayList arr, params string[] attributes)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable 
					|| elem.Kind == EnvDTE.vsCMElement.vsCMElementProperty)
				{
					/*if (attributes.Length == 0)
					{
						// no attrib criteria scpecified

						CodeVariable var = elem as CodeVariable;
						if (var != null)
						{
							if ((var.Access & access) != 0)
								arr.Add(var);
						}
						else
						{
							CodeProperty prop = elem as CodeProperty;
							if ((prop.Access & access) != 0)
								arr.Add(prop);
						}
					}
					else
					{*/
					// attrib criteria specified
					CodeVariable var = elem as CodeVariable;
					if (var != null)
					{
						if ((var.Access & access) != 0)
							if (HasAnyOfAttributes(var.Attributes, attributes))
								arr.Add(var);
					}
					else
					{
						CodeProperty prop = elem as CodeProperty;
						if ((prop.Access & access) != 0)
							if (HasAnyOfAttributes(prop.Attributes, attributes))
								arr.Add(prop);
					}
					//}
				}
			}

			// fill the members from bases
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FindMembersForAttribs(cls.Bases.Item(i) as CodeClass, access, arr, attributes);
				}
			}
		}

		public static bool IsFormatter(CodeElement elem)
		{
			if (elem == null)
				return false;

			string elemName = elem.Name;
			if (elemName.Length >= 4)
				if (elemName.Substring(0, 4) == "Fmt_")
					return true;
			return false;
		}

		public static bool IsValidator(CodeElement elem)
		{
			if (elem == null)
				return false;

			string elemName = elem.Name;
			if (elemName.Length >= 4)
				if (elemName.Substring(0, 4) == "Vld_")
					return true;
			return false;
		}

		public static bool IsLanguageClass(CodeClass cls)
		{
			return Util.DerivesFromClass(cls, "Language");
		}

		public static bool IsEntity(CodeClass cls)
		{
            return IsDerivedFromBaseEntity(cls);
			//return Util.HasAnyOfAttributes(cls, Util.EntityAttribs);
		}

        public static bool IsEntityWithDataAccess(CodeClass cls)
        {
            return IsDerivedFromBaseEntityWithDataAccess(cls);
            //return Util.HasAnyOfAttributes(cls, Util.EntityAttribs);
        }

		public static bool IsDerivedFromBaseEntity(CodeClass cls)
		{
			return DerivesFromClass(cls, "Entity");
		}

        public static bool IsDerivedFromBaseEntityWithDataAccess(CodeClass cls)
        {
            return DerivesFromClass(cls, "EntityWithDataAccess");
        }

		public static bool IsDerivedFromEntityCollectionClass(CodeClass cls)
		{
			return DerivesFromClass(cls, "EntityCollection");
		}

		public static bool IsCollectionClass(CodeClass cls)
		{
            return IsDerivedFromEntityCollectionClass(cls);
			//return Util.HasAnyOfAttributes(cls, Util.collectionClassAttribs);
		}

        public static bool IsCollectionClass(CodeTypeRef codeTypeRef)
        {
            if (codeTypeRef.TypeKind == vsCMTypeRef.vsCMTypeRefCodeType)
            {
                CodeClass cls = codeTypeRef.CodeType as CodeClass;
                if (cls != null)
                    return IsCollectionClass(cls);
            }
            return false;
        }

        public static bool IsEntity(CodeTypeRef codeTypeRef)
        {
            if (codeTypeRef.TypeKind == vsCMTypeRef.vsCMTypeRefCodeType)
            {
                CodeClass cls = codeTypeRef.CodeType as CodeClass;
                if (cls != null)
                    return IsEntity(cls);
            }
            return false;
        }

		public static bool IsFormatter(CodeClass cls, string memberName)
		{
			return IsFormatter(Util.FindFirstMember(cls, memberName));
		}

		public static bool IsValidator(CodeClass cls, string memberName)
		{
			return IsValidator(Util.FindFirstMember(cls, memberName));
		}

		public static bool IsFieldValuesProp(CodeClass cls, string memberName)
		{
			return IsFieldValuesProp(Util.FindFirstMember(cls, memberName));
		}

		public static bool IsDateTime(CodeTypeRef typeRef)
		{
			return typeRef.AsString.IndexOf("DateTime") >= 0;
		}

		public static string GetSuggestedControlTypeForVar(CodeVariable var)
		{
			if (IsDateTime(var.Type))
				return "EnumControlTypes.TextBox";

			switch (var.Type.TypeKind)
			{
				case EnvDTE.vsCMTypeRef.vsCMTypeRefBool:
					return "EnumControlTypes.CheckBox";
				case EnvDTE.vsCMTypeRef.vsCMTypeRefString:
				case EnvDTE.vsCMTypeRef.vsCMTypeRefDecimal:
				case EnvDTE.vsCMTypeRef.vsCMTypeRefDouble:
				case EnvDTE.vsCMTypeRef.vsCMTypeRefFloat:
				case EnvDTE.vsCMTypeRef.vsCMTypeRefInt:
				case EnvDTE.vsCMTypeRef.vsCMTypeRefLong:
					return "EnumControlTypes.TextBox";
				default:
					return null;		// no suggestion !
			}
		}

		// tries to find a project that already added a reference with the same name
		// and uses it.  if it's a project, then it's added as a project ref.
		// if it's not, then it's added by it's path.
		// if no projects were found, an open project with the same name is searched.
		// if found, a project ref is added.
		// if not, then attempts to add it directly.  this last chance may fail if
		// the assembly is not registered in the GAC.
		// normaly, at least one of the projects must give a ref.  the others will use
		// this.
		public static void AddReference(Project prj, string reference)
		{
			try
			{
				if (prj.Name == reference)
					return;
				VSLangProj.VSProject vsproj = prj.Object as VSLangProj.VSProject;
				Solution solution = Connect.Instance.applicationObject.Solution;

				// add references
				if (vsproj.References.Find(reference) == null)
				{
					// try to find the reference in other projects
					for (int i = 1; i <= solution.Projects.Count; i++)
					{
						VSLangProj.VSProject vsp = solution.Projects.Item(i).Object as VSLangProj.VSProject;
						if (vsp != null)
						{
							VSLangProj.Reference foundref = vsp.References.Find(reference);
							if (foundref != null)
							{
								if (foundref.SourceProject != null)
									vsproj.References.AddProject(foundref.SourceProject);
								else
									vsproj.References.Add(foundref.Path);
								return;
							}
						}
					}
					// try to find a project with the same name
					Project prjRef = Util.FindProjectInSolution(solution, reference);
					if (prjRef != null)
						vsproj.References.AddProject(prjRef);
					else
						vsproj.References.Add(reference);
				}
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.Message);
			}
		}

		public static string MakeCollectionInstanceName(Project prj, string colName)
		{
			CodeClass colCls = Util.FindClassInProject(prj, colName);
			string name = MakeCollectionInstanceName(colCls);
			if (name == null)
				name = colName;
			return name;
		}

		public static string MakeCollectionInstanceName(CodeClass colCls)
		{
			if (colCls == null)
				return null;
			CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
			if (elemCls == null)
				return null;

			return MakePlural(elemCls.Name);
		}

		public static string MakeMethodNameFromSPName(string spName)
		{
			int i = spName.IndexOf('_');
			if (i >= 0)
				spName = spName.Substring(i + 1);
			if (spName.Length > 3)
				if (spName.Substring(0, 3).ToLower() == "get")
					spName = "Load" + spName.Substring(3);
			return spName;
		}

		public static string MakeParamName(string s)
		{
			return "@" + s.Replace(" ", "_").Replace("/", "_");
		}

		public static string MakeSPLoadByPKName(string className)
		{
			return String.Format("usp_Load{0}", className);
		}

		public static string MakeSPExistsByPKName(string className)
		{
			return String.Format("usp_Exists{0}", className);
		}

		public static string MakeSPDeleteName(string className)
		{
			return String.Format("usp_Delete{0}", className);
		}

		public static string MakeSPUpdateName(string className)
		{
			return String.Format("usp_Update{0}", className);
		}

		public static string MakeSPInsertName(string className)
		{
			return String.Format("usp_Insert{0}", className);
		}

		public static string MakeSPLoadChildName(string parent, string child)
		{
			return MakeSPLoadChildName(null, parent, child);
		}

		public static string MakeSPLoadChildName(string spPrefix, string parent, string child)
		{
			return String.Format("usp_Load{0}{1}{2}", spPrefix, parent, child);
		}

		public static string GetDBTypeForType(CodeTypeRef typeRef)
		{
			Type type = null;
			try
			{
				type = Type.GetType(typeRef.AsString);
			}
			catch
			{
				// in the worst case use the after dot part
				return Util.GetLastTerm(typeRef.AsString).ToLower();
			}

			// Try to create a db type for the detected type
			return GetDBTypeForType(type);
		}

		public static string GetDBTypeForType(Type type)
		{
			if (type == typeof(string))
				return "varchar(255)";
			if (type == typeof(Int16))
				return "smallint";
			if (type == typeof(int))
				return "int";
			if (type == typeof(bool))
				return "bit";
			if (type == typeof(byte))
				return "tinyint";
			if (type == typeof(decimal))
				return "money";
			if (type == typeof(float))
				return "float";
			if (type == typeof(double))
				return "float";
			if (type == typeof(Guid))
				return "uniqueidentifier";
			if (type == typeof(byte[]))
				return "binary(64)";				// assumption
			return GetLastTerm(type.Name).ToLower();
		}

		public static string GetDBTypeForDataColumn(DataColumn col)
		{
			if (col == null)
				return null;
			if (col.DataType == typeof(string))
			{
				if (col.MaxLength > 0)
				{
					string dbTypeName = Convert.ToString( col.ExtendedProperties["TYPE_NAME"] );
					if (dbTypeName != null)
						dbTypeName = dbTypeName.ToUpper();
					if (dbTypeName == "TEXT")
						return "Text";

					return String.Format("varchar({0})", col.MaxLength);
				}
			}
            else if (col.DataType == typeof(decimal))
            {
                string dbTypeName = Convert.ToString(col.ExtendedProperties["TYPE_NAME"]);
                //if (dbTypeName != null)
                //dbTypeName = dbTypeName.ToUpper();

                return String.Format("decimal({0},{1})", col.ExtendedProperties["PRECISION"], col.ExtendedProperties["SCALE"]);
            }
			else if (col.DataType == typeof(byte[]))
			{
				return String.Format("binary({0})", (int)col.ExtendedProperties["LENGTH"]);
			}
			return GetDBTypeForType(col.DataType);
		}

		public static string GetValueForNullExp(Type type)
		{
			return null; // Automatically detected at runtime.  Optionally may be provided on the attribute.
			/*  
			if (type == null)
				return null;
			if (type == typeof(string))
				return "ValuesForNull.NullObject";
			if (type == typeof(DateTime))
				return "ValuesForNull.NullDateTime";
			if (type == typeof(Decimal))
				return "ValuesForNull.NullDecimal";
			if (type == typeof(Guid))
				return "ValuesForNull.NullGuid";
			//if (type == typeof(double))
			//	return EnvDTE.vsCMTypeRef.vsCMTypeRefDouble;
			//if (type == typeof(float))
			//	return EnvDTE.vsCMTypeRef.vsCMTypeRefFloat;
			//if (type == typeof(int))
			//	return EnvDTE.vsCMTypeRef.vsCMTypeRefInt;
			//if (type == typeof(long))
			//	return EnvDTE.vsCMTypeRef.vsCMTypeRefLong;
			//if (type == typeof(short))
			//	return EnvDTE.vsCMTypeRef.vsCMTypeRefShort;
			if (type == typeof(object))
				return "ValuesForNull.NullObject";
			return null;*/
		}

		public static string GetValueForNullExp(Type type, bool useComma)
		{
			string s = GetValueForNullExp(type);
			if (s == null)
				return null;
			if (useComma)
				return "," + s;
			else
				return s;
		}

		public static FormatterPropertyKind DetectFormatterPropertyKindFromDataCol(DataColumn col, bool allowThousands)
		{
			if (col != null)
			{
				if (col.DataType == typeof(string))
					return FormatterPropertyKind.UseAsIs;

				if (col.DataType == typeof(DateTime))
					return FormatterPropertyKind.ShortDate;

				if (col.DataType == typeof(Decimal))
					if (allowThousands)
						return FormatterPropertyKind.DecimalThousands;	// decimal will probabily a big number, so suggest comma sep
					else
						return FormatterPropertyKind.Decimal;

				if (col.DataType == typeof(float))
					return FormatterPropertyKind.Float;

				if (col.DataType == typeof(double))
					return FormatterPropertyKind.Double;
				
				if (col.DataType == typeof(System.Int32))
					return FormatterPropertyKind.Int;
			
			}
			return FormatterPropertyKind.UseConvert;
		}

		public static FormatterPropertyKind DetectFormatterPropertyKindFromElem(CodeElement elem)
		{
			if (elem != null)
			{
				CodeTypeRef t = Util.GetCodeTypeRefForMember(elem);

				string stereoType = GetStereoTypeForMember(elem);
				/*if (stereoType == null)
				{
					// not specified on the variable, try to look it up from column desc
					Hashtable extProps = new Hashtable();
					string desc;
					string sfulldesc = Util.GetColumnDescriptionFromDB(tblName, colName);
					Util.ParseColumnDescription(sfulldesc, out desc, extProps);
				}*/

				switch(stereoType)
				{
					case "DataStereoType.Currency":
						return FormatterPropertyKind.Currency;
					case "DataStereoType.USSSN":
						if (t!= null && t.TypeKind == vsCMTypeRef.vsCMTypeRefInt)
							return FormatterPropertyKind.USSSNInt;
						else
							return FormatterPropertyKind.USSSN;
					case "DataStereoType.USState":
						return FormatterPropertyKind.USState;
					case "DataStereoType.Gender":
						return FormatterPropertyKind.Gender;
					case "DataStereoType.USZipCode":
						if (t!= null && t.TypeKind == vsCMTypeRef.vsCMTypeRefInt)
							return FormatterPropertyKind.USZipCodeInt;
						else
							return FormatterPropertyKind.USZipCode;
					case "DataStereoType.USPhoneNumber":
						if (t!= null && t.TypeKind == vsCMTypeRef.vsCMTypeRefInt)
							return FormatterPropertyKind.USPhoneNumberInt;
						else
							return FormatterPropertyKind.USPhoneNumber;
					case "DataStereoType.Email":
						return FormatterPropertyKind.Email;
					case "DataStereoType.URL":
						return FormatterPropertyKind.URL;
					case "DataStereoType.Password":
						return FormatterPropertyKind.Password;
				}
			}
			return FormatterPropertyKind.Default;
		}

		public static bool GetJoinRelation(string JoinRelation, out string left, out string right)
		{
			if (JoinRelation == null)
			{
				left = null;
				right = null;
				return false;
			}

			ParseLogicalExp(JoinRelation, out left, out right, '=');
			return true;
		}

		public static string NoBracket(string term)
		{
			return term.Trim('[', ']');
		}

		public static string Bracket(string term)
		{
			if (term == "*")
				return term;
			else
				return "[" + NoBracket(term) + "]";
		}

		public static void ParseColumn(string fullColDesc, out string tableName, out string colName)
		{
			string[] terms = fullColDesc.Split('.');
			if (terms.Length == 0)
			{
				tableName = "";
				colName = "";
			}
			else if (terms.Length == 1)
			{
				tableName = "";
				colName = NoBracket(terms[0]);
			}
			else if (terms.Length == 2)
			{
				tableName = NoBracket(terms[0]);
				colName = NoBracket(terms[1]);
			}
			else
				throw new ArgumentException("Invalid column descriptor");
		}

        public static void ParseNamespaceType(string fullTypeName, out string nameSpace, out string typeName)
		{
            string[] terms = fullTypeName.Split('.');
			if (terms.Length == 0)
			{
				nameSpace = "";
				typeName = "";
			}
			else 
            {
                nameSpace = "";
                for (int i = 0; i < terms.Length - 1; i++)
                {
                    if (i > 0)
                        nameSpace += ".";
                    nameSpace += terms[i];
                }
				typeName = terms[terms.Length - 1];
			}
		}

		public static void ParseLogicalExp(string exp, out string left, out string right, char op)
		{
			string[] terms = exp.Split(op);
			if (terms.Length != 2)
				throw new ArgumentException("Invalid logical expression");
			else
			{
				left = terms[0];
				right = terms[1];
			}
		}

		public static Hashtable GetUsedJoins(CodeClass cls)
		{
            if (cls == null)
                return null;
			Hashtable usedJoins = new Hashtable();
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colName = Util.GetColMappingForVar(var);
					if (colName != null)
					{
						string joinRel = Util.GetJoinRelationForVar(var);
						if (joinRel != null)
						{
							string left, right;
							string joinTableLeft, joinColumnLeft;
							string joinTableRight, joinColumnRight;
							ParseLogicalExp(joinRel, out left, out right, '=');
							ParseColumn(left, out joinTableLeft, out joinColumnLeft);
							ParseColumn(right, out joinTableRight, out joinColumnRight);

							if (!usedJoins.Contains(joinTableRight))
								usedJoins[joinTableRight] = String.Format("[{0}].[{1}]=[{2}].[{3}]", joinTableLeft, joinColumnLeft, joinTableRight, joinColumnRight);
						}
					}
				}
			}

			if (usedJoins.Count > 0)
				return usedJoins;
			else
				return null;
		}

		public static string MakeJoinStatements(CodeClass cls)
		{
            if (cls == null)
                return null;

			Hashtable usedJoins = GetUsedJoins(cls);
			if (usedJoins == null)
				return null;

			StringBuilder joinClauses = new StringBuilder();

			foreach (DictionaryEntry joinEntry in usedJoins)
			{
				string joinTableRight = (string)joinEntry.Key;
				string joinRelation = (string)joinEntry.Value;
				string clause = "left join [" + joinTableRight + "] on " + joinRelation;
				joinClauses.Append(clause);
				joinClauses.Append(' ');
			}

			if (joinClauses.Length > 0)
				return joinClauses.ToString();
			else
				return null;
			
		}

		public static CodeVariable[] FindVars(CodeClass cls, string[] memberNames)
		{
            if (cls == null)
                return null;

			if (memberNames == null)
				return null;

			CodeVariable[] vars = new CodeVariable[memberNames.Length];
			for (int i = 0; i < memberNames.Length; i ++)
			{
				vars[i] = Util.FindFirstMember(cls, memberNames[i]) as CodeVariable;
				if (vars[i] == null)
					return null;
			}

			return vars;
		}

		public static void AddMembersAsFuncParam(CodeVariable[] vars, CodeFunction func)
		{
			for (int i = 0; i < vars.Length; i ++)
				func.AddParameter(vars[i].Name, vars[i].Type, -1);
		}

		public static string JoinStrings(string seperator, string[] strs, string format)
		{
			if (strs == null)
				return null;
			string s = null;
			for (int i = 0; i < strs.Length; i++)
			{
				if (i > 0)
					s += seperator;
				s += String.Format(format, strs[i]);
			}
			return s;
		}

		public static string[] SplitString(string s, char[] seperators, char[] trimchars)
		{
			if (s == null)
				return null;

			string[] strs = s.Split(seperators);

			if (trimchars.Length > 0)
			{
				for (int i = 0; i < strs.Length; i++)
				{
					strs[i] = strs[i].Trim(trimchars);
				}
			}
			return strs;
		}

		public static void FillMembersForColumn(CodeClass cls, string colName, ArrayList members)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					if (colName == Util.GetColMappingForVar(var, false))
						members.Add(elem.Name);
				}
			}

			// fill the members from bases
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillMembersForColumn(cls.Bases.Item(i) as CodeClass, colName, members);
				}
			}
		}

		public static string[] GetMembersForColumn(CodeClass cls, string colName)
		{
            if (cls == null)
                return null;
			ArrayList members = new ArrayList();
			FillMembersForColumn(cls, colName, members);
			return (string[])members.ToArray(typeof(string));
		}

		public static void FillMembersForColumns(CodeClass cls, Hashtable colMap)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colName = Util.GetColMappingForVar(var, false);
					if (colName != null)	// if there's a column mapping
					{
						ArrayList members = (ArrayList)colMap[colName];
						if (members == null)
						{
							members = new ArrayList();
							colMap[colName] = members;
						}
						members.Add(elem.Name);
					}
				}
			}

			// fill the members from bases
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillMembersForColumns(cls.Bases.Item(i) as CodeClass, colMap);
				}
			}
		}

		public static Hashtable FindMembersForColumns(CodeClass cls)
		{
            if (cls == null)
                return null;
			Hashtable colMap = new Hashtable();
			FillMembersForColumns(cls, colMap);
			return colMap;
		}

		public static void ArrangeListByTableColumnOrder(DataTable tbl, CodeClass cls, ListBox lst)
		{
			ArrangeListByTableColumnOrder(tbl, cls, lst, false);
		}

		public static void ArrangeListByTableColumnOrder(DataTable tbl, CodeClass cls, ListBox lst, bool memberNames)
		{
			if (tbl == null)
				return;
			Hashtable cols = new Hashtable();
			for (int i = 0; i < lst.Items.Count; i++)
				cols[(string)lst.Items[i]] = null;
			lst.Items.Clear();
			Hashtable colMap = Util.FindMembersForColumns(cls);
			for (int i = 0; i < tbl.Columns.Count; i++)
			{
				string col = tbl.Columns[i].ColumnName;

				if (memberNames)
				{
					// member names are in the list, check all the mappings
					//string[] members = Util.GetMembersForColumn(cls, col);
					ArrayList members = (ArrayList)colMap[col];
					if (members != null)
					{
						for (int j = 0; j < members.Count; j++)
						{
							string member = (string)members[j];
							if (cols.ContainsKey(member))
							{
								lst.Items.Add(member);
								cols.Remove(member);
							}
						}
					}
				}
				else
				{	// direct column names are in the list
					if (cols.ContainsKey(col))
					{
						lst.Items.Add(col);
						cols.Remove(col);
					}
				}
			}

			// add the rest
			foreach (DictionaryEntry de in cols)
				lst.Items.Add(de.Key);
		}

		public static void FillFieldsAndParams(CodeClass cls, ListBox lsAllFields, ListBox lsParams)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					//CodeVariable var = elem as CodeVariable;
					lsAllFields.Items.Add(elem.Name);
				}
			}

			// fill all fields in the bases
			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					FillFieldsAndParams(cls.Bases.Item(i) as CodeClass, lsAllFields, lsParams);
				}
			}
		}

		public static string[] GetStringArrayFromList(ListBox lst)
		{
			string[] arr = new string[lst.Items.Count];
			lst.Items.CopyTo(arr, 0);
			return arr;
		}

		public static void GetColMapMembers(CodeClass cls, ArrayList arr, bool includederived, bool colNames)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (elem.Kind == EnvDTE.vsCMElement.vsCMElementVariable)
				{
					CodeVariable var = elem as CodeVariable;
					string colName = Util.GetColMappingForVar(var, false);

					if (colName != null)	// only if mapped
						if (colNames)
							arr.Add(colName);
						else
							arr.Add(elem.Name);
				}
			}

			if (includederived)
			for (int i = 1; i <= cls.Bases.Count; i++)
				GetColMapMembers(cls.Bases.Item(i) as CodeClass, arr, includederived, colNames);
		}

		public static string[] GetColMapMembers(CodeClass cls, bool includederived, bool colNames)
		{
            if (cls == null)
                return null;
			ArrayList arr = new ArrayList();
			GetColMapMembers(cls, arr, includederived, colNames);
			return (string[])arr.ToArray(typeof(string));
		}

		public static DataColumn[] GetDataColumns(DataTable tbl, string[] cols)
		{
			DataColumn[] datacols = new DataColumn[cols.Length];
			for (int i = 0; i < cols.Length; i++)
			{
				datacols[i] = tbl.Columns[cols[i]];
				if (datacols[i] == null)
					return null;
			}
			return datacols;
		}

		public static string MakePropNameFromVarName(string varName)
		{
			string propName = varName;
			string firstLet = propName.Substring(0, 1);
			return firstLet.ToUpper() + propName.Substring(1);
		}

		/* // Doesn't work!
		public static bool IsStatic(EditPoint ep)
		{
			ep.StartOfLine();
			
			if (ep.GetLines(1, 2).IndexOf(" static ") >= 0)
				return true;
			else
				return false;
		}

		public static bool IsPropertyStatic(CodeProperty prop)
		{
			EditPoint ep = prop.Getter.StartPoint.CreateEditPoint();
			for (int i = 0; i < 3; i++)
			{
				ep.LineUp(1);
				if (ep.GetLines(1, 2).IndexOf(prop.Name) >= 0)
					return IsStatic(ep);
			}
			return false;
		}
		*/

		// Remove plural s
		public static string MakeSingular(string s)
		{
			if (s.Length > 0)
			{
				if (s.Length > 3 && s.Substring(s.Length - 3, 3).ToUpper() == "IES")
					s = s.Substring(0, s.Length - 3) + "y";
				else 
				{
					if (s.Substring(s.Length - 1, 1).ToUpper() == "S")
						s = s.Substring(0, s.Length - 1);
				}
			}
			return s;
		}

		// Add plural s
		public static string MakePlural(string s)
		{
			if (s == null)
				return null;
			if (s.Length == 0)
				return s;

			if (s.Length > 0)
			{
				if (s.Substring(s.Length - 1) == "s")
					return s + "es";

				if (s.Length > 2 && s.Substring(s.Length - 1, 1).ToUpper() == "Y")
				{
					if (s.Substring(s.Length - 2, 1).IndexOfAny(
							new char[] { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' } ) < 0)
						return s.Substring(0, s.Length - 1) + "ies";
				}
			}
			return s + "s";
		}

		public static string CreateCallArgsForFunction(CodeFunction func)
		{
			string args = null;

			for (int i = 1; i <= func.Parameters.Count; i++)
			{
				CodeParameter param = func.Parameters.Item(i) as CodeParameter;
				if (args != null)
					args += ", ";
				args += param.Name;
			}

			return args;
		}

		public static void GetAttributes(CodeClass cls, string attribName, ArrayList arr)
		{
            if (cls == null)
                return;
			for (int i = 1; i <= cls.Attributes.Count; i++)
			{
				CodeAttribute att = cls.Attributes.Item(i) as CodeAttribute;
				if (attribName == null || att.Name == attribName)
					arr.Add(att);
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
				{
					GetAttributes(cls.Bases.Item(i) as CodeClass, attribName, arr);
				}
			}
		}

		public static ArrayList GetAttributes(CodeClass cls, string attribName)
		{
			if (cls == null)
				return null;
			ArrayList arr = new ArrayList();
			GetAttributes(cls, attribName, arr);
			return arr;
		}

		public static ArrayList GetSPAutoGenAttributes(CodeClass cls)
		{
			return GetAttributes(cls, "SPAutoGen");
		}

		public static void GetSPAutoDeclAttribValues(CodeAttribute att, ref string spName, ref string spTemplate, ref string args, ref SPGenerationInjections injections, ref string manuallyManaged)
		{
			spName = Util.GetParamFromAttrib(att, null, 0);
			spTemplate = Util.GetParamFromAttrib(att, null, 1);
			args = Util.GetParamFromAttrib(att, null, 2);

			manuallyManaged = Util.GetParamFromAttrib(att, "ManuallyManaged", -1);
			
			injections = new SPGenerationInjections();
			injections.InjectPreOperation = Util.GetParamFromAttrib(att, "InjectPreOperation", -1);
			injections.InjectPostOperation = Util.GetParamFromAttrib(att, "InjectPostOperation", -1);
			injections.InjectWhere = Util.GetParamFromAttrib(att, "InjectWhere", -1);
			injections.InjectOrderBy = Util.GetParamFromAttrib(att, "InjectOrderBy", -1);
			injections.InjectParameters = Util.GetParamFromAttrib(att, "InjectParameters", -1);
		}

		public static CodeAttribute GetSPAutoDeclAttrib(CodeClass cls, string spName)
		{
            if (cls == null)
                return null;
			ArrayList arr = Util.GetSPAutoGenAttributes(cls);
			if (arr == null)
				return null;
			for (int i = 0; i < arr.Count; i++)
			{
				CodeAttribute att = arr[i] as CodeAttribute;
				if (spName == Util.GetParamFromAttrib(att, null, 0))
					return att;
			}
			return null;
		}

		public static ArrayList GetSPAutoDeclAttribForTemplate(CodeClass cls, string spTemplate)
		{
            if (cls == null)
                return null;
			ArrayList arr = Util.GetSPAutoGenAttributes(cls);
			if (arr == null)
				return null;
			ArrayList arrForTpl = new ArrayList();
			for (int i = 0; i < arr.Count; i++)
			{
				CodeAttribute att = arr[i] as CodeAttribute;
				if (spTemplate == Util.GetParamFromAttrib(att, null, 1))
					arrForTpl.Add(att);
			}
			return arrForTpl;
		}

		public static bool IsSharedMember(CodeClass cls, CodeElement elem)
		{
			CodeProperty prop = elem as CodeProperty;
			if (prop != null)
			{
				//if (Util.IsPropertyStatic(prop))
				if (prop.Type.TypeKind == vsCMTypeRef.vsCMTypeRefCodeType)
					if (cls.FullName == prop.Type.AsFullName)
						return true;
			}
			return false;
		}

		public static bool IsFieldValuesProp(CodeElement elem)
		{
			if (elem == null)
				return false;

			string elemName = elem.Name;
			if (elemName.Length >= 9)
			{
				if (elemName.Substring(0, 9) == "ValuesOf_" ||
					elemName.Substring(0, 9) == "LookupOf_")
					return true;
			}
			return false;
		}

		public static void FillSelectableColumnsAndTables(CodeClass cls, ArrayList columns, ArrayList joinColumns, ArrayList joinTables, ArrayList joinRelations)
		{
            if (cls == null)
                return;
			string tableName = Util.GetTableMappingForClass(cls, true);
			string[] mappedMembers = Util.GetColMapMembers(cls, true, false);
			Hashtable joinTblMap = new Hashtable();

			// Process joined columns
			for (int i = 0; i < mappedMembers.Length; i++)
			{
				string member = (string)mappedMembers[i];
				CodeVariable var = Util.FindFirstMember(cls, member) as CodeVariable;
				CodeAttribute att = Util.GetColMappingAtt(var);
				if (att != null && Util.IsColumnSelectable(att))
				{
					string columnName = Util.GetParamFromAttrib(att, "ColumnName", 0);
					string joinRelation = Util.GetParamFromAttrib(att, "JoinRelation", -1);

					if (joinRelation != null && joinRelation != "")
					{
						string joinColumn = Util.GetParamFromAttrib(att, "JoinColumn", -1);

						string[] terms = joinRelation.Split('=');
						if (terms.Length != 2)
							throw new Exception("Invalid join relation");
						string rightExp = terms[1].Trim();
						string leftExp = terms[0].Trim();
						string rightTable = rightExp.Split('.')[0].Trim(' ', '[', ']');
						string rightTableUpcase = rightTable.ToUpper();

						// add table if doesn't exist
						if (!joinTblMap.ContainsKey(rightTableUpcase))
						{
							int index = joinTables.Add(rightTable);
							joinRelations.Add(joinRelation);
							joinTblMap[rightTableUpcase] = index;
						}
						joinColumns.Add(String.Format("[{0}].[{1}] as {2}", rightTable, joinColumn, columnName));
					}
					else		// normal column
					{
						columns.Add(String.Format("[{0}].[{1}]", tableName, columnName));
					}

				}

			}

		}

		public static void GetSelectableColumnsAndJoinClauses(CodeClass cls, ref string cols, ref string joinClauses)
		{
            if (cls == null)
                return;
			ArrayList columns = new ArrayList();
			ArrayList joinColumns = new ArrayList();
			ArrayList joinTables = new ArrayList();
			ArrayList joinRelations = new ArrayList();
			Util.FillSelectableColumnsAndTables(cls, columns, joinColumns, joinTables, joinRelations);

			cols = String.Join(", ", (string[])columns.ToArray(typeof(string)) );
			string joincols = String.Join(", ", (string[])joinColumns.ToArray(typeof(string)) );
			if (joincols != null && joincols != "")
			{
				if (cols != null && cols != "")
					cols += ", ";
				cols += "\r\n-- join columns\r\n" + joincols;
			}

			// add join clauses
			joinClauses = null;
			for (int i = 0; i < joinTables.Count; i++)
				joinClauses += "LEFT JOIN [" + joinTables[i] + "] ON " + joinRelations[i] + "\r\n";
		}

		public static bool IsColumnInsertable(CodeAttribute colMapAtt)
		{
			if (colMapAtt == null)
				return true;
			if (Util.HasJoinRelation(colMapAtt))
				return false;

			string sqlGenFlagsExp = Util.GetParamFromAttrib(colMapAtt, "SQLGen", 3);
			ArrayList sqlGenFlags = Util.ParseFlags(sqlGenFlagsExp, true);
			if (Util.FindStringInArray(sqlGenFlags, "NoInsert") >= 0)
				return false;
			if (Util.FindStringInArray(sqlGenFlags, "NoInsertUpdate") >= 0)
				return false;
			return true;
		}

		public static bool IsColumnUpdatable(CodeAttribute colMapAtt)
		{
			if (colMapAtt == null)
				return true;
			if (Util.HasJoinRelation(colMapAtt))
				return false;

			string sqlGenFlagsExp = Util.GetParamFromAttrib(colMapAtt, "SQLGen", 3);
			ArrayList sqlGenFlags = Util.ParseFlags(sqlGenFlagsExp, true);
			if (Util.FindStringInArray(sqlGenFlags, "NoUpdate") >= 0)
				return false;
			if (Util.FindStringInArray(sqlGenFlags, "NoInsertUpdate") >= 0)
				return false;
			return true;
		}

		public static bool IsColumnSelectable(CodeAttribute colMapAtt)
		{
			if (colMapAtt == null)
				return true;
			string sqlGenFlagsExp = Util.GetParamFromAttrib(colMapAtt, "SQLGen", 3);
			ArrayList sqlGenFlags = Util.ParseFlags(sqlGenFlagsExp, true);
			if (Util.FindStringInArray(sqlGenFlags, "NoSelect") >= 0)
				return false;
			return true;
		}

		public static bool IsStatementTypeSupportedByColumn(CodeAttribute colMapAtt, EnumStatementType statementType)
		{
			switch (statementType)
			{
				case EnumStatementType.Update:
					return IsColumnUpdatable(colMapAtt);
				case EnumStatementType.Insert:
					return IsColumnInsertable(colMapAtt);
				case EnumStatementType.Select:
					return IsColumnSelectable(colMapAtt);
				default:
					return true;
			}
		}

		public static void AddRangeToArrayList(ArrayList arr, ICollection range)
		{
			if (range == null)
				return;
			arr.AddRange(range);
		}

        public static CodeNamespace FindCodeNamespace(CodeElements codeElements)
        {
            if (codeElements == null)
                return null;

            // Most probabily the namespace is the last element, so we start from the end.

            for (int i = codeElements.Count; i >= 1 ; i--)
            {
                Debug.WriteLine(codeElements.Item(i).Kind);
                if (codeElements.Item(i).Kind == vsCMElement.vsCMElementNamespace)
                {
                    CodeNamespace ns = codeElements.Item(i) as CodeNamespace;
                    if (ns != null)
                        return ns;
                }
            }
            return null;
        }

        public static string MakeColumnNameConstant(string tableName, string columnName)
        {
            return String.Format("DBTables.{0}.{1}", NormalizeIdentifierName(tableName, false, null), NormalizeIdentifierName(columnName, false, null));
        }

        public static string MakeColumnIdent(string tableName, string colName, bool useColumnNameConstant)
        {
            if (useColumnNameConstant)
                return Util.MakeColumnNameConstant(tableName, colName);
            else
                return "\"" + colName + "\"";
        }

        public static bool IsSystemValueType(string typeName)
        {
            if (typeName == "DateTime" || typeName == "Guid")
                return true;
            return typeName.StartsWith("System.");
        }

        public static List<MethodParamInfo> AnalyzeMethodSignature(EnvDTE.CodeFunction method)
        {
            List<MethodParamInfo> methodParams = new List<MethodParamInfo>();
            for (int i = 1; i <= method.Parameters.Count; i++)
            {
                // For each parameter, copy the entity to DTO
                EnvDTE80.CodeParameter2 param = method.Parameters.Item(i) as EnvDTE80.CodeParameter2;
                MethodParamInfo paramInfo = new MethodParamInfo(param);
                methodParams.Add(paramInfo);
            }

            return methodParams;
        }

    }


}
