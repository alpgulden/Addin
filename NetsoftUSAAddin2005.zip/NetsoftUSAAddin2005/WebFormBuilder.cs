using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Text;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

using System.Diagnostics;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class WebFormBuilder : System.Windows.Forms.Form
	{
		/*
		private TreeNode ndByDeclaredCtlType;
		private TreeNode ndTextBox;
		private TreeNode ndCheckBox;
		private TreeNode ndComboBox;
		private TreeNode ndUndefinedCtlTypes;*/
		
		private CodeClass cls;
		private CodeClass pageClass;
		private ControlGenerationOptions opt;
		private bool keepTemplate = false;
		private bool generatePreviewForMembers = false;
		private bool generatePreviewForOrdered = false;

		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ImageList icons;
		private System.Windows.Forms.TabPage tabBindableMembers;
		private System.Windows.Forms.TreeView tvBindables;
		private System.Windows.Forms.TabControl tab;
		private System.Windows.Forms.ColumnHeader colMember;
		private System.Windows.Forms.ListView listBindables;
		private System.Windows.Forms.TabPage tabHTMLTemplate;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtHeader;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtItem;
		private System.Windows.Forms.TextBox txtFooter;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cbTemplates;
		private System.Windows.Forms.Label lbHelp;
		private System.Windows.Forms.TabPage tabScriptGenOptions;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cbCtlGenerationMethod;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.TextBox txtPreview;
		private System.Windows.Forms.Splitter splitter2;
		private System.Windows.Forms.Button cmdShowEntityBuilder;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.CheckBox chkFormattersOnly;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.TextBox txtSearch;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ContextMenu macrosMenu;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.CheckBox chkFieldValuesProps;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.Button cmdCreateNewWebForm;
		private System.Windows.Forms.Button cmdSaveTemplate;
		private System.Windows.Forms.Button cmdNewTemplate;
		private System.Windows.Forms.Button cmdShowForm;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.CheckBox chkGenerateValidators;
		private System.Windows.Forms.MenuItem menuItem19;
		private System.Windows.Forms.CheckBox chkValidatorProps;
		private System.Windows.Forms.CheckBox chkAlwaysGenerateValidators;
		private System.Windows.Forms.Panel pnlLeft;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Splitter splitter3;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.Panel pnlRight;
		private System.Windows.Forms.ListView lstOrderedBindables;
		private System.Windows.Forms.LinkLabel butMoveUp;
		private System.Windows.Forms.LinkLabel butMoveDown;
		private System.Windows.Forms.LinkLabel butAddToOrdered;
		private System.Windows.Forms.LinkLabel butRemoveFromOrdered;
		private System.Windows.Forms.Timer timer1;
        private MenuItem menuItem20;
		private System.ComponentModel.IContainer components;

		public WebFormBuilder()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WebFormBuilder));
            this.lbHelp = new System.Windows.Forms.Label();
            this.butCancel = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.icons = new System.Windows.Forms.ImageList(this.components);
            this.tabBindableMembers = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.listBindables = new System.Windows.Forms.ListView();
            this.colMember = new System.Windows.Forms.ColumnHeader();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.butRemoveFromOrdered = new System.Windows.Forms.LinkLabel();
            this.butAddToOrdered = new System.Windows.Forms.LinkLabel();
            this.butMoveDown = new System.Windows.Forms.LinkLabel();
            this.butMoveUp = new System.Windows.Forms.LinkLabel();
            this.lstOrderedBindables = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.tvBindables = new System.Windows.Forms.TreeView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.chkValidatorProps = new System.Windows.Forms.CheckBox();
            this.chkFormattersOnly = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.chkFieldValuesProps = new System.Windows.Forms.CheckBox();
            this.tab = new System.Windows.Forms.TabControl();
            this.tabHTMLTemplate = new System.Windows.Forms.TabPage();
            this.cmdSaveTemplate = new System.Windows.Forms.Button();
            this.cbTemplates = new System.Windows.Forms.ComboBox();
            this.cmdNewTemplate = new System.Windows.Forms.Button();
            this.txtHeader = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtItem = new System.Windows.Forms.TextBox();
            this.macrosMenu = new System.Windows.Forms.ContextMenu();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem12 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem19 = new System.Windows.Forms.MenuItem();
            this.menuItem14 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.menuItem15 = new System.Windows.Forms.MenuItem();
            this.menuItem16 = new System.Windows.Forms.MenuItem();
            this.menuItem17 = new System.Windows.Forms.MenuItem();
            this.menuItem18 = new System.Windows.Forms.MenuItem();
            this.menuItem13 = new System.Windows.Forms.MenuItem();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFooter = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabScriptGenOptions = new System.Windows.Forms.TabPage();
            this.chkAlwaysGenerateValidators = new System.Windows.Forms.CheckBox();
            this.chkGenerateValidators = new System.Windows.Forms.CheckBox();
            this.cbCtlGenerationMethod = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmdCreateNewWebForm = new System.Windows.Forms.Button();
            this.cmdShowEntityBuilder = new System.Windows.Forms.Button();
            this.cmdShowForm = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.txtPreview = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuItem20 = new System.Windows.Forms.MenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabBindableMembers.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tab.SuspendLayout();
            this.tabHTMLTemplate.SuspendLayout();
            this.tabScriptGenOptions.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHelp
            // 
            this.lbHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbHelp.Location = new System.Drawing.Point(152, 8);
            this.lbHelp.Name = "lbHelp";
            this.lbHelp.Size = new System.Drawing.Size(232, 56);
            this.lbHelp.TabIndex = 3;
            this.lbHelp.Text = "lbHelp";
            // 
            // butCancel
            // 
            this.butCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel.Location = new System.Drawing.Point(304, 8);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 2;
            this.butCancel.Text = "Close";
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // icons
            // 
            this.icons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("icons.ImageStream")));
            this.icons.TransparentColor = System.Drawing.Color.White;
            this.icons.Images.SetKeyName(0, "");
            this.icons.Images.SetKeyName(1, "");
            this.icons.Images.SetKeyName(2, "");
            this.icons.Images.SetKeyName(3, "");
            this.icons.Images.SetKeyName(4, "");
            this.icons.Images.SetKeyName(5, "");
            this.icons.Images.SetKeyName(6, "");
            this.icons.Images.SetKeyName(7, "");
            this.icons.Images.SetKeyName(8, "");
            this.icons.Images.SetKeyName(9, "");
            this.icons.Images.SetKeyName(10, "");
            this.icons.Images.SetKeyName(11, "");
            this.icons.Images.SetKeyName(12, "");
            this.icons.Images.SetKeyName(13, "");
            this.icons.Images.SetKeyName(14, "");
            // 
            // tabBindableMembers
            // 
            this.tabBindableMembers.Controls.Add(this.panel1);
            this.tabBindableMembers.Location = new System.Drawing.Point(4, 22);
            this.tabBindableMembers.Name = "tabBindableMembers";
            this.tabBindableMembers.Size = new System.Drawing.Size(384, 315);
            this.tabBindableMembers.TabIndex = 0;
            this.tabBindableMembers.Text = "Bindable Members";
            this.tabBindableMembers.ToolTipText = "Bindable public members of the class.  You can drag and drop these members onto a" +
                " web form.";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 315);
            this.panel1.TabIndex = 10;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 48);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(384, 267);
            this.panel9.TabIndex = 10;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.pnlRight);
            this.panel11.Controls.Add(this.splitter1);
            this.panel11.Controls.Add(this.pnlLeft);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(384, 267);
            this.panel11.TabIndex = 11;
            // 
            // pnlRight
            // 
            this.pnlRight.Controls.Add(this.listBindables);
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRight.Location = new System.Drawing.Point(276, 0);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Padding = new System.Windows.Forms.Padding(4);
            this.pnlRight.Size = new System.Drawing.Size(108, 267);
            this.pnlRight.TabIndex = 15;
            // 
            // listBindables
            // 
            this.listBindables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBindables.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMember});
            this.listBindables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBindables.HideSelection = false;
            this.listBindables.Location = new System.Drawing.Point(4, 4);
            this.listBindables.Name = "listBindables";
            this.listBindables.Size = new System.Drawing.Size(100, 259);
            this.listBindables.SmallImageList = this.icons;
            this.listBindables.TabIndex = 8;
            this.listBindables.UseCompatibleStateImageBehavior = false;
            this.listBindables.View = System.Windows.Forms.View.Details;
            this.listBindables.DoubleClick += new System.EventHandler(this.listBindables_DoubleClick);
            this.listBindables.SelectedIndexChanged += new System.EventHandler(this.listBindables_SelectedIndexChanged);
            this.listBindables.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.listBindables_ItemDrag);
            this.listBindables.Click += new System.EventHandler(this.listBindables_Click);
            // 
            // colMember
            // 
            this.colMember.Text = "Member";
            this.colMember.Width = 218;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(272, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 267);
            this.splitter1.TabIndex = 14;
            this.splitter1.TabStop = false;
            // 
            // pnlLeft
            // 
            this.pnlLeft.Controls.Add(this.butRemoveFromOrdered);
            this.pnlLeft.Controls.Add(this.butAddToOrdered);
            this.pnlLeft.Controls.Add(this.butMoveDown);
            this.pnlLeft.Controls.Add(this.butMoveUp);
            this.pnlLeft.Controls.Add(this.lstOrderedBindables);
            this.pnlLeft.Controls.Add(this.splitter3);
            this.pnlLeft.Controls.Add(this.tvBindables);
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Padding = new System.Windows.Forms.Padding(4, 4, 4, 20);
            this.pnlLeft.Size = new System.Drawing.Size(272, 267);
            this.pnlLeft.TabIndex = 13;
            // 
            // butRemoveFromOrdered
            // 
            this.butRemoveFromOrdered.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.butRemoveFromOrdered.Location = new System.Drawing.Point(248, 250);
            this.butRemoveFromOrdered.Name = "butRemoveFromOrdered";
            this.butRemoveFromOrdered.Size = new System.Drawing.Size(24, 16);
            this.butRemoveFromOrdered.TabIndex = 18;
            this.butRemoveFromOrdered.TabStop = true;
            this.butRemoveFromOrdered.Text = ">>";
            this.butRemoveFromOrdered.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butRemoveFromOrdered_LinkClicked);
            // 
            // butAddToOrdered
            // 
            this.butAddToOrdered.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.butAddToOrdered.Location = new System.Drawing.Point(220, 250);
            this.butAddToOrdered.Name = "butAddToOrdered";
            this.butAddToOrdered.Size = new System.Drawing.Size(24, 16);
            this.butAddToOrdered.TabIndex = 17;
            this.butAddToOrdered.TabStop = true;
            this.butAddToOrdered.Text = "<<";
            this.butAddToOrdered.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butAddToOrdered_LinkClicked);
            // 
            // butMoveDown
            // 
            this.butMoveDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.butMoveDown.Location = new System.Drawing.Point(32, 250);
            this.butMoveDown.Name = "butMoveDown";
            this.butMoveDown.Size = new System.Drawing.Size(40, 16);
            this.butMoveDown.TabIndex = 16;
            this.butMoveDown.TabStop = true;
            this.butMoveDown.Text = "Down";
            this.butMoveDown.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butMoveDown_LinkClicked);
            // 
            // butMoveUp
            // 
            this.butMoveUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.butMoveUp.Location = new System.Drawing.Point(8, 250);
            this.butMoveUp.Name = "butMoveUp";
            this.butMoveUp.Size = new System.Drawing.Size(24, 16);
            this.butMoveUp.TabIndex = 15;
            this.butMoveUp.TabStop = true;
            this.butMoveUp.Text = "Up";
            this.butMoveUp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butMoveUp_LinkClicked);
            // 
            // lstOrderedBindables
            // 
            this.lstOrderedBindables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstOrderedBindables.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lstOrderedBindables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstOrderedBindables.HideSelection = false;
            this.lstOrderedBindables.Location = new System.Drawing.Point(4, 88);
            this.lstOrderedBindables.Name = "lstOrderedBindables";
            this.lstOrderedBindables.Size = new System.Drawing.Size(264, 159);
            this.lstOrderedBindables.SmallImageList = this.icons;
            this.lstOrderedBindables.TabIndex = 14;
            this.lstOrderedBindables.UseCompatibleStateImageBehavior = false;
            this.lstOrderedBindables.View = System.Windows.Forms.View.Details;
            this.lstOrderedBindables.DoubleClick += new System.EventHandler(this.lstOrderedBindables_DoubleClick);
            this.lstOrderedBindables.SelectedIndexChanged += new System.EventHandler(this.lstOrderedBindables_SelectedIndexChanged);
            this.lstOrderedBindables.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lstOrderedBindables_KeyPress);
            this.lstOrderedBindables.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.lstOrderedBindables_ItemDrag);
            this.lstOrderedBindables.Click += new System.EventHandler(this.lstOrderedBindables_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ordered Controls";
            this.columnHeader1.Width = 255;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter3.Location = new System.Drawing.Point(4, 84);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(264, 4);
            this.splitter3.TabIndex = 13;
            this.splitter3.TabStop = false;
            // 
            // tvBindables
            // 
            this.tvBindables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tvBindables.Dock = System.Windows.Forms.DockStyle.Top;
            this.tvBindables.HideSelection = false;
            this.tvBindables.Location = new System.Drawing.Point(4, 4);
            this.tvBindables.Name = "tvBindables";
            this.tvBindables.Size = new System.Drawing.Size(264, 80);
            this.tvBindables.TabIndex = 0;
            this.tvBindables.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvBindables_AfterSelect);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtSearch);
            this.panel8.Controls.Add(this.chkValidatorProps);
            this.panel8.Controls.Add(this.chkFormattersOnly);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.chkFieldValuesProps);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(384, 48);
            this.panel8.TabIndex = 9;
            // 
            // txtSearch
            // 
            this.txtSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Location = new System.Drawing.Point(264, 5);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(112, 20);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.Enter += new System.EventHandler(this.txtSearch_Enter);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // chkValidatorProps
            // 
            this.chkValidatorProps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkValidatorProps.Location = new System.Drawing.Point(8, 33);
            this.chkValidatorProps.Name = "chkValidatorProps";
            this.chkValidatorProps.Size = new System.Drawing.Size(160, 16);
            this.chkValidatorProps.TabIndex = 0;
            this.chkValidatorProps.Text = "Validator Properties";
            this.chkValidatorProps.CheckedChanged += new System.EventHandler(this.chkFormattersOnly_CheckedChanged);
            // 
            // chkFormattersOnly
            // 
            this.chkFormattersOnly.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkFormattersOnly.Location = new System.Drawing.Point(8, 4);
            this.chkFormattersOnly.Name = "chkFormattersOnly";
            this.chkFormattersOnly.Size = new System.Drawing.Size(104, 16);
            this.chkFormattersOnly.TabIndex = 0;
            this.chkFormattersOnly.Text = "Formatters Only";
            this.chkFormattersOnly.CheckedChanged += new System.EventHandler(this.chkFormattersOnly_CheckedChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.Location = new System.Drawing.Point(216, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Search:";
            // 
            // chkFieldValuesProps
            // 
            this.chkFieldValuesProps.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkFieldValuesProps.Location = new System.Drawing.Point(8, 19);
            this.chkFieldValuesProps.Name = "chkFieldValuesProps";
            this.chkFieldValuesProps.Size = new System.Drawing.Size(160, 16);
            this.chkFieldValuesProps.TabIndex = 0;
            this.chkFieldValuesProps.Text = "Field Values Properties";
            this.chkFieldValuesProps.CheckedChanged += new System.EventHandler(this.chkFormattersOnly_CheckedChanged);
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabBindableMembers);
            this.tab.Controls.Add(this.tabHTMLTemplate);
            this.tab.Controls.Add(this.tabScriptGenOptions);
            this.tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab.HotTrack = true;
            this.tab.ItemSize = new System.Drawing.Size(99, 18);
            this.tab.Location = new System.Drawing.Point(0, 0);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(392, 341);
            this.tab.TabIndex = 7;
            this.tab.SelectedIndexChanged += new System.EventHandler(this.tab_SelectedIndexChanged);
            // 
            // tabHTMLTemplate
            // 
            this.tabHTMLTemplate.Controls.Add(this.cmdSaveTemplate);
            this.tabHTMLTemplate.Controls.Add(this.cbTemplates);
            this.tabHTMLTemplate.Controls.Add(this.cmdNewTemplate);
            this.tabHTMLTemplate.Controls.Add(this.txtHeader);
            this.tabHTMLTemplate.Controls.Add(this.label4);
            this.tabHTMLTemplate.Controls.Add(this.txtItem);
            this.tabHTMLTemplate.Controls.Add(this.label3);
            this.tabHTMLTemplate.Controls.Add(this.label1);
            this.tabHTMLTemplate.Controls.Add(this.txtFooter);
            this.tabHTMLTemplate.Controls.Add(this.label5);
            this.tabHTMLTemplate.Location = new System.Drawing.Point(4, 22);
            this.tabHTMLTemplate.Name = "tabHTMLTemplate";
            this.tabHTMLTemplate.Size = new System.Drawing.Size(384, 315);
            this.tabHTMLTemplate.TabIndex = 1;
            this.tabHTMLTemplate.Text = "HTML Template";
            this.tabHTMLTemplate.ToolTipText = "HTML Templates to be used in the generation of HTML script to be dropped.";
            // 
            // cmdSaveTemplate
            // 
            this.cmdSaveTemplate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdSaveTemplate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdSaveTemplate.Location = new System.Drawing.Point(328, 8);
            this.cmdSaveTemplate.Name = "cmdSaveTemplate";
            this.cmdSaveTemplate.Size = new System.Drawing.Size(40, 20);
            this.cmdSaveTemplate.TabIndex = 5;
            this.cmdSaveTemplate.Text = "Save";
            this.cmdSaveTemplate.Click += new System.EventHandler(this.cmdSaveTemplate_Click);
            // 
            // cbTemplates
            // 
            this.cbTemplates.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbTemplates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTemplates.Location = new System.Drawing.Point(72, 8);
            this.cbTemplates.Name = "cbTemplates";
            this.cbTemplates.Size = new System.Drawing.Size(216, 21);
            this.cbTemplates.TabIndex = 0;
            this.cbTemplates.SelectedIndexChanged += new System.EventHandler(this.cbTemplates_SelectedIndexChanged);
            this.cbTemplates.TextChanged += new System.EventHandler(this.cbTemplates_TextChanged);
            // 
            // cmdNewTemplate
            // 
            this.cmdNewTemplate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdNewTemplate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdNewTemplate.Location = new System.Drawing.Point(288, 8);
            this.cmdNewTemplate.Name = "cmdNewTemplate";
            this.cmdNewTemplate.Size = new System.Drawing.Size(40, 20);
            this.cmdNewTemplate.TabIndex = 4;
            this.cmdNewTemplate.Text = "New";
            this.cmdNewTemplate.Click += new System.EventHandler(this.cmdNewTemplate_Click);
            // 
            // txtHeader
            // 
            this.txtHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtHeader.Location = new System.Drawing.Point(72, 32);
            this.txtHeader.Multiline = true;
            this.txtHeader.Name = "txtHeader";
            this.txtHeader.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtHeader.Size = new System.Drawing.Size(296, 64);
            this.txtHeader.TabIndex = 1;
            this.txtHeader.WordWrap = false;
            this.txtHeader.TextChanged += new System.EventHandler(this.txtHeader_TextChanged);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 4;
            this.label4.Text = "Template";
            // 
            // txtItem
            // 
            this.txtItem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtItem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtItem.ContextMenu = this.macrosMenu;
            this.txtItem.Location = new System.Drawing.Point(72, 104);
            this.txtItem.Multiline = true;
            this.txtItem.Name = "txtItem";
            this.txtItem.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtItem.Size = new System.Drawing.Size(296, 127);
            this.txtItem.TabIndex = 2;
            this.txtItem.Text = "*<BR>";
            this.txtItem.WordWrap = false;
            this.txtItem.TextChanged += new System.EventHandler(this.txtItem_TextChanged);
            // 
            // macrosMenu
            // 
            this.macrosMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem5,
            this.menuItem10,
            this.menuItem12,
            this.menuItem20,
            this.menuItem9,
            this.menuItem19,
            this.menuItem14,
            this.menuItem11,
            this.menuItem13});
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 0;
            this.menuItem5.Text = "CONTROL";
            this.menuItem5.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 1;
            this.menuItem10.Text = "BOUNDCONTROL";
            this.menuItem10.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem12
            // 
            this.menuItem12.Index = 2;
            this.menuItem12.Text = "DATAGRIDCOLUMN";
            this.menuItem12.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 4;
            this.menuItem9.Text = "FIELDLABEL";
            this.menuItem9.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem19
            // 
            this.menuItem19.Index = 5;
            this.menuItem19.Text = "VALIDATORS";
            this.menuItem19.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem14
            // 
            this.menuItem14.Index = 6;
            this.menuItem14.Text = "-";
            // 
            // menuItem11
            // 
            this.menuItem11.Index = 7;
            this.menuItem11.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem15,
            this.menuItem16,
            this.menuItem17,
            this.menuItem18});
            this.menuItem11.Text = "Non-input Controls";
            // 
            // menuItem15
            // 
            this.menuItem15.Index = 0;
            this.menuItem15.Text = "BUTTON";
            this.menuItem15.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem16
            // 
            this.menuItem16.Index = 1;
            this.menuItem16.Text = "LINKBUTTON";
            this.menuItem16.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem17
            // 
            this.menuItem17.Index = 2;
            this.menuItem17.Text = "IMAGEBUTTON";
            this.menuItem17.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem18
            // 
            this.menuItem18.Index = 3;
            this.menuItem18.Text = "HYPERLINK";
            this.menuItem18.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem13
            // 
            this.menuItem13.Index = 8;
            this.menuItem13.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem2,
            this.menuItem3,
            this.menuItem4,
            this.menuItem6,
            this.menuItem7,
            this.menuItem8});
            this.menuItem13.Text = "Special Functions";
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.Text = "NAME";
            this.menuItem1.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 1;
            this.menuItem2.Text = "CLASSNAME";
            this.menuItem2.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 2;
            this.menuItem3.Text = "FULLCLASSNAME";
            this.menuItem3.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 3;
            this.menuItem4.Text = "ASSEMBLYNAME";
            this.menuItem4.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 4;
            this.menuItem6.Text = "COUNT";
            this.menuItem6.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 5;
            this.menuItem7.Text = "COUNTER";
            this.menuItem7.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 6;
            this.menuItem8.Text = "TOGGLER";
            this.menuItem8.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 40);
            this.label3.TabIndex = 2;
            this.label3.Text = "Item Template";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Header";
            // 
            // txtFooter
            // 
            this.txtFooter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFooter.Location = new System.Drawing.Point(72, 240);
            this.txtFooter.Multiline = true;
            this.txtFooter.Name = "txtFooter";
            this.txtFooter.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtFooter.Size = new System.Drawing.Size(296, 64);
            this.txtFooter.TabIndex = 3;
            this.txtFooter.WordWrap = false;
            this.txtFooter.TextChanged += new System.EventHandler(this.txtFooter_TextChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.Location = new System.Drawing.Point(16, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 2;
            this.label5.Text = "Footer";
            // 
            // tabScriptGenOptions
            // 
            this.tabScriptGenOptions.Controls.Add(this.chkAlwaysGenerateValidators);
            this.tabScriptGenOptions.Controls.Add(this.chkGenerateValidators);
            this.tabScriptGenOptions.Controls.Add(this.cbCtlGenerationMethod);
            this.tabScriptGenOptions.Controls.Add(this.label2);
            this.tabScriptGenOptions.Location = new System.Drawing.Point(4, 22);
            this.tabScriptGenOptions.Name = "tabScriptGenOptions";
            this.tabScriptGenOptions.Size = new System.Drawing.Size(384, 315);
            this.tabScriptGenOptions.TabIndex = 2;
            this.tabScriptGenOptions.Text = "Options";
            this.tabScriptGenOptions.ToolTipText = "Script generation options.";
            // 
            // chkAlwaysGenerateValidators
            // 
            this.chkAlwaysGenerateValidators.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAlwaysGenerateValidators.Location = new System.Drawing.Point(24, 96);
            this.chkAlwaysGenerateValidators.Name = "chkAlwaysGenerateValidators";
            this.chkAlwaysGenerateValidators.Size = new System.Drawing.Size(232, 24);
            this.chkAlwaysGenerateValidators.TabIndex = 4;
            this.chkAlwaysGenerateValidators.Text = "Always Generate Validators";
            this.chkAlwaysGenerateValidators.CheckedChanged += new System.EventHandler(this.chkAlwaysGenerateValidators_CheckedChanged);
            // 
            // chkGenerateValidators
            // 
            this.chkGenerateValidators.Checked = true;
            this.chkGenerateValidators.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkGenerateValidators.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkGenerateValidators.Location = new System.Drawing.Point(24, 72);
            this.chkGenerateValidators.Name = "chkGenerateValidators";
            this.chkGenerateValidators.Size = new System.Drawing.Size(232, 24);
            this.chkGenerateValidators.TabIndex = 2;
            this.chkGenerateValidators.Text = "Generate Validators if declared";
            this.chkGenerateValidators.CheckedChanged += new System.EventHandler(this.chkGenerateValidators_CheckedChanged);
            // 
            // cbCtlGenerationMethod
            // 
            this.cbCtlGenerationMethod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbCtlGenerationMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCtlGenerationMethod.Items.AddRange(new object[] {
            "Use Netsoft OB controls",
            "Use Netsoft Wrappers for Infragistics",
            "Use Standard ASP controls",
            "Use Standard HTML controls"});
            this.cbCtlGenerationMethod.Location = new System.Drawing.Point(24, 40);
            this.cbCtlGenerationMethod.Name = "cbCtlGenerationMethod";
            this.cbCtlGenerationMethod.Size = new System.Drawing.Size(336, 21);
            this.cbCtlGenerationMethod.TabIndex = 0;
            this.cbCtlGenerationMethod.SelectedIndexChanged += new System.EventHandler(this.cbCtlGenerationMethod_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Control Generation Method:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.butCancel);
            this.panel2.Controls.Add(this.cmdCreateNewWebForm);
            this.panel2.Controls.Add(this.cmdShowEntityBuilder);
            this.panel2.Controls.Add(this.cmdShowForm);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 469);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(392, 40);
            this.panel2.TabIndex = 8;
            // 
            // cmdCreateNewWebForm
            // 
            this.cmdCreateNewWebForm.Location = new System.Drawing.Point(8, 8);
            this.cmdCreateNewWebForm.Name = "cmdCreateNewWebForm";
            this.cmdCreateNewWebForm.Size = new System.Drawing.Size(96, 23);
            this.cmdCreateNewWebForm.TabIndex = 0;
            this.cmdCreateNewWebForm.Text = "New Web Form";
            this.cmdCreateNewWebForm.Click += new System.EventHandler(this.cmdCreateNewWebForm_Click);
            // 
            // cmdShowEntityBuilder
            // 
            this.cmdShowEntityBuilder.Location = new System.Drawing.Point(184, 8);
            this.cmdShowEntityBuilder.Name = "cmdShowEntityBuilder";
            this.cmdShowEntityBuilder.Size = new System.Drawing.Size(120, 23);
            this.cmdShowEntityBuilder.TabIndex = 1;
            this.cmdShowEntityBuilder.Text = "Entity Class Builder";
            this.cmdShowEntityBuilder.Click += new System.EventHandler(this.cmdShowEntityBuilder_Click);
            // 
            // cmdShowForm
            // 
            this.cmdShowForm.Location = new System.Drawing.Point(104, 8);
            this.cmdShowForm.Name = "cmdShowForm";
            this.cmdShowForm.Size = new System.Drawing.Size(80, 23);
            this.cmdShowForm.TabIndex = 1;
            this.cmdShowForm.Text = "Web Form";
            this.cmdShowForm.Click += new System.EventHandler(this.cmdShowForm_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(392, 72);
            this.panel3.TabIndex = 9;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel10);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(392, 72);
            this.panel7.TabIndex = 7;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.lbHelp);
            this.panel10.Controls.Add(this.pictureBox1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(392, 72);
            this.panel10.TabIndex = 6;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.splitter2);
            this.panel6.Controls.Add(this.tab);
            this.panel6.Controls.Add(this.txtPreview);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 72);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(392, 397);
            this.panel6.TabIndex = 12;
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter2.Location = new System.Drawing.Point(0, 337);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(392, 4);
            this.splitter2.TabIndex = 12;
            this.splitter2.TabStop = false;
            // 
            // txtPreview
            // 
            this.txtPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPreview.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtPreview.Location = new System.Drawing.Point(0, 341);
            this.txtPreview.Multiline = true;
            this.txtPreview.Name = "txtPreview";
            this.txtPreview.ReadOnly = true;
            this.txtPreview.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPreview.Size = new System.Drawing.Size(392, 56);
            this.txtPreview.TabIndex = 0;
            this.txtPreview.WordWrap = false;
            this.txtPreview.Enter += new System.EventHandler(this.txtPreview_Enter);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 400;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuItem20
            // 
            this.menuItem20.Index = 3;
            this.menuItem20.Text = "GRIDVIEWCOLUMN";
            this.menuItem20.Click += new System.EventHandler(this.macrosMenu_Click);
            // 
            // WebFormBuilder
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(392, 509);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "WebFormBuilder";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Netsoft USA Web Form Builder";
            this.TopMost = true;
            this.Closing += new System.ComponentModel.CancelEventHandler(this.WebFormBuilder_Closing);
            this.Load += new System.EventHandler(this.WebFormBuilder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabBindableMembers.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.pnlRight.ResumeLayout(false);
            this.pnlLeft.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tab.ResumeLayout(false);
            this.tabHTMLTemplate.ResumeLayout(false);
            this.tabHTMLTemplate.PerformLayout();
            this.tabScriptGenOptions.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

		}
		#endregion

		public static void BuildWebForm(CodeClass cls, CodeClass pageClass)
		{
			WebFormBuilder wfb = new WebFormBuilder();
			wfb.cls = cls;
			wfb.pageClass = pageClass;
			wfb.Show();
		}

		public static void BuildWebForm(CodeClass cls)
		{
			BuildWebForm(cls, null);
		}

		private void RefillBindableMembers()
		{
			FillBindables(tvBindables.SelectedNode);
		}

		private void FillBindables(TreeNode nd)
		{
			if (nd == null)
				return;
			BindableFilter filter = nd.Tag as BindableFilter;
			if (filter != null)
			{
				lbHelp.Text = filter.GetDescription();
				filter.FillBindables(cls, listBindables, GetFilteringOptions());
			}
		}

		private void FillBindables()
		{
			tvBindables.Nodes.Clear();
			TreeNode group = null, nd = null;
			group = tvBindables.Nodes.Add("Bindable members by declared control type");
			group.Tag = new AllControlTypesFilter();
				nd = group.Nodes.Add("Label Only");
				nd.Tag = new LabelFilter();
				nd = group.Nodes.Add("TextBox Only");
				nd.Tag = new TextBoxFilter();
				nd = group.Nodes.Add("ComboBox Only");
				nd.Tag = new ComboBoxFilter();
				nd = group.Nodes.Add("CheckBox Only");
				nd.Tag = new CheckBoxFilter();
				nd = group.Nodes.Add("MultiCheckBox Only");
				nd.Tag = new MultiCheckBoxFilter();
				nd = group.Nodes.Add("RadioButtonBox Only");
				nd.Tag = new RadioButtonBoxFilter();
				//nd = group.Nodes.Add("Button Only");
				//nd.Tag = new RadioButtonBoxFilter();
				nd = group.Nodes.Add("Undefined Only");
				nd.Tag = new UndefinedControlTypesFilter();
				nd = group.Nodes.Add("Defined Only");
				nd.Tag = new UndefinedControlTypesFilter(true);

			group = tvBindables.Nodes.Add("Bindable members by forced control type");
			TreeNode fctNode = group;
			group.Tag = new AllControlTypesFilter("TextBox");
				nd = group.Nodes.Add("As Label");
				nd.Tag = new AllControlTypesFilter("Label");
				nd = group.Nodes.Add("As TextBox");
				nd.Tag = new AllControlTypesFilter("TextBox");
				nd = group.Nodes.Add("As ComboBox");
				nd.Tag = new AllControlTypesFilter("ComboBox");
				nd = group.Nodes.Add("As CheckBox");
				nd.Tag = new AllControlTypesFilter("CheckBox");
				nd = group.Nodes.Add("As MultiCheckBox");
				nd.Tag = new AllControlTypesFilter("MultiCheckBox");
				nd = group.Nodes.Add("As RadioButtonBox");
				nd.Tag = new AllControlTypesFilter("RadioButtonBox");
				
				group = group.Nodes.Add("Undefined Only");
				group.Tag = new UndefinedControlTypesFilter("TextBox");
					nd = group.Nodes.Add("As Label");
					nd.Tag = new UndefinedControlTypesFilter("Label");
					nd = group.Nodes.Add("As TextBox");
					nd.Tag = new UndefinedControlTypesFilter("TextBox");
					nd = group.Nodes.Add("As ComboBox");
					nd.Tag = new UndefinedControlTypesFilter("ComboBox");
					nd = group.Nodes.Add("As CheckBox");
					nd.Tag = new UndefinedControlTypesFilter("CheckBox");
					nd = group.Nodes.Add("As MultiCheckBox");
					nd.Tag = new UndefinedControlTypesFilter("MultiCheckBox");
					nd = group.Nodes.Add("As RadioButtonBox");
					nd.Tag = new UndefinedControlTypesFilter("RadioButtonBox");
				group = fctNode;
				group = group.Nodes.Add("Defined Only");
				group.Tag = new UndefinedControlTypesFilter("TextBox", true);
					nd = group.Nodes.Add("As Label");
					nd.Tag = new UndefinedControlTypesFilter("Label", true);
					nd = group.Nodes.Add("As TextBox");
					nd.Tag = new UndefinedControlTypesFilter("TextBox", true);
					nd = group.Nodes.Add("As ComboBox");
					nd.Tag = new UndefinedControlTypesFilter("ComboBox", true);
					nd = group.Nodes.Add("As CheckBox");
					nd.Tag = new UndefinedControlTypesFilter("CheckBox", true);
					nd = group.Nodes.Add("As MultiCheckBox");
					nd.Tag = new UndefinedControlTypesFilter("MultiCheckBox", true);
					nd = group.Nodes.Add("As RadioButtonBox");
					nd.Tag = new UndefinedControlTypesFilter("RadioButtonBox", true);

			tvBindables.SelectedNode = tvBindables.TopNode;
		}

		private string DataProjPath
		{
			get
			{
				string projPath = cls.ProjectItem.ContainingProject.FullName;
				projPath = Path.GetDirectoryName(projPath);
				return projPath;
			}
		}

		private string HTMLTemplatesPath
		{
			get
			{
				return this.DataProjPath + @"\HTMLTemplates";
			}
		}

		private void FillTemplates()
		{
			HTMLTemplate[] templates =
				{
					new HTMLTemplate("", 
						"", "", ""),

					new HTMLTemplate("Label + Control", 
					"", "@FIELDLABEL@@CONTROL@", ""),

					new HTMLTemplate("Controls only", 
						"", "@CONTROL@", ""),

					new HTMLTemplate("Validators only", 
					"", "@VALIDATORS@", ""),

					new HTMLTemplate("Each control in a seperate line", 
						"", "@CONTROL@<BR>", ""),

					new HTMLTemplate("Each label in a seperate line", 
					"", "@FIELDLABEL@<BR>", ""),

					new HTMLTemplate("Each Label+Control in a seperate line", 
					"", "@FIELDLABEL@@CONTROL@<BR>", ""),

					new HTMLTemplate("Each control in a table cell", 
						"", "<TD>@CONTROL@</TD>", ""),

					new HTMLTemplate("Each Label+Control in a table cell", 
					"", "<TD>@FIELDLABEL@@CONTROL@</TD>", ""),

					new HTMLTemplate("Each control in a table row", 
						"", "<TR><TD>@CONTROL@</TD></TR>", ""),

					new HTMLTemplate("Each Label+Control in a table row", 
					"", "<TR><TD>@FIELDLABEL@</TD><TD>@CONTROL@</TD></TR>", ""),

					new HTMLTemplate("Controls in a full table", 
						"<TABLE>", "<TR><TD>@CONTROL@</TD></TR>", "</TABLE>"),

					new HTMLTemplate("Labels+Controls in a full table", 
						"<TABLE>", "<TR><TD>@FIELDLABEL@</TD><TD>@CONTROL@</TD></TR>", "</TABLE>"),

					new HTMLTemplate("DataGrid bound columns", 
						"", "@DATAGRIDCOLUMN@", ""),

					new HTMLTemplate("Full DataGrid with bound columns", 
						"<asp:datagrid runat=\"server\" AutoGenerateColumns=\"False\" ><Columns>", 
						"@DATAGRIDCOLUMN@", 
						"</Columns></asp:datagrid>"),

					//new HTMLTemplate("DataList bound columns", 
					//	"", "@DATALISTCOLUMN@", ""),

					new HTMLTemplate("DataList bound columns", 
						"", "@FIELDLABEL@ @BOUNDCONTROL@ \r\n", ""),

					/*new HTMLTemplate("Full DataList with bound columns", 
					"<asp:DataList runat=\"server\"><ItemTemplate>", 
					"@DATALISTCOLUMN@", 
					"</ItemTemplate></asp:DataList>")*/

					new HTMLTemplate("Full DataList with bound columns", 
					"<asp:DataList runat=\"server\"><ItemTemplate>", 
					"@FIELDLABEL@ @BOUNDCONTROL@ \r\n", 
					"</ItemTemplate></asp:DataList>"),

                    new HTMLTemplate("Full OBDataList with bound columns", 
					"<ns:OBDataList runat=\"server\"><ItemTemplate>", 
					"@FIELDLABEL@ @BOUNDCONTROL@ \r\n", 
					"</ItemTemplate></ns:OBDataList>"),

                     new HTMLTemplate("Full OBDataList with editable bound columns", 
					"<ns:OBDataList runat=\"server\"><ItemTemplate>", 
					"@FIELDLABEL@ @BOUNDCONTROL@ \r\n", 
					"</ItemTemplate></ns:OBDataList>"),

                    new HTMLTemplate("OBGridView bound columns", 
						"", "@GRIDVIEWCOLUMN@", ""),

                    new HTMLTemplate("Full OBGridView with bound columns", 
						"<ns:OBGridView runat=\"server\" AutoGenerateColumns=\"False\" ><Columns>", 
						"@GRIDVIEWCOLUMN@", 
						"</Columns></ns:OBGridView>")
				};
			cbTemplates.DataSource = null;
			ArrayList arr = new ArrayList();
			arr.AddRange(templates);

			// load custom templates from the project folder
			
			string projPath = HTMLTemplatesPath;

			FillTemplates(arr, projPath);

			/*
			string[] files = Directory.GetFiles(projPath, "*.htmlt");
			for (int i = 0; i < files.Length; i++)
			{
				try
				{
					HTMLTemplate tpl = HTMLTemplate.Load(files[i]);
					arr.Add(tpl);
				}
				catch(Exception ex)
				{
					Debug.WriteLine(ex.Message);
				}
			}*/
			
			cbTemplates.DisplayMember = "Description";
			cbTemplates.DataSource = arr;
		}

		
		void FillTemplates(ArrayList arr, string dir)
		{
			try
			{
				string[] files = Directory.GetFiles(dir, "*.htmlt");
				for (int i = 0; i < files.Length; i++)
				{
					try
					{
						HTMLTemplate tpl = HTMLTemplate.Load(files[i]);
						arr.Add(tpl);
					}
					catch(Exception ex)
					{
						Debug.WriteLine(ex.Message);
					}
				}

				string[] dirs = Directory.GetDirectories(dir);
				for (int i = 0; i < dirs.Length; i++)
				{
					FillTemplates(arr, dirs[i]);
				}
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, String.Format("Can't find html templates in {0}.\r\n{1}", 
					dir, ex.Message));																					 
				//this.Close();
			}
		}

		private void SetHelp()
		{
			lbHelp.Text = tab.SelectedTab.ToolTipText;
		}

		private FilteringOptions GetFilteringOptions()
		{
			FilteringOptions options = new FilteringOptions();
			options.formattersOnly = chkFormattersOnly.Checked;
			options.fieldValuesProps = chkFieldValuesProps.Checked;
			options.validatorProps = chkValidatorProps.Checked;
			options.searchMember = txtSearch.Text;
			return options;
		}

		private ControlGenerationOptions GetControlGenerationOptions()
		{
			ControlGenerationOptions options = new ControlGenerationOptions();
			options.method = (ControlGenerationMethods)cbCtlGenerationMethod.SelectedIndex;
			options.GenerateValidators = chkGenerateValidators.Checked;
			options.AlwaysGenerateValidators = chkAlwaysGenerateValidators.Checked;
			return options;
		}

		private string CreateScriptForItem(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScript(cls, opt);
			return null;
		}

		private string CreateScriptForLabel(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForLabel(cls, opt);
			return null;
		}


		private string CreateScriptForButton(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForButton(cls, opt);
			return null;
		}

		private string CreateScriptForLinkButton(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForLinkButton(cls, opt);
			return null;
		}

		private string CreateScriptForImageButton(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForImageButton(cls, opt);
			return null;
		}

		private string CreateScriptForHyperLink(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForHyperLink(cls, opt);
			return null;
		}

		private string CreateScriptForDataGridColumn(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForDataGridColumn(cls, opt);
			return null;
		}

        private string CreateScriptForGridViewColumn(BindableMember bm)
        {
            if (bm != null)
                return bm.CreateScriptForGridViewColumn(cls, opt);
            return null;
        }


		private string CreateScriptForDataListColumn(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForDataListColumn(cls, opt);
			return null;
		}

		private string CreateScriptForBoundControl(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForBoundControl(cls, opt);
			return null;
		}

		private string CreateScriptForClientValidators(BindableMember bm)
		{
			if (bm != null)
				return bm.CreateScriptForClientValidators(cls, opt, true);
			return null;
		}

		private string FormatScriptByItemTemplate(BindableMember bm, int counter, int count)
		{	
			string sLabel = CreateScriptForLabel(bm);
			string sItem = CreateScriptForItem(bm);
			string s = txtItem.Text;
			//s = s.Replace("*", sItem);
			s = s.Replace("@NAME@", bm.Name);
			s = s.Replace("@CLASSNAME@", cls.FullName);
			s = s.Replace("@FULLCLASSNAME@", Util.GetFullClassName(cls));
			s = s.Replace("@ASSEMBLYNAME@", cls.ProjectItem.ContainingProject.Name);
			s = s.Replace("@CONTROL@", sItem);
			s = s.Replace("@FIELDLABEL@", sLabel);
			if (s.IndexOf("@VALIDATORS@") >= 0)
				s = s.Replace("@VALIDATORS@", CreateScriptForClientValidators(bm));
			s = s.Replace("@COUNT@", count.ToString());
			s = s.Replace("@COUNTER@", counter.ToString());
			s = s.Replace("@TOGGLER@", (counter % 2).ToString());

			if (s.IndexOf("@DATAGRIDCOLUMN@") >= 0)
			{
				// generate DataGrid special binding scripts
				string sDataGridCol = CreateScriptForDataGridColumn(bm);
				s = s.Replace("@DATAGRIDCOLUMN@", sDataGridCol);
			}

            if (s.IndexOf("@GRIDVIEWCOLUMN@") >= 0)
            {
                // generate DataGrid special binding scripts
                string sGridViewCol = CreateScriptForGridViewColumn(bm);
                s = s.Replace("@GRIDVIEWCOLUMN@", sGridViewCol);
            }

			/*if (s.IndexOf("@DATALISTCOLUMN@") >= 0)
			{
				// generate DataGrid special binding scripts
				string sDataListCol = CreateScriptForDataListColumn(bm);
				s = s.Replace("@DATALISTCOLUMN@", sDataListCol);
			}*/

			if (s.IndexOf("@BOUNDCONTROL@") >= 0)
			{
				string sBoundControl = CreateScriptForBoundControl(bm);
				s = s.Replace("@BOUNDCONTROL@", sBoundControl);
			}

			// Direct data bound controls
			if (s.IndexOf("@BUTTON@") >= 0)
				s = s.Replace("@BUTTON@", CreateScriptForButton(bm));
			if (s.IndexOf("@LINKBUTTON@") >= 0)
				s = s.Replace("@LINKBUTTON@", CreateScriptForLinkButton(bm));
			if (s.IndexOf("@IMAGEBUTTON@") >= 0)
				s = s.Replace("@IMAGEBUTTON@", CreateScriptForImageButton(bm));
			if (s.IndexOf("@HYPERLINK@") >= 0)
				s = s.Replace("@HYPERLINK@", CreateScriptForHyperLink(bm));

			return s + "\r\n";
		}

		private string FormatScriptByTemplate(string s)
		{
			string fmt = "";
			if (txtHeader.Text != "")
				fmt += txtHeader.Text.Replace(@"\n", "\r\n") + "\r\n";
			if (s != "")
				fmt += s + "\r\n";
			if (txtFooter.Text != "")
				fmt += txtFooter.Text.Replace(@"\n", "\r\n") + "\r\n";
			return fmt;
		}

		private string GenerateScript()
		{
			return GenerateScript(listBindables);
		}

		private string GenerateScript(ListView listView)
		{
			string s = "";
			opt = GetControlGenerationOptions();	// refill options
			if (listView.SelectedItems.Count > 0)
			{
				int count = listView.SelectedItems.Count;
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < count; i++)
				{
					ListViewItem item = (ListViewItem)listView.SelectedItems[i];
					BindableMember bm = item.Tag as BindableMember;
					sb.Append(FormatScriptByItemTemplate(bm, i, count));
				}
				s = sb.ToString();
				if (s != null && s != "")
				{
					s = FormatScriptByTemplate(s);
				}
			}
			return s;
		}

		private void GeneratePreview()
		{
			GeneratePreview(listBindables);
		}

		private void GeneratePreview(ListView listView)
		{
			txtPreview.Text = GenerateScript(listView);
		}

		private HTMLTemplate SelectedTemplate
		{
			get
			{
				return cbTemplates.SelectedItem as HTMLTemplate;
			}
		}

		private void SelectTemplate(string description)
		{
			for (int i = 0; i < cbTemplates.Items.Count; i++)
			{
				HTMLTemplate tpl = cbTemplates.Items[i] as HTMLTemplate; 
				if (tpl.description == description)
				{
					cbTemplates.SelectedIndex = i;
				}
			}
		}

		private void WebFormBuilder_Load(object sender, System.EventArgs e)
		{
			this.SuspendLayout();
			this.Left = (int)Util.GetSetting("__WebFormBuilder", "Left", Screen.PrimaryScreen.Bounds.Width - this.Width);
			this.Top = (int)Util.GetSetting("__WebFormBuilder", "Top", 0);
			this.Width = (int)Util.GetSetting("__WebFormBuilder", "Width", this.Width);
			this.Height = (int)Util.GetSetting("__WebFormBuilder", "Height", this.Height);
			tvBindables.Width = (int)Util.GetSetting("__WebFormBuilder", "SplitterLeft", tvBindables.Width);
			txtPreview.Height = (int)Util.GetSetting("__WebFormBuilder", "SplitterTop", txtPreview.Height);
			chkGenerateValidators.Checked = (bool)Util.GetSetting("__WebFormBuilder", "GenerateValidators", chkGenerateValidators.Checked);
			chkAlwaysGenerateValidators.Checked = (bool)Util.GetSetting("__WebFormBuilder", "AlwaysGenerateValidators", chkAlwaysGenerateValidators.Checked);

			this.Text += "    Class Name='" + cls.Name + "'";
			cbCtlGenerationMethod.SelectedIndex = (int)Util.GetSetting("__WebFormBuilder", "CtlGenerationMethod", 0);
			FillTemplates();
			FillBindables();
			SetHelp();

			tvBindables.ExpandAll();
			EnableButtons();

			cbTemplates.SelectedIndex = 1;
			this.ResumeLayout();
		}

		private void EnableButtons()
		{
			HTMLTemplate tpl = SelectedTemplate;
			if (tpl == null)
			{
				cmdSaveTemplate.Enabled = cbTemplates.Text != "";
				cbTemplates.DropDownStyle = ComboBoxStyle.DropDown;
			}
			else
			{
				cmdSaveTemplate.Enabled = tpl.IsCustom &&
					cbTemplates.Text != "";
				//if (tpl.IsCustom)
				//	cbTemplates.DropDownStyle = ComboBoxStyle.DropDown;
				//else
				//	cbTemplates.DropDownStyle = ComboBoxStyle.DropDownList;
			}

			cmdShowForm.Enabled = pageClass != null;
		}

		private void listBindables_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
		{
			string s = GenerateScript();
			if (s != null && s != "")
			{
				CodeClass cls = Connect.Instance.CurrentClass;
				if (cls != null)
				{
					if (cls.Bases.Count > 0)
					{
						Debug.WriteLine(cls.Name);
					}
				}
				this.DoDragDrop(s, DragDropEffects.Copy);
			}
		}

		private void listBindables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void tvBindables_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			FillBindables(e.Node);
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void cbTemplates_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (keepTemplate)
				return;

			HTMLTemplate tpl = cbTemplates.SelectedItem as HTMLTemplate;
			if (tpl != null)
			{
				if (tpl.item  == null)
				{
					cbTemplates.DropDownStyle = ComboBoxStyle.DropDown;
				}
				else
				{
					if (cbTemplates.DropDownStyle != ComboBoxStyle.DropDownList)
					{
						int selInd = cbTemplates.SelectedIndex;
						keepTemplate = true;
						cbTemplates.DropDownStyle = ComboBoxStyle.DropDownList;
						cbTemplates.SelectedIndex = selInd;
						keepTemplate = false;
					}
				}
				txtHeader.Text = tpl.header;
				txtItem.Text = tpl.item;
				txtFooter.Text = tpl.footer;
			}

			EnableButtons();
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void tab_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetHelp();
		}

		private void SaveWindowPos()
		{
			Util.SetSetting("__WebFormBuilder", "Left", this.Left);
			Util.SetSetting("__WebFormBuilder", "Top", this.Top);
			Util.SetSetting("__WebFormBuilder", "Height", this.Height);
			Util.SetSetting("__WebFormBuilder", "Width", this.Width);
			Util.SetSetting("__WebFormBuilder", "SplitterLeft", tvBindables.Width);
			Util.SetSetting("__WebFormBuilder", "SplitterTop", txtPreview.Height);
		}

		private void WebFormBuilder_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			SaveWindowPos();
			Util.SetSetting("__WebFormBuilder", "GenerateValidators", chkGenerateValidators.Checked);
			Util.SetSetting("__WebFormBuilder", "AlwaysGenerateValidators", chkAlwaysGenerateValidators.Checked);
			Util.SetSetting("__WebFormBuilder", "CtlGenerationMethod", cbCtlGenerationMethod.SelectedIndex);
		}

		private void txtHeader_TextChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void txtItem_TextChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void txtFooter_TextChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void cbCtlGenerationMethod_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void txtPreview_Enter(object sender, System.EventArgs e)
		{
			lbHelp.Text = "Preview pane displays the HTML script that will be " +
				"generated when you drag and drop the selected members onto the web form.";
		}

		private void cmdShowEntityBuilder_Click(object sender, System.EventArgs e)
		{
			this.Close();
			Util.ShowClass(cls);
			EntityBuilder.BuildClass(this.cls);
		}

		private void chkFormattersOnly_CheckedChanged(object sender, System.EventArgs e)
		{
			RefillBindableMembers();
		}

		private void txtSearch_TextChanged(object sender, System.EventArgs e)
		{
			RefillBindableMembers();
		}

		private void txtSearch_Enter(object sender, System.EventArgs e)
		{
			lbHelp.Text = "Enter substring to search in the member names";
		}

		private void macrosMenu_Click(object sender, System.EventArgs e)
		{
			MenuItem mi = sender as MenuItem;
			if (mi != null)
				txtItem.SelectedText = "@" + mi.Text + "@";
		}

		private void listBindables_Click(object sender, System.EventArgs e)
		{
			if (listBindables.SelectedItems.Count > 0)
			{
				ListViewItem item = (ListViewItem)listBindables.SelectedItems[0];
				BindableMember bm = item.Tag as BindableMember;
				CodeElement elem = Util.FindFirstMember(cls, bm.Name);
				Util.MarkElement(cls, elem);
			}
		}

		private void cmdCreateNewWebForm_Click(object sender, System.EventArgs e)
		{
			CodeClass pageClass = WebFormCreator.CreateWebForm(cls.ProjectItem.ContainingProject, cls.Name);
			if (pageClass != null)
				this.pageClass = pageClass;
			EnableButtons();
		}

		private void cmdSaveTemplate_Click(object sender, System.EventArgs e)
		{
			HTMLTemplate tpl = SelectedTemplate;
			if (tpl == null)
			{
				tpl = new HTMLTemplate(cbTemplates.Text);
				string projPath = HTMLTemplatesPath;
				tpl.fileName = projPath + "\\" + cbTemplates.Text + ".htmlt";
			}

			tpl.description = cbTemplates.Text;
			tpl.header = txtHeader.Text.Replace("\r\n", @"\n");
			tpl.item = txtItem.Text;
			tpl.footer = txtFooter.Text.Replace("\r\n", @"\n");

			try
			{
				tpl.Save();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
				return;
			}

			FillTemplates();
			SelectTemplate(tpl.description);
			EnableButtons();
		}

		private void cbTemplates_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cmdNewTemplate_Click(object sender, System.EventArgs e)
		{
			cbTemplates.DropDownStyle = ComboBoxStyle.DropDown;
			keepTemplate = true;
			cbTemplates.SelectedIndex = -1;
			EnableButtons();
			cbTemplates.Text = "";
			cbTemplates.DropDownStyle = ComboBoxStyle.DropDown;
			keepTemplate = false;
		}

		private void cmdShowForm_Click(object sender, System.EventArgs e)
		{
			if (pageClass != null)
			{
				//Util.ShowClass(pageClass);
				//pageClass.ProjectItem.Document.Activate();
				Connect.Instance.applicationObject.Windows.Item(pageClass.Name + ".aspx").Activate();
			}
		}

		private void chkGenerateValidators_CheckedChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void chkAlwaysGenerateValidators_CheckedChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = true;
			generatePreviewForOrdered = false;
		}

		private void listBindables_DoubleClick(object sender, System.EventArgs e)
		{
			for (int i = 0; i < listBindables.SelectedIndices.Count; i++)
			{
				ListViewItem item = (ListViewItem)listBindables.SelectedItems[i];
				BindableMember bm = item.Tag as BindableMember;
				ListViewItem li = lstOrderedBindables.Items.Add(bm.Name, bm.IconIndex);
				li.Tag = bm;
			}
		}

		private void lstOrderedBindables_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)8)
			{
				RemoveFromOrdered();
			}
		}

		private void lstOrderedBindables_Click(object sender, System.EventArgs e)
		{
			if (lstOrderedBindables.SelectedItems.Count > 0)
			{
				ListViewItem item = (ListViewItem)lstOrderedBindables.SelectedItems[0];
				BindableMember bm = item.Tag as BindableMember;
				CodeElement elem = Util.FindFirstMember(cls, bm.Name);
				Util.MarkElement(cls, elem);
			}
		}

		private void lstOrderedBindables_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
		{
			string s = GenerateScript(lstOrderedBindables);
			if (s != null && s != "")
			{
				CodeClass cls = Connect.Instance.CurrentClass;
				if (cls != null)
				{
					if (cls.Bases.Count > 0)
					{
						Debug.WriteLine(cls.Name);
					}
				}
				this.DoDragDrop(s, DragDropEffects.Copy);
			}
		}

		private void lstOrderedBindables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			generatePreviewForMembers = false;
			generatePreviewForOrdered = true;
		}

		private void butMoveUp_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			if (lstOrderedBindables.SelectedItems.Count == 0)
				return;
			
			int pos = lstOrderedBindables.SelectedIndices[0];
			pos--;

			if (pos < 0)
			{
				lstOrderedBindables.Focus();
				return;
			}

			ArrayList lsSel = new ArrayList();
			for (int i = lstOrderedBindables.SelectedItems.Count - 1; i >= 0; i--)
			{
				ListViewItem item = (ListViewItem)lstOrderedBindables.SelectedItems[i];
				BindableMember bm = item.Tag as BindableMember;
				lsSel.Add(bm);
				lstOrderedBindables.Items.RemoveAt(item.Index);
			}

			for (int i = 0; i < lsSel.Count; i++)
			{
				BindableMember bm = lsSel[i] as BindableMember;
				ListViewItem li = lstOrderedBindables.Items.Insert(pos, bm.Name, bm.IconIndex);
				li.Tag = bm;
				li.Selected = true;
			}

			lstOrderedBindables.Focus();
		}

		private void butMoveDown_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			if (lstOrderedBindables.SelectedItems.Count == 0)
				return;
			
			int pos = lstOrderedBindables.SelectedIndices[0];
			pos++;

			if (pos > lstOrderedBindables.Items.Count)
			{
				lstOrderedBindables.Focus();
				return;
			}

			ArrayList lsSel = new ArrayList();
			for (int i = lstOrderedBindables.SelectedItems.Count - 1; i >= 0; i--)
			{
				ListViewItem item = (ListViewItem)lstOrderedBindables.SelectedItems[i];
				BindableMember bm = item.Tag as BindableMember;
				lsSel.Add(bm);
				lstOrderedBindables.Items.RemoveAt(item.Index);
			}

			if (pos < lstOrderedBindables.Items.Count)
			{
				for (int i = lsSel.Count - 1; i >= 0; i--)
				{
					BindableMember bm = lsSel[i] as BindableMember;
					ListViewItem li = lstOrderedBindables.Items.Insert(pos, bm.Name, bm.IconIndex);
					li.Tag = bm;
					li.Selected = true;
				}
			}
			else
			{
				for (int i = 0; i < lsSel.Count; i++)
				{
					BindableMember bm = lsSel[i] as BindableMember;
					ListViewItem li = lstOrderedBindables.Items.Add(bm.Name, bm.IconIndex);
					li.Tag = bm;
					li.Selected = true;
				}
			}

			lstOrderedBindables.Focus();
		}

		private void butAddToOrdered_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			listBindables_DoubleClick(this, new EventArgs());
			listBindables.Focus();
		}

		private void RemoveFromOrdered()
		{
			for (int i = lstOrderedBindables.SelectedIndices.Count - 1; i >= 0; i--)
			{
				lstOrderedBindables.Items.RemoveAt(lstOrderedBindables.SelectedIndices[i]);
			}
		}

		private void butRemoveFromOrdered_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			RemoveFromOrdered();
			lstOrderedBindables.Focus();
		}

		private void lstOrderedBindables_DoubleClick(object sender, System.EventArgs e)
		{
			RemoveFromOrdered();
			lstOrderedBindables.Focus();
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			bool generateMembers = generatePreviewForMembers;
			bool generateOrdered = generatePreviewForOrdered;
			generatePreviewForMembers = false;
			generatePreviewForOrdered = false;
			if (generateMembers)
				GeneratePreview();
			else if (generateOrdered)
				GeneratePreview(lstOrderedBindables);
		}

	}

	/// <summary>
	/// 
	/// </summary>
	[XmlType("HTMLTemplate")]
	public class HTMLTemplate
	{
		[XmlIgnore]
		public bool IsCustom = false;
		[XmlIgnore]
		public string fileName;
		[XmlElement("header")]
		public string header;
		[XmlElement("item")]
		public string item;
		[XmlElement("footer")]
		public string footer;
		[XmlElement("description")]
		public string description;
		

		public HTMLTemplate(string description, string header, string item, string footer)
		{
			this.description = description;
			this.header = header;
			this.item = item;
			this.footer = footer;
		}

		// custom template constructor
		public HTMLTemplate(string filename)
		{
			this.IsCustom = true;
			this.fileName = filename;
		}

		public string Description
		{
			get
			{
				return description;
			}
		}

		public void Save()
		{
			StreamWriter wr = new StreamWriter(fileName);
			try
			{
				wr.WriteLine(String.Format("DESCRIPTION:{0}", this.description));
				wr.WriteLine(String.Format("HEADER:{0}", this.header));
				wr.WriteLine(String.Format("FOOTER:{0}", this.footer));
				wr.Write(String.Format("ITEM:\r\n{0}", this.item));
			}
			finally
			{
				wr.Flush();
				wr.Close();
			}


			/*StreamWriter sOut = new StreamWriter(fileName, false);
			try
			{
				XmlSerializer xmlOut = new System.Xml.Serialization.XmlSerializer(typeof(HTMLTemplate));
				xmlOut.Serialize(sOut, this);
			}
			finally
			{
				sOut.Flush();
				sOut.Close();
			}*/
		}

		// parses items and 
		private bool parseItem(StreamReader sIn)
		{
			string s = sIn.ReadLine();
			if (s == null)
				return false;
			int icolon = s.IndexOf(':');
			string key = null, val = null;
			if (icolon >= 0)
			{
				key = s.Substring(0, icolon);
				val = s.Substring(icolon + 1);
			}
			else
			{
				key = "ITEM";
				val = s;
			}

			if (val != null)
				val = val.Replace(@"\n", "\r\n");

			switch (key)
			{
				case "DESCRIPTION":
					this.description = val;
					break;
				case "HEADER":
					this.header = val;
					break;
				case "FOOTER":
					this.footer = val;
					break;
				case "ITEM":
					if (val != "")
						this.item = val + "\r\n";
					else
						this.item = "";
					this.item += sIn.ReadToEnd();
					return false;
			}
			return true;
		}

		public static HTMLTemplate Load(string fileName)
		{
			StreamReader sIn = new StreamReader(fileName, false);
			HTMLTemplate tpl = new HTMLTemplate(fileName);
			try
			{
				while (tpl.parseItem(sIn))
				{
					// read and parsed
				}
			}
			finally
			{
				sIn.Close();
			}

			return tpl;

			/*
			StreamReader sIn = new StreamReader(fileName, false);
			XmlSerializer xmlIn = new System.Xml.Serialization.XmlSerializer(typeof(HTMLTemplate));
			HTMLTemplate tpl = xmlIn.Deserialize(sIn) as HTMLTemplate;
			tpl.fileName = fileName;
			sIn.Close();
			return tpl;*/
		}

	}
}
