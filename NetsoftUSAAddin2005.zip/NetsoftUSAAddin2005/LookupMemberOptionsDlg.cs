using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class LookupMemberOptionsDlg : System.Windows.Forms.Form
	{
		private CodeClass cls;
		private LookupMemberOptions options;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbCollectionClass;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cbValueMember;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbDescriptionMember;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cbStaticMember;
		private System.Windows.Forms.LinkLabel butCreateStaticMember;
		private System.Windows.Forms.PictureBox pictureBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LookupMemberOptionsDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LookupMemberOptionsDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.cbCollectionClass = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.cbValueMember = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cbDescriptionMember = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cbStaticMember = new System.Windows.Forms.ComboBox();
			this.butCreateStaticMember = new System.Windows.Forms.LinkLabel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(264, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select options to create a lookup collection returning property for the sp" +
				"ecified member.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(168, 200);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Cancel";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(248, 200);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// cbCollectionClass
			// 
			this.cbCollectionClass.Location = new System.Drawing.Point(168, 80);
			this.cbCollectionClass.Name = "cbCollectionClass";
			this.cbCollectionClass.Size = new System.Drawing.Size(256, 21);
			this.cbCollectionClass.TabIndex = 11;
			this.cbCollectionClass.SelectedIndexChanged += new System.EventHandler(this.cbCollectionClass_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.TabIndex = 12;
			this.label1.Text = "Collection Type:";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 128);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 13;
			this.label4.Text = "Value Member:";
			// 
			// cbValueMember
			// 
			this.cbValueMember.Location = new System.Drawing.Point(168, 128);
			this.cbValueMember.Name = "cbValueMember";
			this.cbValueMember.Size = new System.Drawing.Size(256, 21);
			this.cbValueMember.TabIndex = 14;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 152);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(120, 23);
			this.label3.TabIndex = 15;
			this.label3.Text = "Description Member:";
			// 
			// cbDescriptionMember
			// 
			this.cbDescriptionMember.Location = new System.Drawing.Point(168, 152);
			this.cbDescriptionMember.Name = "cbDescriptionMember";
			this.cbDescriptionMember.Size = new System.Drawing.Size(256, 21);
			this.cbDescriptionMember.TabIndex = 16;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(136, 23);
			this.label5.TabIndex = 17;
			this.label5.Text = "Get From Static Member:";
			// 
			// cbStaticMember
			// 
			this.cbStaticMember.Location = new System.Drawing.Point(168, 104);
			this.cbStaticMember.Name = "cbStaticMember";
			this.cbStaticMember.Size = new System.Drawing.Size(256, 21);
			this.cbStaticMember.TabIndex = 18;
			// 
			// butCreateStaticMember
			// 
			this.butCreateStaticMember.Location = new System.Drawing.Point(168, 176);
			this.butCreateStaticMember.Name = "butCreateStaticMember";
			this.butCreateStaticMember.Size = new System.Drawing.Size(160, 16);
			this.butCreateStaticMember.TabIndex = 19;
			this.butCreateStaticMember.TabStop = true;
			this.butCreateStaticMember.Text = "First Create a Static Member";
			this.butCreateStaticMember.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.butCreateStaticMember_LinkClicked);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(8, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(16, 16);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 20;
			this.pictureBox2.TabStop = false;
			// 
			// LookupMemberOptionsDlg
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(434, 231);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.butCreateStaticMember);
			this.Controls.Add(this.cbStaticMember);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.cbDescriptionMember);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.cbValueMember);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbCollectionClass);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "LookupMemberOptionsDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Lookup Member Creation Options";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.LookupMemberOptionsDlg_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool SelectLookupMemberOptions(LookupMemberOptions options)
		{
			LookupMemberOptionsDlg lmo = new LookupMemberOptionsDlg();
			lmo.options = options;
			lmo.cls = options.Class;
			if (lmo.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				DialogResult = DialogResult.OK;

				//Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseEntity.Checked);

				options.collectionClass = cbCollectionClass.Text;
				options.valueMember = cbValueMember.Text;
				options.descriptionMember = cbDescriptionMember.Text;
				if (cbStaticMember.Text != "")
					options.staticMemberToUse = cbStaticMember.Text; 

				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void LookupMemberOptionsDlg_Load(object sender, System.EventArgs e)
		{
			//ToolTip tooltip = new ToolTip();
			//tooltip.ShowAlways = true;
			//tooltip.SetToolTip(cbCollectionClass, "If you select a collection type, the method will be created on the selected collection.");

			object[] colClasses = Util.FindCollectionClassesInProject(cls.ProjectItem.ContainingProject, null);
			for (int i = 0; i < colClasses.Length; i++)
			{
				CodeClass colClass = colClasses[i] as CodeClass;
				if (colClass != null)
					cbCollectionClass.Items.Add(colClass.Name);
			}
		}

		private void cbCollectionClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			cbValueMember.Items.Clear();
			cbDescriptionMember.Items.Clear();
			cbStaticMember.Items.Clear();
			string colClass = (string)cbCollectionClass.SelectedItem;
			if (colClass == null)
				return;

			CodeClass colCls = Util.FindClassInProject(cls.ProjectItem.ContainingProject, cbCollectionClass.Text);
			if (colCls == null)
				return;

			CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
			if (elemCls == null)
				return;

			FillProps(elemCls, cbValueMember);
			FillProps(elemCls, cbDescriptionMember);

			FillStaticProps(colCls, elemCls, cbStaticMember);

			cbValueMember.Text = null;
			try
			{
				// try to find a possible property name for the primary key
				string pk = Util.MakePropNameFromVarName(Util.GetPKMembersForClass(elemCls)[0]);
				if (cbValueMember.FindStringExact(pk) >= 0)
					cbValueMember.Text = pk;
			}
			catch
			{
				// ingnore if not found or any error
			}
		}

		private void FillProps(CodeClass elemCls, ComboBox cb)
		{
			for (int i = 1; i <= elemCls.Members.Count; i++)
			{
				CodeProperty prop = elemCls.Members.Item(i) as CodeProperty;
				if (prop != null)
				{
					cb.Items.Add(prop.Name);
				}
			}

			if (elemCls.Bases != null)
			{
				for (int i = 1; i <= elemCls.Bases.Count; i++)
					FillProps(elemCls.Bases.Item(i) as CodeClass, cb);
			}
		}

		private void FillStaticProps(CodeClass cls, CodeClass elemCls, ComboBox cb)
		{
			for (int i = 1; i <= cls.Members.Count; i++)
			{
				CodeProperty prop = cls.Members.Item(i) as CodeProperty;
				if (prop != null)
				{
					//if (Util.IsPropertyStatic(prop))
					if (prop.Type.TypeKind == vsCMTypeRef.vsCMTypeRefCodeType)
						if (cls.FullName == prop.Type.AsString)
							cb.Items.Add(prop.Name);
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
					FillStaticProps(cls.Bases.Item(i) as CodeClass, elemCls, cb);
			}
		}

		private void butCreateStaticMember_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			string colClass = (string)cbCollectionClass.SelectedItem;
			if (colClass == null)
				return;

			CodeClass colCls = Util.FindClassInProject(cls.ProjectItem.ContainingProject, cbCollectionClass.Text);
			if (colCls == null)
				return;

			CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
			if (elemCls == null)
				return;
			this.Visible = false;
			if (CreateCollectionCachedMemberDlg.CreateCachedMember(colCls, elemCls))
				cbCollectionClass_SelectedIndexChanged(this, new EventArgs());
			this.Visible = true;
		}
	}

	public class LookupMemberOptions
	{
		public CodeClass Class;
		public CodeElement Elem;

		public string collectionClass;
		public string staticMemberToUse;		// collection's static member to use
		public string valueMember;
		public string descriptionMember;

		public LookupMemberOptions(CodeClass cls, CodeElement elem)
		{
			this.Class = cls;
			this.Elem = elem;
		}
	}
}
