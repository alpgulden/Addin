using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for DataClassCreator.
	/// </summary>
	public class PageDataPropertyCreator : System.Windows.Forms.Form
	{
		private CodeClass pageCls;
		private CodeClass pageDataCls = null;
		private bool extendsBaseDataClass = false;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cbDataClass;
		private System.Windows.Forms.CheckBox chkCreateReadControlsMethod;
		private System.Windows.Forms.TextBox txtMemberName;
		private System.Windows.Forms.Label Label4;
		private System.Windows.Forms.TextBox txtPropertyName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox chkCreateNewDataMethod;
		private System.Windows.Forms.CheckBox chkCreateLoadDataMethod;
		private System.Windows.Forms.CheckBox chkCreateSaveDataMethod;
		private System.Windows.Forms.ComboBox cbPropType;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.CheckBox chkCreateSearchMethod;
		private System.Windows.Forms.CheckBox chkCreateRedirectMethod;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPageProperty;
		private System.Windows.Forms.TabPage tabSearcherAndSearchMethods;
		private System.Windows.Forms.CheckBox chkMainPageMethods;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.CheckBox chkCacheAfterDataIsSet;
		private System.Windows.Forms.ComboBox cbSearchMethod;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuSearchPageMainCollection;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem mnuSearchPageMainSearchObject;
		private System.Windows.Forms.MenuItem mnuSearchPageOtherCollection;
		private System.Windows.Forms.MenuItem mnuSearchPageOtherSearchObject;
		private System.Windows.Forms.MenuItem mnuDataPageMainDataObject;
		private System.Windows.Forms.MenuItem mnuDataPageOtherDataObject;
		private System.Windows.Forms.MenuItem mnuDataPageOtherCollection;
		private System.Windows.Forms.MenuItem mnuDataPageChildDataObject;
		private System.Windows.Forms.MenuItem mnuDataPageChildCollection;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cbCachingKey;
		private System.Windows.Forms.MenuItem mnuPresets;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PageDataPropertyCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PageDataPropertyCreator));
			this.label1 = new System.Windows.Forms.Label();
			this.cbDataClass = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.chkCreateReadControlsMethod = new System.Windows.Forms.CheckBox();
			this.txtMemberName = new System.Windows.Forms.TextBox();
			this.Label4 = new System.Windows.Forms.Label();
			this.txtPropertyName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.chkCreateNewDataMethod = new System.Windows.Forms.CheckBox();
			this.chkCreateLoadDataMethod = new System.Windows.Forms.CheckBox();
			this.chkCreateSaveDataMethod = new System.Windows.Forms.CheckBox();
			this.cbPropType = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.chkCreateSearchMethod = new System.Windows.Forms.CheckBox();
			this.chkCreateRedirectMethod = new System.Windows.Forms.CheckBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPageProperty = new System.Windows.Forms.TabPage();
			this.tabSearcherAndSearchMethods = new System.Windows.Forms.TabPage();
			this.chkMainPageMethods = new System.Windows.Forms.CheckBox();
			this.chkCacheAfterDataIsSet = new System.Windows.Forms.CheckBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.cbSearchMethod = new System.Windows.Forms.ComboBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuPresets = new System.Windows.Forms.MenuItem();
			this.mnuDataPageMainDataObject = new System.Windows.Forms.MenuItem();
			this.mnuDataPageOtherDataObject = new System.Windows.Forms.MenuItem();
			this.mnuSearchPageMainCollection = new System.Windows.Forms.MenuItem();
			this.mnuDataPageOtherCollection = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.mnuSearchPageMainSearchObject = new System.Windows.Forms.MenuItem();
			this.mnuSearchPageOtherCollection = new System.Windows.Forms.MenuItem();
			this.mnuSearchPageOtherSearchObject = new System.Windows.Forms.MenuItem();
			this.mnuDataPageChildDataObject = new System.Windows.Forms.MenuItem();
			this.mnuDataPageChildCollection = new System.Windows.Forms.MenuItem();
			this.label8 = new System.Windows.Forms.Label();
			this.cbCachingKey = new System.Windows.Forms.ComboBox();
			this.tabControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 104);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Class Name:";
			// 
			// cbDataClass
			// 
			this.cbDataClass.Location = new System.Drawing.Point(144, 104);
			this.cbDataClass.Name = "cbDataClass";
			this.cbDataClass.Size = new System.Drawing.Size(256, 21);
			this.cbDataClass.TabIndex = 1;
			this.cbDataClass.TextChanged += new System.EventHandler(this.cbDataClass_TextChanged);
			this.cbDataClass.SelectedIndexChanged += new System.EventHandler(this.cbDataClass_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(248, 64);
			this.label2.TabIndex = 3;
			this.label2.Text = "Select a data class to create a page member and a property for.  When this proper" +
				"ty is set, bound page controls are expected to be populated.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(112, 352);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 9;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(200, 352);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 8;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// chkCreateReadControlsMethod
			// 
			this.chkCreateReadControlsMethod.Checked = true;
			this.chkCreateReadControlsMethod.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkCreateReadControlsMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateReadControlsMethod.Location = new System.Drawing.Point(24, 200);
			this.chkCreateReadControlsMethod.Name = "chkCreateReadControlsMethod";
			this.chkCreateReadControlsMethod.Size = new System.Drawing.Size(176, 16);
			this.chkCreateReadControlsMethod.TabIndex = 4;
			this.chkCreateReadControlsMethod.Text = "Create Read Controls Method";
			// 
			// txtMemberName
			// 
			this.txtMemberName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMemberName.Location = new System.Drawing.Point(144, 152);
			this.txtMemberName.Name = "txtMemberName";
			this.txtMemberName.Size = new System.Drawing.Size(256, 20);
			this.txtMemberName.TabIndex = 3;
			this.txtMemberName.Text = "";
			this.txtMemberName.TextChanged += new System.EventHandler(this.txtMemberName_TextChanged_1);
			// 
			// Label4
			// 
			this.Label4.Location = new System.Drawing.Point(24, 152);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(136, 23);
			this.Label4.TabIndex = 15;
			this.Label4.Text = "Page Member Name:";
			// 
			// txtPropertyName
			// 
			this.txtPropertyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPropertyName.Location = new System.Drawing.Point(144, 128);
			this.txtPropertyName.Name = "txtPropertyName";
			this.txtPropertyName.Size = new System.Drawing.Size(256, 20);
			this.txtPropertyName.TabIndex = 2;
			this.txtPropertyName.Text = "";
			this.txtPropertyName.TextChanged += new System.EventHandler(this.txtPropertyName_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(136, 23);
			this.label3.TabIndex = 17;
			this.label3.Text = "Page Property Name:";
			// 
			// chkCreateNewDataMethod
			// 
			this.chkCreateNewDataMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateNewDataMethod.Location = new System.Drawing.Point(24, 216);
			this.chkCreateNewDataMethod.Name = "chkCreateNewDataMethod";
			this.chkCreateNewDataMethod.Size = new System.Drawing.Size(168, 16);
			this.chkCreateNewDataMethod.TabIndex = 5;
			this.chkCreateNewDataMethod.Text = "Create New Data Method";
			// 
			// chkCreateLoadDataMethod
			// 
			this.chkCreateLoadDataMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateLoadDataMethod.Location = new System.Drawing.Point(24, 232);
			this.chkCreateLoadDataMethod.Name = "chkCreateLoadDataMethod";
			this.chkCreateLoadDataMethod.Size = new System.Drawing.Size(168, 16);
			this.chkCreateLoadDataMethod.TabIndex = 6;
			this.chkCreateLoadDataMethod.Text = "Create Load Data Method";
			// 
			// chkCreateSaveDataMethod
			// 
			this.chkCreateSaveDataMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateSaveDataMethod.Location = new System.Drawing.Point(24, 248);
			this.chkCreateSaveDataMethod.Name = "chkCreateSaveDataMethod";
			this.chkCreateSaveDataMethod.Size = new System.Drawing.Size(168, 16);
			this.chkCreateSaveDataMethod.TabIndex = 7;
			this.chkCreateSaveDataMethod.Text = "Create Save Data Method";
			// 
			// cbPropType
			// 
			this.cbPropType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPropType.Items.AddRange(new object[] {
															"Data Class",
															"Data Collection"});
			this.cbPropType.Location = new System.Drawing.Point(144, 80);
			this.cbPropType.Name = "cbPropType";
			this.cbPropType.Size = new System.Drawing.Size(256, 21);
			this.cbPropType.TabIndex = 0;
			this.cbPropType.SelectedIndexChanged += new System.EventHandler(this.cbPropType_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(24, 80);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(136, 23);
			this.label5.TabIndex = 22;
			this.label5.Text = "DataClass or Collection:";
			// 
			// chkCreateSearchMethod
			// 
			this.chkCreateSearchMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateSearchMethod.Location = new System.Drawing.Point(200, 200);
			this.chkCreateSearchMethod.Name = "chkCreateSearchMethod";
			this.chkCreateSearchMethod.Size = new System.Drawing.Size(216, 16);
			this.chkCreateSearchMethod.TabIndex = 23;
			this.chkCreateSearchMethod.Text = "Create Load/Search Method based on:";
			this.chkCreateSearchMethod.CheckedChanged += new System.EventHandler(this.chkCreateSearchMethod_CheckedChanged);
			// 
			// chkCreateRedirectMethod
			// 
			this.chkCreateRedirectMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateRedirectMethod.Location = new System.Drawing.Point(24, 264);
			this.chkCreateRedirectMethod.Name = "chkCreateRedirectMethod";
			this.chkCreateRedirectMethod.Size = new System.Drawing.Size(176, 16);
			this.chkCreateRedirectMethod.TabIndex = 24;
			this.chkCreateRedirectMethod.Text = "Create Page.Redirect Method";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPageProperty);
			this.tabControl1.Controls.Add(this.tabSearcherAndSearchMethods);
			this.tabControl1.Location = new System.Drawing.Point(32, 368);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(360, 100);
			this.tabControl1.TabIndex = 25;
			this.tabControl1.Visible = false;
			// 
			// tabPageProperty
			// 
			this.tabPageProperty.Location = new System.Drawing.Point(4, 22);
			this.tabPageProperty.Name = "tabPageProperty";
			this.tabPageProperty.Size = new System.Drawing.Size(352, 74);
			this.tabPageProperty.TabIndex = 0;
			this.tabPageProperty.Text = "Page Property";
			// 
			// tabSearcherAndSearchMethods
			// 
			this.tabSearcherAndSearchMethods.Location = new System.Drawing.Point(4, 22);
			this.tabSearcherAndSearchMethods.Name = "tabSearcherAndSearchMethods";
			this.tabSearcherAndSearchMethods.Size = new System.Drawing.Size(352, 74);
			this.tabSearcherAndSearchMethods.TabIndex = 1;
			this.tabSearcherAndSearchMethods.Text = "Searcher/Search Methods";
			// 
			// chkMainPageMethods
			// 
			this.chkMainPageMethods.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkMainPageMethods.Location = new System.Drawing.Point(24, 304);
			this.chkMainPageMethods.Name = "chkMainPageMethods";
			this.chkMainPageMethods.Size = new System.Drawing.Size(184, 16);
			this.chkMainPageMethods.TabIndex = 26;
			this.chkMainPageMethods.Text = "Use Main Data Method Naming";
			this.chkMainPageMethods.CheckedChanged += new System.EventHandler(this.chkMainPageMethods_CheckedChanged);
			// 
			// chkCacheAfterDataIsSet
			// 
			this.chkCacheAfterDataIsSet.Checked = true;
			this.chkCacheAfterDataIsSet.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkCacheAfterDataIsSet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCacheAfterDataIsSet.Location = new System.Drawing.Point(208, 304);
			this.chkCacheAfterDataIsSet.Name = "chkCacheAfterDataIsSet";
			this.chkCacheAfterDataIsSet.Size = new System.Drawing.Size(168, 16);
			this.chkCacheAfterDataIsSet.TabIndex = 27;
			this.chkCacheAfterDataIsSet.Text = "Cache after data is set";
			this.chkCacheAfterDataIsSet.CheckedChanged += new System.EventHandler(this.chkCacheAfterDataIsSet_CheckedChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(24, 288);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(100, 16);
			this.label6.TabIndex = 28;
			this.label6.Text = "Options:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(24, 184);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 16);
			this.label7.TabIndex = 29;
			this.label7.Text = "Methods:";
			// 
			// cbSearchMethod
			// 
			this.cbSearchMethod.Items.AddRange(new object[] {
																"Data Class",
																"Data Collection"});
			this.cbSearchMethod.Location = new System.Drawing.Point(216, 216);
			this.cbSearchMethod.Name = "cbSearchMethod";
			this.cbSearchMethod.Size = new System.Drawing.Size(184, 21);
			this.cbSearchMethod.TabIndex = 30;
			this.cbSearchMethod.TextChanged += new System.EventHandler(this.cbSearchMethod_TextChanged);
			this.cbSearchMethod.SelectedIndexChanged += new System.EventHandler(this.cbSearchMethod_SelectedIndexChanged);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuPresets});
			// 
			// mnuPresets
			// 
			this.mnuPresets.Index = 0;
			this.mnuPresets.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem6,
																					   this.menuItem7});
			this.mnuPresets.Text = "Presets";
			// 
			// mnuDataPageMainDataObject
			// 
			this.mnuDataPageMainDataObject.Index = 0;
			this.mnuDataPageMainDataObject.Text = "Main Data Object";
			this.mnuDataPageMainDataObject.Click += new System.EventHandler(this.mnuDataPageMainDataObject_Click);
			// 
			// mnuDataPageOtherDataObject
			// 
			this.mnuDataPageOtherDataObject.Index = 3;
			this.mnuDataPageOtherDataObject.Text = "Other Data Object";
			this.mnuDataPageOtherDataObject.Click += new System.EventHandler(this.mnuDataPageOtherDataObject_Click);
			// 
			// mnuSearchPageMainCollection
			// 
			this.mnuSearchPageMainCollection.Index = 0;
			this.mnuSearchPageMainCollection.Text = "Main Collection";
			this.mnuSearchPageMainCollection.Click += new System.EventHandler(this.mnuSearchPageMainCollection_Click);
			// 
			// mnuDataPageOtherCollection
			// 
			this.mnuDataPageOtherCollection.Index = 4;
			this.mnuDataPageOtherCollection.Text = "Other Collection";
			this.mnuDataPageOtherCollection.Click += new System.EventHandler(this.mnuDataPageOtherCollection_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuSearchPageMainCollection,
																					  this.mnuSearchPageMainSearchObject,
																					  this.mnuSearchPageOtherCollection,
																					  this.mnuSearchPageOtherSearchObject});
			this.menuItem6.Text = "Browse/Search Page";
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuDataPageMainDataObject,
																					  this.mnuDataPageChildDataObject,
																					  this.mnuDataPageChildCollection,
																					  this.mnuDataPageOtherDataObject,
																					  this.mnuDataPageOtherCollection});
			this.menuItem7.Text = "Data Entry Page";
			// 
			// mnuSearchPageMainSearchObject
			// 
			this.mnuSearchPageMainSearchObject.Index = 1;
			this.mnuSearchPageMainSearchObject.Text = "Main Search Object";
			this.mnuSearchPageMainSearchObject.Click += new System.EventHandler(this.mnuSearchPageMainSearchObject_Click);
			// 
			// mnuSearchPageOtherCollection
			// 
			this.mnuSearchPageOtherCollection.Index = 2;
			this.mnuSearchPageOtherCollection.Text = "Other Collection";
			this.mnuSearchPageOtherCollection.Click += new System.EventHandler(this.mnuSearchPageOtherCollection_Click);
			// 
			// mnuSearchPageOtherSearchObject
			// 
			this.mnuSearchPageOtherSearchObject.Index = 3;
			this.mnuSearchPageOtherSearchObject.Text = "Other Search Object";
			this.mnuSearchPageOtherSearchObject.Click += new System.EventHandler(this.mnuSearchPageOtherSearchObject_Click);
			// 
			// mnuDataPageChildDataObject
			// 
			this.mnuDataPageChildDataObject.Index = 1;
			this.mnuDataPageChildDataObject.Text = "Child Data Object";
			this.mnuDataPageChildDataObject.Click += new System.EventHandler(this.mnuDataPageChildDataObject_Click);
			// 
			// mnuDataPageChildCollection
			// 
			this.mnuDataPageChildCollection.Index = 2;
			this.mnuDataPageChildCollection.Text = "Child Collection";
			this.mnuDataPageChildCollection.Click += new System.EventHandler(this.mnuDataPageChildCollection_Click);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(222, 323);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(100, 16);
			this.label8.TabIndex = 32;
			this.label8.Text = "Caching Key:";
			// 
			// cbCachingKey
			// 
			this.cbCachingKey.Items.AddRange(new object[] {
															  "[ClassName]"});
			this.cbCachingKey.Location = new System.Drawing.Point(288, 320);
			this.cbCachingKey.Name = "cbCachingKey";
			this.cbCachingKey.Size = new System.Drawing.Size(112, 21);
			this.cbCachingKey.TabIndex = 33;
			this.cbCachingKey.Text = "[ClassName]";
			// 
			// PageDataPropertyCreator
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(410, 379);
			this.Controls.Add(this.cbCachingKey);
			this.Controls.Add(this.cbSearchMethod);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.chkCacheAfterDataIsSet);
			this.Controls.Add(this.chkMainPageMethods);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.chkCreateRedirectMethod);
			this.Controls.Add(this.chkCreateSearchMethod);
			this.Controls.Add(this.cbPropType);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.chkCreateSaveDataMethod);
			this.Controls.Add(this.txtPropertyName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtMemberName);
			this.Controls.Add(this.Label4);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbDataClass);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkCreateReadControlsMethod);
			this.Controls.Add(this.chkCreateNewDataMethod);
			this.Controls.Add(this.chkCreateLoadDataMethod);
			this.Controls.Add(this.label8);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu1;
			this.MinimizeBox = false;
			this.Name = "PageDataPropertyCreator";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Web Page Data Property Creator";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.ChildMemberCreator_Load);
			this.tabControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void EnableButtons()
		{
			chkCreateSearchMethod.Enabled = cbPropType.SelectedIndex == 1;
			cbSearchMethod.Enabled = chkCreateSearchMethod.Enabled && chkCreateSearchMethod.Checked;
			cbCachingKey.Enabled = chkCacheAfterDataIsSet.Checked;
			mnuPresets.Enabled =
				(cbDataClass.Text != "") &&
				(txtMemberName.Text != "") &&
				(txtPropertyName.Text != "") &&
				(txtPropertyName.Text != txtMemberName.Text);

			butCreate.Enabled = 
				(cbDataClass.Text != "") &&
				(txtMemberName.Text != "") &&
				(txtPropertyName.Text != "") &&
				(txtPropertyName.Text != txtMemberName.Text) &&
				(!cbSearchMethod.Enabled || cbSearchMethod.Enabled && cbSearchMethod.Text != "");
		}

		private void AddLoadObjectToPageLoad(string loadObjectExp)
		{
			CodeFunction func = Util.FindFirstMember(pageCls, "Page_Load") as CodeFunction;
			if (func != null)
			{
				EditPoint ep = func.EndPoint.CreateEditPoint();
				ep.LineUp(1);
				ep.EndOfLine();
				ep.Insert("\r\n");
				ep.Insert("\t\t\tif (IsPostBack)\r\n");
				ep.Insert("\t\t\t\t" + loadObjectExp);
			}
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				CodeClass dataCls = Util.FindClassInProject(pageDataCls.ProjectItem.ContainingProject, cbDataClass.Text);
				if (dataCls == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find data class " + cbDataClass.Text, "Page Data Property Creator");
					return;
				}

				if (Util.FindFirstMember(false, pageCls, txtMemberName.Text) == null)
				{
					// Create a private member
					CodeVariable var = pageCls.AddVariable(txtMemberName.Text, 
						dataCls.Name,
						0,
						EnvDTE.vsCMAccess.vsCMAccessPrivate,
						null);
				}

				if (Util.FindFirstMember(false, pageCls, txtPropertyName.Text) == null)
				{
					// create a public accessor for the member
					CodeProperty prop = pageCls.AddProperty(
						txtPropertyName.Text,
						txtPropertyName.Text,
						dataCls.Name, 
						-1, EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);

					prop.Comment = "Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls";
					EditPoint ep = null;
					ep = prop.Getter.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					Util.DeleteEditLine(ep);
					ep.Insert(String.Format("\t\t\t\treturn {0};", txtMemberName.Text));
					ep = prop.Getter.StartPoint.CreateEditPoint();
					Util.MergeFollowingLine(ep, 3);

					ep = prop.Setter.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					ep.Insert(String.Format("\t\t\t\t{0} = value;\r\n", txtMemberName.Text));
					ep.Insert("\t\t\t\ttry\r\n");
					ep.Insert("\t\t\t\t{\r\n");
					if (cbPropType.SelectedIndex == 0)
						ep.Insert(String.Format("\t\t\t\t\tthis.UpdateFromObject(this.Controls, {0});  // update controls for the given control collection\r\n", txtMemberName.Text));
					else
					{
						if (!chkCacheAfterDataIsSet.Checked)
							ep.Insert(String.Format("\t\t\t\t\tgrid.KeepCollectionIndices = false;  // update given grid from the collection\r\n", txtMemberName.Text));
						ep.Insert(String.Format("\t\t\t\t\tgrid.UpdateFromCollection({0});  // update given grid from the collection\r\n", txtMemberName.Text));
					}
					ep.Insert(String.Format("\t\t\t\t\t// other object-to-control methods if any\r\n"));
					ep.Insert("\t\t\t\t}\r\n");
					ep.Insert("\t\t\t\tcatch(Exception ex)\r\n");
					ep.Insert("\t\t\t\t{\r\n");
					ep.Insert("\t\t\t\t\tthis.RaisePageException(ex);  // notify the page about the error\r\n");
					ep.Insert("\t\t\t\t}\r\n");
					if (chkCacheAfterDataIsSet.Checked)
					{
						if (cbCachingKey.Text == "" || cbCachingKey.Text == "[ClassName]")
						{
							ep.Insert(String.Format("\t\t\t\tthis.CacheObject(typeof({0}), {1});  // cache object using the caching method declared on the page\r\n", dataCls.Name, txtMemberName.Text));
							AddLoadObjectToPageLoad(String.Format("{1} = ({0})this.LoadObject(typeof({0}));  // load object from cache\r\n", dataCls.Name, txtMemberName.Text));
						}
						else
						{
							ep.Insert(String.Format("\t\t\t\tthis.CacheObject(\"{0}\", {1});  // cache object using the caching method declared on the page\r\n", cbCachingKey.Text, txtMemberName.Text));
							AddLoadObjectToPageLoad(String.Format("{1} = ({0})this.LoadObject(\"{2}\");  // load object from cache\r\n", dataCls.Name, txtMemberName.Text, cbCachingKey.Text));
						}
					}
					else
					{
						ep.Insert(String.Format("\t\t\t\t// active the caching if the object is not too big and you need this object in the next post-back\r\n"));
						ep.Insert(String.Format("\t\t\t\t// this.CacheObject(typeof({0}), {1});  // cache object using the caching method declared on the page\r\n", dataCls.Name, txtMemberName.Text));
						AddLoadObjectToPageLoad(String.Format("{1} = ({0})this.LoadObject(typeof({0}));  // load object from cache\r\n", dataCls.Name, txtMemberName.Text));
					}
				}

				// methods  ----------------

				if (chkCreateReadControlsMethod.Checked)
				{
					string funcName = "ReadControlsFor" + txtPropertyName.Text;
					if (chkMainPageMethods.Checked)
						funcName = "ReadControls";
					if (Util.FindFirstMember(pageCls, funcName) == null)
					{
						// Add ReadControlsFor[Property] method
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						func.Comment = "Reads control values into the data object and validates them.  Returns false if there's any problem";
						EditPoint ep = func.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);

						ep.Insert("\t\t\ttry\r\n");
						ep.Insert("\t\t\t{\t//customize this method for this specific page\r\n");
						if (cbPropType.SelectedIndex == 0)
							ep.Insert(String.Format("\t\t\t\tthis.UpdateToObject(this.Controls, {0});	// controls-to-object\r\n", txtMemberName.Text));
						else
							ep.Insert(String.Format("\t\t\t\tgrid.UpdateToCollection({0});	// grid-to-collection\r\n", txtMemberName.Text));
						ep.Insert(String.Format("\t\t\t\t// other control-to-object methods if any\r\n"));
						//ep.Insert("\t\t\t\tthis.Validate();	// Validation called after data is saved into object\r\n");
						ep.Insert("\t\t\t\treturn this.IsValid;	// Return validation result\r\n");
						ep.Insert("\t\t\t}\r\n");
						ep.Insert("\t\t\tcatch(Exception ex)\r\n");
						ep.Insert("\t\t\t{\r\n");
						ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
						ep.Insert("\t\t\t\treturn false;\r\n");
						ep.Insert("\t\t\t}");
					}
				}

				if (chkCreateNewDataMethod.Checked)
				{
					string funcName = "New" + txtPropertyName.Text;
					if (chkMainPageMethods.Checked)
						funcName = "NewData";
					if (Util.FindFirstMember(pageCls, funcName) == null)
					{
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method whenever you need to create a new data object and also populate the controls for it";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\tbool result = true;\r\n");
							ep.Insert(String.Format("\t\t\t{0} {1} = null; //new {0}(); // use a parameterized constructor which also initializes the data object\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\t// or use an initialization method here\r\n");
							ep.Insert(String.Format("\t\t\t\t{1} = new {0}();\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
							ep.Insert("\t\t\t\tresult = false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tfinally\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert(String.Format("\t\t\t\t// finalization code\r\n"));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert(String.Format("\t\t\tthis.{0} = {1};\r\n", txtPropertyName.Text, txtMemberName.Text));
							ep.Insert("\t\t\treturn result;");
						}
					}
				}

				if (chkCreateLoadDataMethod.Checked)
				{
					string funcName = "LoadDataFor" + txtPropertyName.Text;
					if (chkMainPageMethods.Checked)
						funcName = "LoadData";
					if (Util.FindFirstMember(pageCls, funcName) == null)
					{
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method from Page_Load or anytime you want to load data";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\tbool result = true;\r\n");
							ep.Insert(String.Format("\t\t\t{0} {1} = new {0}();\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\t// use any load method here\r\n");
							ep.Insert(String.Format("\t\t\t\tresult = {0}.Load();\r\n", txtMemberName.Text));
							ep.Insert(String.Format("\t\t\t\t// or pull from the parameter passed to this page via PushParam\r\n"));
							ep.Insert(String.Format("\t\t\t\t// {1} = this.GetParam(\"{0}\") as {0};\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert(String.Format("\t\t\t\t// if ({1} == null) {1} = new {0}(true); // if not passed, create a new data object and init as new\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
							ep.Insert("\t\t\t\tresult = false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tfinally\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert(String.Format("\t\t\t\t//{0}.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!\r\n", txtMemberName.Text));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert(String.Format("\t\t\tthis.{0} = {1};\r\n", txtPropertyName.Text, txtMemberName.Text));
							ep.Insert("\t\t\treturn result;");
						}
					}
				}

				if (chkCreateRedirectMethod.Checked)
				{
					string funcName = "Redirect";
					if (Util.FindFirstMethod(true, pageCls, funcName, dataCls.Name) == null)
					{
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
                            EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,  // "static void",
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
                            func.IsShared = true;

							func.AddParameter(txtMemberName.Text, dataCls.Name, -1);

							func.Comment = "Passes the given object to the redirected page.";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert(String.Format("\t\t\tBasePage.PushCurrentCallingPage();\r\n"));
							ep.Insert(String.Format("\t\t\tBasePage.PushParam(\"{0}\", {1});\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert(String.Format("\t\t\tBasePage.Redirect(\"{0}.aspx\");\r\n", this.pageCls.Name));
						}
					}
				}

				if (chkCreateSearchMethod.Enabled && chkCreateSearchMethod.Checked)
				{
					string funcName = "SearchFor" + txtPropertyName.Text;
					if (chkMainPageMethods.Checked)
						funcName = "Search";
					if (Util.FindFirstMember(pageCls, funcName) == null)
					{
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method from anytime you want to load the collection with search results";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\tbool result = true;\r\n");
							ep.Insert(String.Format("\t\t\t{0} {1} = new {0}();\r\n", dataCls.Name, txtMemberName.Text));
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert(String.Format("\t\t\t\tif (!this.ReadControlsForSearcherObject()) // Use appropriate read controls method to read the searcher object from controls \r\n"));
							ep.Insert(String.Format("\t\t\t\t\treturn false;\r\n"));
							//ep.Insert(String.Format("\t\t\t\t{0}.{2}(-1, this.{1}); // Use appropriate search method here \r\n", txtMemberName.Text, cbSearcherObject.Text, cbSearchMethod.Text));
							CodeFunction searchfunc = Util.FindFirstMethodAll(true, dataCls, cbSearchMethod.Text);
							if (searchfunc == null)
							{
								ep.Insert(String.Format("\t\t\t\t\t{0}.{1}({2});\r\n", txtMemberName.Text, cbSearchMethod.Text,
									"/* specify parameters if any */"));
							}
							else
							{
								// find parameters and substitue
								ep.Insert(String.Format("\t\t\t\t\t{0}.{1}({2});\r\n", txtMemberName.Text, cbSearchMethod.Text,
									Util.CreateCallArgsForFunction(searchfunc)));
							}
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);	// notify the page about the error\r\n");
							ep.Insert("\t\t\t\tresult = false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tfinally\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert(String.Format("\t\t\t\t//{0}.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!\r\n", txtMemberName.Text));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert(String.Format("\t\t\tthis.{0} = {1};\r\n", txtPropertyName.Text, txtMemberName.Text));
							ep.Insert("\t\t\treturn result;");
						}
					}
				}

				if (chkCreateSaveDataMethod.Checked)
				{
					string funcName = "SaveDataFor" + txtPropertyName.Text;
					if (chkMainPageMethods.Checked)
						funcName = "SaveData";
					if (Util.FindFirstMember(pageCls, funcName) == null)
					{
						CodeFunction func = pageCls.AddFunction(funcName, 
							EnvDTE.vsCMFunction.vsCMFunctionFunction,
							EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
							-1,
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);
						if (func != null)
						{
							func.Comment = "Call this method when you want to retrieve data from controls and save them to table.";
							EditPoint ep = func.StartPoint.CreateEditPoint();
							ep.LineDown(2);
							ep.StartOfLine();
							Util.DeleteEditLine(ep);
							ep.Insert("\t\t\ttry\r\n");
							ep.Insert("\t\t\t{\t// data from controls to object\r\n");
							if (chkMainPageMethods.Checked)
								ep.Insert(String.Format("\t\t\t\tif (!this.ReadControls())\r\n", txtPropertyName.Text));
							else
								ep.Insert(String.Format("\t\t\t\tif (!this.ReadControlsFor{0}())\r\n", txtPropertyName.Text));
							ep.Insert("\t\t\t\t\treturn false;\r\n");
							ep.Insert(String.Format("\t\t\t\t{0}.Save(); // update or insert to db \r\n", txtMemberName.Text));
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\tcatch(Exception ex)\r\n");
							ep.Insert("\t\t\t{\r\n");
							ep.Insert("\t\t\t\tthis.RaisePageException(ex);\r\n");
							ep.Insert("\t\t\t\treturn false;\r\n");
							ep.Insert("\t\t\t}\r\n");
							ep.Insert("\t\t\treturn true;");
						}
					}
				}

				DialogResult = DialogResult.OK;
				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		/*public void LoadPrograms()
		{
			SQLDataFiller.FillIntoObject(this.SqlData, this, "Programs", true, false);
		}

		public void SavePrograms()
		{
			SQLDataFiller.FillFromObject(this.SqlData, this, "Programs", true, false);
		}*/

		private void SetMemberName()
		{
			if (cbPropType.SelectedIndex > 0)		// collection
			{
				txtPropertyName.Text = Util.MakeCollectionInstanceName(pageDataCls.ProjectItem.ContainingProject, cbDataClass.Text);
				txtMemberName.Text = Util.CapitalizeString(txtPropertyName.Text, false, false);
				return;
			}
			txtPropertyName.Text = Util.CapitalizeString(cbDataClass.Text, true, false);
			txtMemberName.Text = Util.CapitalizeString(cbDataClass.Text, false, false);
		}

		private void cbForeignKey_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void txtMemberName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbDataClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetMemberName();
			EnableButtons();
		}

		private void FillDataClasses()
		{
			cbDataClass.Items.Clear();
			
			object[] dataClasses = null;
			
			if (cbPropType.SelectedIndex == 0)
				dataClasses = Util.FindDataClassesInProject(pageDataCls.ProjectItem.ContainingProject);
			else
				dataClasses = Util.FindCollectionClassesInProject(pageDataCls.ProjectItem.ContainingProject, null);
			
			for (int i = 0; i < dataClasses.Length; i++)
			{
				CodeClass dataClass = dataClasses[i] as CodeClass;
				if (dataClass != null)
					cbDataClass.Items.Add(dataClass.Name);
			}
		}

		private void ChildMemberCreator_Load(object sender, System.EventArgs e)
		{
			cbPropType.SelectedIndex = 0;
			//FillDataClasses();
			EnableButtons();
		}

		public static void CreatePageDataProperty(Form parentForm, CodeClass pageCls)
		{
			string assemblyName = null;
			string dataClass = null;
			CodeClass dataCls = null;
			if (Util.GetMainDataClassForForm(pageCls, ref assemblyName, ref dataClass))
			{
				dataCls = Util.FindClassInProject(dataClass + "," + assemblyName) as CodeClass;
				if (dataCls == null)
				{
					Connect.Instance.ShowDialog(parentForm, "Can't find data class " + dataClass, "Page Data Property Creator");
					return;
				}
			}

			PageDataPropertyCreator pdp = new PageDataPropertyCreator();
			pdp.pageCls = pageCls;
			pdp.pageDataCls = dataCls;
			pdp.extendsBaseDataClass = Util.IsDerivedFromBaseDataClass(dataCls);
			if (pdp.ShowDialog(Connect.Instance) == DialogResult.OK)
			{		
			}
		}

		private void cbDataClass_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void txtPropertyName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
			txtMemberName.Text = Util.CapitalizeString(txtPropertyName.Text, false, false);
		}

		private void txtMemberName_TextChanged_1(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbPropType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			FillDataClasses();
		}

		private void chkMainPageMethods_CheckedChanged(object sender, System.EventArgs e)
		{
			/*if (chkMainPageMethods.Checked)
			{
				if (cbPropType.SelectedIndex == 0)
				{
					txtMemberName.Text = "data";			// standard name for the main page data
					txtPropertyName.Text = "Data";			// standard name for the main page data
				}
				else
				{
					txtMemberName.Text = "col";				// standard name for the main page collection
					txtPropertyName.Text = "Collection";		// standard name for the main page collection
				}
			}*/
		}

		private void FillSearchMethods(CodeClass cls, ComboBox cb)
		{
			for (int i = 1; i <= cls.Members.Count; i++)
			{
				CodeFunction func = cls.Members.Item(i) as CodeFunction;
				if (func != null)
				{
					if (func.Access != vsCMAccess.vsCMAccessPrivate)
						cb.Items.Add(func.Name);
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
					FillSearchMethods(cls.Bases.Item(i) as CodeClass, cb);
			}
		}

		private void chkCreateSearchMethod_CheckedChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
			if (chkCreateSearchMethod.Checked)
			{
				CodeClass dataCls = Util.FindClassInProject(pageDataCls.ProjectItem.ContainingProject, cbDataClass.Text);
				if (dataCls == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find data class " + cbDataClass.Text, "Page Data Property Creator");
					return;
				}

				cbSearchMethod.Items.Clear();
				FillSearchMethods(dataCls, cbSearchMethod);
			}
		}

		private void cbSearchMethod_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cbSearchMethod_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void chkCacheAfterDataIsSet_CheckedChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void mnuSearchPageMainCollection_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 1)
				cbPropType.SelectedIndex = 1;

			// options
			chkMainPageMethods.Checked = true;
			chkCacheAfterDataIsSet.Checked = false;
			cbCachingKey.Text = "";

			// methods
			chkCreateReadControlsMethod.Checked = false;
			chkCreateNewDataMethod.Checked = false;
			chkCreateLoadDataMethod.Checked = false;
			chkCreateSaveDataMethod.Checked = false;
			chkCreateRedirectMethod.Checked = false;
			chkCreateSearchMethod.Checked = true;

			EnableButtons();
		}

		private void mnuSearchPageMainSearchObject_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 0)
				cbPropType.SelectedIndex = 0;

			// options
			chkMainPageMethods.Checked = true;
			chkCacheAfterDataIsSet.Checked = true;
			cbCachingKey.Text = txtPropertyName.Text;

			// methods
			chkCreateReadControlsMethod.Checked = true;
			chkCreateNewDataMethod.Checked = true;
			chkCreateLoadDataMethod.Checked = false;
			chkCreateSaveDataMethod.Checked = false;
			chkCreateRedirectMethod.Checked = false;
			chkCreateSearchMethod.Checked = true;

			EnableButtons();
		}

		private void mnuSearchPageOtherCollection_Click(object sender, System.EventArgs e)
		{
			mnuSearchPageMainCollection_Click(sender, e);
			chkMainPageMethods.Checked = false;
		}

		private void mnuSearchPageOtherSearchObject_Click(object sender, System.EventArgs e)
		{
			mnuSearchPageMainSearchObject_Click(sender, e);
			chkMainPageMethods.Checked = false;
		}

		private void mnuDataPageMainDataObject_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 0)
				cbPropType.SelectedIndex = 0;

			// options
			chkMainPageMethods.Checked = true;
			chkCacheAfterDataIsSet.Checked = true;
			cbCachingKey.Text = "[ClassName]";

			// methods
			chkCreateReadControlsMethod.Checked = true;
			chkCreateNewDataMethod.Checked = true;
			chkCreateLoadDataMethod.Checked = true;
			chkCreateSaveDataMethod.Checked = true;
			chkCreateRedirectMethod.Checked = true;
			chkCreateSearchMethod.Checked = false;

			EnableButtons();
		}

		private void mnuDataPageChildDataObject_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 0)
				cbPropType.SelectedIndex = 0;

			// options
			chkMainPageMethods.Checked = false;
			chkCacheAfterDataIsSet.Checked = true;
			cbCachingKey.Text = "[ClassName]";

			// methods
			chkCreateReadControlsMethod.Checked = true;
			chkCreateNewDataMethod.Checked = true;
			chkCreateLoadDataMethod.Checked = false;
			chkCreateSaveDataMethod.Checked = true;
			chkCreateRedirectMethod.Checked = false;
			chkCreateSearchMethod.Checked = false;

			EnableButtons();
		}

		private void mnuDataPageChildCollection_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 1)
				cbPropType.SelectedIndex = 1;

			// options
			chkMainPageMethods.Checked = false;
			chkCacheAfterDataIsSet.Checked = false;
			cbCachingKey.Text = "";

			// methods
			chkCreateReadControlsMethod.Checked = false;
			chkCreateNewDataMethod.Checked = false;
			chkCreateLoadDataMethod.Checked = true;
			chkCreateSaveDataMethod.Checked = false;
			chkCreateRedirectMethod.Checked = false;
			chkCreateSearchMethod.Checked = false;

			EnableButtons();		
		}

		private void mnuDataPageOtherDataObject_Click(object sender, System.EventArgs e)
		{
			mnuDataPageMainDataObject_Click(sender, e);
			chkMainPageMethods.Checked = false;
		}

		private void mnuDataPageOtherCollection_Click(object sender, System.EventArgs e)
		{
			if (cbPropType.SelectedIndex != 1)
				cbPropType.SelectedIndex = 1;

			// options
			chkMainPageMethods.Checked = false;
			chkCacheAfterDataIsSet.Checked = true;
			cbCachingKey.Text = "[ClassName]";

			// methods
			chkCreateReadControlsMethod.Checked = false;
			chkCreateNewDataMethod.Checked = false;
			chkCreateLoadDataMethod.Checked = true;
			chkCreateSaveDataMethod.Checked = false;
			chkCreateRedirectMethod.Checked = false;
			chkCreateSearchMethod.Checked = false;

			EnableButtons();
		}


	}
}
