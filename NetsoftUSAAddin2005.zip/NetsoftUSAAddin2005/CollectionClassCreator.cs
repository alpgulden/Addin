using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class CollectionClassCreator : System.Windows.Forms.Form
	{
		private CodeClass elementCls;
		private CodeClass cls;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TextBox txtClassName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbElementType;
		private System.Windows.Forms.CheckBox chkCreateInThisFile;
		private System.Windows.Forms.CheckBox chkAddParentCollection;
		private System.Windows.Forms.CheckBox chkDeriveFromBaseCollectionClass;
		private System.Windows.Forms.PictureBox pictureBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CollectionClassCreator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CollectionClassCreator));
			this.label1 = new System.Windows.Forms.Label();
			this.cbElementType = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.txtClassName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.chkCreateInThisFile = new System.Windows.Forms.CheckBox();
			this.chkAddParentCollection = new System.Windows.Forms.CheckBox();
			this.chkDeriveFromBaseCollectionClass = new System.Windows.Forms.CheckBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(80, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Element Type:";
			// 
			// cbElementType
			// 
			this.cbElementType.Location = new System.Drawing.Point(136, 80);
			this.cbElementType.Name = "cbElementType";
			this.cbElementType.Size = new System.Drawing.Size(264, 21);
			this.cbElementType.TabIndex = 2;
			this.cbElementType.TextChanged += new System.EventHandler(this.cbElementType_TextChanged);
			this.cbElementType.SelectedIndexChanged += new System.EventHandler(this.cbElementType_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(240, 48);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select an element type to create a strongly typed collection for.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(136, 208);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			// 
			// butCreate
			// 
			this.butCreate.Location = new System.Drawing.Point(224, 208);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// txtClassName
			// 
			this.txtClassName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtClassName.Location = new System.Drawing.Point(136, 104);
			this.txtClassName.Name = "txtClassName";
			this.txtClassName.Size = new System.Drawing.Size(264, 20);
			this.txtClassName.TabIndex = 11;
			this.txtClassName.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 104);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(136, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Collection Class Name:";
			// 
			// chkCreateInThisFile
			// 
			this.chkCreateInThisFile.Checked = true;
			this.chkCreateInThisFile.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkCreateInThisFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkCreateInThisFile.Location = new System.Drawing.Point(112, 136);
			this.chkCreateInThisFile.Name = "chkCreateInThisFile";
			this.chkCreateInThisFile.Size = new System.Drawing.Size(208, 24);
			this.chkCreateInThisFile.TabIndex = 12;
			this.chkCreateInThisFile.Text = "Create in this file";
			// 
			// chkAddParentCollection
			// 
			this.chkAddParentCollection.Checked = true;
			this.chkAddParentCollection.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkAddParentCollection.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkAddParentCollection.Location = new System.Drawing.Point(112, 152);
			this.chkAddParentCollection.Name = "chkAddParentCollection";
			this.chkAddParentCollection.Size = new System.Drawing.Size(224, 32);
			this.chkAddParentCollection.TabIndex = 12;
			this.chkAddParentCollection.Text = "Add ParentCollection to element type";
			// 
			// chkDeriveFromBaseCollectionClass
			// 
			this.chkDeriveFromBaseCollectionClass.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.chkDeriveFromBaseCollectionClass.Location = new System.Drawing.Point(112, 176);
			this.chkDeriveFromBaseCollectionClass.Name = "chkDeriveFromBaseCollectionClass";
			this.chkDeriveFromBaseCollectionClass.Size = new System.Drawing.Size(224, 24);
			this.chkDeriveFromBaseCollectionClass.TabIndex = 15;
			this.chkDeriveFromBaseCollectionClass.Text = "Derive from EntityCollectionClass";
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(8, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(16, 16);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 17;
			this.pictureBox2.TabStop = false;
			// 
			// CollectionClassCreator
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(410, 240);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.chkDeriveFromBaseCollectionClass);
			this.Controls.Add(this.chkCreateInThisFile);
			this.Controls.Add(this.txtClassName);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbElementType);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkAddParentCollection);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CollectionClassCreator";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Collection Class Creator";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.TextChanged += new System.EventHandler(this.cbElementType_TextChanged);
			this.ResumeLayout(false);

		}
		#endregion

		public static void CreateCollectionClass(CodeClass elemClass)
		{
            
			CollectionClassCreator ccb = new CollectionClassCreator();
			ccb.cbElementType.Text = elemClass.Name;
            ccb.elementCls = elemClass;
			ccb.SetClassName();
			if (ccb.ShowDialog(Connect.Instance) == DialogResult.OK)
			{		
				if (ccb.cls != null)
				{
					CollectionClassBuilder.BuildCollectionClass(ccb.cls);
				}
			}
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			try
			{
				string elemType = cbElementType.Text;

				CodeClass clsElem = Util.FindClassInProject(this.elementCls.ProjectItem.ContainingProject, elemType);

				if (clsElem == null)
				{
					Connect.Instance.ShowDialog(this, "Can't find element type!");
					return;
				}

                string baseClass = String.Format("EntityCollection<{0}>", elementCls.Name);
                /*
                if (chkDeriveFromBaseCollectionClass.Checked)
                    baseClass = "EntityCollection";
                else
                {
                    if (chkCreateInThisFile.Checked)
                        baseClass = "System.Collections.CollectionBase";
                    else
                        baseClass = "CollectionBase";
                }*/

				//NewCSharpFile.cs
                CodeNamespace ns = null;
				ProjectItem prjItem = null;

                if (chkCreateInThisFile.Checked)
                {
                    prjItem = Connect.Instance.CurrentProjectItem;
                    ns = Util.FindCodeNamespace(prjItem.FileCodeModel.CodeElements);
                    cls = ns.AddClass(txtClassName.Text, -1, baseClass, null, EnvDTE.vsCMAccess.vsCMAccessPublic);
                }
                else
                {
                    cls = Connect.Instance.AddClassToCurrentProject(txtClassName.Text, baseClass);
                    prjItem = cls.ProjectItem;
                    ns = cls.Namespace;
                }

				if (prjItem == null)
					return;

				if (!chkCreateInThisFile.Checked)
				{
					// add:   using NetsoftUSA.Model;
					EditPoint ep = ns.StartPoint.CreateEditPoint();
					ep.LineUp(1);
					ep.EndOfLine();
					ep.Insert("\r\nusing System.Collections;\r\n");
					ep.Insert("using NetsoftUSA.Model;\r\n\r\n");
				}

				//if (chkCreateInThisFile.Checked)
				//	cls = ns.AddClass(txtClassName.Text, -1, baseClass, null, EnvDTE.vsCMAccess.vsCMAccessPublic);
				//else
				//	cls = ns.Members.Item(1) as CodeClass;

				if (cls != null)
				{
					cls.Comment = String.Format("Strongly typed collection of {0} objects", elemType);

					EditPoint ep = cls.StartPoint.CreateEditPoint();
					ep.LineUp(1);
					ep.EndOfLine();
					string pars = String.Format("typeof({0})", elemType);
                    ep.Insert(String.Format("\r\n\t//[ServiceClass(\"{0}\")]    // You can optionally declare a service class different from element entity's service..", elementCls.Name + "Service"));
					ep.Insert(String.Format("\r\n\t[ElementType({0})]", pars));

					//if (!chkCreateInThisFile.Checked)
					//cls.AddBase(baseClass, -1);

					// create ParentCollection property in the element class
					if (chkAddParentCollection.Checked)
					{
						//string parentColVar = "parent" + cls.Name;
						string parentColProp = "Parent" + cls.Name;

						/*CodeVariable var = clsElem.AddVariable(parentColVar,
							cls.Name,
							0, 
							EnvDTE.vsCMAccess.vsCMAccessPrivate, 
							null);*/

						//Util.DeclareNonSerialized(var);

						// add public ParentCollection property
						CodeProperty prop = clsElem.AddProperty(parentColProp, parentColProp,
							cls.Name,
							-1, 
							EnvDTE.vsCMAccess.vsCMAccessPublic, 
							null);

						prop.Comment = String.Format("Parent {0} that contains this element", cls.Name); 

						ep = prop.Getter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);
                        ep.Insert(String.Format("\t\t\t\treturn this.ParentCollection as {0};", cls.Name));

						ep = prop.Setter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						ep.Insert(String.Format("\t\t\t\tthis.ParentCollection = value; // parent is set when added to a collection\r\n"));

					}


				}

				if (!chkCreateInThisFile.Checked)
				{
					prjItem.Save(null);
					prjItem.Open(Constants.vsViewKindCode);
				}
				else
				{
					// show it in this file
					EditPoint ep = cls.StartPoint.CreateEditPoint();
					ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				}

				Util.SetSetting("__ClassManager", "DeriveFromBaseEntity", chkDeriveFromBaseCollectionClass.Checked);
				DialogResult = DialogResult.OK;
				Close();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void FillElemTypes()
		{
			cbElementType.Items.Clear();
			object[] Entityes = Util.FindClassesWithAttribsInProject(Util.EntityAttribs);

			for (int i = 0; i < Entityes.Length; i++)
			{
				CodeClass elemCls = Entityes[i] as CodeClass;
				cbElementType.Items.Add(elemCls.Name);
			}
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			chkDeriveFromBaseCollectionClass.Checked = Util.GetSetting("__ClassManager", "DeriveFromBaseEntity", false);
			FillElemTypes();
		}

		private void SetClassName()
		{
			string clsName = Util.NormalizeClassName(cbElementType.Text);
			clsName = clsName + "Collection";
			txtClassName.Text = clsName;
		}

		private void cbElementType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetClassName();
		}

		private void cbElementType_TextChanged(object sender, System.EventArgs e)
		{
			SetClassName();
		}

	}
}
