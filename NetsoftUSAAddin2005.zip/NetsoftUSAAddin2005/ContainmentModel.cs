using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	public enum EnumContainmentNodeType
	{
		rootClass = 0,
		childCollection = 1,	// collection
		containedObject = 2,	// contained object
		collectionIndexer = 3,	// this[] member
		parentObject = 4		// parent object
	}

	/// <summary>
	/// Summary description for FormatterPropOptions.
	/// </summary>
	public class ContainmentModel : System.Windows.Forms.Form
	{
		private CodeClass rootCls;	// root class
		private TreeNode rootNode;

		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TreeView tree;
		private System.Windows.Forms.ImageList icons;
		private System.Windows.Forms.Button butBuildClass;
		private System.Windows.Forms.Button butShowContainmentModel;
		private System.Windows.Forms.Button butCreateContained;
		private System.Windows.Forms.Button butCreateChildCol;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListView lstOtherRefs;
		private System.Windows.Forms.ColumnHeader colMemberName;
		private System.Windows.Forms.ColumnHeader colType;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Splitter splitter1;
		private System.ComponentModel.IContainer components;

		public ContainmentModel()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ContainmentModel));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tree = new System.Windows.Forms.TreeView();
			this.icons = new System.Windows.Forms.ImageList(this.components);
			this.butBuildClass = new System.Windows.Forms.Button();
			this.butShowContainmentModel = new System.Windows.Forms.Button();
			this.butCreateContained = new System.Windows.Forms.Button();
			this.butCreateChildCol = new System.Windows.Forms.Button();
			this.lstOtherRefs = new System.Windows.Forms.ListView();
			this.colMemberName = new System.Windows.Forms.ColumnHeader();
			this.colType = new System.Windows.Forms.ColumnHeader();
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(502, 56);
			this.label2.TabIndex = 3;
			this.label2.Text = @"The following tree shows the objects contained by this root object.  The containing object is responsible for the in memory life time management and DB-persistence of its immediate contained objects/child collections.  Child collections map 1-to-many relationship, and contained objects map 1-to-1 relationship.";
			// 
			// butCancel
			// 
			this.butCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(590, 302);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Close";
			this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// tree
			// 
			this.tree.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.tree.HideSelection = false;
			this.tree.ImageList = this.icons;
			this.tree.Location = new System.Drawing.Point(0, 24);
			this.tree.Name = "tree";
			this.tree.Size = new System.Drawing.Size(272, 184);
			this.tree.TabIndex = 7;
			this.tree.Click += new System.EventHandler(this.tree_Click);
			this.tree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tree_AfterSelect);
			// 
			// icons
			// 
			this.icons.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
			this.icons.ImageSize = new System.Drawing.Size(16, 16);
			this.icons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("icons.ImageStream")));
			this.icons.TransparentColor = System.Drawing.Color.White;
			// 
			// butBuildClass
			// 
			this.butBuildClass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butBuildClass.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.butBuildClass.Location = new System.Drawing.Point(8, 302);
			this.butBuildClass.Name = "butBuildClass";
			this.butBuildClass.TabIndex = 8;
			this.butBuildClass.Text = "Build Class";
			this.butBuildClass.Click += new System.EventHandler(this.butBuildClass_Click);
			// 
			// butShowContainmentModel
			// 
			this.butShowContainmentModel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butShowContainmentModel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.butShowContainmentModel.Location = new System.Drawing.Point(88, 302);
			this.butShowContainmentModel.Name = "butShowContainmentModel";
			this.butShowContainmentModel.Size = new System.Drawing.Size(208, 23);
			this.butShowContainmentModel.TabIndex = 9;
			this.butShowContainmentModel.Text = "Show Containment Model for Selected";
			this.butShowContainmentModel.Click += new System.EventHandler(this.butShowContainmentModel_Click);
			// 
			// butCreateContained
			// 
			this.butCreateContained.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateContained.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.butCreateContained.Location = new System.Drawing.Point(8, 276);
			this.butCreateContained.Name = "butCreateContained";
			this.butCreateContained.Size = new System.Drawing.Size(144, 23);
			this.butCreateContained.TabIndex = 10;
			this.butCreateContained.Text = "Create Contained Class";
			this.butCreateContained.Click += new System.EventHandler(this.butCreateContained_Click);
			// 
			// butCreateChildCol
			// 
			this.butCreateChildCol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateChildCol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.butCreateChildCol.Location = new System.Drawing.Point(156, 276);
			this.butCreateChildCol.Name = "butCreateChildCol";
			this.butCreateChildCol.Size = new System.Drawing.Size(140, 23);
			this.butCreateChildCol.TabIndex = 11;
			this.butCreateChildCol.Text = "Create Child Collection";
			this.butCreateChildCol.Click += new System.EventHandler(this.butCreateChildCol_Click);
			// 
			// lstOtherRefs
			// 
			this.lstOtherRefs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lstOtherRefs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lstOtherRefs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.colMemberName,
																						   this.colType});
			this.lstOtherRefs.Location = new System.Drawing.Point(8, 24);
			this.lstOtherRefs.Name = "lstOtherRefs";
			this.lstOtherRefs.Size = new System.Drawing.Size(376, 184);
			this.lstOtherRefs.SmallImageList = this.icons;
			this.lstOtherRefs.TabIndex = 12;
			this.lstOtherRefs.View = System.Windows.Forms.View.Details;
			this.lstOtherRefs.DoubleClick += new System.EventHandler(this.lstOtherRefs_DoubleClick);
			this.lstOtherRefs.SelectedIndexChanged += new System.EventHandler(this.lstOtherRefs_SelectedIndexChanged);
			// 
			// colMemberName
			// 
			this.colMemberName.Text = "Member Name";
			this.colMemberName.Width = 164;
			// 
			// colType
			// 
			this.colType.Text = "Type";
			this.colType.Width = 395;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.TabIndex = 13;
			this.label1.Text = "Other References:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(0, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(216, 23);
			this.label3.TabIndex = 14;
			this.label3.Text = "Contained Objects && Child Collections:";
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.Controls.Add(this.splitter1);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new System.Drawing.Point(8, 64);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(656, 208);
			this.panel1.TabIndex = 15;
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(272, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(8, 208);
			this.splitter1.TabIndex = 17;
			this.splitter1.TabStop = false;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.lstOtherRefs);
			this.panel3.Controls.Add(this.label1);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(272, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(384, 208);
			this.panel3.TabIndex = 16;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.tree);
			this.panel2.Controls.Add(this.label3);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(272, 208);
			this.panel2.TabIndex = 15;
			// 
			// ContainmentModel
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(672, 333);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.butCreateChildCol);
			this.Controls.Add(this.butCreateContained);
			this.Controls.Add(this.butShowContainmentModel);
			this.Controls.Add(this.butBuildClass);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.MaximizeBox = false;
			this.Name = "ContainmentModel";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Object Containment Model";
			this.TopMost = true;
			this.Closing += new System.ComponentModel.CancelEventHandler(this.ContainmentModel_Closing);
			this.Load += new System.EventHandler(this.EntityCreator_Load);
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public static void Display(CodeClass rootCls) //CodeClass elemClass)
		{
			ContainmentModel ocm = new ContainmentModel();
			ocm.rootCls = rootCls;
			ocm.Show();
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			Util.LoadFormPos(this, true);
			FillContainmentHierarchy();
		}

		private void FillContainmentHierarchy()
		{
			lstOtherRefs.Items.Clear();
			tree.Nodes.Clear();

			rootNode = AddClassToNodes(tree.Nodes, rootCls, EnumContainmentNodeType.rootClass, null);
			FillMembersOfClass(rootNode);
			rootNode.ExpandAll();
			EnableButtons();
		}

		private TreeNode AddClassToNodes(TreeNodeCollection nodes, CodeClass cls, EnumContainmentNodeType nodeType, CodeElement elem)
		{
			string text = null;
			int icon = 0;
			switch (nodeType)
			{
				case EnumContainmentNodeType.rootClass:
					text = cls.Name;
					icon = 1;
					break;
				case EnumContainmentNodeType.childCollection:
					text = elem.Name + "   (" + cls.Name + ")";
					icon = 3;
					break;
				case EnumContainmentNodeType.containedObject:
					text = elem.Name + "   (" + cls.Name + ")";
					icon = 2;
					break;
				case EnumContainmentNodeType.collectionIndexer:
					text = "[]   (" + cls.Name + ")";
					icon = 4;
					break;
				case EnumContainmentNodeType.parentObject:
					text = elem.Name + "   (" + cls.Name + ")";
					icon = 5;
					break;
				default:
					System.Diagnostics.Debug.Fail("Invalid EnumContainmentNodeType");
					break;
			}
			TreeNode node = nodes.Add(text);
			node.Tag = cls;
			node.ImageIndex = icon;
			node.SelectedImageIndex = icon;
			return node;
		}
		
		private TreeNode AddChildMemberToNode(TreeNode classNode, CodeElement elem)
		{
			CodeProperty prop = elem as CodeProperty;
			if (prop == null)
				return null;
			string clsName = Util.GetLastTerm(prop.Type.AsString);
			CodeClass ccls = Util.FindClassInProject(clsName);
			if (ccls != null)
				return AddClassToNodes(classNode.Nodes, ccls, EnumContainmentNodeType.childCollection, elem);

			return null;
		}

		private TreeNode AddContainedMemberToNode(TreeNode classNode, CodeElement elem)
		{
			CodeProperty prop = elem as CodeProperty;
			if (prop == null)
				return null;
			string clsName = Util.GetLastTerm(prop.Type.AsString);
			CodeClass ccls = Util.FindClassInProject(clsName);
			if (ccls != null)
				return AddClassToNodes(classNode.Nodes, ccls, EnumContainmentNodeType.containedObject, elem);

			return null;
		}

		private TreeNode AddColIndexerToNode(TreeNode classNode, CodeElement elem)
		{
			CodeProperty prop = elem as CodeProperty;
			if (prop == null)
				return null;
			string clsName = Util.GetLastTerm(prop.Type.AsString);
			CodeClass ccls = Util.FindClassInProject(clsName);
			if (ccls != null)
				return AddClassToNodes(classNode.Nodes, ccls, EnumContainmentNodeType.collectionIndexer, elem);

			return null;
		}

		private TreeNode AddParentMemberToNode(TreeNode classNode, CodeElement elem)
		{
			CodeProperty prop = elem as CodeProperty;
			if (prop == null)
				return null;
			string clsName = Util.GetLastTerm(prop.Type.AsString);
			CodeClass ccls = Util.FindClassInProject(clsName);
			if (ccls != null)
				return AddClassToNodes(classNode.Nodes, ccls, EnumContainmentNodeType.parentObject, elem);

			return null;
		}

		private void FillMembersOfClass(TreeNode classNode)
		{
			if (classNode == null)
				return;
			CodeClass cls = classNode.Tag as CodeClass;
			if (cls == null)
				return;

			FillMembersOfClassRecursive(classNode, cls);
		}

		private void FillMembersOfClassRecursive(TreeNode classNode, CodeClass cls)
		{
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "ChildCollection", "SimpleRelation", "SPLoadChild"))
				{
					TreeNode colNd = AddChildMemberToNode(classNode, elem);
					FillMembersOfClass(colNd);

					// trace into the element class
					if (colNd != null)
					{
						CodeClass colCls = colNd.Tag as CodeClass;
						/*CodeClass elemCls = Util.GetElementClassOfCollection(colCls);
						if (elemCls != null)
						{
							CodeElement thisElem = Util.FindFirstMember(colCls, "this");
							TreeNode elemNd = AddContainedMemberToNode(colNd, thisElem);
							FillMembersOfClass(elemNd);
						}*/
					}

				}
				else if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "Contained"))
				{
					TreeNode nd = AddContainedMemberToNode(classNode, elem);
					FillMembersOfClass(nd);
				}
				else if (elem.Name == "this")
				{
					TreeNode nd = AddColIndexerToNode(classNode, elem);
					FillMembersOfClass(nd);
				}
				else if (elem.Name.Length >= 6 && elem.Name.Substring(0, 6).ToLower() == "parent")
				{
					TreeNode nd = AddParentMemberToNode(classNode, elem);
					//  FillMembersOfClass(nd);  // never fill the child members for the parent
				}
			}

			// fill the bases
			for (int i = 1; i <= cls.Bases.Count; i ++)
			{
				FillMembersOfClassRecursive(classNode, cls.Bases.Item(i) as CodeClass);
			}

		}

		public void FillOtherReferences(CodeClass cls, bool clear)
		{
			if (clear)
				lstOtherRefs.Items.Clear();

			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "ChildCollection", "SimpleRelation", "SPLoadChild")
					|| Util.HasAnyOfAttributes(Util.GetAttributes(elem), "Contained")
					|| (elem.Name == "this")
					|| (elem.Name.Length >= 6 && elem.Name.Substring(0, 6).ToLower() == "parent"))
				{
					// something related to containment relationship
				}
				else
				{
					// some other member
					CodeProperty prop = elem as CodeProperty;
					if (prop != null)
					{
						// a property
						if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
						{
							if (prop.Type.CodeType.Kind == vsCMElement.vsCMElementClass)
							{
								// an object reference
								int icon = 6;

								if (Util.IsSharedMember(cls, elem))
									icon = 8;
								else if (Util.IsFieldValuesProp(elem))
									icon = 7;
								ListViewItem lvi = new ListViewItem(new string[] { prop.Name, prop.Type.AsString }, icon);
								lstOtherRefs.Items.Add(lvi);
							}
						}
					}
				}
			}

			// fill the bases
			for (int i = 1; i <= cls.Bases.Count; i ++)
			{
				FillOtherReferences(cls.Bases.Item(i) as CodeClass, false);
			}
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void tree_Click(object sender, System.EventArgs e)
		{
			
		}

		private void tree_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			TreeNode nd = e.Node;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;
			if (nodeCls == null)
				return;
			FillOtherReferences(nodeCls, true);
			Util.ShowClass(nodeCls);
			EnableButtons();
		}

		private void butBuildClass_Click(object sender, System.EventArgs e)
		{
			TreeNode nd = tree.SelectedNode;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;
			if (Util.IsCollectionClass(nodeCls))
				CollectionClassBuilder.BuildCollectionClass(nodeCls);
			else if (Util.IsEntity(nodeCls))
				EntityBuilder.BuildClass(nodeCls);
		}

		private void EnableButtons()
		{
			butCreateChildCol.Enabled = false;
			butCreateContained.Enabled = false;
			TreeNode nd = tree.SelectedNode;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;
			if (nd.ImageIndex == 1 || nd.ImageIndex == 2 || nd.ImageIndex == 4)  //Util.IsEntity(nodeCls))
			{
				butCreateChildCol.Enabled = true;
				butCreateContained.Enabled = true;
			}
		}

		private void butShowContainmentModel_Click(object sender, System.EventArgs e)
		{
			TreeNode nd = tree.SelectedNode;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;
			this.rootCls = nodeCls;
			FillContainmentHierarchy();
		}

		private void butCreateChildCol_Click(object sender, System.EventArgs e)
		{
			TreeNode nd = tree.SelectedNode;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;

			try
			{
				ChildMemberCreator.CreateChildMember(null, nodeCls);
				FillContainmentHierarchy();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void butCreateContained_Click(object sender, System.EventArgs e)
		{
			TreeNode nd = tree.SelectedNode;
			if (nd == null)
				return;
			CodeClass nodeCls = nd.Tag as CodeClass;

			try
			{
				ContainedEntityObjectCreator.CreateConatinedEntityObject(null, nodeCls);
				FillContainmentHierarchy();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void ContainmentModel_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Util.SaveFormPos(this);
		}

		private void lstOtherRefs_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (lstOtherRefs.SelectedItems.Count > 0)
			{
				int count = lstOtherRefs.SelectedItems.Count;
				for (int i = 0; i < count; i++)
				{
					ListViewItem lvi = (ListViewItem)lstOtherRefs.SelectedItems[i];
					if (lvi != null)
					{
						TreeNode nd = tree.SelectedNode;
						if (nd == null)
							return;
						CodeClass nodeCls = nd.Tag as CodeClass;
						CodeElement elem = Util.FindFirstMember(nodeCls, lvi.SubItems[0].Text);
						Util.MarkElement(nodeCls, elem);
						return;
					}
				}
			}
			
		}

		private void lstOtherRefs_DoubleClick(object sender, System.EventArgs e)
		{
			if (lstOtherRefs.SelectedItems.Count > 0)
			{
				int count = lstOtherRefs.SelectedItems.Count;
				for (int i = 0; i < count; i++)
				{
					ListViewItem lvi = (ListViewItem)lstOtherRefs.SelectedItems[i];
					if (lvi != null)
					{
						TreeNode nd = tree.SelectedNode;
						if (nd == null)
							return;
						CodeClass nodeCls = nd.Tag as CodeClass;
						CodeProperty prop = Util.FindFirstMember(nodeCls, lvi.SubItems[0].Text) as CodeProperty;
						if (prop != null)
						{
							CodeClass cls = prop.Type.CodeType as CodeClass;
							if (cls != null)
								Util.ShowClass(cls);
						}
						return;
					}
				}
			}
		}


		/*private void FillContainedEntityObjects()
		{
			lsContainedEntityObjects.Items.Clear();
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				CodeProperty prop = elem as CodeProperty;
				if (prop != null)
				{
					if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
					{
						if (Util.HasAnyOfAttributes(Util.GetAttributes(elem), "Contained"))
						{
							lsContainedEntityObjects.Items.Add(elem.Name);
						}
					}
				}
			}
		}

		private void FillParentObjects()
		{
			lsParentObjects.Items.Clear();
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				CodeProperty prop = elem as CodeProperty;
				if (prop != null)
				{
					if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
					{
						if (prop.Name.Length >= 6)
							if (prop.Name.Substring(0, 6).ToLower() == "parent")
							{
								lsParentObjects.Items.Add(prop.Name);
							}
					}
				}
			}
		}*/

	}

	
}
