using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for CreateCollectionCachedMemberDlg.
	/// </summary>
	public class CreateCollectionCachedMemberDlg : System.Windows.Forms.Form
	{
		private CodeClass cls;
		private CodeClass elemCls;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.Button butCreate;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtMemberName;
		private System.Windows.Forms.ComboBox cbLoadMethod;
		private System.Windows.Forms.PictureBox pictureBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CreateCollectionCachedMemberDlg()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(CreateCollectionCachedMemberDlg));
			this.label2 = new System.Windows.Forms.Label();
			this.butCancel = new System.Windows.Forms.Button();
			this.butCreate = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.cbLoadMethod = new System.Windows.Forms.ComboBox();
			this.txtMemberName = new System.Windows.Forms.TextBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(288, 56);
			this.label2.TabIndex = 3;
			this.label2.Text = "Please select options to create a static collection member that returns a cached " +
				"instance of this collection.";
			// 
			// butCancel
			// 
			this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCancel.Location = new System.Drawing.Point(168, 144);
			this.butCancel.Name = "butCancel";
			this.butCancel.TabIndex = 4;
			this.butCancel.Text = "Cancel";
			// 
			// butCreate
			// 
			this.butCreate.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.butCreate.Location = new System.Drawing.Point(248, 144);
			this.butCreate.Name = "butCreate";
			this.butCreate.TabIndex = 5;
			this.butCreate.Text = "Create";
			this.butCreate.Click += new System.EventHandler(this.butCreate_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(136, 53);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 80);
			this.label1.Name = "label1";
			this.label1.TabIndex = 12;
			this.label1.Text = "Member Name:";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(144, 23);
			this.label5.TabIndex = 17;
			this.label5.Text = "Load Method:";
			// 
			// cbLoadMethod
			// 
			this.cbLoadMethod.Location = new System.Drawing.Point(168, 104);
			this.cbLoadMethod.Name = "cbLoadMethod";
			this.cbLoadMethod.Size = new System.Drawing.Size(264, 21);
			this.cbLoadMethod.TabIndex = 18;
			// 
			// txtMemberName
			// 
			this.txtMemberName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtMemberName.Location = new System.Drawing.Point(168, 80);
			this.txtMemberName.Name = "txtMemberName";
			this.txtMemberName.Size = new System.Drawing.Size(264, 20);
			this.txtMemberName.TabIndex = 19;
			this.txtMemberName.Text = "";
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(8, 8);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(16, 16);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 20;
			this.pictureBox2.TabStop = false;
			// 
			// CreateCollectionCachedMemberDlg
			// 
			this.AcceptButton = this.butCreate;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.butCancel;
			this.ClientSize = new System.Drawing.Size(450, 175);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.txtMemberName);
			this.Controls.Add(this.cbLoadMethod);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.butCreate);
			this.Controls.Add(this.butCancel);
			this.Controls.Add(this.label2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CreateCollectionCachedMemberDlg";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Netsoft USA Collection Cached Member Creator";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.LookupMemberOptionsDlg_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public static bool CreateCachedMember(CodeClass cls, CodeClass elemCls)
		{
			return CreateCachedMember(cls, elemCls, null);
		}

		public static bool CreateCachedMember(CodeClass cls, CodeClass elemCls, string loadMethod)
		{
			CreateCollectionCachedMemberDlg cmc = new CreateCollectionCachedMemberDlg();
			cmc.cls = cls;
			cmc.elemCls = elemCls;
			cmc.cbLoadMethod.Text = loadMethod;
			if (cmc.ShowDialog(Connect.Instance) == DialogResult.OK)
				return true;
			else
				return false;
		}

		private void butCreate_Click(object sender, System.EventArgs e)
		{
			if (Connect.Instance.CreateCachedCollectionMember(this, cls, txtMemberName.Text, cbLoadMethod.Text))
			{
				DialogResult = DialogResult.OK;
				Close();
			}
		}

		private void LookupMemberOptionsDlg_Load(object sender, System.EventArgs e)
		{
			txtMemberName.Text = Util.MakePlural(elemCls.Name);
			FillMethods(cls, cbLoadMethod);
		}

		private void FillMethods(CodeClass elemCls, ComboBox cb)
		{
			for (int i = 1; i <= elemCls.Members.Count; i++)
			{
				CodeFunction func = elemCls.Members.Item(i) as CodeFunction;
				if (func != null)
				{
					if (func.Access != vsCMAccess.vsCMAccessPrivate)
						cb.Items.Add(func.Name);
				}
			}

			if (elemCls.Bases != null)
			{
				for (int i = 1; i <= elemCls.Bases.Count; i++)
					FillMethods(elemCls.Bases.Item(i) as CodeClass, cb);
			}
		}

		
	}

}
