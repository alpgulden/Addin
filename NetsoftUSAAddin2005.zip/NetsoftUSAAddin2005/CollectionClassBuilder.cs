using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Office.Core;
using Extensibility;
using System.Runtime.InteropServices;
using EnvDTE;
using EnvDTE80;

namespace NetsoftUSAAddin2005
{
	/// <summary>
	/// Summary description for EntityCreator.
	/// </summary>
	public class CollectionClassBuilder : System.Windows.Forms.Form
	{
		//private CodeClass elementCls;
		private CodeClass cls;
		private CodeClass elemCls;
		DataTable tbl;
		private bool extendsEntityCollectionClass = false;
		//private StoredProcedureOptions spOptions;

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button butCancel;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TabPage tabElementAccessMethods;
		private System.Windows.Forms.CheckBox chkAllMethods;
		private System.Windows.Forms.CheckBox chkItemIndexer;
		private System.Windows.Forms.CheckBox chkInsertMethod;
		private System.Windows.Forms.CheckBox chkAddMethod;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.Button cmdShowInsertMethod;
		private System.Windows.Forms.Button cmdShowAddMethod;
		private System.Windows.Forms.CheckBox chkRemoveMethod;
		private System.Windows.Forms.Button cmdShowRemoveMethod;
		private System.Windows.Forms.Button cmShowItemIndexer;
		private System.Windows.Forms.Button cmdShowContainsMethod;
		private System.Windows.Forms.CheckBox chkContainsMethod;
		private System.Windows.Forms.Button cmdShowCopyToMethod;
		private System.Windows.Forms.CheckBox chkCopyToMethod;
		private System.Windows.Forms.Button butCreateMethods;
		private System.Windows.Forms.TabPage tabDBMethods;
		private System.Windows.Forms.CheckBox chkAllDBMethods;
		private System.Windows.Forms.Button butCancel2;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.CheckBox checkBox6;
		private System.Windows.Forms.Button butCreateDBMethods;
		private System.Windows.Forms.CheckBox chkLoadMethod;
		private System.Windows.Forms.CheckBox chkReadMethod;
		private System.Windows.Forms.Button cmdShowLoadMethod;
		private System.Windows.Forms.Button cmdShowReadMethod;
		private System.Windows.Forms.CheckBox chkExecuteSQLMethod;
		private System.Windows.Forms.Button cmdShowExecuteSQLMethod;
		private System.Windows.Forms.Button cmdCreateTestForLoad;
		private System.Windows.Forms.Button cmdCreateTestForExecuteSQL;
		private System.Windows.Forms.Button cmdCreateTestForRead;
		private System.Windows.Forms.Button cmdShowElementTypeAttrib;
		private System.Windows.Forms.Button cmdCreateElementAccessTester;
		private System.Windows.Forms.TabControl tab;
		private System.Windows.Forms.Label lbHelp;
		private System.Windows.Forms.TabPage tabBuildParamsMethods;
		private System.Windows.Forms.Button butCreateParamsMethods;
		private System.Windows.Forms.ListBox lsAllFields;
		private System.Windows.Forms.ListBox lsParams;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button butRemoveParam;
		private System.Windows.Forms.Button butAddParam;
		private System.Windows.Forms.CheckBox chkCollectionIndexer;
		private System.Windows.Forms.Button butCancel3;
		private System.Windows.Forms.CheckBox chkIndexOfMethod;
		private System.Windows.Forms.CheckBox chkFindByMethod;
		private System.Windows.Forms.Button cmdShowToArrayMethod;
		private System.Windows.Forms.CheckBox chkToArrayMethod;
		private System.Windows.Forms.CheckBox chkFromArrayMethod;
		private System.Windows.Forms.Button cmdShowFromArrayMethod;
		private System.Windows.Forms.CheckBox chkSortByMembersMethod;
		private System.Windows.Forms.Button cmdShowSortByMembersMethod;
		private System.Windows.Forms.CheckBox chkAddRangeMethod;
		private System.Windows.Forms.Button cmdShowAddRangeMethod;
		private System.Windows.Forms.CheckBox chkSortByMethod;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lbClassName;
		private System.Windows.Forms.LinkLabel lbElementType;
		private System.Windows.Forms.Label lbTable;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button cmdShowLoadFromStoredProcMethod;
		private System.Windows.Forms.CheckBox chkLoadFromStoredProcMethod;
		private System.Windows.Forms.ComboBox cbSprocName;
		private System.Windows.Forms.LinkLabel lbProcNameLabel;
		private System.Windows.Forms.CheckBox chkExecuteStoredProcMethod;
		private System.Windows.Forms.Button butRemoveParamAll;
		private System.Windows.Forms.Button butAddParamAll;
		private System.Windows.Forms.Button butAddParamsOnlyMapped;
		private System.Windows.Forms.Button cmdShowSaveMethod;
		private System.Windows.Forms.CheckBox chkSaveMethod;
		private System.Windows.Forms.Button cmdShowSynchronizeMethod;
		private System.Windows.Forms.CheckBox chkSynchronizeMethod;
		private System.Windows.Forms.TabPage tabParentObjects;
		private System.Windows.Forms.ListBox lsParentObjects;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Button cmdShowClassBuilderForParentObject;
		private System.Windows.Forms.TabPage tabCachedInstances;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListBox lsCachedMembers;
		private System.Windows.Forms.Button butCancel5;
		private System.Windows.Forms.Button butCancel4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button butCreateCachedMember;
		private System.Windows.Forms.CheckBox chkLookupMethod;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CollectionClassBuilder()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CollectionClassBuilder));
            this.label1 = new System.Windows.Forms.Label();
            this.lbHelp = new System.Windows.Forms.Label();
            this.butCancel = new System.Windows.Forms.Button();
            this.butCreateMethods = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tab = new System.Windows.Forms.TabControl();
            this.tabElementAccessMethods = new System.Windows.Forms.TabPage();
            this.cmdCreateElementAccessTester = new System.Windows.Forms.Button();
            this.chkAllMethods = new System.Windows.Forms.CheckBox();
            this.cmShowItemIndexer = new System.Windows.Forms.Button();
            this.chkItemIndexer = new System.Windows.Forms.CheckBox();
            this.chkInsertMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowInsertMethod = new System.Windows.Forms.Button();
            this.chkAddMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowAddMethod = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.chkRemoveMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowRemoveMethod = new System.Windows.Forms.Button();
            this.cmdShowContainsMethod = new System.Windows.Forms.Button();
            this.chkContainsMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowCopyToMethod = new System.Windows.Forms.Button();
            this.chkCopyToMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowSortByMembersMethod = new System.Windows.Forms.Button();
            this.chkSortByMembersMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowToArrayMethod = new System.Windows.Forms.Button();
            this.chkToArrayMethod = new System.Windows.Forms.CheckBox();
            this.chkFromArrayMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowFromArrayMethod = new System.Windows.Forms.Button();
            this.chkAddRangeMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowAddRangeMethod = new System.Windows.Forms.Button();
            this.tabBuildParamsMethods = new System.Windows.Forms.TabPage();
            this.chkLookupMethod = new System.Windows.Forms.CheckBox();
            this.butAddParamsOnlyMapped = new System.Windows.Forms.Button();
            this.butRemoveParamAll = new System.Windows.Forms.Button();
            this.butAddParamAll = new System.Windows.Forms.Button();
            this.cbSprocName = new System.Windows.Forms.ComboBox();
            this.lbProcNameLabel = new System.Windows.Forms.LinkLabel();
            this.chkExecuteStoredProcMethod = new System.Windows.Forms.CheckBox();
            this.chkIndexOfMethod = new System.Windows.Forms.CheckBox();
            this.chkCollectionIndexer = new System.Windows.Forms.CheckBox();
            this.butCreateParamsMethods = new System.Windows.Forms.Button();
            this.butCancel3 = new System.Windows.Forms.Button();
            this.lsAllFields = new System.Windows.Forms.ListBox();
            this.lsParams = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.butRemoveParam = new System.Windows.Forms.Button();
            this.butAddParam = new System.Windows.Forms.Button();
            this.chkFindByMethod = new System.Windows.Forms.CheckBox();
            this.chkSortByMethod = new System.Windows.Forms.CheckBox();
            this.tabDBMethods = new System.Windows.Forms.TabPage();
            this.cmdShowSynchronizeMethod = new System.Windows.Forms.Button();
            this.chkSynchronizeMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowSaveMethod = new System.Windows.Forms.Button();
            this.chkSaveMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowLoadFromStoredProcMethod = new System.Windows.Forms.Button();
            this.chkLoadFromStoredProcMethod = new System.Windows.Forms.CheckBox();
            this.cmdCreateTestForRead = new System.Windows.Forms.Button();
            this.cmdCreateTestForLoad = new System.Windows.Forms.Button();
            this.cmdCreateTestForExecuteSQL = new System.Windows.Forms.Button();
            this.chkAllDBMethods = new System.Windows.Forms.CheckBox();
            this.cmdShowLoadMethod = new System.Windows.Forms.Button();
            this.chkLoadMethod = new System.Windows.Forms.CheckBox();
            this.chkExecuteSQLMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowExecuteSQLMethod = new System.Windows.Forms.Button();
            this.butCreateDBMethods = new System.Windows.Forms.Button();
            this.butCancel2 = new System.Windows.Forms.Button();
            this.chkReadMethod = new System.Windows.Forms.CheckBox();
            this.cmdShowReadMethod = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.tabParentObjects = new System.Windows.Forms.TabPage();
            this.butCancel5 = new System.Windows.Forms.Button();
            this.cmdShowClassBuilderForParentObject = new System.Windows.Forms.Button();
            this.lsParentObjects = new System.Windows.Forms.ListBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tabCachedInstances = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.butCreateCachedMember = new System.Windows.Forms.Button();
            this.butCancel4 = new System.Windows.Forms.Button();
            this.lsCachedMembers = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmdShowElementTypeAttrib = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbClassName = new System.Windows.Forms.Label();
            this.lbElementType = new System.Windows.Forms.LinkLabel();
            this.lbTable = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tab.SuspendLayout();
            this.tabElementAccessMethods.SuspendLayout();
            this.tabBuildParamsMethods.SuspendLayout();
            this.tabDBMethods.SuspendLayout();
            this.tabParentObjects.SuspendLayout();
            this.tabCachedInstances.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Element Type:";
            // 
            // lbHelp
            // 
            this.lbHelp.Location = new System.Drawing.Point(160, 8);
            this.lbHelp.Name = "lbHelp";
            this.lbHelp.Size = new System.Drawing.Size(384, 56);
            this.lbHelp.TabIndex = 3;
            this.lbHelp.Text = "lbHelp";
            // 
            // butCancel
            // 
            this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel.Location = new System.Drawing.Point(352, 200);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 1;
            this.butCancel.Text = "Close";
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // butCreateMethods
            // 
            this.butCreateMethods.Enabled = false;
            this.butCreateMethods.Location = new System.Drawing.Point(432, 200);
            this.butCreateMethods.Name = "butCreateMethods";
            this.butCreateMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateMethods.TabIndex = 2;
            this.butCreateMethods.Text = "Create";
            this.butCreateMethods.Click += new System.EventHandler(this.butCreateMethods_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // tab
            // 
            this.tab.Controls.Add(this.tabElementAccessMethods);
            this.tab.Controls.Add(this.tabBuildParamsMethods);
            this.tab.Controls.Add(this.tabDBMethods);
            this.tab.Controls.Add(this.tabParentObjects);
            this.tab.Controls.Add(this.tabCachedInstances);
            this.tab.HotTrack = true;
            this.tab.Location = new System.Drawing.Point(16, 112);
            this.tab.Name = "tab";
            this.tab.SelectedIndex = 0;
            this.tab.Size = new System.Drawing.Size(528, 256);
            this.tab.TabIndex = 7;
            this.tab.SelectedIndexChanged += new System.EventHandler(this.tab_SelectedIndexChanged);
            // 
            // tabElementAccessMethods
            // 
            this.tabElementAccessMethods.Controls.Add(this.cmdCreateElementAccessTester);
            this.tabElementAccessMethods.Controls.Add(this.chkAllMethods);
            this.tabElementAccessMethods.Controls.Add(this.cmShowItemIndexer);
            this.tabElementAccessMethods.Controls.Add(this.chkItemIndexer);
            this.tabElementAccessMethods.Controls.Add(this.chkInsertMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowInsertMethod);
            this.tabElementAccessMethods.Controls.Add(this.butCreateMethods);
            this.tabElementAccessMethods.Controls.Add(this.butCancel);
            this.tabElementAccessMethods.Controls.Add(this.chkAddMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowAddMethod);
            this.tabElementAccessMethods.Controls.Add(this.button2);
            this.tabElementAccessMethods.Controls.Add(this.checkBox2);
            this.tabElementAccessMethods.Controls.Add(this.chkRemoveMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowRemoveMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowContainsMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkContainsMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowCopyToMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkCopyToMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowSortByMembersMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkSortByMembersMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowToArrayMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkToArrayMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkFromArrayMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowFromArrayMethod);
            this.tabElementAccessMethods.Controls.Add(this.chkAddRangeMethod);
            this.tabElementAccessMethods.Controls.Add(this.cmdShowAddRangeMethod);
            this.tabElementAccessMethods.Location = new System.Drawing.Point(4, 22);
            this.tabElementAccessMethods.Name = "tabElementAccessMethods";
            this.tabElementAccessMethods.Size = new System.Drawing.Size(520, 230);
            this.tabElementAccessMethods.TabIndex = 0;
            this.tabElementAccessMethods.Text = "Element Access Methods";
            this.tabElementAccessMethods.ToolTipText = "Create strongly typed element access methods.";
            // 
            // cmdCreateElementAccessTester
            // 
            this.cmdCreateElementAccessTester.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateElementAccessTester.Location = new System.Drawing.Point(200, 32);
            this.cmdCreateElementAccessTester.Name = "cmdCreateElementAccessTester";
            this.cmdCreateElementAccessTester.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateElementAccessTester.TabIndex = 0;
            this.cmdCreateElementAccessTester.Text = "Create Tester";
            this.cmdCreateElementAccessTester.Click += new System.EventHandler(this.cmdCreateElementAccessTester_Click);
            // 
            // chkAllMethods
            // 
            this.chkAllMethods.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllMethods.Location = new System.Drawing.Point(16, 8);
            this.chkAllMethods.Name = "chkAllMethods";
            this.chkAllMethods.Size = new System.Drawing.Size(96, 24);
            this.chkAllMethods.TabIndex = 19;
            this.chkAllMethods.Text = "All Methods";
            this.chkAllMethods.CheckedChanged += new System.EventHandler(this.chkAllMethods_CheckedChanged);
            // 
            // cmShowItemIndexer
            // 
            this.cmShowItemIndexer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmShowItemIndexer.Location = new System.Drawing.Point(16, 32);
            this.cmShowItemIndexer.Name = "cmShowItemIndexer";
            this.cmShowItemIndexer.Size = new System.Drawing.Size(42, 23);
            this.cmShowItemIndexer.TabIndex = 6;
            this.cmShowItemIndexer.Text = "Show";
            this.cmShowItemIndexer.Visible = false;
            this.cmShowItemIndexer.Click += new System.EventHandler(this.cmShowItemIndexer_Click);
            // 
            // chkItemIndexer
            // 
            this.chkItemIndexer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkItemIndexer.Location = new System.Drawing.Point(64, 32);
            this.chkItemIndexer.Name = "chkItemIndexer";
            this.chkItemIndexer.Size = new System.Drawing.Size(160, 24);
            this.chkItemIndexer.TabIndex = 7;
            this.chkItemIndexer.Text = "Item Indexer";
            this.chkItemIndexer.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // chkInsertMethod
            // 
            this.chkInsertMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkInsertMethod.Location = new System.Drawing.Point(64, 56);
            this.chkInsertMethod.Name = "chkInsertMethod";
            this.chkInsertMethod.Size = new System.Drawing.Size(160, 24);
            this.chkInsertMethod.TabIndex = 9;
            this.chkInsertMethod.Text = "Insert Method";
            this.chkInsertMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowInsertMethod
            // 
            this.cmdShowInsertMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowInsertMethod.Location = new System.Drawing.Point(16, 56);
            this.cmdShowInsertMethod.Name = "cmdShowInsertMethod";
            this.cmdShowInsertMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowInsertMethod.TabIndex = 8;
            this.cmdShowInsertMethod.Text = "Show";
            this.cmdShowInsertMethod.Visible = false;
            this.cmdShowInsertMethod.Click += new System.EventHandler(this.cmdShowInsertMethod_Click);
            // 
            // chkAddMethod
            // 
            this.chkAddMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAddMethod.Location = new System.Drawing.Point(64, 80);
            this.chkAddMethod.Name = "chkAddMethod";
            this.chkAddMethod.Size = new System.Drawing.Size(160, 24);
            this.chkAddMethod.TabIndex = 11;
            this.chkAddMethod.Text = "Add Method";
            this.chkAddMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowAddMethod
            // 
            this.cmdShowAddMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowAddMethod.Location = new System.Drawing.Point(16, 80);
            this.cmdShowAddMethod.Name = "cmdShowAddMethod";
            this.cmdShowAddMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowAddMethod.TabIndex = 10;
            this.cmdShowAddMethod.Text = "Show";
            this.cmdShowAddMethod.Visible = false;
            this.cmdShowAddMethod.Click += new System.EventHandler(this.cmdShowAddMethod_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Location = new System.Drawing.Point(16, 32);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(40, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Show";
            this.button2.Visible = false;
            // 
            // checkBox2
            // 
            this.checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.checkBox2.Location = new System.Drawing.Point(64, 32);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(160, 24);
            this.checkBox2.TabIndex = 15;
            this.checkBox2.Text = "Insert Method";
            // 
            // chkRemoveMethod
            // 
            this.chkRemoveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkRemoveMethod.Location = new System.Drawing.Point(64, 104);
            this.chkRemoveMethod.Name = "chkRemoveMethod";
            this.chkRemoveMethod.Size = new System.Drawing.Size(160, 24);
            this.chkRemoveMethod.TabIndex = 13;
            this.chkRemoveMethod.Text = "Remove Method";
            this.chkRemoveMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowRemoveMethod
            // 
            this.cmdShowRemoveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowRemoveMethod.Location = new System.Drawing.Point(16, 104);
            this.cmdShowRemoveMethod.Name = "cmdShowRemoveMethod";
            this.cmdShowRemoveMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowRemoveMethod.TabIndex = 12;
            this.cmdShowRemoveMethod.Text = "Show";
            this.cmdShowRemoveMethod.Visible = false;
            this.cmdShowRemoveMethod.Click += new System.EventHandler(this.cmdShowRemoveMethod_Click);
            // 
            // cmdShowContainsMethod
            // 
            this.cmdShowContainsMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowContainsMethod.Location = new System.Drawing.Point(16, 128);
            this.cmdShowContainsMethod.Name = "cmdShowContainsMethod";
            this.cmdShowContainsMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowContainsMethod.TabIndex = 14;
            this.cmdShowContainsMethod.Text = "Show";
            this.cmdShowContainsMethod.Visible = false;
            this.cmdShowContainsMethod.Click += new System.EventHandler(this.cmdShowContainsMethod_Click);
            // 
            // chkContainsMethod
            // 
            this.chkContainsMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkContainsMethod.Location = new System.Drawing.Point(64, 128);
            this.chkContainsMethod.Name = "chkContainsMethod";
            this.chkContainsMethod.Size = new System.Drawing.Size(160, 24);
            this.chkContainsMethod.TabIndex = 15;
            this.chkContainsMethod.Text = "Contains Method";
            this.chkContainsMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowCopyToMethod
            // 
            this.cmdShowCopyToMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowCopyToMethod.Location = new System.Drawing.Point(296, 32);
            this.cmdShowCopyToMethod.Name = "cmdShowCopyToMethod";
            this.cmdShowCopyToMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowCopyToMethod.TabIndex = 18;
            this.cmdShowCopyToMethod.Text = "Show";
            this.cmdShowCopyToMethod.Visible = false;
            this.cmdShowCopyToMethod.Click += new System.EventHandler(this.cmdShowCopyToMethod_Click);
            // 
            // chkCopyToMethod
            // 
            this.chkCopyToMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkCopyToMethod.Location = new System.Drawing.Point(344, 32);
            this.chkCopyToMethod.Name = "chkCopyToMethod";
            this.chkCopyToMethod.Size = new System.Drawing.Size(160, 24);
            this.chkCopyToMethod.TabIndex = 19;
            this.chkCopyToMethod.Text = "CopyTo Method";
            this.chkCopyToMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowSortByMembersMethod
            // 
            this.cmdShowSortByMembersMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSortByMembersMethod.Location = new System.Drawing.Point(16, 152);
            this.cmdShowSortByMembersMethod.Name = "cmdShowSortByMembersMethod";
            this.cmdShowSortByMembersMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSortByMembersMethod.TabIndex = 16;
            this.cmdShowSortByMembersMethod.Text = "Show";
            this.cmdShowSortByMembersMethod.Visible = false;
            this.cmdShowSortByMembersMethod.Click += new System.EventHandler(this.cmdShowSortByMembersMethod_Click);
            // 
            // chkSortByMembersMethod
            // 
            this.chkSortByMembersMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSortByMembersMethod.Location = new System.Drawing.Point(64, 152);
            this.chkSortByMembersMethod.Name = "chkSortByMembersMethod";
            this.chkSortByMembersMethod.Size = new System.Drawing.Size(160, 24);
            this.chkSortByMembersMethod.TabIndex = 17;
            this.chkSortByMembersMethod.Text = "SortByMember Method";
            this.chkSortByMembersMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowToArrayMethod
            // 
            this.cmdShowToArrayMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowToArrayMethod.Location = new System.Drawing.Point(296, 56);
            this.cmdShowToArrayMethod.Name = "cmdShowToArrayMethod";
            this.cmdShowToArrayMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowToArrayMethod.TabIndex = 20;
            this.cmdShowToArrayMethod.Text = "Show";
            this.cmdShowToArrayMethod.Visible = false;
            this.cmdShowToArrayMethod.Click += new System.EventHandler(this.cmdShowToArrayMethod_Click);
            // 
            // chkToArrayMethod
            // 
            this.chkToArrayMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkToArrayMethod.Location = new System.Drawing.Point(344, 56);
            this.chkToArrayMethod.Name = "chkToArrayMethod";
            this.chkToArrayMethod.Size = new System.Drawing.Size(160, 24);
            this.chkToArrayMethod.TabIndex = 21;
            this.chkToArrayMethod.Text = "ToArray Method";
            this.chkToArrayMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // chkFromArrayMethod
            // 
            this.chkFromArrayMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkFromArrayMethod.Location = new System.Drawing.Point(344, 80);
            this.chkFromArrayMethod.Name = "chkFromArrayMethod";
            this.chkFromArrayMethod.Size = new System.Drawing.Size(160, 24);
            this.chkFromArrayMethod.TabIndex = 23;
            this.chkFromArrayMethod.Text = "FromArray Method";
            this.chkFromArrayMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowFromArrayMethod
            // 
            this.cmdShowFromArrayMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowFromArrayMethod.Location = new System.Drawing.Point(296, 80);
            this.cmdShowFromArrayMethod.Name = "cmdShowFromArrayMethod";
            this.cmdShowFromArrayMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowFromArrayMethod.TabIndex = 22;
            this.cmdShowFromArrayMethod.Text = "Show";
            this.cmdShowFromArrayMethod.Visible = false;
            this.cmdShowFromArrayMethod.Click += new System.EventHandler(this.cmdShowFromArrayMethod_Click);
            // 
            // chkAddRangeMethod
            // 
            this.chkAddRangeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAddRangeMethod.Location = new System.Drawing.Point(344, 104);
            this.chkAddRangeMethod.Name = "chkAddRangeMethod";
            this.chkAddRangeMethod.Size = new System.Drawing.Size(160, 24);
            this.chkAddRangeMethod.TabIndex = 25;
            this.chkAddRangeMethod.Text = "AddRange Method";
            this.chkAddRangeMethod.Click += new System.EventHandler(this.chkCopyToMethod_Click);
            // 
            // cmdShowAddRangeMethod
            // 
            this.cmdShowAddRangeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowAddRangeMethod.Location = new System.Drawing.Point(296, 104);
            this.cmdShowAddRangeMethod.Name = "cmdShowAddRangeMethod";
            this.cmdShowAddRangeMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowAddRangeMethod.TabIndex = 24;
            this.cmdShowAddRangeMethod.Text = "Show";
            this.cmdShowAddRangeMethod.Visible = false;
            this.cmdShowAddRangeMethod.Click += new System.EventHandler(this.cmdShowAddRangeMethod_Click);
            // 
            // tabBuildParamsMethods
            // 
            this.tabBuildParamsMethods.Controls.Add(this.chkLookupMethod);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParamsOnlyMapped);
            this.tabBuildParamsMethods.Controls.Add(this.butRemoveParamAll);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParamAll);
            this.tabBuildParamsMethods.Controls.Add(this.cbSprocName);
            this.tabBuildParamsMethods.Controls.Add(this.lbProcNameLabel);
            this.tabBuildParamsMethods.Controls.Add(this.chkExecuteStoredProcMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkIndexOfMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkCollectionIndexer);
            this.tabBuildParamsMethods.Controls.Add(this.butCreateParamsMethods);
            this.tabBuildParamsMethods.Controls.Add(this.butCancel3);
            this.tabBuildParamsMethods.Controls.Add(this.lsAllFields);
            this.tabBuildParamsMethods.Controls.Add(this.lsParams);
            this.tabBuildParamsMethods.Controls.Add(this.label7);
            this.tabBuildParamsMethods.Controls.Add(this.label6);
            this.tabBuildParamsMethods.Controls.Add(this.butRemoveParam);
            this.tabBuildParamsMethods.Controls.Add(this.butAddParam);
            this.tabBuildParamsMethods.Controls.Add(this.chkFindByMethod);
            this.tabBuildParamsMethods.Controls.Add(this.chkSortByMethod);
            this.tabBuildParamsMethods.Location = new System.Drawing.Point(4, 22);
            this.tabBuildParamsMethods.Name = "tabBuildParamsMethods";
            this.tabBuildParamsMethods.Size = new System.Drawing.Size(520, 230);
            this.tabBuildParamsMethods.TabIndex = 2;
            this.tabBuildParamsMethods.Text = "Parameterized Methods";
            this.tabBuildParamsMethods.ToolTipText = "Builds various methods with the given parameters.";
            // 
            // chkLookupMethod
            // 
            this.chkLookupMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLookupMethod.Location = new System.Drawing.Point(16, 200);
            this.chkLookupMethod.Name = "chkLookupMethod";
            this.chkLookupMethod.Size = new System.Drawing.Size(152, 16);
            this.chkLookupMethod.TabIndex = 37;
            this.chkLookupMethod.Text = "Lookup Method";
            this.chkLookupMethod.CheckedChanged += new System.EventHandler(this.chkLookupMethod_CheckedChanged);
            // 
            // butAddParamsOnlyMapped
            // 
            this.butAddParamsOnlyMapped.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParamsOnlyMapped.Location = new System.Drawing.Point(224, 120);
            this.butAddParamsOnlyMapped.Name = "butAddParamsOnlyMapped";
            this.butAddParamsOnlyMapped.Size = new System.Drawing.Size(72, 24);
            this.butAddParamsOnlyMapped.TabIndex = 36;
            this.butAddParamsOnlyMapped.Text = "Mapped >>";
            this.butAddParamsOnlyMapped.Click += new System.EventHandler(this.butAddParamsOnlyMapped_Click);
            // 
            // butRemoveParamAll
            // 
            this.butRemoveParamAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveParamAll.Location = new System.Drawing.Point(240, 96);
            this.butRemoveParamAll.Name = "butRemoveParamAll";
            this.butRemoveParamAll.Size = new System.Drawing.Size(40, 24);
            this.butRemoveParamAll.TabIndex = 35;
            this.butRemoveParamAll.Text = "<<";
            this.butRemoveParamAll.Click += new System.EventHandler(this.butRemoveParamAll_Click);
            // 
            // butAddParamAll
            // 
            this.butAddParamAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParamAll.Location = new System.Drawing.Point(240, 72);
            this.butAddParamAll.Name = "butAddParamAll";
            this.butAddParamAll.Size = new System.Drawing.Size(40, 24);
            this.butAddParamAll.TabIndex = 34;
            this.butAddParamAll.Text = ">>";
            this.butAddParamAll.Click += new System.EventHandler(this.butAddParamAll_Click);
            // 
            // cbSprocName
            // 
            this.cbSprocName.Location = new System.Drawing.Point(352, 168);
            this.cbSprocName.Name = "cbSprocName";
            this.cbSprocName.Size = new System.Drawing.Size(152, 21);
            this.cbSprocName.TabIndex = 32;
            this.cbSprocName.SelectedIndexChanged += new System.EventHandler(this.cbSprocName_SelectedIndexChanged);
            this.cbSprocName.TextChanged += new System.EventHandler(this.cbSprocName_TextChanged);
            // 
            // lbProcNameLabel
            // 
            this.lbProcNameLabel.Location = new System.Drawing.Point(296, 168);
            this.lbProcNameLabel.Name = "lbProcNameLabel";
            this.lbProcNameLabel.Size = new System.Drawing.Size(56, 18);
            this.lbProcNameLabel.TabIndex = 33;
            this.lbProcNameLabel.TabStop = true;
            this.lbProcNameLabel.Text = "Procedure:";
            this.lbProcNameLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbProcNameLabel_LinkClicked);
            // 
            // chkExecuteStoredProcMethod
            // 
            this.chkExecuteStoredProcMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExecuteStoredProcMethod.Location = new System.Drawing.Point(296, 152);
            this.chkExecuteStoredProcMethod.Name = "chkExecuteStoredProcMethod";
            this.chkExecuteStoredProcMethod.Size = new System.Drawing.Size(168, 16);
            this.chkExecuteStoredProcMethod.TabIndex = 31;
            this.chkExecuteStoredProcMethod.Text = "ExecuteStoredProc Method";
            this.chkExecuteStoredProcMethod.Visible = false;
            this.chkExecuteStoredProcMethod.Click += new System.EventHandler(this.chkExecuteStoredProcMethod_Click);
            // 
            // chkIndexOfMethod
            // 
            this.chkIndexOfMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkIndexOfMethod.Location = new System.Drawing.Point(16, 168);
            this.chkIndexOfMethod.Name = "chkIndexOfMethod";
            this.chkIndexOfMethod.Size = new System.Drawing.Size(152, 16);
            this.chkIndexOfMethod.TabIndex = 28;
            this.chkIndexOfMethod.Text = "IndexOf Method";
            this.chkIndexOfMethod.Click += new System.EventHandler(this.chkIndexOfMethod_Click);
            // 
            // chkCollectionIndexer
            // 
            this.chkCollectionIndexer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkCollectionIndexer.Location = new System.Drawing.Point(16, 152);
            this.chkCollectionIndexer.Name = "chkCollectionIndexer";
            this.chkCollectionIndexer.Size = new System.Drawing.Size(152, 16);
            this.chkCollectionIndexer.TabIndex = 28;
            this.chkCollectionIndexer.Text = "Collection Indexer";
            this.chkCollectionIndexer.Click += new System.EventHandler(this.chkCollectionIndexer_Click);
            // 
            // butCreateParamsMethods
            // 
            this.butCreateParamsMethods.Location = new System.Drawing.Point(432, 200);
            this.butCreateParamsMethods.Name = "butCreateParamsMethods";
            this.butCreateParamsMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateParamsMethods.TabIndex = 27;
            this.butCreateParamsMethods.Text = "Create";
            this.butCreateParamsMethods.Click += new System.EventHandler(this.butCreateParamsMethods_Click);
            // 
            // butCancel3
            // 
            this.butCancel3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel3.Location = new System.Drawing.Point(352, 200);
            this.butCancel3.Name = "butCancel3";
            this.butCancel3.Size = new System.Drawing.Size(75, 23);
            this.butCancel3.TabIndex = 26;
            this.butCancel3.Text = "Close";
            this.butCancel3.Click += new System.EventHandler(this.butCancel3_Click);
            // 
            // lsAllFields
            // 
            this.lsAllFields.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsAllFields.Location = new System.Drawing.Point(16, 24);
            this.lsAllFields.Name = "lsAllFields";
            this.lsAllFields.Size = new System.Drawing.Size(208, 119);
            this.lsAllFields.TabIndex = 20;
            this.lsAllFields.DoubleClick += new System.EventHandler(this.lsAllFields_DoubleClick);
            this.lsAllFields.SelectedIndexChanged += new System.EventHandler(this.lsAllFields_SelectedIndexChanged);
            // 
            // lsParams
            // 
            this.lsParams.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsParams.Location = new System.Drawing.Point(296, 24);
            this.lsParams.Name = "lsParams";
            this.lsParams.Size = new System.Drawing.Size(208, 119);
            this.lsParams.TabIndex = 21;
            this.lsParams.DoubleClick += new System.EventHandler(this.lsParams_DoubleClick);
            this.lsParams.SelectedIndexChanged += new System.EventHandler(this.lsParams_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(296, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 25;
            this.label7.Text = "Parameters:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 24;
            this.label6.Text = "Members:";
            // 
            // butRemoveParam
            // 
            this.butRemoveParam.Enabled = false;
            this.butRemoveParam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRemoveParam.Location = new System.Drawing.Point(240, 48);
            this.butRemoveParam.Name = "butRemoveParam";
            this.butRemoveParam.Size = new System.Drawing.Size(40, 24);
            this.butRemoveParam.TabIndex = 23;
            this.butRemoveParam.Text = "<";
            this.butRemoveParam.Click += new System.EventHandler(this.butRemoveParam_Click);
            // 
            // butAddParam
            // 
            this.butAddParam.Enabled = false;
            this.butAddParam.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butAddParam.Location = new System.Drawing.Point(240, 24);
            this.butAddParam.Name = "butAddParam";
            this.butAddParam.Size = new System.Drawing.Size(40, 24);
            this.butAddParam.TabIndex = 22;
            this.butAddParam.Text = ">";
            this.butAddParam.Click += new System.EventHandler(this.butAddParam_Click);
            // 
            // chkFindByMethod
            // 
            this.chkFindByMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkFindByMethod.Location = new System.Drawing.Point(16, 184);
            this.chkFindByMethod.Name = "chkFindByMethod";
            this.chkFindByMethod.Size = new System.Drawing.Size(152, 16);
            this.chkFindByMethod.TabIndex = 28;
            this.chkFindByMethod.Text = "FindBy Method";
            this.chkFindByMethod.Click += new System.EventHandler(this.chkFindByMethod_Click);
            // 
            // chkSortByMethod
            // 
            this.chkSortByMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSortByMethod.Location = new System.Drawing.Point(168, 152);
            this.chkSortByMethod.Name = "chkSortByMethod";
            this.chkSortByMethod.Size = new System.Drawing.Size(120, 16);
            this.chkSortByMethod.TabIndex = 28;
            this.chkSortByMethod.Text = "SortBy Method";
            this.chkSortByMethod.Click += new System.EventHandler(this.chkFindByMethod_Click);
            // 
            // tabDBMethods
            // 
            this.tabDBMethods.Controls.Add(this.cmdShowSynchronizeMethod);
            this.tabDBMethods.Controls.Add(this.chkSynchronizeMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowSaveMethod);
            this.tabDBMethods.Controls.Add(this.chkSaveMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowLoadFromStoredProcMethod);
            this.tabDBMethods.Controls.Add(this.chkLoadFromStoredProcMethod);
            this.tabDBMethods.Controls.Add(this.cmdCreateTestForRead);
            this.tabDBMethods.Controls.Add(this.cmdCreateTestForLoad);
            this.tabDBMethods.Controls.Add(this.cmdCreateTestForExecuteSQL);
            this.tabDBMethods.Controls.Add(this.chkAllDBMethods);
            this.tabDBMethods.Controls.Add(this.cmdShowLoadMethod);
            this.tabDBMethods.Controls.Add(this.chkLoadMethod);
            this.tabDBMethods.Controls.Add(this.chkExecuteSQLMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowExecuteSQLMethod);
            this.tabDBMethods.Controls.Add(this.butCreateDBMethods);
            this.tabDBMethods.Controls.Add(this.butCancel2);
            this.tabDBMethods.Controls.Add(this.chkReadMethod);
            this.tabDBMethods.Controls.Add(this.cmdShowReadMethod);
            this.tabDBMethods.Controls.Add(this.button9);
            this.tabDBMethods.Controls.Add(this.checkBox6);
            this.tabDBMethods.Location = new System.Drawing.Point(4, 22);
            this.tabDBMethods.Name = "tabDBMethods";
            this.tabDBMethods.Size = new System.Drawing.Size(520, 230);
            this.tabDBMethods.TabIndex = 1;
            this.tabDBMethods.Text = "DB Methods";
            this.tabDBMethods.ToolTipText = "Create database methods.   These methods fill the collection from database but do" +
                " not save the changes back.  Changes must be updated to the database on element " +
                "basis.";
            // 
            // cmdShowSynchronizeMethod
            // 
            this.cmdShowSynchronizeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSynchronizeMethod.Location = new System.Drawing.Point(16, 152);
            this.cmdShowSynchronizeMethod.Name = "cmdShowSynchronizeMethod";
            this.cmdShowSynchronizeMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSynchronizeMethod.TabIndex = 46;
            this.cmdShowSynchronizeMethod.Text = "Show";
            this.cmdShowSynchronizeMethod.Visible = false;
            this.cmdShowSynchronizeMethod.Click += new System.EventHandler(this.cmdShowSynchronizeMethod_Click);
            // 
            // chkSynchronizeMethod
            // 
            this.chkSynchronizeMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSynchronizeMethod.Location = new System.Drawing.Point(64, 152);
            this.chkSynchronizeMethod.Name = "chkSynchronizeMethod";
            this.chkSynchronizeMethod.Size = new System.Drawing.Size(136, 24);
            this.chkSynchronizeMethod.TabIndex = 45;
            this.chkSynchronizeMethod.Text = "Synchronize Method";
            this.chkSynchronizeMethod.Click += new System.EventHandler(this.chkSynchronizeMethod_Click);
            // 
            // cmdShowSaveMethod
            // 
            this.cmdShowSaveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowSaveMethod.Location = new System.Drawing.Point(16, 128);
            this.cmdShowSaveMethod.Name = "cmdShowSaveMethod";
            this.cmdShowSaveMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowSaveMethod.TabIndex = 44;
            this.cmdShowSaveMethod.Text = "Show";
            this.cmdShowSaveMethod.Visible = false;
            this.cmdShowSaveMethod.Click += new System.EventHandler(this.cmdShowSaveMethod_Click);
            // 
            // chkSaveMethod
            // 
            this.chkSaveMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkSaveMethod.Location = new System.Drawing.Point(64, 128);
            this.chkSaveMethod.Name = "chkSaveMethod";
            this.chkSaveMethod.Size = new System.Drawing.Size(104, 24);
            this.chkSaveMethod.TabIndex = 43;
            this.chkSaveMethod.Text = "Save Method";
            this.chkSaveMethod.Click += new System.EventHandler(this.chkSaveMethod_Click);
            // 
            // cmdShowLoadFromStoredProcMethod
            // 
            this.cmdShowLoadFromStoredProcMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowLoadFromStoredProcMethod.Location = new System.Drawing.Point(16, 56);
            this.cmdShowLoadFromStoredProcMethod.Name = "cmdShowLoadFromStoredProcMethod";
            this.cmdShowLoadFromStoredProcMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowLoadFromStoredProcMethod.TabIndex = 42;
            this.cmdShowLoadFromStoredProcMethod.Text = "Show";
            this.cmdShowLoadFromStoredProcMethod.Visible = false;
            this.cmdShowLoadFromStoredProcMethod.Click += new System.EventHandler(this.cmdShowLoadFromStoredProcMethod_Click);
            // 
            // chkLoadFromStoredProcMethod
            // 
            this.chkLoadFromStoredProcMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLoadFromStoredProcMethod.Location = new System.Drawing.Point(64, 56);
            this.chkLoadFromStoredProcMethod.Name = "chkLoadFromStoredProcMethod";
            this.chkLoadFromStoredProcMethod.Size = new System.Drawing.Size(184, 24);
            this.chkLoadFromStoredProcMethod.TabIndex = 41;
            this.chkLoadFromStoredProcMethod.Text = "Load from Stored Procedure";
            this.chkLoadFromStoredProcMethod.Click += new System.EventHandler(this.chkReadMethod_Click);
            // 
            // cmdCreateTestForRead
            // 
            this.cmdCreateTestForRead.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTestForRead.Location = new System.Drawing.Point(200, 104);
            this.cmdCreateTestForRead.Name = "cmdCreateTestForRead";
            this.cmdCreateTestForRead.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTestForRead.TabIndex = 40;
            this.cmdCreateTestForRead.Text = "Create Tester";
            this.cmdCreateTestForRead.Click += new System.EventHandler(this.cmdCreateTestForRead_Click);
            // 
            // cmdCreateTestForLoad
            // 
            this.cmdCreateTestForLoad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTestForLoad.Location = new System.Drawing.Point(200, 32);
            this.cmdCreateTestForLoad.Name = "cmdCreateTestForLoad";
            this.cmdCreateTestForLoad.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTestForLoad.TabIndex = 39;
            this.cmdCreateTestForLoad.Text = "Create Tester";
            this.cmdCreateTestForLoad.Click += new System.EventHandler(this.cmdCreateTestForLoad_Click);
            // 
            // cmdCreateTestForExecuteSQL
            // 
            this.cmdCreateTestForExecuteSQL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdCreateTestForExecuteSQL.Location = new System.Drawing.Point(200, 80);
            this.cmdCreateTestForExecuteSQL.Name = "cmdCreateTestForExecuteSQL";
            this.cmdCreateTestForExecuteSQL.Size = new System.Drawing.Size(88, 23);
            this.cmdCreateTestForExecuteSQL.TabIndex = 40;
            this.cmdCreateTestForExecuteSQL.Text = "Create Tester";
            this.cmdCreateTestForExecuteSQL.Click += new System.EventHandler(this.cmdCreateTestForExecuteSQL_Click);
            // 
            // chkAllDBMethods
            // 
            this.chkAllDBMethods.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkAllDBMethods.Location = new System.Drawing.Point(16, 8);
            this.chkAllDBMethods.Name = "chkAllDBMethods";
            this.chkAllDBMethods.Size = new System.Drawing.Size(96, 24);
            this.chkAllDBMethods.TabIndex = 38;
            this.chkAllDBMethods.Text = "All Methods";
            this.chkAllDBMethods.CheckedChanged += new System.EventHandler(this.chkAllDBMethods_CheckedChanged);
            // 
            // cmdShowLoadMethod
            // 
            this.cmdShowLoadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowLoadMethod.Location = new System.Drawing.Point(16, 32);
            this.cmdShowLoadMethod.Name = "cmdShowLoadMethod";
            this.cmdShowLoadMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowLoadMethod.TabIndex = 32;
            this.cmdShowLoadMethod.Text = "Show";
            this.cmdShowLoadMethod.Visible = false;
            this.cmdShowLoadMethod.Click += new System.EventHandler(this.cmdShowLoadMethod_Click);
            // 
            // chkLoadMethod
            // 
            this.chkLoadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkLoadMethod.Location = new System.Drawing.Point(64, 32);
            this.chkLoadMethod.Name = "chkLoadMethod";
            this.chkLoadMethod.Size = new System.Drawing.Size(160, 24);
            this.chkLoadMethod.TabIndex = 24;
            this.chkLoadMethod.Text = "Load with filter Method";
            this.chkLoadMethod.Click += new System.EventHandler(this.chkReadMethod_Click);
            // 
            // chkExecuteSQLMethod
            // 
            this.chkExecuteSQLMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkExecuteSQLMethod.Location = new System.Drawing.Point(64, 80);
            this.chkExecuteSQLMethod.Name = "chkExecuteSQLMethod";
            this.chkExecuteSQLMethod.Size = new System.Drawing.Size(160, 24);
            this.chkExecuteSQLMethod.TabIndex = 30;
            this.chkExecuteSQLMethod.Text = "ExecuteSQL Method";
            this.chkExecuteSQLMethod.Click += new System.EventHandler(this.chkReadMethod_Click);
            // 
            // cmdShowExecuteSQLMethod
            // 
            this.cmdShowExecuteSQLMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowExecuteSQLMethod.Location = new System.Drawing.Point(16, 80);
            this.cmdShowExecuteSQLMethod.Name = "cmdShowExecuteSQLMethod";
            this.cmdShowExecuteSQLMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowExecuteSQLMethod.TabIndex = 37;
            this.cmdShowExecuteSQLMethod.Text = "Show";
            this.cmdShowExecuteSQLMethod.Visible = false;
            this.cmdShowExecuteSQLMethod.Click += new System.EventHandler(this.cmdShowExecuteSQLMethod_Click);
            // 
            // butCreateDBMethods
            // 
            this.butCreateDBMethods.Enabled = false;
            this.butCreateDBMethods.Location = new System.Drawing.Point(432, 200);
            this.butCreateDBMethods.Name = "butCreateDBMethods";
            this.butCreateDBMethods.Size = new System.Drawing.Size(75, 23);
            this.butCreateDBMethods.TabIndex = 23;
            this.butCreateDBMethods.Text = "Create";
            this.butCreateDBMethods.Click += new System.EventHandler(this.butCreateDBMethods_Click);
            // 
            // butCancel2
            // 
            this.butCancel2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel2.Location = new System.Drawing.Point(352, 200);
            this.butCancel2.Name = "butCancel2";
            this.butCancel2.Size = new System.Drawing.Size(75, 23);
            this.butCancel2.TabIndex = 22;
            this.butCancel2.Text = "Close";
            this.butCancel2.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // chkReadMethod
            // 
            this.chkReadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.chkReadMethod.Location = new System.Drawing.Point(64, 104);
            this.chkReadMethod.Name = "chkReadMethod";
            this.chkReadMethod.Size = new System.Drawing.Size(160, 24);
            this.chkReadMethod.TabIndex = 29;
            this.chkReadMethod.Text = "Read Method";
            this.chkReadMethod.Click += new System.EventHandler(this.chkReadMethod_Click);
            // 
            // cmdShowReadMethod
            // 
            this.cmdShowReadMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowReadMethod.Location = new System.Drawing.Point(16, 104);
            this.cmdShowReadMethod.Name = "cmdShowReadMethod";
            this.cmdShowReadMethod.Size = new System.Drawing.Size(42, 23);
            this.cmdShowReadMethod.TabIndex = 36;
            this.cmdShowReadMethod.Text = "Show";
            this.cmdShowReadMethod.Visible = false;
            this.cmdShowReadMethod.Click += new System.EventHandler(this.cmdShowReadMethod_Click);
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Location = new System.Drawing.Point(16, 32);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 23);
            this.button9.TabIndex = 31;
            this.button9.Text = "Show";
            this.button9.Visible = false;
            // 
            // checkBox6
            // 
            this.checkBox6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.checkBox6.Location = new System.Drawing.Point(64, 32);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(160, 24);
            this.checkBox6.TabIndex = 25;
            this.checkBox6.Text = "Insert Method";
            // 
            // tabParentObjects
            // 
            this.tabParentObjects.Controls.Add(this.butCancel5);
            this.tabParentObjects.Controls.Add(this.cmdShowClassBuilderForParentObject);
            this.tabParentObjects.Controls.Add(this.lsParentObjects);
            this.tabParentObjects.Controls.Add(this.label24);
            this.tabParentObjects.Location = new System.Drawing.Point(4, 22);
            this.tabParentObjects.Name = "tabParentObjects";
            this.tabParentObjects.Size = new System.Drawing.Size(520, 230);
            this.tabParentObjects.TabIndex = 3;
            this.tabParentObjects.Text = "Parent Objects";
            this.tabParentObjects.ToolTipText = "Parent objects that can contain this collection.";
            // 
            // butCancel5
            // 
            this.butCancel5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel5.Location = new System.Drawing.Point(432, 200);
            this.butCancel5.Name = "butCancel5";
            this.butCancel5.Size = new System.Drawing.Size(75, 23);
            this.butCancel5.TabIndex = 41;
            this.butCancel5.Text = "Close";
            this.butCancel5.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // cmdShowClassBuilderForParentObject
            // 
            this.cmdShowClassBuilderForParentObject.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowClassBuilderForParentObject.Location = new System.Drawing.Point(264, 24);
            this.cmdShowClassBuilderForParentObject.Name = "cmdShowClassBuilderForParentObject";
            this.cmdShowClassBuilderForParentObject.Size = new System.Drawing.Size(248, 23);
            this.cmdShowClassBuilderForParentObject.TabIndex = 40;
            this.cmdShowClassBuilderForParentObject.Text = "Show Class Builder for parent object";
            this.cmdShowClassBuilderForParentObject.Click += new System.EventHandler(this.cmdShowClassBuilderForParentObject_Click);
            // 
            // lsParentObjects
            // 
            this.lsParentObjects.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsParentObjects.Location = new System.Drawing.Point(16, 24);
            this.lsParentObjects.Name = "lsParentObjects";
            this.lsParentObjects.Size = new System.Drawing.Size(240, 145);
            this.lsParentObjects.TabIndex = 38;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(16, 8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(248, 23);
            this.label24.TabIndex = 39;
            this.label24.Text = "Parent objects of this class:";
            // 
            // tabCachedInstances
            // 
            this.tabCachedInstances.Controls.Add(this.label5);
            this.tabCachedInstances.Controls.Add(this.butCreateCachedMember);
            this.tabCachedInstances.Controls.Add(this.butCancel4);
            this.tabCachedInstances.Controls.Add(this.lsCachedMembers);
            this.tabCachedInstances.Controls.Add(this.label4);
            this.tabCachedInstances.Location = new System.Drawing.Point(4, 22);
            this.tabCachedInstances.Name = "tabCachedInstances";
            this.tabCachedInstances.Size = new System.Drawing.Size(520, 230);
            this.tabCachedInstances.TabIndex = 4;
            this.tabCachedInstances.Text = "Cached Instances";
            this.tabCachedInstances.ToolTipText = "Cached instances of this collection that are accessible on the static members.";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(344, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 56);
            this.label5.TabIndex = 30;
            this.label5.Text = "To create a static member returning a shared instance of the collection which is " +
                "cached in NSGlobal, click Create.";
            // 
            // butCreateCachedMember
            // 
            this.butCreateCachedMember.Location = new System.Drawing.Point(432, 200);
            this.butCreateCachedMember.Name = "butCreateCachedMember";
            this.butCreateCachedMember.Size = new System.Drawing.Size(75, 23);
            this.butCreateCachedMember.TabIndex = 29;
            this.butCreateCachedMember.Text = "Create";
            this.butCreateCachedMember.Click += new System.EventHandler(this.butCreateCachedMember_Click);
            // 
            // butCancel4
            // 
            this.butCancel4.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel4.Location = new System.Drawing.Point(352, 200);
            this.butCancel4.Name = "butCancel4";
            this.butCancel4.Size = new System.Drawing.Size(75, 23);
            this.butCancel4.TabIndex = 28;
            this.butCancel4.Text = "Close";
            this.butCancel4.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // lsCachedMembers
            // 
            this.lsCachedMembers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsCachedMembers.Location = new System.Drawing.Point(16, 24);
            this.lsCachedMembers.Name = "lsCachedMembers";
            this.lsCachedMembers.Size = new System.Drawing.Size(208, 119);
            this.lsCachedMembers.TabIndex = 25;
            this.lsCachedMembers.SelectedIndexChanged += new System.EventHandler(this.lsCachedMembers_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 23);
            this.label4.TabIndex = 26;
            this.label4.Text = "Static members returning cached instances:";
            // 
            // cmdShowElementTypeAttrib
            // 
            this.cmdShowElementTypeAttrib.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmdShowElementTypeAttrib.Location = new System.Drawing.Point(504, 80);
            this.cmdShowElementTypeAttrib.Name = "cmdShowElementTypeAttrib";
            this.cmdShowElementTypeAttrib.Size = new System.Drawing.Size(40, 18);
            this.cmdShowElementTypeAttrib.TabIndex = 1;
            this.cmdShowElementTypeAttrib.Text = "Show";
            this.cmdShowElementTypeAttrib.Visible = false;
            this.cmdShowElementTypeAttrib.Click += new System.EventHandler(this.cmdShowElementTypeAttrib_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 18;
            this.label3.Text = "Class:";
            // 
            // lbClassName
            // 
            this.lbClassName.Location = new System.Drawing.Point(64, 64);
            this.lbClassName.Name = "lbClassName";
            this.lbClassName.Size = new System.Drawing.Size(472, 16);
            this.lbClassName.TabIndex = 19;
            this.lbClassName.Text = "lbClassName";
            // 
            // lbElementType
            // 
            this.lbElementType.Location = new System.Drawing.Point(64, 80);
            this.lbElementType.Name = "lbElementType";
            this.lbElementType.Size = new System.Drawing.Size(480, 16);
            this.lbElementType.TabIndex = 20;
            this.lbElementType.TabStop = true;
            this.lbElementType.Text = "lbElementType";
            this.lbElementType.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbElementType_LinkClicked);
            // 
            // lbTable
            // 
            this.lbTable.Location = new System.Drawing.Point(368, 64);
            this.lbTable.Name = "lbTable";
            this.lbTable.Size = new System.Drawing.Size(184, 12);
            this.lbTable.TabIndex = 21;
            this.lbTable.Text = "lbTable";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(328, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 12);
            this.label2.TabIndex = 22;
            this.label2.Text = "Table:";
            // 
            // CollectionClassBuilder
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(554, 375);
            this.Controls.Add(this.lbTable);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tab);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbHelp);
            this.Controls.Add(this.cmdShowElementTypeAttrib);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbElementType);
            this.Controls.Add(this.lbClassName);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "CollectionClassBuilder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Netsoft USA Collection Class Builder";
            this.TopMost = true;
            this.Closing += new System.ComponentModel.CancelEventHandler(this.CollectionClassBuilder_Closing);
            this.Load += new System.EventHandler(this.EntityCreator_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tab.ResumeLayout(false);
            this.tabElementAccessMethods.ResumeLayout(false);
            this.tabBuildParamsMethods.ResumeLayout(false);
            this.tabDBMethods.ResumeLayout(false);
            this.tabParentObjects.ResumeLayout(false);
            this.tabCachedInstances.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private string TableName
		{
			get
			{
				return lbTable.Text;
			}
			set
			{
				lbTable.Text = value;
			}
		}

		private void GetTablePrototype()
		{
			try
			{
				tbl = Util.GetTablePrototype(lbTable.Text);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, String.Format("Can't access to table {0}.\r\n{1}", 
					lbTable.Text, ex.Message));																					 
				//this.Close();
			}
		}

		public static void BuildCollectionClass(CodeClass cls)
		{
			CollectionClassBuilder ccb = new CollectionClassBuilder();
			ccb.cls = cls;

			ccb.lbClassName.Text = cls.Name;
			ccb.extendsEntityCollectionClass = Util.IsDerivedFromEntityCollectionClass(cls);
			if (ccb.extendsEntityCollectionClass)
			{
				ccb.lbClassName.ForeColor = System.Drawing.Color.Navy;
				ccb.lbClassName.Font = new Font(ccb.lbClassName.Font, FontStyle.Bold);
				//ccb.lbClassName.Text += ": EntityCollectionClass";
				ToolTip tooltip = new ToolTip();
				tooltip.ShowAlways = true;
				tooltip.SetToolTip(ccb.lbClassName, "This class extends EntityCollectionClass.  Methods will be generated based on the base class.");
			}

			ccb.Show();
		}

		public string ElemType
		{
			get
			{
				return Util.GetElementTypeForClass(cls);
			}
		}

		public CodeClass ElemClass
		{
			get
			{
				string elemType = this.ElemType;
				if (elemType == null)
					return null;
				else
					return Util.FindClassInProject(elemType);
			}
		}

		private void DisplayHelp()
		{
			lbHelp.Text = tab.SelectedTab.ToolTipText;
		}

		private void SetElemTypeLabel()
		{
			cmdShowElementTypeAttrib.Visible = false;
			string elemType = this.ElemType;
			lbElementType.BackColor = SystemColors.Control;
			if (elemType == null)
			{
				lbElementType.BackColor = Color.Red;
				lbElementType.Text = "(ElementType attribute not declared!)";
				cmdShowElementTypeAttrib.Visible = true;
			}
			else
			{
				elemCls = Util.FindClassInProject(elemType);

				if (elemCls == null)
				{
					lbElementType.BackColor = Color.Orange;
					lbElementType.Text = elemType + 
						"   (WARNING: This class is not defined in this project.  " +
						"It may be in a different project but this wizard can't access some of it's properties.)";
					cmdShowElementTypeAttrib.Visible = true;
				}
				else
					lbElementType.Text = elemType;
			}

			if (elemCls != null)
				this.TableName = Util.GetTableMappingForClass(elemCls);
			else
				this.TableName = "???";
		}

		private void EntityCreator_Load(object sender, System.EventArgs e)
		{
			Util.LoadFormPos(this, false);
			this.Text += "    Class Name='" + cls.Name + "'";
			DisplayHelp();
			SetElemTypeLabel();
			FillAllFields();
			EnableButtons();
			GetTablePrototype();
		}

		private void ArrangeListByTableColumnOrder(ListBox lst)
		{
			Util.ArrangeListByTableColumnOrder(tbl, elemCls, lst);
		}

		private void ArrangeListByTableColumnOrder(ListBox lst, bool memberNames)
		{
			Util.ArrangeListByTableColumnOrder(tbl, elemCls, lst, memberNames);
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void EnableButtons()
		{
			string elemType = this.ElemType;
			chkSaveMethod.Enabled = extendsEntityCollectionClass;
			chkSynchronizeMethod.Enabled = extendsEntityCollectionClass;

			cmShowItemIndexer.Visible = Util.FindIndexer(cls) != null;
			cmdShowInsertMethod.Visible = Util.FindFirstMethod(cls, "Insert", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, elemType) != null;
			cmdShowAddMethod.Visible = Util.FindFirstMethod(cls, "Add", elemType) != null;
			cmdShowRemoveMethod.Visible = Util.FindFirstMethod(cls, "Remove", elemType) != null;
			cmdShowContainsMethod.Visible = Util.FindFirstMethod(cls, "Contains", elemType) != null;
			cmdShowCopyToMethod.Visible = Util.FindFirstMethod(cls, "CopyTo", "System.Array", EnvDTE.vsCMTypeRef.vsCMTypeRefInt) != null;
			cmdShowToArrayMethod.Visible = Util.FindFirstMethod(cls, "ToArray") != null;
			cmdShowFromArrayMethod.Visible = Util.FindFirstMethod(cls, "FromArray", "System.Array") != null;
			cmdShowSortByMembersMethod.Visible = Util.FindFirstMember(cls, "SortByMembers") as CodeFunction != null;
			cmdShowAddRangeMethod.Visible = Util.FindFirstMethod(cls, "AddRange", "IList") as CodeFunction != null;

			cmdShowLoadMethod.Visible = Util.FindFirstMethod(cls, "Load", EnvDTE.vsCMTypeRef.vsCMTypeRefString, EnvDTE.vsCMTypeRef.vsCMTypeRefString) != null;
			cmdShowLoadFromStoredProcMethod.Visible = Util.FindFirstMethod(cls, "Load", EnvDTE.vsCMTypeRef.vsCMTypeRefString, EnvDTE.vsCMTypeRef.vsCMTypeRefString) != null;
			cmdShowSaveMethod.Visible = Util.FindFirstMethod(cls, "Save") != null;
			cmdShowSynchronizeMethod.Visible = Util.FindFirstMethod(cls, "Synchronize") != null;
			cmdShowExecuteSQLMethod.Visible = Util.FindFirstMethod(cls, "ExecuteSQL") as CodeElement != null;
			cmdShowReadMethod.Visible = Util.FindFirstMethod(cls, "Read", "IDataReader", EnvDTE.vsCMTypeRef.vsCMTypeRefInt) != null;

			butCreateMethods.Enabled = 
				chkItemIndexer.Checked ||
				chkInsertMethod.Checked ||
				chkAddMethod.Checked ||
				chkRemoveMethod.Checked ||
				chkContainsMethod.Checked ||
				chkCopyToMethod.Checked ||
				chkToArrayMethod.Checked ||
				chkFromArrayMethod.Checked ||
				chkSortByMembersMethod.Checked ||
				chkAddRangeMethod.Checked;

			butCreateDBMethods.Enabled = 
				chkLoadMethod.Checked ||
				chkLoadFromStoredProcMethod.Checked ||
				chkSaveMethod.Checked ||
				chkSynchronizeMethod.Checked ||
				chkExecuteSQLMethod.Checked ||
				chkReadMethod.Checked;

			butAddParam.Enabled = lsAllFields.SelectedIndex >= 0;
			butRemoveParam.Enabled = lsParams.SelectedIndex >= 0;

			butCreateParamsMethods.Enabled = 
				((chkCollectionIndexer.Checked
				|| chkIndexOfMethod.Checked
				|| chkFindByMethod.Checked
				|| chkSortByMethod.Checked
				|| chkLookupMethod.Checked)
				&& lsParams.Items.Count > 0) ||
				(chkExecuteStoredProcMethod.Checked 
					&& cbSprocName.Text != "");

			bool oldcbSprocNameVisible = cbSprocName.Visible;
			cbSprocName.Visible = chkExecuteStoredProcMethod.Checked;
			lbProcNameLabel.Visible = cbSprocName.Visible;
			if (cbSprocName.Visible)	// if newly made visible fill it
				if (cbSprocName.Visible != oldcbSprocNameVisible)
					FillSprocNames();

			cmdShowClassBuilderForParentObject.Enabled = lsParentObjects.SelectedIndex >= 0;
		}

		private void FillSprocNames()
		{
			cbSprocName.Items.Clear();
			string[] procs = Util.GetStoredProcsFromDB();
			cbSprocName.Items.AddRange(procs);
		}

		private void chkAllMethods_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkItemIndexer.Enabled)
				chkItemIndexer.Checked = chkAllMethods.Checked;
			if (chkInsertMethod.Enabled)
				chkInsertMethod.Checked = chkAllMethods.Checked;
			if (chkAddMethod.Enabled)
				chkAddMethod.Checked = chkAllMethods.Checked;
			if (chkRemoveMethod.Enabled)
				chkRemoveMethod.Checked = chkAllMethods.Checked;
			if (chkContainsMethod.Enabled)
				chkContainsMethod.Checked = chkAllMethods.Checked;
			if (chkSortByMembersMethod.Enabled)
				chkSortByMembersMethod.Checked = chkAllMethods.Checked;
			if (chkCopyToMethod.Enabled)
				chkCopyToMethod.Checked = chkAllMethods.Checked;
			if (chkToArrayMethod.Enabled)
				chkToArrayMethod.Checked = chkAllMethods.Checked;
			if (chkFromArrayMethod.Enabled)
				chkFromArrayMethod.Checked = chkAllMethods.Checked;
			if (chkAddRangeMethod.Enabled)
				chkAddRangeMethod.Checked = chkAllMethods.Checked;

			EnableButtons();
		}

        /*
		private bool EnsureSetParentOnElem()
		{
			if (Util.FindFirstMember(cls, "SetParentOnElem") as CodeFunction != null)
				return true;

			CodeClass elemCls = this.ElemClass;
			string parentColProp = "Parent" + cls.Name;

			if (Util.FindFirstMember(elemCls, parentColProp) == null)
				return false;		// no parentCollection prop, ignore

			CodeFunction func = cls.AddFunction("SetParentOnElem", EnvDTE.vsCMFunction.vsCMFunctionFunction,
				EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPrivate,
				null);

			func.AddParameter("elem", elemCls.Name, -1);
			func.AddParameter("setUnset", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);

			func.Comment = "Sets/Unsets this as the parent collection on the specified element";
							
			EditPoint ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(2);
			ep.StartOfLine();
			ep.Insert(String.Format("\t\t\tif (setUnset)\r\n"));
			ep.Insert(String.Format("\t\t\t\telem.{0} = this;\r\n", parentColProp));
			ep.Insert(String.Format("\t\t\telse\r\n"));
			ep.Insert(String.Format("\t\t\t\telem.{0} = null;", parentColProp));

			EnsureOnClearMethod();

			return true;
		}
        */
		private void EnsureOnClearMethod()
		{
			if (Util.FindFirstMember(cls, "OnClear") as CodeFunction == null)
			{
				// Override OnClear method
				/*
					protected override void OnClear()
					{
						foreach (ElemType elem in base.List)
							OnSetComplete(elem, false);
						base.OnClear ();
					}
				 */

				//CodeClass elemCls = this.ElemClass;

                CodeFunction2 func = (CodeFunction2)cls.AddFunction("OnClear", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //"override void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessProtected,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tforeach ({0} elem in base.List)\r\n", this.ElemType));
				ep.Insert(String.Format("\t\t\t\tSetParentOnElem(elem, false);\r\n"));
				ep.Insert(String.Format("\t\t\tbase.OnClear();"));
			}
		}

		private void EnsureOnSetCompleteMethod()
		{
			if (Util.FindFirstMember(cls, "OnSetComplete") as CodeFunction == null)
			{
				// override OnSetComplete Method
				/*
						protected override void OnSetComplete(int index, object oldValue, object newValue)
						{
							base.OnSetComplete (index, oldValue, newValue);
							SetParentOnElem(oldValue, false);
							SetParentOnElem(newValue, true);
						}
					*/

                CodeFunction2 func = (CodeFunction2)cls.AddFunction("OnSetComplete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //"override void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessProtected,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

				func.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("oldValue", EnvDTE.vsCMTypeRef.vsCMTypeRefObject, -1);
				func.AddParameter("newValue", EnvDTE.vsCMTypeRef.vsCMTypeRefObject, -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tSetParentOnElem(({0})oldValue, false);\r\n", this.ElemType));
				ep.Insert(String.Format("\t\t\tSetParentOnElem(({0})newValue, true);\r\n", this.ElemType));
				ep.Insert(String.Format("\t\t\tbase.OnSetComplete (index, oldValue, newValue);"));
			}
		}

        /*
		private void EnsureOnInsertCompleteMethod()
		{
			if (Util.FindFirstMember(cls, "OnInsertComplete") as CodeFunction == null)
			{
				// override OnInsertComplete Method
				/
						protected override void OnInsertComplete(int index, object value)
						{
							SetParentOnElem(value, true);
							base.OnInsertComplete (index, value);
						}
					/

                CodeFunction2 func = (CodeFunction2)cls.AddFunction("OnInsertComplete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //"override void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessProtected,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

				func.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("value", EnvDTE.vsCMTypeRef.vsCMTypeRefObject, -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tSetParentOnElem(({0})value, true);\r\n", this.ElemType));
				ep.Insert(String.Format("\t\t\tbase.OnInsertComplete (index, value);"));
			}
		}
        */

        /*
		private void EnsureOnRemoveComplete()
		{
			if (Util.FindFirstMember(cls, "OnRemoveComplete") as CodeFunction == null)
			{
				// override OnRemoveComplete Method
				/
					protected override void OnRemoveComplete(int index, object value)
					{
						base.OnRemoveComplete (index, value);
					}
				/

                CodeFunction2 func = (CodeFunction2)cls.AddFunction("OnRemoveComplete", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, //"override void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessProtected,
					null);

                func.OverrideKind = vsCMOverrideKind.vsCMOverrideKindVirtual;

				func.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("value", EnvDTE.vsCMTypeRef.vsCMTypeRefObject, -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tSetParentOnElem(({0})value, false);\r\n", this.ElemType));
				ep.Insert(String.Format("\t\t\tbase.OnRemoveComplete (index, value);"));
			}
		}
         */

		private void CreateMethods()
		{
			string elemType = this.ElemType;
			CodeClass elemCls = this.ElemClass;
			if (elemCls == null)
			{
				Connect.Instance.ShowDialog(this, "Can't find element type!");
				return;
			}

			if (chkItemIndexer.Checked)
			{
				//bool bSetParent = EnsureSetParentOnElem();

				// add this[] prop
				//CodeProperty prop = Util.FindIndexer(cls);
				CodeProperty prop = cls.AddProperty("this[int index]", "this[int index]",
					elemType,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				prop.Comment = "Gets/Sets the object at the given index";

				//prop.Setter.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				//prop.Getter.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
							
				EditPoint ep = prop.Getter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\t\treturn ({0})List[index];", elemType));

				ep = prop.Setter.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\t\tList[index] = value;\r\n"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
				
				//if (bSetParent)
				//	EnsureOnSetCompleteMethod();
			}

			if (chkInsertMethod.Checked)
			{
				//bool bSetParent = EnsureSetParentOnElem();

				// add Insert Method
				CodeFunction func = cls.AddFunction("Insert", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Inserts the object into the collection at the given index";

				func.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("elem", elemType, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				if (extendsEntityCollectionClass)
					ep.Insert(String.Format("\t\t\tInsertRecord(index, elem);"));
				else
					ep.Insert(String.Format("\t\t\tList.Insert(index, elem);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

				//if (bSetParent)
				//	EnsureOnInsertCompleteMethod();
			}

			if (chkAddMethod.Checked)
			{
				//bool bSetParent = EnsureSetParentOnElem();

				// add Add Method
				CodeFunction func = cls.AddFunction("Add", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Adds the object to the collection";

				func.AddParameter("elem", elemType, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				if (this.extendsEntityCollectionClass)
					ep.Insert(String.Format("\t\t\treturn AddRecord(elem);"));
				else
					ep.Insert(String.Format("\t\t\treturn List.Add(elem);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

				//if (bSetParent)
				//	EnsureOnInsertCompleteMethod();
			}

			if (chkContainsMethod.Checked)
			{
				// add Contains Method
				CodeFunction func = cls.AddFunction("Contains", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefBool,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Returns true if the collection contains the given object";

				func.AddParameter("elem", elemType, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\treturn List.Contains(elem);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkRemoveMethod.Checked)
			{
				//bool bSetParent = EnsureSetParentOnElem();

				// add Remove Method
				CodeFunction func = cls.AddFunction("Remove", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Removes the object from the collection";

				func.AddParameter("elem", elemType, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				if (extendsEntityCollectionClass)
					ep.Insert(String.Format("\t\t\tRemoveRecord(elem);"));
				else
					ep.Insert(String.Format("\t\t\tList.Remove(elem);"));
				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);

				//if (bSetParent)
				//	EnsureOnRemoveComplete();
			}

			if (chkSortByMembersMethod.Checked)
			{
				// add SortByMembers Method
				CodeFunction func = cls.AddFunction("SortByMembers", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Sorts the collection elements by the given members";

				func.AddParameter("ascending", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);
				func.AddParameter("ignoreCase", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);
				func.AddParameter("memberNames", "params string[]", -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tCollectionUtil.SortBy(this, ascending, ignoreCase, memberNames);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkCopyToMethod.Checked)
			{
				// add CopyTo Method
				CodeFunction func = cls.AddFunction("CopyTo", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Copys the elements of the collection to the specified target Array";

				func.AddParameter("array", "System.Array", -1);
				func.AddParameter("index", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tList.CopyTo(array, index);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkToArrayMethod.Checked)
			{
				// add ToArray Method
				CodeFunction func = cls.AddFunction("ToArray", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    "object[]",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Populates the elements into an object array and returns it";

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);
				ep.Insert(String.Format("\t\t\treturn CollectionUtil.CollectionToArray(this);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkFromArrayMethod.Checked)
			{
				// add FromArray Method
				CodeFunction func = cls.AddFunction("FromArray", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Fills the collection from the given array";

				func.AddParameter("array", "System.Array", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tCollectionUtil.ArrayToCollection(array, this);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkAddRangeMethod.Checked)
			{
				// add AddRange Method
				CodeFunction func = cls.AddFunction("AddRange", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Adds a given range of elements into the collection";

				func.AddParameter("range", "System.Collections.IList", -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				ep.Insert(String.Format("\t\t\tCollectionUtil.AppendToCollection(range, this);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			chkAllMethods.Checked = false;
			chkAllMethods_CheckedChanged(chkAllDBMethods, new EventArgs());

			EnableButtons();
		}

		private void CreateDBMethods()
		{
			string elemType = this.ElemType;
			CodeClass elemCls = this.ElemClass;
			string tableName = null;
			if (elemCls != null)
				tableName = Util.GetTableMappingForClass(elemCls);
			else
				tableName = elemType;

			if (chkLoadMethod.Checked && !extendsEntityCollectionClass)
			{
                Connect.Instance.ShowDialog(this, "LoadMethod not implemented for NetsoftUSA Library 2", "CollectionClassBuilder");
                /*
				// add Load(filter, sort) method
				CodeFunction func = cls.AddFunction("Load", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Loads records from the table to which the element type is mapped";

				func.AddParameter("filter", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);
				func.AddParameter("sort", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);

				ep.Insert(String.Format("\t\t\tSQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof({0}), filter, sort);\r\n", elemType));
				ep.Insert(String.Format("\t\t\tthis.Clear();\r\n"));
				ep.Insert(String.Format("\t\t\tSQLDataFiller.AppendToCollection(sd, this, true, false);\r\n"));
				ep.Insert(String.Format("\t\t\treturn this.Count;"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);*/
			}

			if (chkLoadFromStoredProcMethod.Checked || (chkLoadMethod.Checked && extendsEntityCollectionClass))
			{
				// add Load(filter, sort) method
				CodeFunction func = cls.AddFunction("Load", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Loads records from the table to which the element type is mapped";

				func.AddParameter("maxRecords", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
				func.AddParameter("filter", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);
				func.AddParameter("sort", EnvDTE.vsCMTypeRef.vsCMTypeRefString, -1);

				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);

				//if (this.extendsEntityCollectionClass)
				//{
					ep.Insert(String.Format("\t\t\tthis.Clear();\r\n"));
					ep.Insert(String.Format("\t\t\treturn this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );"));
				//}

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkSaveMethod.Checked)
			{
				//EnsureSqlDataProp();

				// add Save Method
				CodeFunction func = cls.AddFunction("Save", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, // "void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Calls save methods of all the collection elements";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();

                if (Util.IsEntityWithDataAccess(elemCls))
				    ep.Insert(String.Format("\t\t\tthis.SaveElements();"));
                else
                    ep.Insert(String.Format("\t\t\tthis.SaveElementsUsingService(true);"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkSynchronizeMethod.Checked)
			{
				//EnsureSqlDataProp();

				// add Synchronize Method
				CodeFunction func = cls.AddFunction("Synchronize", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                    EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, // "void",
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);
				func.Comment = "Calls Synchronize methods of all collection elements.";
								
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();

				ep.Insert(String.Format("\t\t\tthis.SynchronizeElements();"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}

			if (chkExecuteSQLMethod.Checked)
			{
                Connect.Instance.ShowDialog(this, "ExecuteSQLMethod not implemented for NetsoftUSA Library 2", "CollectionClassBuilder");
                /*
				// add ExecuteSQL() method
				CodeFunction func = cls.AddFunction("ExecuteSQL", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Executes an SQL statement and fills the collection with the mapped columns of the result";

				func.AddParameter("/ object param /", "", -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);

				ep.Insert(String.Format("\t\t\tSQLParser sql = new SQLParser(\"select * from [{0}] \" +\r\n", tableName));
				ep.Insert(String.Format("\t\t\t\"\");  //\"where param=@param\");\r\n"));
				ep.Insert(String.Format("\t\t\tSQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);\r\n"));
				ep.Insert(String.Format("\t\t\t//sd.SQLCommand.Parameters[\"@param\"].Value = param;\r\n"));
				ep.Insert(String.Format("\t\t\tthis.Clear();\r\n"));
				ep.Insert(String.Format("\t\t\tSQLDataFiller.AppendToCollection(sd, this, true, false);\r\n"));
				ep.Insert(String.Format("\t\t\treturn this.Count;"));

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
                */
			}

			if (chkReadMethod.Checked)
			{
				// add Read(sourceReader, maxRecords) method
				CodeFunction func = cls.AddFunction("Read", EnvDTE.vsCMFunction.vsCMFunctionFunction,
					EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
					-1,
					EnvDTE.vsCMAccess.vsCMAccessPublic,
					null);

				func.Comment = "Reads a max number of records from the given data reader and fills the collection. " +
					"If maxRecords is negative, all records will be read.";

				func.AddParameter("sourceReader", "IDataReader", -1);
				func.AddParameter("maxRecords", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, -1);
							
				EditPoint ep = func.StartPoint.CreateEditPoint();
				ep.LineDown(2);
				ep.StartOfLine();
				Util.DeleteEditLine(ep);

				if (this.extendsEntityCollectionClass)
				{
					ep.Insert(String.Format("\t\t\treturn base.Read(sourceReader, maxRecords, false);"));
				}
				else
				{
					ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", elemType));
					ep.Insert(String.Format("\t\t\treturn obj.SqlData.ReadCollection(sourceReader, maxRecords, this, typeof({0}), true, false);", elemType));
				}

				ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
			}
			
			chkAllDBMethods.Checked = false;
			chkLoadMethod.Checked = false;
			chkLoadFromStoredProcMethod.Checked = false;
			chkExecuteSQLMethod.Checked = false;
			chkReadMethod.Checked = false;
			chkSaveMethod.Checked = false;
			chkSynchronizeMethod.Checked = false;

			EnableButtons();
		}

		private void butCreateMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				CreateMethods();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkCopyToMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cmdShowInsertMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "Insert", EnvDTE.vsCMTypeRef.vsCMTypeRefInt, ElemType);
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowAddMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "Add", ElemType);
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowRemoveMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "Remove", ElemType);
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowContainsMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "Contains", ElemType);
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowCopyToMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "CopyTo", "System.Array", EnvDTE.vsCMTypeRef.vsCMTypeRefInt);
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmShowItemIndexer_Click(object sender, System.EventArgs e)
		{
			CodeProperty prop = Util.FindIndexer(cls);
			Util.MarkElement(cls, prop as CodeElement);
		}

		private void chkReadMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void butCreateDBMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				CreateDBMethods();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void chkAllDBMethods_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkLoadMethod.Enabled)
				chkLoadMethod.Checked = chkAllDBMethods.Checked;
			if (chkExecuteSQLMethod.Enabled)
				chkExecuteSQLMethod.Checked = chkAllDBMethods.Checked;
			if (chkReadMethod.Enabled)
				chkReadMethod.Checked = chkAllDBMethods.Checked;
			if (chkLoadFromStoredProcMethod.Enabled)
				chkLoadFromStoredProcMethod.Checked = chkAllDBMethods.Checked;
			if (chkSaveMethod.Enabled)
				chkSaveMethod.Checked = chkAllDBMethods.Checked;
			if (chkSynchronizeMethod.Enabled)
				chkSynchronizeMethod.Checked = chkAllDBMethods.Checked;

			EnableButtons();		
		}

		private void cmdShowLoadMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "Load", EnvDTE.vsCMTypeRef.vsCMTypeRefString, EnvDTE.vsCMTypeRef.vsCMTypeRefString) as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowExecuteSQLMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "ExecuteSQL") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowReadMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "Read", "IDataReader", EnvDTE.vsCMTypeRef.vsCMTypeRefInt) as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdCreateTestForLoad_Click(object sender, System.EventArgs e)
		{
			string elemType = this.ElemType;
            CodeFunction2 func = (CodeFunction2)cls.AddFunction("TestLoad", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,  // "static void",
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true; 

			func.Comment = "Use this function to test Load method";

			EditPoint ep = func.StartPoint.CreateEditPoint();
			
			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();

			ep.Insert(String.Format("\t\t\t{0} col = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\tif (col.Load(null, null) > 0) // use any filter, sort here\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert("\t\t\t\t// use loaded elements\r\n");
			ep.Insert(String.Format("\t\t\t\tforeach ({0} elem in col)\r\n", elemType));
			ep.Insert("\t\t\t\t{\r\n");
			ep.Insert(String.Format("\t\t\t\t\tSystem.Diagnostics.Debug.WriteLine(elem); // access any fields/properties\r\n"));
			ep.Insert("\t\t\t\t}\r\n");
			ep.Insert("\t\t\t}\r\n");

			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void cmdShowElementTypeAttrib_Click(object sender, System.EventArgs e)
		{
			Util.MarkAttribute(cls, "ElementType");
		}

		private void cmdCreateTestForExecuteSQL_Click(object sender, System.EventArgs e)
		{
			string elemType = this.ElemType;
			CodeFunction func = cls.AddFunction("TestExecuteSQL", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,   // "static void",		
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test ExecuteSQL method";

			EditPoint ep = func.StartPoint.CreateEditPoint();

			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();

			ep.Insert(String.Format("\t\t\t{0} col = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\tif (col.ExecuteSQL() > 0) // use necessary parameters for the function here\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert("\t\t\t\t// use loaded elements\r\n");
			ep.Insert(String.Format("\t\t\t\tforeach ({0} elem in col)\r\n", elemType));
			ep.Insert("\t\t\t\t{\r\n");
			ep.Insert(String.Format("\t\t\t\t\tSystem.Diagnostics.Debug.WriteLine(elem); // access any fields/properties\r\n"));
			ep.Insert("\t\t\t\t}\r\n");
			ep.Insert("\t\t\t}\r\n");

			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void cmdCreateTestForRead_Click(object sender, System.EventArgs e)
		{
			string elemType = this.ElemType;
			CodeFunction func = cls.AddFunction("TestRead", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, // "static void",
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test Read method";

			EditPoint ep = func.StartPoint.CreateEditPoint();

			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();

			ep.Insert(String.Format("\t\t\t{0} obj = new {0}();\r\n", elemType));
			ep.Insert(String.Format("\t\t\t{0} col = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\tIDataReader rdr = obj.SqlData.ExecuteReader(); // execute any reader\r\n"));
			ep.Insert(String.Format("\t\t\twhile (col.Read(rdr, 3) > 0) // use any number of max records\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert("\t\t\t\t// col contains the read elements\r\n");
			ep.Insert(String.Format("\t\t\t\tSystem.Diagnostics.Debug.WriteLine(col.Count);\r\n", elemType));
			ep.Insert("\t\t\t\t// access any collection elements and use it\r\n");
			ep.Insert(String.Format("\t\t\t\tforeach ({0} elem in col)\r\n", elemType));
			ep.Insert("\t\t\t\t{\r\n");
			ep.Insert(String.Format("\t\t\t\t\tSystem.Diagnostics.Debug.WriteLine(elem); // access any fields/properties\r\n"));
			ep.Insert("\t\t\t\t}\r\n");
			ep.Insert("\t\t\t\t// col.Clear(); // collection may be cleared for the next read\r\n");
			ep.Insert("\t\t\t}\r\n");

			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void cmdCreateElementAccessTester_Click(object sender, System.EventArgs e)
		{
			string elemType = this.ElemType;
			CodeFunction func = cls.AddFunction("TestCollection", EnvDTE.vsCMFunction.vsCMFunctionFunction,
                EnvDTE.vsCMTypeRef.vsCMTypeRefVoid, // "static void"
				-1,
				EnvDTE.vsCMAccess.vsCMAccessPublic,
				null);

            func.IsShared = true;

			func.Comment = "Use this function to test collection element access";

			EditPoint ep = func.StartPoint.CreateEditPoint();

			ep.LineUp(1);
			ep.EndOfLine();
			ep.Insert(String.Format("\r\n\t\t[System.Diagnostics.Conditional(\"DEBUG\")]"));

			ep = func.StartPoint.CreateEditPoint();
			ep.LineDown(3);
			ep.StartOfLine();

			ep.Insert(String.Format("\t\t\t{0} col = new {0}();\r\n", cls.Name));
			ep.Insert(String.Format("\t\t\t{0} elem = null;\r\n", elemType));
			ep.Insert(String.Format("\t\t\t// create and add a number of elements\r\n"));
			// add a number of elements code
			for (int i = 0; i < 4; i++)
			{
				ep.Insert(String.Format("\t\t\telem = new {0}();\r\n", elemType));
				ep.Insert(String.Format("\t\t\tcol.Add(elem);\r\n"));
			}
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(\"Elements added\");\r\n"));
			ep.Insert(String.Format("\t\t\t// display number of elements\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(col.Count);\r\n"));
			ep.Insert(String.Format("\t\t\t// remove last element\r\n"));
			ep.Insert(String.Format("\t\t\tcol.Remove(elem);\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(\"Last element removed\");\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(col.Count);\r\n"));
			ep.Insert(String.Format("\t\t\t// iterate on the elements\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(\"Elements in collection are:\");\r\n"));
			ep.Insert(String.Format("\t\t\tforeach (Event obj in col)\r\n"));
			ep.Insert("\t\t\t{\r\n");
			ep.Insert(String.Format("\t\t\t\tSystem.Diagnostics.Debug.WriteLine(obj); // access any fields/properties\r\n"));
			ep.Insert("\t\t\t}\r\n");
			ep.Insert(String.Format("\t\t\t// copy the collection into an untyped array\r\n"));
			ep.Insert(String.Format("\t\t\tobject[] arr = new object[col.Count];\r\n"));
			ep.Insert(String.Format("\t\t\tcol.CopyTo(arr, 0);\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(\"First element in array is:\");\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(arr[0]);\r\n"));
			ep.Insert(String.Format("\t\t\tcol.Clear();\r\n"));
			ep.Insert(String.Format("\t\t\tSystem.Diagnostics.Debug.WriteLine(col.Count);\r\n"));

			ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowCentered, 0);
		}

		private void FillParentObjects()
		{
			lsParentObjects.Items.Clear();
			for (int i = 1; i <= cls.Members.Count; i ++)
			{
				CodeElement elem = cls.Members.Item(i);
				CodeProperty prop = elem as CodeProperty;
				if (prop != null)
				{
					if (prop.Type.TypeKind == EnvDTE.vsCMTypeRef.vsCMTypeRefCodeType)
					{
						if (prop.Name.Length >= 6)
						if (prop.Name.Substring(0, 6).ToLower() == "parent")
						{
							lsParentObjects.Items.Add(prop.Name);
						}
					}
				}
			}
		}

		private void FillCachedMembers(CodeClass cls, ListBox lst)
		{
			for (int i = 1; i <= cls.Members.Count; i++)
			{
				CodeProperty prop = cls.Members.Item(i) as CodeProperty;
				if (prop != null)
				{
					if (Util.IsSharedMember(cls, prop as CodeElement))
						lst.Items.Add(prop.Name);
				}
			}

			if (cls.Bases != null)
			{
				for (int i = 1; i <= cls.Bases.Count; i++)
					FillCachedMembers(cls.Bases.Item(i) as CodeClass, lst);
			}
		}

		private void FillCachedMembers()
		{
			lsCachedMembers.Items.Clear();
			FillCachedMembers(cls, lsCachedMembers);
		}

		private void tab_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DisplayHelp();

			if (tab.SelectedTab == tabParentObjects)
			{
				FillParentObjects();
			}

			if (tab.SelectedTab == tabCachedInstances)
			{
				FillCachedMembers();
			}

			EnableButtons(); //tab.SelectedTab);
		}

		private void cmdShowElemClass_Click(object sender, System.EventArgs e)
		{
			
		}

		private void butAddParam_Click(object sender, System.EventArgs e)
		{
			if (lsAllFields.SelectedIndex < 0)
				return;
			lsParams.Items.Add(lsAllFields.Items[lsAllFields.SelectedIndex]);
			int sel = lsAllFields.SelectedIndex;
			lsAllFields.Items.RemoveAt(sel);
			if (sel < lsAllFields.Items.Count)
				lsAllFields.SelectedIndex = sel;
			EnableButtons();
		}

		private void butRemoveParam_Click(object sender, System.EventArgs e)
		{
			if (lsParams.SelectedIndex < 0)
				return;
			lsAllFields.Items.Add(lsParams.Items[lsParams.SelectedIndex]);
			int sel = lsParams.SelectedIndex;
			lsParams.Items.RemoveAt(sel);
			ArrangeListByTableColumnOrder(lsAllFields, true);
			if (sel < lsParams.Items.Count)
				lsParams.SelectedIndex = sel;
			EnableButtons();
		}

		private void lsAllFields_DoubleClick(object sender, System.EventArgs e)
		{
			butAddParam_Click(sender, e);
		}

		private void lsParams_DoubleClick(object sender, System.EventArgs e)
		{
			butRemoveParam_Click(sender, e);
		}

		private void butCancel3_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void AddParams(CodeClass elemClass, CodeFunction func)
		{
			// add parameters
			for (int i = 0; i < lsParams.Items.Count; i++)
			{
				string param = (string)lsParams.Items[i];
				CodeVariable var = Util.FindFirstMember(elemClass, param) as CodeVariable;
				func.AddParameter(param, var.Type, -1);
			}
		}

		private void butCreateParamsMethods_Click(object sender, System.EventArgs e)
		{
			try
			{
				CodeClass elemCls = this.ElemClass;
				if (elemCls == null)
				{
					Connect.Instance.ShowDialog(this, "Element class not found!");
					return;
				}

				string rootName = "";
				string memberNamesArrDecl = "";
				string paramNames = "";
				for (int i = 0; i < lsParams.Items.Count; i++)
				{
					if (i > 0)
					{
						rootName += "_";
						memberNamesArrDecl += ", ";
						paramNames += ", ";
					}
					string name = (string)lsParams.Items[i];
					rootName += Util.CapitalizeString(name, true, false);
					memberNamesArrDecl += "\"" + name + "\"";
					paramNames += name;
				}

				memberNamesArrDecl = "{ " + memberNamesArrDecl + " }";

				string indexerVarName = "indexBy_" + rootName;
				string indexerPropName = "IndexBy_" + rootName;

				// IndexOf method requires indexer prop, but don't force anyway because the class may be
				// a derived one and the base class may already have it.
				if (chkCollectionIndexer.Checked)	// || chkIndexOfMethod.Checked || chkFindByMethod.Checked)
				{
					// add private CollectionIndexer member

					CodeVariable var = Util.FindFirstMember(cls, indexerVarName) as CodeVariable;

					if (var == null)
					{
						var = cls.AddVariable(indexerVarName,
							"CollectionIndexer",
							0, 
							EnvDTE.vsCMAccess.vsCMAccessPrivate, 
							null);

						Util.DeclareNonSerialized(var);
					}

					CodeProperty prop = Util.FindFirstMember(cls, indexerPropName) as CodeProperty;

					if (prop == null)
					{
						// add public indexer property
						prop = cls.AddProperty(indexerPropName, indexerPropName,
							"CollectionIndexer",
							-1, 
							EnvDTE.vsCMAccess.vsCMAccessPublic, 
							null);

						prop.Comment = String.Format("Hashtable based index on {0} fields allows fast access to item indices", paramNames); 

						EditPoint ep = null;
				
						ep = prop.Getter.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);
						ep.Insert(String.Format("\t\t\t\tif (this.{0} == null)\r\n", indexerVarName));
						ep.Insert(String.Format(
							"\t\t\t\t\tthis.{0} = new CollectionIndexer(this, new string[] {1}, true);\r\n",
							indexerVarName, memberNamesArrDecl));
						ep.Insert(String.Format("\t\t\t\treturn this.{0};", indexerVarName));

						TextSelection selection = 
							(TextSelection) cls.ProjectItem.Document.Selection;
						Util.SelectElement(selection, prop.Setter as CodeElement);
						selection.Delete(1);
					}
				}

				// IndexOf method
				if (chkIndexOfMethod.Checked)
				{
					CodeFunction func = cls.AddFunction("IndexOf", EnvDTE.vsCMFunction.vsCMFunctionFunction,
						EnvDTE.vsCMTypeRef.vsCMTypeRefInt,
						-1, 
						EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);

					func.Comment = String.Format("Hashtable based search on {0} fields returns the collection index.  Uses the {1} indexer.", paramNames, indexerPropName); 

					AddParams(elemCls, func);

					EditPoint ep = null;
			
					ep = func.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					Util.DeleteEditLine(ep);
					ep.Insert(String.Format("\t\t\treturn this.{0}.IndexOf({1});", indexerPropName, paramNames));
				}

				// FindBy method
				if (chkFindByMethod.Checked)
				{
					CodeFunction func = cls.AddFunction("FindBy", EnvDTE.vsCMFunction.vsCMFunctionFunction,
						elemCls.Name,
						-1, 
						EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);

					func.Comment = String.Format("Hashtable based search on {0} fields returns the object.  Uses the {1} indexer.", paramNames, indexerPropName); 

					AddParams(elemCls, func);

					EditPoint ep = null;
			
					ep = func.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					Util.DeleteEditLine(ep);
					ep.Insert(String.Format("\t\t\treturn ({0})this.{1}.GetObject({2});", elemCls.Name, indexerPropName, paramNames));
				}

				// Collection Value Lookup method
				if (chkLookupMethod.Checked)
				{
					ValueLookupOptions options = new ValueLookupOptions();
					options.RootName = rootName;
					if (CollectionValueLookupMethodOptions.Display(elemCls, options))
					{
						CodeProperty prop = Util.FindFirstMember(elemCls, options.MemberToReturn) as CodeProperty;
						CodeFunction func = cls.AddFunction(options.MethodName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
							prop.Type,
							-1, 
							EnvDTE.vsCMAccess.vsCMAccessPublic,
							null);

						func.Comment = String.Format("Looks up by {0} and returns {2} value.  Uses the {1} indexer.", paramNames, indexerPropName, options.MemberToReturn); 

						AddParams(elemCls, func);

						EditPoint ep = null;
			
						ep = func.StartPoint.CreateEditPoint();
						ep.LineDown(2);
						ep.StartOfLine();
						Util.DeleteEditLine(ep);
						string lookupMethod = null;
						if (prop.Type.TypeKind == vsCMTypeRef.vsCMTypeRefInt)
							lookupMethod = "LookupIntMember";
						else if (prop.Type.TypeKind == vsCMTypeRef.vsCMTypeRefString)
							lookupMethod = "LookupStringMember";
						else 
							lookupMethod = "LookupMember";

						ep.Insert(String.Format("\t\t\treturn this.{0}.{3}(\"{1}\", {2});", indexerPropName, options.MemberToReturn, paramNames, lookupMethod));
					}
				}

				// SortBy method
				if (chkSortByMethod.Checked)
				{
					CodeFunction func = cls.AddFunction("SortBy_" + rootName, EnvDTE.vsCMFunction.vsCMFunctionFunction,
						EnvDTE.vsCMTypeRef.vsCMTypeRefVoid,
						-1, 
						EnvDTE.vsCMAccess.vsCMAccessPublic,
						null);

					func.Comment = String.Format("Sorts the collection by the {0} members.", paramNames); 

					func.AddParameter("ascending", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);
					func.AddParameter("ignoreCase", EnvDTE.vsCMTypeRef.vsCMTypeRefBool, -1);

					EditPoint ep = null;
			
					ep = func.StartPoint.CreateEditPoint();
					ep.LineDown(2);
					ep.StartOfLine();
					ep.Insert(String.Format("\t\t\tCollectionUtil.SortBy(this, ascending, ignoreCase, new string[] {0});", memberNamesArrDecl));
				}

				chkCollectionIndexer.Checked = false;
				chkIndexOfMethod.Checked = false;
				chkFindByMethod.Checked = false;
				chkLookupMethod.Checked = false;
				chkSortByMethod.Checked = false;

				FillAllFields();
				EnableButtons();
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
			}
		}

		private void FillAllFields()
		{
			CodeClass elemCls = this.ElemClass;
			if (elemCls == null)
				return;

			lsAllFields.Items.Clear();
			lsParams.Items.Clear();
			Util.FillFieldsAndParams(elemCls, lsAllFields, lsParams);
			ArrangeListByTableColumnOrder(lsAllFields, true);
		}

		private void chkCollectionIndexer_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void lsParams_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void lsAllFields_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void chkIndexOfMethod_Click(object sender, System.EventArgs e)
		{
			if (chkIndexOfMethod.Checked)
				chkCollectionIndexer.Checked = true;
			EnableButtons();
		}

		private void chkFindByMethod_Click(object sender, System.EventArgs e)
		{
			if (chkFindByMethod.Checked)
				chkCollectionIndexer.Checked = true;
			EnableButtons();
		}

		private void CollectionClassBuilder_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Util.SaveFormPos(this);
		}

		private void cmdShowToArrayMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "ToArray");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowFromArrayMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "FromArray", "System.Array");
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowSortByMembersMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMember(cls, "SortByMembers") as CodeFunction;
			Util.MarkElement(cls, func as CodeElement);
		}

		private void cmdShowAddRangeMethod_Click(object sender, System.EventArgs e)
		{
			CodeFunction func = Util.FindFirstMethod(cls, "AddRange", "IList") as CodeFunction;
			Util.MarkElement(cls, func as CodeElement);
		}

		private void lbElementType_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			string elemType = this.ElemType;
			if (elemType != null)
			{
				CodeClass elemClass = Util.FindClassInProject(elemType);
				if (elemClass != null)
				{
					elemClass.ProjectItem.Open(Constants.vsViewKindCode);
					EditPoint ep = elemClass.StartPoint.CreateEditPoint();
					ep.TryToShow(EnvDTE.vsPaneShowHow.vsPaneShowAsIs, 0);
					this.Close();
					EntityBuilder.BuildClass(elemClass);
				}
			}
		}

		private void cmdShowLoadFromStoredProcMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "Load", EnvDTE.vsCMTypeRef.vsCMTypeRefString, EnvDTE.vsCMTypeRef.vsCMTypeRefString) as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void chkExecuteStoredProcMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private bool EditSP(string spName)
		{
			try
			{
				return StoredProcDlg.EditStoredProc(spName);
			}
			catch(Exception ex)
			{
				Connect.Instance.ShowDialog(this, ex.Message);
				return false;
			}
		}

		private void lbProcNameLabel_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			EditSP(cbSprocName.Text);
		}

		private void cbSprocName_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (cbSprocName.Text != "")
			{
				string[] spParams = Util.GetStoredProcParameters(cbSprocName.Text);
				if (spParams != null)
				{
					// remove all parameters selected
					//butRemoveParamAll_Click(this, new EventArgs());

					// fill stored proc parameters to the parameters selected.
					string unmappedParams = null;
					for (int i = 0; i < spParams.Length; i++)
					{
						string paramName = spParams[i];
						int sel = lsAllFields.FindString(paramName);
						if (sel >= 0)
						{
							lsAllFields.SelectedIndex = sel;
							butAddParam_Click(this, new EventArgs());	// add the found param
						}
						else
						{
							if (unmappedParams != null)
								unmappedParams += ", ";
							unmappedParams += paramName;
						}
					}

					if (unmappedParams != null)
					{
						Connect.Instance.ShowDialog(this, "There are some parameter names that do not match any member names:\r\n\r\n  " + unmappedParams);
					}

				}
			}

			EnableButtons();
		}

		private void cbSprocName_TextChanged(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void butAddParamAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsAllFields.Items.Count; i++)
			{
				lsParams.Items.Add(lsAllFields.Items[i]);
			}
			lsAllFields.Items.Clear();
			EnableButtons();
		}

		private void butRemoveParamAll_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < lsParams.Items.Count; i++)
			{
				lsAllFields.Items.Add(lsParams.Items[i]);
			}
			ArrangeListByTableColumnOrder(lsAllFields, true);
			lsParams.Items.Clear();
			EnableButtons();
		}

		private void butAddParamsOnlyMapped_Click(object sender, System.EventArgs e)
		{
			int pos = lsParams.SelectedIndex + 1;
			for (int i = lsAllFields.Items.Count - 1; i >= 0; i--)
			{
				string member = (string)lsAllFields.Items[i];
				if (Util.IsMemberMapped(elemCls, member))
				{
					lsParams.Items.Insert(pos, member);
					lsAllFields.Items.RemoveAt(i);
				}

			}
			EnableButtons();
		}

		private void cmdShowSaveMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "Save") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void cmdShowSynchronizeMethod_Click(object sender, System.EventArgs e)
		{
			CodeElement elem = Util.FindFirstMethod(cls, "Synchronize") as CodeElement;
			Util.MarkElement(cls, elem);
		}

		private void chkSaveMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void chkSynchronizeMethod_Click(object sender, System.EventArgs e)
		{
			EnableButtons();
		}

		private void cmdShowClassBuilderForParentObject_Click(object sender, System.EventArgs e)
		{
			string selItem = (string)lsParentObjects.SelectedItem;
			if (selItem != null)
			{
				CodeProperty prop = Util.FindFirstMember(cls, selItem) as CodeProperty;
				if (prop == null)
					return;
				string clsName = Util.GetLastTerm(prop.Type.AsString);
				CodeClass ccls = Util.FindClassInProject(clsName);
				if (ccls != null)
				{
					this.Close();
					EntityBuilder.BuildClass(ccls);
				}
			}
		}

		private void butCreateCachedMember_Click(object sender, System.EventArgs e)
		{
			if (CreateCollectionCachedMemberDlg.CreateCachedMember(cls, elemCls))
			{
				FillCachedMembers();
			}
		}

		private void lsCachedMembers_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int sel = lsCachedMembers.SelectedIndex;
			if (sel < 0)
				return;

			string member = (string)lsCachedMembers.Items[sel];

			CodeElement elem = Util.FindFirstMember(cls, member);
			Util.MarkElement(cls, elem);
		}

		private void chkLookupMethod_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chkLookupMethod.Checked)
				chkCollectionIndexer.Checked = true;
			EnableButtons();		
		}

	}
}
