//SupportTypes.cs: Iterates CODEDOM tree and calls some analysys (defined by object 
//implementing IAnalyser interface
//
// Written by IZ for purposes of CS CODEDOM Parser, 2002
//(c) 2002 Ivan Zderadicka (ivan.zderadicka@seznam.cz)
using System;
using System.CodeDom;

namespace IvanZ.CSParser
{

	public interface IAnalyser
	{
		void AnalyzeCompUnit(CodeItemContext context, CodeCompileUnit unit);
		void AnalyzeNamespace(CodeItemContext context, CodeNamespace ns);
		void AnalyzeType(CodeItemContext context, CodeTypeDeclaration type, bool isInner);
		void AnalyzeMember(CodeItemContext context, CodeTypeMember member);
		void AnalyzeParameters(CodeItemContext context, CodeParameterDeclarationExpression parameter);

	}
	
	public class CodeItemContext
	{
		private CodeObject parent;
		public CodeObject Parent
		{
			get
			{
				return parent;
			}
		}
		private int position;
	     /// <summary>
	     /// e.g. possition in parent (first, second, etc.)
	     /// </summary>
		public int OrdinalPosition
		{
			get 
			
			    {
				return position;
				}
		}
		private bool isLast;
		public bool IsLast
		{
			get
			{
				return isLast;
				}
		}
		

		public CodeItemContext(CodeObject parent, int pos, bool last)
		{
			this.parent=parent;
			this.position=pos;
			this.isLast=last;
		}
	}
	/// <summary>
	/// Summary description for TreeAnalyser.
	/// </summary>
	public class TreeAnalyzer
	{
		IAnalyser analyser;
		CodeCompileUnit unit;
		
		public TreeAnalyzer(IAnalyser analyser, CodeCompileUnit cu)
		{
			this.analyser=analyser;
			this.unit=cu;
		}

		public void DoAnalysis()
		{
			analyser.AnalyzeCompUnit(new CodeItemContext(null,0,true), unit);
			for(int a=0; a<unit.Namespaces.Count; a++)
			{
				CodeNamespace ns= unit.Namespaces[a];
				analyser.AnalyzeNamespace(new CodeItemContext(unit, a, (a==unit.Namespaces.Count-1)), ns);
				for( int b=0; b<ns.Types.Count; b++)
				{
					CodeTypeDeclaration type= ns.Types[b];
					// Changed to support inner types
					DoTypeAnalysis(type, ns, b, (b==ns.Types.Count-1));
					
				}
			}
			
		}

		private void DoTypeAnalysis(CodeTypeDeclaration type, CodeObject parent , int count, bool last)
		{

			analyser.AnalyzeType(new CodeItemContext(parent,count,last), type, (parent is CodeTypeDeclaration));
			if (type is CodeTypeDelegate)
			{
				CodeTypeDelegate dlg= (CodeTypeDelegate) type;
				for(int i=0; i< dlg.Parameters.Count; i++)
					analyser.AnalyzeParameters(new CodeItemContext(dlg,i, 
						(i==dlg.Parameters.Count-1)), dlg.Parameters[i]);
			}
			for (int c=0; c<type.Members.Count; c++)
			{
				CodeTypeMember member= type.Members[c];
				if (member is CodeTypeDeclaration)
					DoTypeAnalysis((CodeTypeDeclaration) member, type, c, (c==type.Members.Count-1));
				else
				{
					analyser.AnalyzeMember(new CodeItemContext(type, c,(c==type.Members.Count-1)),  member);
					CodeParameterDeclarationExpressionCollection pars=null;
					if (member is CodeMemberMethod)
						pars=((CodeMemberMethod)member).Parameters;
					else if (member is CodeMemberProperty)
						pars=((CodeMemberProperty)member).Parameters;
					if (pars!=null)
						for (int d=0; d<pars.Count; d++)
							analyser.AnalyzeParameters(new CodeItemContext(member,d, (d==pars.Count-1)), pars[d]);
				}
			}
		}
	}
}
